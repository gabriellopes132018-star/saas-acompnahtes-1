<?php
/*
Template Name: Register - Independent Girl
*/

global $taxonomy_profile_url, $taxonomy_profile_name;
$current_user = wp_get_current_user();
$registration_plan_intent = escortwp_get_registration_plan_intent(
	isset($_GET['plan_intent']) ? wp_unslash($_GET['plan_intent']) : (isset($_POST['registration_plan_intent']) ? wp_unslash($_POST['registration_plan_intent']) : '')
);
$is_direct_plan_registration = $registration_plan_intent !== '';

if (is_user_logged_in() && !current_user_can('level_10')) {
	escortwp_safe_template_redirect(escortwp_get_current_user_account_url(), home_url('/'));
}

$err = '';
$ok = '';
if (isset($_POST['action']) && $_POST['action'] == 'register') {
	include get_template_directory() . '/register-independent-personal-info-process.php';
}

get_header();
?>

<div class="contentwrapper escortwp-auth-shell escortwp-auth-shell--editor">
	<div class="body escortwp-auth-main escortwp-auth-main--editor">
		<div class="bodybox registerform escortwp-workspace-box">
			<div class="escortwp-auth-header escortwp-auth-header--left">
				<div class="escortwp-auth-kicker"><?php _e('Conta de acompanhante', 'escortwp'); ?></div>
				<h3><?php printf(esc_html__('Crie sua conta de %s', 'escortwp'), ucwords($taxonomy_profile_name)); ?></h3>
				<?php if ($registration_plan_intent === 'premium') { ?>
					<p class="escortwp-register-intro"><?php _e('Conclua o cadastro da acompanhante para seguir direto ao checkout do plano mensal de 30 dias.', 'escortwp'); ?></p>
				<?php } elseif ($registration_plan_intent === 'featured_boost') { ?>
					<p class="escortwp-register-intro"><?php _e('Conclua o cadastro da acompanhante para seguir direto ao checkout do destaque semanal de 7 dias.', 'escortwp'); ?></p>
				<?php } else { ?>
					<p class="escortwp-register-intro"><?php _e('Abra seu acesso para publicar, organizar o anúncio e contratar planos com clareza dentro do painel.', 'escortwp'); ?></p>
				<?php } ?>
			</div>

			<div class="escortwp-workspace-steps">
				<div class="escortwp-workspace-step">
					<strong><?php _e('1. Conta', 'escortwp'); ?></strong>
					<span><?php _e('Cadastre acesso, nome público e e-mail válido.', 'escortwp'); ?></span>
				</div>
				<div class="escortwp-workspace-step">
					<strong><?php _e('2. Anúncio', 'escortwp'); ?></strong>
					<span><?php _e('Defina contato, localização, descrição e apresentação.', 'escortwp'); ?></span>
				</div>
				<div class="escortwp-workspace-step">
					<?php if ($is_direct_plan_registration) { ?>
						<strong><?php _e('3. Checkout', 'escortwp'); ?></strong>
						<span><?php _e('Ao concluir o cadastro, você segue direto para a etapa do pagamento no painel.', 'escortwp'); ?></span>
					<?php } else { ?>
						<strong><?php _e('3. Planos', 'escortwp'); ?></strong>
						<span><?php _e('Depois do cadastro, o painel libera o mensal e o destaque semanal.', 'escortwp'); ?></span>
					<?php } ?>
				</div>
			</div>

			<nav class="escortwp-workspace-nav escortwp-workspace-nav--public" aria-label="<?php esc_attr_e('Seções do cadastro', 'escortwp'); ?>">
				<a href="#aba-conta"><?php _e('Conta', 'escortwp'); ?></a>
				<a href="#aba-contato"><?php _e('Contato', 'escortwp'); ?></a>
				<a href="#aba-localizacao"><?php _e('Localização', 'escortwp'); ?></a>
				<a href="#aba-perfil"><?php _e('Perfil', 'escortwp'); ?></a>
				<a href="#aba-valores"><?php _e('Valores', 'escortwp'); ?></a>
				<a href="#aba-servicos"><?php _e('Serviços', 'escortwp'); ?></a>
			</nav>

			<?php
			if (current_user_can('level_10')) {
				$admin_registers_independent_escort = 'yes';
			}
			include get_template_directory() . '/register-independent-personal-information-form.php';
			?>
			<div class="clear"></div>
		</div>
		<div class="clear"></div>
	</div>
</div>

<div class="clear"></div>

<?php get_footer(); ?>
