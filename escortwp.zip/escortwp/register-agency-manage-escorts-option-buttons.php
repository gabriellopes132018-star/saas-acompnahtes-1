<?php
if(!defined('error_reporting')) { define('error_reporting', '0'); }
ini_set( 'display_errors', error_reporting );
if(error_reporting == '1') { error_reporting( E_ALL ); }
if(isdolcetheme !== 1) { die(); }

global $taxonomy_profile_name;
?>
<script type="text/javascript">
jQuery(document).ready(function($) {
	var maxPhotos = <?php echo (int) get_option('maximgupload'); ?>;
	var $photoDropzone = $('.profile-page-no-photos');
	var $photoGrid = $('.escortwp-dashboard-media-panel .thumbs').first();
	if (!$photoGrid.length) {
		$photoGrid = $('.girlsingle .profile-overview-media .thumbs').first();
	}

	function escortwpGetManagedGrid() {
		if (!$photoGrid.length) {
			$photoGrid = $('.escortwp-dashboard-media-panel .thumbs').first();
			if (!$photoGrid.length) {
				$photoGrid = $('.girlsingle .profile-overview-media .thumbs').first();
			}
		}
		return $photoGrid;
	}

	function escortwpEnsureManagedGridExists() {
		var $grid = escortwpGetManagedGrid();
		if ($grid.length) {
			return $grid;
		}

		var $emptyState = $('.girlsingle .profile-overview-media .profile-media-empty').first();
		if ($emptyState.length) {
			$grid = $('<div class="thumbs thumbs-count-1 escortwp-managed-gallery-grid" itemscope itemtype="http://schema.org/ImageGallery"><div class="escortwp-gallery-empty">Nenhuma foto enviada ainda. As próximas imagens aparecerão aqui automaticamente.</div></div>');
			$emptyState.after($grid);
			$photoGrid = $grid;
			return $photoGrid;
		}

		var $mediaSection = $('.escortwp-dashboard-media-panel').first();
		if ($mediaSection.length) {
			$grid = $('<div class="thumbs thumbs-count-1 escortwp-managed-gallery-grid"><div class="escortwp-gallery-empty">Nenhuma foto enviada ainda. As próximas imagens aparecerão aqui automaticamente.</div></div>');
			$mediaSection.append($grid);
			$photoGrid = $grid;
		}

		return $photoGrid;
	}

	function escortwpEscapeHtml(value) {
		return $('<div />').text(value || '').html();
	}

	function escortwpParseJsonLoose(payload) {
		if (!payload) {
			return null;
		}

		try {
			return JSON.parse(String(payload).replace(/^\uFEFF+/, '').trim());
		} catch (e) {
			return null;
		}
	}

	function escortwpNormalizeMediaTexts() {
		$('#aba-fotos .escortwp-auth-kicker').first().text('Fotos do anúncio');
		$('#aba-fotos .escortwp-dashboard-media-panel__copy h4').first().text('Organizar fotos');
		$('#aba-fotos .escortwp-dashboard-media-panel__copy p').first().html('Envie <b>fotos verticais (mínimo de 800x1200px)</b> com boa iluminação.');
		$('.girlsingle #gerenciar-galeria .profile-media-tools-header h4').first().text('Gerenciar galeria');
		$('.girlsingle #gerenciar-galeria .profile-media-tools-header p').first().text('Envie novas fotos ou vídeos sem interromper a apresentação pública do perfil.');
		$('.girlsingle .profile-media-empty p').text('Este perfil ainda não tem imagens públicas.');
	}

	function escortwpApplyMediaTextOverrides() {
		$('#aba-fotos .escortwp-auth-kicker').first().text('Fotos do anúncio');
		$('#aba-fotos .escortwp-dashboard-media-panel__copy h4').first().text('Organizar fotos');
		$('#aba-fotos .escortwp-dashboard-media-panel__copy p').first().html('Envie <b>fotos verticais (mínimo de 800x1200px)</b> com boa iluminação.');
		$('.girlsingle #gerenciar-galeria .profile-media-tools-header h4').first().text('Gerenciar galeria');
		$('.girlsingle #gerenciar-galeria .profile-media-tools-header p').first().text('Envie novas fotos ou vídeos sem interromper a apresentação pública do perfil.');
		$('.girlsingle .profile-media-empty p').text('Este perfil ainda não tem imagens públicas.');
		$('.profile-page-no-photos .for-browsers').attr('data-mobile-text', 'Toque aqui para enviar fotos');
		$('.profile-page-no-photos .for-browsers p').text('Arraste as fotos aqui ou clique para selecionar');
		$('.profile-page-no-videos .for-browsers').attr('data-mobile-text', 'Toque aqui para enviar vídeos');
		$('.profile-page-no-videos .for-browsers p').text('Arraste os vídeos aqui ou clique para selecionar');
		$('.profile-page-no-photos .escortwp-media-dropzone-button').text('Selecionar fotos');
		$('.profile-page-no-videos .escortwp-media-dropzone-button').text('Selecionar vídeos');
		$('.profile-page-no-photos .escortwp-media-dropzone-helper').text('Formatos aceitos: JPG, PNG, GIF e WebP. Recomendado: 1200x1600px, enquadramento vertical e boa iluminação.');
		$('.profile-page-no-videos .escortwp-media-dropzone-helper').text('Formatos aceitos: MP4, MOV e outros formatos liberados pelo site. Grave com boa luz e rosto visível.');
		$('.escortwp-gallery-empty').text('Nenhuma foto enviada ainda. As próximas imagens aparecerão aqui automaticamente.');
	}

	function escortwpApplyReadableMediaTexts() {
		$('.escortwp-auth-main--editor .escortwp-auth-header h3').first().text('Painel do anúncio');
		$('.escortwp-auth-main--editor .escortwp-register-intro').first().text('Ajuste os dados essenciais do anúncio com uma navegação mais clara e profissional.');
		$('#aba-fotos .escortwp-auth-kicker').first().text('Fotos do anúncio');
		$('#aba-fotos .escortwp-dashboard-media-panel__copy h4').first().text('Organizar fotos');
		$('#aba-fotos .escortwp-dashboard-media-panel__copy p').first().html('Envie <b>fotos verticais (mínimo de 800x1200px)</b> com boa iluminação.');
		$('.girlsingle #gerenciar-galeria .profile-media-tools-header h4').first().text('Gerenciar galeria');
		$('.girlsingle #gerenciar-galeria .profile-media-tools-header p').first().text('Envie novas fotos ou vídeos sem interromper a apresentação pública do perfil.');
		$('.girlsingle .profile-media-empty p').text('Este perfil ainda não tem imagens públicas.');
		$('.profile-page-no-photos .for-browsers').attr('data-mobile-text', 'Toque aqui para enviar fotos');
		$('.profile-page-no-photos .for-browsers p').text('Arraste as fotos aqui ou clique para selecionar');
		$('.profile-page-no-videos .for-browsers').attr('data-mobile-text', 'Toque aqui para enviar vídeos');
		$('.profile-page-no-videos .for-browsers p').text('Arraste os vídeos aqui ou clique para selecionar');
		$('.profile-page-no-photos .escortwp-media-dropzone-button').text('Selecionar fotos');
		$('.profile-page-no-videos .escortwp-media-dropzone-button').text('Selecionar vídeos');
		$('.profile-page-no-photos .escortwp-media-dropzone-helper').text('Formatos aceitos: JPG, PNG, GIF e WebP. Recomendado: 1200x1600px, enquadramento vertical e boa iluminação.');
		$('.profile-page-no-videos .escortwp-media-dropzone-helper').text('Formatos aceitos: MP4, MOV e outros formatos liberados pelo site. Grave com boa luz e rosto visível.');
		$('.escortwp-gallery-empty').text('Nenhuma foto enviada ainda. As próximas imagens aparecerão aqui automaticamente.');
	}

	function escortwpEnsureManagedGalleryClasses() {
		var $grid = escortwpEnsureManagedGridExists();
		$('.profile-media-tools').addClass('escortwp-gallery-uploader-grid');
		$('.profile-page-no-photos .for-browsers').attr('data-mobile-text', "<?php echo esc_js(__('Toque aqui para enviar fotos', 'escortwp')); ?>");
		$('.profile-page-no-photos .for-browsers p').html("<?php echo esc_js(__('Arraste as fotos aqui ou clique para selecionar', 'escortwp')); ?>");
		if (!$('.profile-page-no-photos .escortwp-media-dropzone-button').length) {
			$('.profile-page-no-photos .for-browsers').append('<span class="escortwp-media-dropzone-button"><?php echo esc_js(__('Selecionar fotos', 'escortwp')); ?></span>');
		}
		if (!$('.profile-page-no-photos .escortwp-media-dropzone-helper').length) {
			$('.profile-page-no-photos').append('<p class="escortwp-media-dropzone-helper"><?php echo esc_js(__('Formatos aceitos: JPG, PNG, GIF e WebP. Recomendado: 1200x1600px, enquadramento vertical e boa iluminação.', 'escortwp')); ?></p>');
		}
		$('.profile-page-no-videos .for-browsers').attr('data-mobile-text', "<?php echo esc_js(__('Toque aqui para enviar vídeos', 'escortwp')); ?>");
		$('.profile-page-no-videos .for-browsers p').html("<?php echo esc_js(__('Arraste os vídeos aqui ou clique para selecionar', 'escortwp')); ?>");
		if (!$('.profile-page-no-videos .escortwp-media-dropzone-button').length) {
			$('.profile-page-no-videos .for-browsers').append('<span class="escortwp-media-dropzone-button"><?php echo esc_js(__('Selecionar vídeos', 'escortwp')); ?></span>');
		}
		if (!$('.profile-page-no-videos .escortwp-media-dropzone-helper').length) {
			$('.profile-page-no-videos').append('<p class="escortwp-media-dropzone-helper"><?php echo esc_js(__('Formatos aceitos: MP4, MOV e outros formatos liberados pelo site. Grave com boa luz e rosto visível.', 'escortwp')); ?></p>');
		}
		$('.profile-page-no-photos .for-browsers').attr('data-mobile-text', "<?php echo esc_js(__('Toque aqui para enviar fotos', 'escortwp')); ?>");
		$('.profile-page-no-photos .for-browsers p').html("<?php echo esc_js(__('Arraste as fotos aqui ou clique para selecionar', 'escortwp')); ?>");
		$('.profile-page-no-videos .for-browsers').attr('data-mobile-text', "<?php echo esc_js(__('Toque aqui para enviar vídeos', 'escortwp')); ?>");
		$('.profile-page-no-videos .for-browsers p').html("<?php echo esc_js(__('Arraste os vídeos aqui ou clique para selecionar', 'escortwp')); ?>");
		$('.profile-page-no-videos .for-browsers').attr('data-mobile-text', 'Toque aqui para enviar vídeos');
		$('.profile-page-no-videos .for-browsers p').text('Arraste os vídeos aqui ou clique para selecionar');
		if (!$grid.length) {
			return;
		}

		$grid.addClass('escortwp-managed-gallery-grid').attr('data-max-photos', maxPhotos);
		$grid.find('.profile-img-thumb-wrapper').addClass('escortwp-managed-gallery-card');
		$grid.find('.profile-img-thumb').each(function() {
			var $thumb = $(this);
			var isMain = !$thumb.find('.button-main-image:visible').length;
			if (!$thumb.find('.escortwp-managed-gallery-badge').length) {
				$thumb.prepend('<span class="escortwp-managed-gallery-badge"' + (isMain ? '' : ' style="display:none"') + '>Capa atual</span>');
			}
			$thumb.closest('.profile-img-thumb-wrapper').toggleClass('is-main', isMain);
		});
	}

	function escortwpGetPhotoCount() {
		var $grid = escortwpGetManagedGrid();
		return $grid.length ? $grid.find('.profile-img-thumb').length : 0;
	}

	function escortwpGetRemainingPhotos() {
		return Math.max(0, maxPhotos - escortwpGetPhotoCount());
	}

	function escortwpSyncPhotoCapacity() {
		var remaining = escortwpGetRemainingPhotos();
		$('.profile-page-no-photos p.max-photos b').text(remaining);
		try {
			$('#profile_photos_upload').uploadifive('settings', 'queueSizeLimit', remaining);
			$('#profile_photos_upload').uploadifive('settings', 'uploadLimit', remaining);
			$('#profile_photos_upload').uploadifive('settings', 'simUploadLimit', remaining > 10 ? 10 : remaining);
		} catch (e) {}

		$photoDropzone.toggleClass('escortwp-dropzone-disabled', remaining < 1);
	}

	function escortwpSetMainImageUi(attachmentId) {
		var $grid = escortwpGetManagedGrid();
		if (!$grid.length) {
			return;
		}

		$grid.find('.profile-img-thumb-wrapper').removeClass('is-main');
		$grid.find('.escortwp-managed-gallery-badge').hide();
		$grid.find('.button-main-image').show();

		var $thumb = $grid.find('.profile-img-thumb#' + attachmentId);
		if (!$thumb.length) {
			return;
		}

		$thumb.closest('.profile-img-thumb-wrapper').addClass('is-main');
		$thumb.find('.escortwp-managed-gallery-badge').show();
		$thumb.find('.button-main-image').hide();
	}

	function escortwpShowGalleryFeedback(message, kind) {
		var $target = $('.escortwp-gallery-feedback');
		if (!$target.length) {
			$target = $('<div class="escortwp-gallery-feedback" />').insertAfter('.profile-media-tools:visible').first();
		}

		$target
			.removeClass('is-error is-success')
			.addClass(kind === 'error' ? 'is-error' : 'is-success')
			.text(message)
			.stop(true, true)
			.fadeIn(150)
			.delay(2200)
			.fadeOut(250);
	}

	function escortwpSetActionLoading($thumb, isLoading) {
		var $controls = $thumb.find('.edit-buttons').first();
		if (!$controls.length) {
			return;
		}

		if (isLoading) {
			$thumb.css('opacity', '0.72');
			$controls.addClass('is-loading');
			$controls.find('.btn-action').prop('disabled', true).attr('aria-disabled', 'true');
			if (!$controls.find('.escortwp-action-loader').length) {
				$controls.append('<span class="escortwp-action-loader"><span class="preloader r"></span></span>');
				loader('#' + $thumb.attr('id') + ' .escortwp-action-loader .preloader');
			}
			return;
		}

		$thumb.css('opacity', '1');
		$controls.removeClass('is-loading');
		$controls.find('.btn-action').prop('disabled', false).removeAttr('aria-disabled');
		$controls.find('.escortwp-action-loader').remove();
	}

	function escortwpShouldIgnoreSyntheticClick($button, e) {
		var now = Date.now();
		var lastTouch = parseInt($button.data('escortwpLastTouch') || 0, 10);
		if (e.type === 'touchend') {
			$button.data('escortwpLastTouch', now);
			return false;
		}
		return !!(lastTouch && (now - lastTouch) < 700);
	}

	function escortwpBuildPhotoCard(data) {
		var id = parseInt(data.attachment_id, 10) || 0;
		var thumbUrl = escortwpEscapeHtml(data.thumb_url);
		var fullUrl = escortwpEscapeHtml(data.full_url || data.thumb_url);
		var isMain = !!data.is_main;
		return '' +
			'<div class="profile-img-thumb-wrapper escortwp-managed-gallery-card' + (isMain ? ' is-main' : '') + '" data-attachment-id="' + id + '">' +
				'<div class="profile-img-thumb girl-single-thumb-manage" id="' + id + '">' +
					'<span class="escortwp-managed-gallery-badge"' + (isMain ? '' : ' style="display:none"') + '>Capa atual</span>' +
					'<span class="edit-buttons">' +
						'<button type="button" class="btn-action button-delete"><i class="icon icon-cancel"></i><span>Excluir</span></button>' +
						'<button type="button" class="btn-action button-main-image"' + (isMain ? ' style="display:none"' : '') + '><i class="icon icon-ok"></i><span>Capa</span></button>' +
					'</span>' +
					'<a href="' + fullUrl + '" data-fancybox="escortwp-managed-gallery">' +
						'<img src="' + thumbUrl + '" class="mobile-ready-img rad3" alt="" />' +
					'</a>' +
				'</div>' +
			'</div>';
	}

	function escortwpAppendUploadedPhoto(data) {
		var $grid = escortwpEnsureManagedGridExists();
		if (!$grid.length) {
			return;
		}

		$('.girlsingle .profile-overview-media .profile-media-empty').remove();
		$grid.find('.escortwp-gallery-empty').remove();
		$grid.prepend(escortwpBuildPhotoCard(data));
		escortwpApplyMediaTextOverrides();
		escortwpEnsureManagedGalleryClasses();
		if (data.is_main) {
			escortwpSetMainImageUi(data.attachment_id);
		}
	}

	// Photo upload START
		// if images are dragged in the upload images div
		var obj = $photoDropzone;
		// if images are dragged outside the upload images div
		$(document).on('dragenter', function (e) {
			e.stopPropagation();
			e.preventDefault();
			obj.css('border-color', '#41c7f9'); //blue
		});
		$(document).on('dragover', function (e) {
			e.stopPropagation();
			e.preventDefault();
			obj.css('border-color', '#41c7f9'); //blue
		});
		$(document).on('drop', function (e) {
			e.stopPropagation();
			e.preventDefault();
			obj.css('border-color', '#ff0000');
		});

		obj.on('dragenter', function (e) {
			e.stopPropagation();
			e.preventDefault();
			$(this).css('border-color', '#3FC380'); // blue
		});
		obj.on('dragover', function (e)  {
			e.stopPropagation();
			e.preventDefault();
			$(this).css('border-color', '#3FC380'); // blue
		});
		obj.on('drop', function (e)  {
			e.preventDefault();
			$(this).css('border-color', '#3FC380'); // green
		});

		$('.profile-page-no-photos-click').on('click', function(event) {
			if(escortwpGetRemainingPhotos() > 0) {
				$('.profile_photos_button_container input[type="file"]').last().trigger('click');
			} else {
				escortwpShowGalleryFeedback("<?php echo esc_js(__('Você já atingiu o limite de fotos deste anúncio.', 'escortwp')); ?>", 'error');
			}
		});

	    $('#profile_photos_upload').uploadifive({
			'auto'           : true,
			'debug'          : false,
			'buttonClass'    : 'pinkbutton rad25',
			'buttonText'     : "<?php _e('Enviar fotos','escortwp'); ?>",
			'fileSizeLimit'  : '<?=get_option("maximguploadsize")?>MB',
	        'fileType'       : 'image/*',
	        'formData'       : { 'folder' : '<?php echo get_post_meta(get_the_ID(), "secret", true); ?>', 'escortwp_json' : 1 },
			'multi'          : true,
			'queueID'        : 'profile-page-no-photos',
			'queueSizeLimit' : escortwpGetRemainingPhotos(),
			'removeCompleted': true,
			'simUploadLimit' : escortwpGetRemainingPhotos() > 10 ? 10 : escortwpGetRemainingPhotos(),
			'uploadLimit'    : escortwpGetRemainingPhotos(),
			'uploadScript'   : '<?php bloginfo('template_url'); ?>/register-independent-upload-photos-process.php',
			'onUploadComplete': function(file, data) {
				var response = escortwpParseJsonLoose(data);
				if (response && response.success) {
					escortwpAppendUploadedPhoto(response);
					escortwpShowGalleryFeedback(response.message || "<?php echo esc_js(__('Foto enviada com sucesso.', 'escortwp')); ?>", 'success');
					escortwpSyncPhotoCapacity();
				} else {
					var errorMessage = response && response.message ? response.message : "<?php echo esc_js(__('Não foi possível enviar esta foto.', 'escortwp')); ?>";
					escortwpShowGalleryFeedback(errorMessage, 'error');
				}
			},
			'onQueueComplete': function(data) {
				escortwpSyncPhotoCapacity();
				if (data && data.successful > 0) {
					escortwpShowGalleryFeedback(data.successful + ' <?php echo esc_js(__('foto(s) enviada(s).', 'escortwp')); ?>', 'success');
				}
			}
		});
	// Photo upload END


	// Video upload START
		var video = $(".profile-page-no-videos");
		//if videos are dragged outside the upload videos div
		$(document).on('dragenter', function (e) {
			e.stopPropagation();
			e.preventDefault();
			video.css('border-color', '#41c7f9'); //blue
		});
		$(document).on('dragover', function (e) {
			e.stopPropagation();
			e.preventDefault();
			video.css('border-color', '#41c7f9'); //blue
		});
		$(document).on('drop', function (e) {
			e.stopPropagation();
			e.preventDefault();
			video.css('border-color', '#ff0000');
		});

		video.on('dragenter', function (e) {
			e.stopPropagation();
			e.preventDefault();
			$(this).css('border-color', '#3FC380'); // blue
		});
		video.on('dragover', function (e)  {
			e.stopPropagation();
			e.preventDefault();
			$(this).css('border-color', '#3FC380'); // blue
		});
		video.on('drop', function (e)  {
			e.preventDefault();
			$(this).css('border-color', '#3FC380'); // green
		});

		$('.profile-page-no-videos-click').on('click', function(event) {
			if(<?php echo $videos_left; ?> > 0) {
				$('.profile_videos_button_container input[type="file"]').last().trigger('click');
			} else {
				$('.profile-page-no-videos').html("<p><?php _e('You can\'t upload anymore videos','escortwp'); ?></p>");
			}
		});

	    $('#profile_videos_upload').uploadifive({
			'auto'           : true,
			'debug'          : true,
			'buttonClass'    : 'pinkbutton rad25',
			'buttonText'     : "<?php _e('Upload videos','escortwp'); ?>",
			'fileSizeLimit'  : '<?=get_option('maxvideouploadsize')?>MB',
	        'fileType'       : 'video/*',
	        'formData'       : { 'folder' : '<?php echo get_post_meta(get_the_ID(), "secret", true); ?>' },
			'multi'          : true,
			'queueID'        : 'profile-page-no-videos',
			'queueSizeLimit' : <?php echo $videos_left; ?>,
			'removeCompleted': true,
			'simUploadLimit' : <?php if($videos_left >= get_option('maxvideoupload')) { echo get_option('maxvideoupload'); } else { echo $videos_left; } ?>,
			'uploadLimit'    : <?php echo $videos_left; ?>,
			'uploadScript'   : '<?php bloginfo('template_url'); ?>/register-independent-upload-videos-process.php',
			'onQueueComplete': function(data) {
				$('.profile-page-no-videos').html('<p>' + data.successful + ' <?=addslashes(__('videos have been uploaded','escortwp'))?>.<br /><'+'a href="<?php echo get_permalink(get_the_ID()); ?>"><?=addslashes(__('Refresh the page to see them','escortwp'))?><'+'/a><br /><small><?=addslashes(__('Refreshing the page automatically in 2 seconds','escortwp'))?>.</small><'+'/p>').css('cursor', 'default').removeClass('profile-page-no-videos-click');
				setTimeout(location.reload(), 2000);
			},
			'onProgress'     : function (file, e) {
	            if (e.lengthComputable) {
	                var percent = Math.round((e.loaded / e.total) * 100);
	                if(percent > 97) {
	                	percent = 97;
	                }
	            }
	            file.queueItem.find('.fileinfo').html(' - ' + percent + '%');
	            file.queueItem.find('.progress-bar').css('width', percent + '%');
			}
		});
	// Video upload END


	// delete verified status image
	$('.verified_status_images .girl span i').on('click', function(){
		var img = $(this).text();
		var arr = img.split('.');
		var imgid = arr[0] + arr[1];
		$(this).parents('.girl').fadeOut("slow");
		$.ajax({
			type: "GET",
			url: "<?php bloginfo('template_url'); ?>/ajax/delete-verified-status-image.php",
			data: "id=" + arr[0],
			success: function(data){
				$('.image_msg').html(data).fadeIn("slow").delay(1000).fadeOut("slow");
			}
		});
	});

	$("a[rel=verified_status_img]").fancybox();

    $('#file_upload_verify').uploadifive({
		'auto'           : true,
		'buttonClass'    : 'pinkbutton rad25',
		'buttonText'     : "<?php _e('Upload image','escortwp'); ?>",
		'fileSizeLimit'  : '<?=get_option("maximguploadsize")?>MB',
        'fileType'       : 'image/*',
        'formData'       : { 'folder' : '<?php echo get_post_meta(get_the_ID(), "secret", true); ?>' },
		'multi'          : false,
		'queueID'        : 'upload-queue-verified-status',
		'queueSizeLimit' : 1,
		'removeCompleted': true,
		'simUploadLimit' : 1,
		'uploadLimit'    : 100,
		'uploadScript'   : '<?php bloginfo('template_url'); ?>/register-independent-verified-status-process.php',
		'onQueueComplete': function(data) {
			$('#status-message-verified-status').html(data.successful + ' <?=addslashes(__('images have been uploaded','escortwp'))?>.<br /><'+'a href="<?php echo get_permalink(get_the_ID()); ?>"><?=addslashes(__('Refresh the page to see them','escortwp'))?><'+'/a>');
			setTimeout(location.reload(), 2000);
		}
	});

	//delete an image from the account
		$(document).on('click touchend', '.thumbs .button-delete', function(e){
		e.preventDefault();
		e.stopPropagation();
		var $button = $(this).closest('.button-delete');
		if (escortwpShouldIgnoreSyntheticClick($button, e) || $button.prop('disabled')) {
			return;
		}
		var imgid = $button.parents('.profile-img-thumb').attr('id');
		var $thumb = $('#'+imgid);
		escortwpSetActionLoading($thumb, true);
		$.ajax({
			type: "GET",
			dataType: "json",
			url: "<?php bloginfo('template_url'); ?>/ajax/delete-uploaded-image.php",
			data: { id: imgid, escortwp_nonce: window.escortwpAjax ? window.escortwpAjax.nonce : '', escortwp_json: 1 },
			success: function(data){
				if (data && data.success) {
					$thumb.closest('.profile-img-thumb-wrapper').fadeOut(180, function() {
						$(this).remove();
						if (data.new_main_id) {
							escortwpSetMainImageUi(data.new_main_id);
						}
						if (!escortwpGetPhotoCount()) {
							var $grid = escortwpGetManagedGrid();
							if ($grid.length && !$grid.find('.escortwp-gallery-empty').length) {
								$grid.append('<div class="escortwp-gallery-empty"><?php echo esc_js(__('Nenhuma foto enviada ainda. As próximas imagens aparecerão aqui automaticamente.', 'escortwp')); ?></div>');
							}
						}
						escortwpSyncPhotoCapacity();
					});
					escortwpShowGalleryFeedback(data.message || "<?php echo esc_js(__('Sua imagem foi excluída.', 'escortwp')); ?>", 'success');
				} else {
					escortwpSetActionLoading($thumb, false);
					escortwpShowGalleryFeedback((data && data.message) ? data.message : "<?php echo esc_js(__('Não foi possível excluir esta imagem.', 'escortwp')); ?>", 'error');
				}
			},
			error: function() {
				escortwpSetActionLoading($thumb, false);
				escortwpShowGalleryFeedback("<?php echo esc_js(__('Não foi possível excluir esta imagem.', 'escortwp')); ?>", 'error');
			}
		});
	});

	//mark an image as the main image
	$(document).on('click touchend', '.thumbs .button-main-image', function(e){
		e.preventDefault();
		e.stopPropagation();
		var $button = $(this).closest('.button-main-image');
		if (escortwpShouldIgnoreSyntheticClick($button, e) || $button.prop('disabled')) {
			return;
		}
		var imgid = $button.parents('.profile-img-thumb').attr('id');
		var $thumb = $('#'+imgid);
		$('.thumbs .edit-buttons .button-main-image').show();
		escortwpSetActionLoading($thumb, true);
		$.ajax({
			type: "GET",
			url: "<?php bloginfo('template_url'); ?>/ajax/mark-as-main-image.php",
			dataType: "json",
			data: { id: imgid, escortwp_nonce: window.escortwpAjax ? window.escortwpAjax.nonce : '' },
			success: function(data){
				escortwpSetMainImageUi(imgid);
				escortwpSetActionLoading($thumb, false);
				escortwpShowGalleryFeedback((data && data.message) ? data.message : "<?php echo esc_js(__('Imagem principal atualizada com sucesso.', 'escortwp')); ?>", 'success');
			},
			error: function() {
				escortwpSetActionLoading($thumb, false);
				escortwpShowGalleryFeedback("<?php echo esc_js(__('Não foi possível definir esta imagem como capa.', 'escortwp')); ?>", 'error');
			}
		});
	});

	escortwpNormalizeMediaTexts();
	escortwpApplyMediaTextOverrides();
	escortwpApplyReadableMediaTexts();
	escortwpEnsureManagedGalleryClasses();
	escortwpSyncPhotoCapacity();
	<?php if(isset($_POST['action']) && $_POST['action'] == 'register' && $err) { echo "$('.girlsingle').slideUp();"."$('.agency_options_editprofile').slideDown();"; } ?>
});
</script>

<?php if (current_user_can('level_10')) { ?>
<div class="agency_options_addanote agency_options_dropdowns registerform">
	<div class="settingspagetitle rad3 l"><?php printf(esc_html__('Add a note to this %s','escortwp'),$taxonomy_profile_name); ?></div>
	<?php closebtn(); ?>
	<div class="clear20"></div>
	<form action="<?php echo get_permalink(get_the_ID()); ?>" method="post" class="form-styling">
    	<input type="hidden" name="action" value="adminnote" />
    	<?php _e('Add a public note about this profile. The text will be shown for all visitors, under the profile name.','escortwp') ?>
    	<div class="form-input col100">
    		<textarea name="adminnote" class="textarea longtextarea"  rows="7"><?php echo $adminnote; ?></textarea>
    		<small><?php _e('html allowed','escortwp'); ?></small>
    	</div> <!-- --> <div class="form-separator"></div>

        <div class="clear10"></div>
        <div class="text-center"><input type="submit" name="submit" value="Add/Update Note" class="pinkbutton rad3" /></div> <!--center-->
	</form>
</div> <!-- ADMIN ADD NOTE -->
<?php } // if admin ?>

<div class="agency_options_delete agency_options_dropdowns text-center">
	<?php closebtn(); ?>
	<div class="clear10"></div>
	<form action="<?php echo get_permalink(get_the_ID()); ?>" method="post" class="text-center">
		<?php
		if(get_the_author_meta('ID') == $userid) {
			printf(esc_html__('Are you sure you want to delete your %s account?','escortwp'),$taxonomy_profile_name);
		} else {
			printf(esc_html__('Are you sure you want to delete this %s account?','escortwp'),$taxonomy_profile_name);
		}
		?><div class="clear5"></div>
		<?php _e('Deleted accounts can\'t be recovered.','escortwp'); ?><div class="clear5"></div>
		<?php _e('To completely delete the account click the button below:','escortwp'); ?><div class="clear20"></div>
		<input type="submit" name="submit" value="<?php printf(esc_html__('Delete %s','escortwp'),$taxonomy_profile_name); ?> <?php the_title(); ?>" class="redbutton submitbutton rad25" />
		<input type="hidden" name="escortidtodelete" value="<?php the_ID(); ?>" />
		<input type="hidden" name="action" value="deleteescort" />
	</form>
</div> <!-- DELETE -->

<div class="agency_options_editprofile agency_options_dropdowns registerform">
	<?php closebtn(); ?>
	<div class="clear"></div>
	<?php include (get_template_directory() . '/register-independent-personal-information-form.php'); ?>
</div> <!-- EDIT PROFILE -->

<div class="agency_options_edittours agency_options_dropdowns managetours"<?php if (isset($err) && $err && $_POST['action'] == 'edittour') { echo ' style="display: block;"'; } ?>>
<script type="text/javascript">
jQuery(document).ready(function($) {
	//delete a city tour
	$('.tour .addedbuttons i').on('click', function(){
		var id = $(this).text();
		$('#tour'+id+' .addedbuttons').html('<b></b>');
		$.ajax({
			type: "GET",
			url: "<?php bloginfo('template_url'); ?>/ajax/delete-tour.php",
			data: { id: id, escortwp_nonce: window.escortwpAjax ? window.escortwpAjax.nonce : '' },
			success: function(data){
				$('.deletemsg').html(data).fadeIn("slow").delay(1500).fadeOut("slow");
				$('#tour'+id).slideUp("slow");
			}
		});
	});

	//edit a city tour
	$('.tour .addedbuttons em').on("click", function(){
		var id = $(this).text();
		$('.editthetoursform').html('');
		$('#tour'+id+' .addedbuttons em').hide('fast');
		$('#tour'+id+' .addedbuttons').append('<b></b>');
		$.ajax({
			type: "GET",
			url: "<?php bloginfo('template_url'); ?>/ajax/edit-tour.php",
			data: { id: id, escort_id: <?php the_ID(); ?>, edit_tour_in_escort_page: 'yes', escortwp_nonce: window.escortwpAjax ? window.escortwpAjax.nonce : '' },
			success: function(data){
				$('html,body').animate({ scrollTop: $('.body').offset().top }, { duration: 'slow', easing: 'swing'});
				$('.girlsingle').hide('fast');
				$('.editthetoursform').html(data);
				$('.agency_options_edittours').slideDown();
				$('#tour'+id+' .addedbuttons b').hide('fast');
				$('#tour'+id+' .addedbuttons').append('<em>'+id+'</em>');
				if($(window).width() > "960") { $('.select2').select2(); }
			}
		});
	});

	<?php if(isset($_POST['action']) && $_POST['action'] == 'edittour' && $err != "") { echo "$('.girlsingle').slideUp();"."$('.agency_options_edittours').slideDown();"; } ?>
});
</script>
	<?php closebtn(); ?>
	<div class="clear"></div>
	<?php if (isset($err) && $err && $_POST['action'] == 'edittour') { echo "<div class=\"err rad25\">$err</div>"; } ?>
    <div class="editthetoursform"></div>
</div> <!-- EDIT TOUR -->


<div class="agency_options_addtours agency_options_dropdowns managetours"<?php if (isset($err) && $err && ($_POST['action'] == 'edittour' || $_POST['action'] == 'addtour')) { echo ' style="display: block;"'; } ?>>
	<?php closebtn(); ?>
	<div class="clear"></div>
	<?php if (isset($err) && $err && $_POST['action'] == 'addtour') { echo "<div class=\"err rad25\">$err</div>"; } ?>
    <div class="addthetoursform">
		<?php
		$is_escort_page = "yes";
		$escort_post_id_for_tours = get_the_ID(); //we need this so we can construct a url for the form action. the submitted data will go to that url for processing
	    include (get_template_directory() . '/register-independent-add-tour-form.php');
		?>
    </div>
</div> <!-- EDIT TOUR -->


<div class="agency_options_verified_status agency_options_dropdowns">
	<h3 class="l settingspagetitle"><?php _e('Images you uploaded for verification:','escortwp'); ?></h3>
	<?php closebtn(); ?>
	<div class="clear10"></div>

	<?php
	$verified_photo_url = get_post_meta(get_the_ID(), "verified_status", true);
	if($verified_photo_url) {
		$verified_photo_url = "data:image/jpeg;base64,".$verified_photo_url;
		echo '<div class="verified_status_images upload_photos_page">';
		echo '<div class="image_msg l"></div>';

		echo '<div class="girl col20"><div class="thumb rad3 l"><span class="rad3 col100 nopadding"><a href="'.$verified_photo_url.'" rel="verified_status_img" class="col100 nopadding"><img src="'.$verified_photo_url.'" alt="" class="col100 nopadding" /></a><i class="rad3">'.get_the_ID().'</i></span></div><div class="clear"></div></div> <!-- GIRL -->'."\n";
		echo '</div> <!-- VERIFIED STATUS IMAGES --> <div class="clear10"></div>';
	}
	?>

	<div id="status-message-verified-status">
		<div class="upload_photos_button r">
			<input class="hide" id="file_upload_verify" name="file_upload" type="file" />
		</div>
		<?php _e('Increase the credibility of your account by submitting a verification photo.','escortwp'); ?><br />
		<?php _e('Please upload a photo of yourself holding a paper in your hands with the name of our website.','escortwp'); ?><br />
		<?php _e('All photos are private and will not be published!','escortwp'); ?><br />
		<?php _e('refresh the page to see newly uploaded images','escortwp'); ?><br />
		<?php _e('You can only upload 1 photo.','escortwp'); ?>
    </div> <div class="clear"></div>

	<div id="upload-queue-verified-status"></div>
</div> <!-- VERIFIED STATUS -->
