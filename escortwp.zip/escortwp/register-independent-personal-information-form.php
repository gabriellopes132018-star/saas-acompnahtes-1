﻿<?php
if(!defined('error_reporting')) { define('error_reporting', '0'); }
ini_set( 'display_errors', error_reporting );
if(error_reporting == '1') { error_reporting( E_ALL ); }
if(isdolcetheme !== 1) { die(); }

global $gender_a, $settings_theme_genders, $taxonomy_profile_name, $taxonomy_location_url;
if (!isset($err)) { $err = ''; }
if (!isset($escort_post_id)) { $escort_post_id = 0; }
if (!isset($agencyid)) { $agencyid = 0; }
if (!isset($single_page)) { $single_page = ''; }
if (!isset($admin_adding_escort)) { $admin_adding_escort = ''; }
if (!isset($agency_profile_id)) { $agency_profile_id = 0; }
if (!isset($user)) { $user = ''; }
if (!isset($pass)) { $pass = ''; }
if (!isset($youremail)) { $youremail = ''; }
if (!isset($sendverification)) { $sendverification = ''; }
if (!isset($sendauth)) { $sendauth = ''; }
if (!isset($yourname)) { $yourname = ''; }
if (!isset($phone)) { $phone = ''; }
if (!isset($phone_available_on) || !is_array($phone_available_on)) { $phone_available_on = array(); }
if (!isset($instagram)) { $instagram = ''; }
if (!isset($snapchat)) { $snapchat = ''; }
if (!isset($twitter)) { $twitter = ''; }
if (!isset($facebook)) { $facebook = ''; }
if (!isset($country)) { $country = 0; }
if (!isset($state)) { $state = 0; }
if (!isset($city)) { $city = 0; }
if (!isset($gender)) { $gender = ''; }
if (!isset($dateday)) { $dateday = ''; }
if (!isset($datemonth)) { $datemonth = ''; }
if (!isset($dateyear)) { $dateyear = ''; }
if (!isset($ethnicity)) { $ethnicity = ''; }
if (!isset($haircolor)) { $haircolor = ''; }
if (!isset($hairlength)) { $hairlength = ''; }
if (!isset($bustsize)) { $bustsize = ''; }
if (!isset($height)) { $height = ''; }
if (!isset($height2)) { $height2 = ''; }
if (!isset($weight)) { $weight = ''; }
if (!isset($build)) { $build = ''; }
if (!isset($looks)) { $looks = ''; }
if (!isset($availability) || !is_array($availability)) { $availability = array(); }
if (!isset($smoker)) { $smoker = ''; }
if (!isset($aboutyou)) { $aboutyou = ''; }
if (!isset($education)) { $education = ''; }
if (!isset($sports)) { $sports = ''; }
if (!isset($hobbies)) { $hobbies = ''; }
if (!isset($zodiacsign)) { $zodiacsign = ''; }
if (!isset($sexualorientation)) { $sexualorientation = ''; }
if (!isset($occupation)) { $occupation = ''; }
if (!isset($currency) || !$currency) { $currency = '1'; }
if (!isset($rate30min_incall)) { $rate30min_incall = ''; }
if (!isset($rate30min_outcall)) { $rate30min_outcall = ''; }
if (!isset($rate1h_incall)) { $rate1h_incall = ''; }
if (!isset($rate1h_outcall)) { $rate1h_outcall = ''; }
if (!isset($rate2h_incall)) { $rate2h_incall = ''; }
if (!isset($rate2h_outcall)) { $rate2h_outcall = ''; }
if (!isset($rate3h_incall)) { $rate3h_incall = ''; }
if (!isset($rate3h_outcall)) { $rate3h_outcall = ''; }
if (!isset($rate6h_incall)) { $rate6h_incall = ''; }
if (!isset($rate6h_outcall)) { $rate6h_outcall = ''; }
if (!isset($rate12h_incall)) { $rate12h_incall = ''; }
if (!isset($rate12h_outcall)) { $rate12h_outcall = ''; }
if (!isset($rate24h_incall)) { $rate24h_incall = ''; }
if (!isset($rate24h_outcall)) { $rate24h_outcall = ''; }
if (!isset($services) || !is_array($services)) { $services = array(); }
if (!isset($extraservices)) { $extraservices = ''; }
if (!$extraservices && $services) {
	$legacy_services_items = array();
	foreach ($services as $legacy_service_key) {
		if (isset($services_a[$legacy_service_key])) {
			$legacy_services_items[] = __($services_a[$legacy_service_key], 'escortwp');
		}
	}
	if ($legacy_services_items) {
		$extraservices = implode("\n", $legacy_services_items);
	}
}
$service_lines_values = preg_split('/\r\n|\r|\n/', (string) $extraservices);
$service_lines_values = array_values(array_filter(array_map('trim', $service_lines_values), 'strlen'));
if (!$service_lines_values) {
	$service_lines_values = array('');
}
while (count($service_lines_values) < 6) {
	$service_lines_values[] = '';
}
$tos_checked = !empty($_POST['tos_accept']) && $_POST['tos_accept'] == "1";

if ($err && !empty($_POST['action']) && $_POST['action'] == 'register') { echo "<div class=\"err rad25\">$err</div>"; }

if (!empty($escort_post_id)) {
	$form_url = get_permalink(get_option('escort_edit_personal_info_page_id'));
} else {
	$form_url = get_permalink(get_option('escort_reg_page_id'));
}
if (!empty($agencyid)) {
	$form_url = get_permalink(get_option('agency_manage_escorts_page_id'));
	if (isset($single_page) && $single_page == "yes") {
		$form_url = get_permalink($escort_post_id);
	}
	if (isset($admin_adding_escort) && $admin_adding_escort == "yes") {
		$form_url = get_permalink($agency_profile_id);
	}
}
?>
<script type="text/javascript">
jQuery(document).ready(function($) {
	//check if the current user is already taken
	$('#register_form #user').keyup(function(){
		var user = $('#user').val();
		var userlength = document.getElementById("user").value.length;
		if(userlength >= 4 && userlength <= 30) {
			$('.checkuser').empty();
			$.ajax({
				type: "GET",
				url: "<?php bloginfo('template_url'); ?>/ajax/check-username.php",
				data: { user: user, escortwp_nonce: window.escortwpAjax ? window.escortwpAjax.nonce : '' },
				success: function(data){
					$('.checkuser').html(data);
				}
			});
		}
	});

	//check availability
	function check_availability(){ }
});
</script>

<form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data" class="form-styling" id="register-form-main-container">
	<input type="hidden" name="action" value="register" />
	<?php wp_nonce_field('escortwp_escort_register', 'escortwp_escort_register_nonce'); ?>
	
	<div id="aba-conta" class="escortwp-form-section-heading">
		<span class="escortwp-form-section-kicker"><?php _e('Conta', 'escortwp'); ?></span>
		<h4><?php _e('Dados de acesso e perfil básico', 'escortwp'); ?></h4>
		<p><?php _e('As de credenciais de login e as informações obrigatórias para sua página funcionar.', 'escortwp'); ?></p>
	</div>

	<?php if (!$escort_post_id) { ?>
	<div class="form-label">
		<label for="user"><?php _e('Username','escortwp'); ?><i>*</i></label>
	</div>
	<div class="form-input">
		<input type="text" name="user" id="user" class="input longinput" value="<?php echo $user; ?>" />
		<div class="checkuser"></div>
	</div> <!-- user --> <div class="formseparator"></div>

	<div class="form-label">
		<label for="pass"><?php _e('Password','escortwp'); ?><i>*</i></label>
	</div>
	<div class="form-input">
		<input type="password" name="pass" id="pass" class="input longinput" />
	</div> <!-- pass --> <div class="formseparator"></div>

	<div class="form-label">
		<label for="youremail"><?php _e('Email address','escortwp'); ?><i>*</i></label>
	</div>
	<div class="form-input">
		<input type="email" name="youremail" id="youremail" class="input longinput" value="<?php echo $youremail; ?>" />
	</div> <!-- email --> <div class="formseparator"></div>
	<?php } ?>

	<div class="form-label">
		<?php
			$namelabel = __('Name','escortwp');
			if ($agencyid || current_user_can('level_10')) { $namelabel = sprintf(esc_html__('Name of the %s','escortwp'),$taxonomy_profile_name); }
		?>
		<label for="yourname"><?php echo $namelabel; ?><i>*</i></label>
	</div>
	<div class="form-input">
		<input type="text" name="yourname" id="yourname" class="input longinput" value="<?php echo $yourname; ?>" />
	</div> <!-- yourname --> <div class="formseparator"></div>


	<div id="aba-contato" class="escortwp-form-section-heading">
		<span class="escortwp-form-section-kicker"><?php _e('Contato', 'escortwp'); ?></span>
		<h4><?php _e('Canais de comunicação para seus clientes', 'escortwp'); ?></h4>
		<p><?php _e('Como as pessoas poderão falar com você. Deixe preenchido apenas o que deseja divulgar.', 'escortwp'); ?></p>
	</div>

	<?php if(showfield('phone')) { ?>
	<div class="form-label">
		<label for="phone"><?php _e('Phone','escortwp'); ismand('phone'); ?></label>
	</div>
	<div class="form-input">
		<input type="text" name="phone" id="phone" class="input longinput" value="<?php echo $phone; ?>" />
	</div> <!-- phone --> <div class="formseparator"></div>
	<?php } ?>

	<?php if(showfield('instagram')) { ?>
	<div class="form-label">
		<label for="instagram"><?php _e('Instagram','escortwp'); ismand('instagram'); ?></label>
	</div>
	<div class="form-input">
		<input type="text" name="instagram" id="instagram" class="input longinput" placeholder="@" value="<?php echo $instagram; ?>" />
		<small><?=__('Instagram username only (ex: @myusername)','escortwp')?></small>
	</div> <!-- instagram --> <div class="formseparator"></div>
	<?php } ?>

	<?php if(showfield('snapchat')) { ?>
	<div class="form-label">
		<label for="snapchat"><?php _e('Snapchat','escortwp'); ismand('snapchat'); ?></label>
	</div>
	<div class="form-input">
		<input type="text" name="snapchat" id="snapchat" class="input longinput" placeholder="@" value="<?php echo $snapchat; ?>" />
		<small><?=__('Snapchat username only (ex: @myusername)','escortwp')?></small>
	</div> <!-- snapchat --> <div class="formseparator"></div>
	<?php } ?>

	<?php if(showfield('twitter')) { ?>
	<div class="form-label">
		<label for="twitter"><?php _e('Twitter','escortwp'); ismand('twitter'); ?></label>
	</div>
	<div class="form-input">
		<input type="url" name="twitter" id="twitter" class="input longinput" placeholder="https://" value="<?php echo $twitter; ?>" />
		<small><?=__('Twitter profile/page url','escortwp')?></small>
	</div> <!-- twitter --> <div class="formseparator"></div>
	<?php } ?>

	<?php if(showfield('facebook')) { ?>
	<div class="form-label">
		<label for="facebook"><?php _e('Facebook','escortwp'); ismand('facebook'); ?></label>
	</div>
	<div class="form-input">


		<small><?=__('Facebook profile/page url','escortwp')?></small>
	</div> <!-- facebook --> <div class="formseparator"></div>
   	<?php } ?>

	<?php if(get_option('locationdropdown') == "1") { ?>
	<script type="text/javascript">
		jQuery(document).ready(function($) {
			//get cities from the selected country in the countries dropdown
			var c = ".country";
			var parent_div = "#register-form-main-container";
			<?php if(showfield('state')) { ?>
				var city_div = '.inputstates';

				var state_c = '.state';
				var state_div = '.inputcities';
			<?php } else { ?>
				var city_div = '.inputcities';
			<?php } ?>

			show_search_cities(c);
			$(parent_div+' '+c).change(function(){ show_search_cities(c); });
			function show_search_cities(e) {
				var country = $(parent_div+' '+e).val();
				$(parent_div+' '+city_div).text($(city_div).data('text'));
				<?php if(showfield('state')) { ?>
					$(parent_div+' '+state_div).text($(state_div).data('text'));
				<?php } ?>

				if(country < 1) return true;

				loader($(e).parents(parent_div).find(city_div));
				$.ajax({
					type: "GET",
					url: "<?php bloginfo('template_url'); ?>/ajax/get-cities.php",
					<?php if(showfield('state')) { ?>
						data: "id=" + country +"&hide_empty=0&state=yes&select2=yes",
					<?php } else { ?>
						data: "id=" + country +"&hide_empty=0&select2=yes",
					<?php } ?>
					success: function(data){
						$(e).parents(parent_div).find(city_div).html(data);
						if($(window).width() > "960") { $('.select2').select2(); }
					}
				});
			}

			<?php if(showfield('state')) { ?>
				$(parent_div).on("change", state_c, function(){
					show_search_cities_when_states(state_c);
				});
				function show_search_cities_when_states(e) {
					var state = $(parent_div+' '+e).val();
					$(parent_div+' '+state_div).text($(state_div).data('text'));
					if(state < 1) {
						return true;
					}

					loader($(e).parents(parent_div).find(state_div));
					$.ajax({
						type: "GET",
						url: "<?php bloginfo('template_url'); ?>/ajax/get-cities.php",
						data: "id=" + state +"&hide_empty=0&select2=yes",
						success: function(data){
							$(e).parents(parent_div).find(state_div).html(data);
							if($(window).width() > "960") { $('.select2').select2(); }
						}
					});
				}
			<?php } // if showfield('state') ?>
		});
	</script>
	<?php } // if the city and state need to be dropdowns ?>
	<div id="aba-localizacao" class="escortwp-form-section-heading">
		<span class="escortwp-form-section-kicker"><?php _e('Localização', 'escortwp'); ?></span>
		<h4><?php _e('Região principal do anúncio', 'escortwp'); ?></h4>
		<p><?php _e('Selecione a Região certa para que o perfil apareça nas buscas corretas e mantenha a navegação do site organizada.', 'escortwp'); ?></p>
	</div>
	<div class="form-label">
		<label for="country"><?php _e('Estado','escortwp'); ?><i>*</i></label>
	</div>
	<div class="form-input">
		<?php
		$args = array(
			'show_option_none'   => __('Selecione o estado','escortwp'),
		    'orderby'            => 'name',
		    'order'              => 'ASC',
			'hide_empty'         => 0,
			'echo'               => 1,
			'selected'           => $country,
			'hierarchical'       => 1,
			'name'               => 'country',
			'id'                 => 'country',
			'class'              => 'country select2',
			'depth'              => 1,
			'taxonomy'           => $taxonomy_location_url
		);

		$categories_count_array = array(
			'show_option_all' => '',
			'show_count' => '0',
			'hide_empty' => '0',
			'show_option_none' => '',
			'pad_counts' => '0',
			'taxonomy' => $taxonomy_location_url,
			'parent' => 0,
			'number' => '2',
			'fields' => 'ids'
		);
		$categories_count_data = get_categories($categories_count_array);
		if(count($categories_count_data) == "1") {
			unset($categories_count_array['fields']);
			$country_list = get_categories($categories_count_array);
			$country_list = array_values($country_list);
			echo '<div class="clear10"></div>'.escortwp_translate_runtime_label($country_list[0]->name);
			echo '<input type="hidden" name="country" class="country" value="'.$country_list[0]->term_id.'" />';
			?>
			<script type="text/javascript"> jQuery(document).ready(function($) { $('.register-form .country').trigger('change'); }); </script>
			<?php
		} else {
			wp_dropdown_categories( $args );
		}
		$city_parent = $country;
		?>
    </div> <!-- country --> <div class="formseparator"></div>

	<?php if(showfield('state')) { ?>
	<div class="form-label">
		<label for="state"><?php _e('Região','escortwp'); ismand('state'); ?></label>
	</div>
	<div class="form-input inputstates" data-text="<?=__('Selecione um estado primeiro','escortwp')?>">
		<?php if(get_option('locationdropdown') == "1") {
				if($country > 0) {
					$city_parent = $state;
					$args = array(
						'show_option_all'    => '',
					'show_option_none'   => __('Selecione a Região','escortwp'),
						'show_last_update'   => 0,
						'show_count'         => 0,
						'parent'			 => $country,
						'hide_empty'         => 0,
						'exclude'            => '',
						'echo'               => 1,
						'selected'           => $state,
						'hierarchical'       => 1, 
						'name'               => 'state',
						'id'                 => '',
						'class'              => 'state select2',
						'depth'              => 1,
						'tab_index'          => 0,
					    'orderby'            => 'name',
					    'order'              => 'ASC',
						'taxonomy'           => $taxonomy_location_url );
					wp_dropdown_categories( $args );
				} else {
					_e('Selecione um estado primeiro','escortwp');
				}
		} else { ?>
			<input type="text" name="state" id="state" class="input longinput" value="<?php echo $state; ?>" />
		<?php } ?>
	</div> <!-- state --> <div class="formseparator"></div>
   	<?php } ?>

    <div class="form-label">
		<label for="city"><?php _e('Cidade','escortwp'); ?> <i>*</i></label>
	</div>
	<?php
	if(showfield('state')) {
		$city_text = __('Selecione uma Região primeiro','escortwp');
	} else {
		$city_text = __('Selecione um estado primeiro','escortwp');
	}
	?>
	<div class="form-input inputcities" data-text="<?=$city_text?>">
		<?php if(get_option('locationdropdown') == "1") {
			if(($country > 0 && !showfield('state')) || ($state > 0 && showfield('state'))) {
				$args = array(
					'show_option_all'    => '',
					'show_option_none'   => __('Selecione a cidade','escortwp'),
					'show_last_update'   => 0,
					'show_count'         => 0,
					'parent'			 => $city_parent,
					'hide_empty'         => 0,
					'exclude'            => '',
					'echo'               => 1,
					'selected'           => $city,
					'hierarchical'       => 1, 
					'name'               => 'city',
					'id'                 => '',
					'class'              => 'city select2',
					'depth'              => 1,
					'tab_index'          => 0,
				    'orderby'            => 'name',
				    'order'              => 'ASC',
					'taxonomy'           => $taxonomy_location_url );
				wp_dropdown_categories( $args );
			} else {
				echo $city_text;
			}
		} else { ?>
			<input type="text" name="city" id="city" class="input longinput" value="<?php echo $city; ?>" />
		<?php } ?>
	</div> <!-- city --> <div class="formseparator"></div>

	<div class="form-label">
		<label><?php _e('Gender','escortwp'); ?><i>*</i></label>
	</div>
	<div class="form-input" id="gender">
		<?php
		foreach($gender_a as $key=>$g) {
			if(in_array($key, $settings_theme_genders)) {
		?>
		<label for="gender<?php echo $key ?>">
			<input type="radio" name="gender" value="<?php echo $key; ?>" id="gender<?php echo $key ?>"<?php if($gender == $key) { echo ' checked'; } ?> />
			<?php _e($g,'escortwp'); ?><br />
		</label>
		<?php
			} // if in_array
		} // foreach
		?>
	</div> <!-- GENDER --> <div class="formseparator"></div>

	<div class="form-label">
		<label class="with-help"><?php _e('Date of birth','escortwp'); ?><i>*</i></label>
		<small><?php _e('we\'ll calculate your age from this','escortwp'); ?></small>
	</div>
	<div class="form-input">
		<select name="dateday" id="dateday" class="birthday select col33 l">
			<option value=""><?php _e('Day','escortwp'); ?></option>
			<?php
			for($i=1;$i<=31;$i+=1) {
				$selected = $dateday == $i ? ' selected="selected"' : "";
				echo '<option value="'.$i.'"'.$selected.'>'.$i.'</option>';
			}
			?>
		</select>
		<select name="datemonth" id="datemonth" class="birthday select col33 l">
			<option value=""><?php _e('Month','escortwp'); ?></option>
			<option value="1"<?php if($datemonth == "1") { echo ' selected="selected"'; } ?>><?php _e('January','escortwp'); ?></option>
			<option value="2"<?php if($datemonth == "2") { echo ' selected="selected"'; } ?>><?php _e('February','escortwp'); ?></option>
			<option value="3"<?php if($datemonth == "3") { echo ' selected="selected"'; } ?>><?php _e('March','escortwp'); ?></option>
			<option value="4"<?php if($datemonth == "4") { echo ' selected="selected"'; } ?>><?php _e('April','escortwp'); ?></option>
			<option value="5"<?php if($datemonth == "5") { echo ' selected="selected"'; } ?>><?php _e('May','escortwp'); ?></option>
			<option value="6"<?php if($datemonth == "6") { echo ' selected="selected"'; } ?>><?php _e('June','escortwp'); ?></option>
			<option value="7"<?php if($datemonth == "7") { echo ' selected="selected"'; } ?>><?php _e('July','escortwp'); ?></option>
			<option value="8"<?php if($datemonth == "8") { echo ' selected="selected"'; } ?>><?php _e('August','escortwp'); ?></option>
			<option value="9"<?php if($datemonth == "9") { echo ' selected="selected"'; } ?>><?php _e('September','escortwp'); ?></option>
			<option value="10"<?php if($datemonth == "10") { echo ' selected="selected"'; } ?>><?php _e('October','escortwp'); ?></option>
			<option value="11"<?php if($datemonth == "11") { echo ' selected="selected"'; } ?>><?php _e('November','escortwp'); ?></option>
			<option value="12"<?php if($datemonth == "12") { echo ' selected="selected"'; } ?>><?php _e('December','escortwp'); ?></option>
		</select>
		<select name="dateyear" id="dateyear" class="birthday select col33 l">
			<option value=""><?php _e('Year','escortwp'); ?></option>
			<?php
			$startyear = date('Y') - 18;
			$endyear = date('Y') - 100;
			for($i=$startyear;$i>=$endyear;$i--) {
				$selected = $dateyear == $i ? ' selected="selected"' : "";
				echo '<option value="'.$i.'"'.$selected.'>'.$i.'</option>';
			}
			?>
		</select>
	</div> <!-- DATE OF BIRTH --> <div class="formseparator"></div>

	<?php if(showfield('ethnicity')) { ?>
	<div class="form-label">
		<label for="ethnicity"><?php _e('Etnia','escortwp'); ismand('ethnicity'); ?></label>
	</div>
	<div class="form-input">
		<select name="ethnicity" id="ethnicity">
			<option value=""><?php _e('Selecione','escortwp'); ?></option>
			<?php foreach($ethnicity_a as $key=>$s) { ?>
				<option value="<?php echo $key; ?>"<?php if($ethnicity == $key) { echo ' selected="selected"'; } ?>><?php _e($s,'escortwp'); ?></option>
			<?php } ?>
		</select>
	</div> <!-- SKIN COLOR --> <div class="formseparator"></div>
	<?php } // showfield ?>


	<?php if(showfield('height')) { ?>
	<div class="form-label">
		<label for="height"><?php _e('Altura','escortwp'); ismand('height'); ?></label>
	</div>
	<div class="form-input">
		<input type="number" name="height" size="4" maxlength="4" id="height" class="input smallinput text-center" value="<?php echo $height; ?>" /> &nbsp; <?=get_option('heightscale') == "imperial" ? "ft" : "cm"?>
		<?php if(get_option('heightscale') == "imperial") { ?>
		&nbsp;&nbsp;<input type="number" name="height2" size="2" maxlength="2" id="height2" class="input smallinput text-center" value="<?php echo $height2; ?>" /> &nbsp; inches
		<?php } ?>
	</div> <!-- HEIGHT --> <div class="formseparator"></div>
	<?php } // showfield ?>

	<?php if(showfield('weight')) { ?>
	<div class="form-label">
		<label for="weight"><?php _e('Peso','escortwp'); ismand('weight'); ?></label>
	</div>
	<div class="form-input">
		<input type="number" step="0.01" name="weight" size="4" id="weight" class="input smallinput text-center" value="<?php echo $weight; ?>" /> &nbsp; <?=get_option('heightscale') == "imperial" ? "lb" : "kg"?>
	</div> <!-- WEIGHT --> <div class="formseparator"></div>
	<?php } // showfield ?>

	<?php if(showfield('build')) { ?>
	<div class="form-label">
		<label for="build"><?php _e('Porte físico','escortwp'); ismand('build'); ?></label>
	</div>
	<div class="form-input">
		<select name="build" id="build" class="build">
			<option value=""><?php _e('Selecione','escortwp'); ?></option>
			<?php foreach($build_a as $key=>$b) { ?>
				<option value="<?php echo $key; ?>"<?php if($build == $key) { echo ' selected="selected"'; } ?>><?php _e($b,'escortwp'); ?></option>
			<?php } ?>
		</select>
	</div> <!-- BUILT --> <div class="formseparator"></div>
	<?php } // showfield ?>


	<?php
	if(showfield('availability')) {
		if(!$availability) { $availability = array(); }
	?>
	<div class="form-label">
		<label><?php _e('Disponibilidade','escortwp'); ismand('availability'); ?></label>
	</div>
	<div class="form-input">
		<label for="incall">
			<input type="checkbox" name="availability[]" value="1" id="incall"<?php if( in_array("1", $availability) ) { echo ' checked'; } ?> />
			<?php _e('No local','escortwp'); ?>
		</label>
		<label for="outcall">
			<input type="checkbox" name="availability[]" value="2" id="outcall"<?php if( in_array("2", $availability) ) { echo ' checked'; } ?> />
			<?php _e('Atendimento externo','escortwp'); ?>
		</label>
	</div> <!-- AVAILABILITY --> <div class="formseparator"></div>
	<?php } // showfield ?>


	<div id="aba-perfil" class="escortwp-form-section-heading">
		<span class="escortwp-form-section-kicker"><?php _e('Perfil', 'escortwp'); ?></span>
		<h4><?php _e('Apresentação pública da acompanhante', 'escortwp'); ?></h4>
		<p><?php _e('Preencha os dados do perfil com clareza para gerar mais confiança e facilitar o entendimento de quem visita o anúncio.', 'escortwp'); ?></p>
	</div>

	<?php if(showfield('aboutyou')) { ?>
	<div class="form-label">
		<?php
			$labeltext = __('Apresentação do anúncio','escortwp');
			if ($agencyid || current_user_can('level_10')) { $labeltext = sprintf(esc_html__('Apresentação da %s','escortwp'),$taxonomy_profile_name); }
		?>
		<label for="aboutyou"><?php echo $labeltext; ismand('aboutyou'); ?></label>
	</div>
	<div class="form-input">
		<textarea name="aboutyou" id="aboutyou" class="textarea longtextarea" rows="7" required><?php echo strip_tags($aboutyou); ?></textarea>
		<small><?php _e('Qualquer cÃ³digo HTML serÃ¡ removido','escortwp'); ?></small>
	</div> <!-- about you --> <div class="formseparator"></div>
	<?php } // showfield ?>


	<div id="aba-valores" class="escortwp-form-section-heading">
		<span class="escortwp-form-section-kicker"><?php _e('Valores', 'escortwp'); ?></span>
		<h4><?php _e('Tabela de atendimento', 'escortwp'); ?></h4>
		<p><?php _e('Informe apenas os valores que realmente serÃ£o praticados. Isso ajuda o painel a montar um anúncio mais profissional e transparente.', 'escortwp'); ?></p>
	</div>

	<?php if(showfield('rates')) { ?>
	<div class="form-label">
		<label><?php _e('Valores','escortwp'); ismand('rates'); ?></label>
		<?php if(ismand('rates', 'no')) { echo '<small>'.__('informe pelo menos um valor','escortwp').'</small>'; } ?>
	</div>
	<div class="form-input">
		<div class="col30 l currency-label-text"><?php _e('Moeda','escortwp'); ?>:</div>
		<div class="col60 l currency-label-dropdown">
			<input type="hidden" name="currency" value="1" />
			<select name="currency_display" id="currency" class="col100" disabled="disabled">
				<option value="1" selected="selected">BRL - Real</option>
			</select>
		</div>
		<div class="clear20"></div>

		<div class="rates l">
			<div class="col30 l">&nbsp;</div>
			<div class="col30 text-center l hide-incall"><b><?php _e('No local','escortwp'); ?></b></div>
			<div class="col30 text-center l hide-outcall"><b><?php _e('Atendimento externo','escortwp'); ?></b></div>
		</div>
		<div class="clear10"></div>
		<div class="rates l">
			<div class="col30 l rates-label"><?php echo "30 ".__('minutos','escortwp'); ?></div>
			<div class="col30 l hide-incall"><input type="number" name="rate30min_incall" maxlength="15" value="<?php echo $rate30min_incall; ?>" class="input" /></div>
			<div class="col30 l hide-outcall"><input type="number" name="rate30min_outcall" maxlength="15" value="<?php echo $rate30min_outcall; ?>" class="input" /></div>
		</div>
		<div class="rates l">
			<div class="col30 l rates-label"><?php echo "1 ".__('hora','escortwp'); ?></div>
			<div class="col30 l hide-incall"><input type="number" name="rate1h_incall" maxlength="15" value="<?php echo $rate1h_incall; ?>" class="input" /></div>
			<div class="col30 l hide-outcall"><input type="number" name="rate1h_outcall" maxlength="15" value="<?php echo $rate1h_outcall; ?>" class="input" /></div>
		</div>
		<div class="rates l">
			<div class="col30 l rates-label"><?php echo "2 ".__('horas','escortwp'); ?></div>
			<div class="col30 l hide-incall"><input type="number" name="rate2h_incall" maxlength="15" value="<?php echo $rate2h_incall; ?>" class="input" /></div>
			<div class="col30 l hide-outcall"><input type="number" name="rate2h_outcall" maxlength="15" value="<?php echo $rate2h_outcall; ?>" class="input" /></div>
		</div>
		<div class="rates l">
			<div class="col30 l rates-label"><?php echo "3 ".__('horas','escortwp'); ?></div>
			<div class="col30 l hide-incall"><input type="number" name="rate3h_incall" maxlength="15" value="<?php echo $rate3h_incall; ?>" class="input" /></div>
			<div class="col30 l hide-outcall"><input type="number" name="rate3h_outcall" maxlength="15" value="<?php echo $rate3h_outcall; ?>" class="input" /></div>
		</div>
		<div class="rates l">
			<div class="col30 l rates-label"><?php echo "6 ".__('horas','escortwp'); ?></div>
			<div class="col30 l hide-incall"><input type="number" name="rate6h_incall" maxlength="15" value="<?php echo $rate6h_incall; ?>" class="input" /></div>
			<div class="col30 l hide-outcall"><input type="number" name="rate6h_outcall" maxlength="15" value="<?php echo $rate6h_outcall; ?>" class="input" /></div>
		</div>
		<div class="rates l">
			<div class="col30 l rates-label"><?php echo "12 ".__('horas','escortwp'); ?></div>
			<div class="col30 l hide-incall"><input type="number" name="rate12h_incall" maxlength="15" value="<?php echo $rate12h_incall; ?>" class="input" /></div>
			<div class="col30 l hide-outcall"><input type="number" name="rate12h_outcall" maxlength="15" value="<?php echo $rate12h_outcall; ?>" class="input" /></div>
		</div>
		<div class="rates l">
			<div class="col30 l rates-label"><?php echo "24 ".__('horas','escortwp'); ?></div>
			<div class="col30 l hide-incall"><input type="number" name="rate24h_incall" maxlength="15" value="<?php echo $rate24h_incall; ?>" class="input" /></div>
			<div class="col30 l hide-outcall"><input type="number" name="rate24h_outcall" maxlength="15" value="<?php echo $rate24h_outcall; ?>" class="input" /></div>
		</div>
		<div class="clear"></div>
	</div> <!-- RATES --> <div class="formseparator"></div>
	<?php } // showfield ?>

	<div id="aba-servicos" class="escortwp-form-section-heading">
		<span class="escortwp-form-section-kicker"><?php _e('Serviços', 'escortwp'); ?></span>
		<h4><?php _e('Serviços do anúncio', 'escortwp'); ?></h4>
		<p><?php _e('Escreva livremente os serviços e combinações que deseja mostrar no perfil. Cada linha pode virar um item do anúncio.', 'escortwp'); ?></p>
	</div>

	<?php if(showfield('services') || showfield('extraservices')) { ?>
	<div class="form-label">
		<label for="service_line_1"><?php _e('Serviços oferecidos','escortwp'); ?></label>
	</div>
	<div class="form-input escortwp-service-lines">
		<?php for($service_line_index = 0; $service_line_index < 6; $service_line_index++) { ?>
			<input
				type="text"
				name="service_lines[]"
				id="service_line_<?php echo $service_line_index + 1; ?>"
				class="input longinput escortwp-service-line"
				value="<?php echo esc_attr($service_lines_values[$service_line_index] ?? ''); ?>"
				placeholder="<?php echo esc_attr(sprintf(__('Serviço %d', 'escortwp'), $service_line_index + 1)); ?>"
			/>
			<div class="clear10"></div>
		<?php } ?>
		<textarea name="extraservices" id="extraservices" class="textarea longtextarea" rows="7" placeholder="<?php echo esc_attr__('Exemplo: Massagem relaxante&#10;Atendimento a casais&#10;Pernoite sob consulta','escortwp'); ?>"><?php echo esc_textarea($extraservices ?? ''); ?></textarea>
		<input type="hidden" name="services_freeform_mode" value="1" />
		<small><?php _e('Preencha apenas os serviços que deseja exibir. Cada linha vira um item separado no anúncio.', 'escortwp'); ?></small>
	</div> <!-- services --> <div class="formseparator"></div>
	<?php } // showfield ?>


    <?php if(get_option('recaptcha_sitekey') && get_option('recaptcha_secretkey') && !is_user_logged_in() && get_option("recaptcha2")) { ?>
	<div class="form-input">
		<div class="g-recaptcha" data-sitekey="<?php echo get_option('recaptcha_sitekey'); ?>"></div>
	</div> <!-- message --> <div class="formseparator"></div>
    <?php } ?>

    <?php
    $tos_page_data = get_post(get_option('tos_page_id'));
    if(($tos_page_data || $data_protection_page_data) && !is_user_logged_in()) {
    	if($tos_page_data) {
    		$message = sprintf(__('Concordo com %s deste site', 'escortwp'), '<a href="'.get_permalink(get_option('tos_page_id')).'" target="_blank">'.$tos_page_data->post_title.'</a>');
    	}
    	if($data_protection_page_data) {
    		$message = sprintf(__('Concordo com %s deste site', 'escortwp'), '<a href="'.get_permalink(get_option('data_protection_page_id')).'" target="_blank">'.$data_protection_page_data->post_title.'</a>');
    	}
    	if($data_protection_page_data && $tos_page_data) {
    		$message = sprintf(__('Concordo com %s e %s deste site', 'escortwp'), '<a href="'.get_permalink(get_option('tos_page_id')).'" target="_blank">'.$tos_page_data->post_title.'</a>', '<a href="'.get_permalink(get_option('data_protection_page_id')).'" target="_blank">'.$data_protection_page_data->post_title.'</a>');
    	}
    ?>
    <div class="formseparator"></div>
	<div class="form-input col100 center form-input-accept-tos">
		<label for="tos_checkbox" class="rad25">
			<input type="checkbox" name="tos_accept" value="1" id="tos_checkbox"<?php if($tos_checked) { echo ' checked'; } ?> />
			<?=$message?>
		</label>
	</div> <!-- message --> <div class="clear15"></div>
    <?php } ?>

	<div class="text-center">
		<input id="register_submit" type="submit" name="submit" value="<?php if($escort_post_id) { _e('Atualizar perfil','escortwp'); } elseif ($agencyid) { printf(esc_html__('Adicionar %s','escortwp'),$taxonomy_profile_name); } else { _e('Concluir cadastro','escortwp'); } ?>" class="pinkbutton rad25" />
	</div> <!--center-->
</form>

