﻿(function () {
    'use strict';

    if (typeof window === 'undefined' || !window.escortwpVideoVerification) {
        return;
    }

    var config = window.escortwpVideoVerification;

    function setFeedback(element, message, type) {
        if (!element) {
            return;
        }

        element.textContent = message || '';
        element.classList.remove('is-error', 'is-success', 'is-loading');
        if (type) {
            element.classList.add('is-' + type);
        }
    }

    function parseJsonPayload(text) {
        var payload = (text || '').replace(/^\uFEFF+/, '').trim();
        var jsonStart = payload.search(/[\{\[]/);
        if (jsonStart > 0) {
            payload = payload.slice(jsonStart);
        }
        return payload ? JSON.parse(payload) : {};
    }

    function attachForm(form) {
        if (!form) {
            return;
        }

        var fileInput = form.querySelector('input[type="file"]');
        var submitButton = form.querySelector('.escortwp-video-verification-submit');
        var feedback = form.querySelector('.escortwp-video-verification-feedback');
        var profileId = form.getAttribute('data-profile-id');

        form.addEventListener('submit', function (event) {
            event.preventDefault();

            if (!fileInput || !fileInput.files || !fileInput.files[0]) {
                setFeedback(feedback, 'Selecione um vídeo antes de enviar.', 'error');
                return;
            }

            var formData = new FormData();
            formData.append('profile_id', profileId);
            formData.append('verification_video', fileInput.files[0]);

            submitButton.disabled = true;
            submitButton.dataset.originalText = submitButton.textContent;
            submitButton.textContent = config.strings.uploading;
            setFeedback(feedback, config.strings.uploading, 'loading');

            fetch(config.restBase, {
                method: 'POST',
                body: formData,
                credentials: 'same-origin',
                headers: {
                    'X-WP-Nonce': config.nonce
                }
            })
                .then(function (response) {
                    return response.text().then(function (rawText) {
                        var data = {};

                        try {
                            data = parseJsonPayload(rawText);
                        } catch (error) {
                            throw new Error(config.strings.genericError);
                        }

                        if (!response.ok) {
                            var message = (data && data.message) ? data.message : config.strings.genericError;
                            throw new Error(message);
                        }

                        return data;
                    });
                })
                .then(function () {
                    setFeedback(feedback, config.strings.success, 'success');
                    window.setTimeout(function () {
                        window.location.reload();
                    }, 1200);
                })
                .catch(function (error) {
                    setFeedback(feedback, error.message || config.strings.genericError, 'error');
                })
                .finally(function () {
                    submitButton.disabled = false;
                    submitButton.textContent = submitButton.dataset.originalText || 'Enviar';
                });
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        Array.prototype.forEach.call(document.querySelectorAll('.escortwp-video-verification-form'), attachForm);
    });
})();
