(function () {
  const cfg = window.escortwpMpPayments;
  if (!cfg) return;

  let modal = null;
  let titleEl = null;
  let subtitleEl = null;
  let statusEl = null;
  let qrEl = null;
  let codeEl = null;
  let noteEl = null;
  let copyButton = null;
  let pollTimer = null;
  let currentPaymentId = 0;

  function resolveElements() {
    if (!modal) {
      modal = document.getElementById('escortwp-mp-modal');
    }

    if (!titleEl) {
      titleEl = document.getElementById('escortwp-mp-modal-title');
    }

    if (!subtitleEl && modal) {
      subtitleEl = modal.querySelector('.escortwp-mp-modal-subtitle');
    }

    if (!statusEl) {
      statusEl = document.getElementById('escortwp-mp-modal-status');
    }

    if (!qrEl) {
      qrEl = document.getElementById('escortwp-mp-modal-qr');
    }

    if (!codeEl) {
      codeEl = document.getElementById('escortwp-mp-modal-code');
    }

    if (!noteEl) {
      noteEl = document.getElementById('escortwp-mp-modal-footer-note');
    }

    if (!copyButton) {
      copyButton = document.getElementById('escortwp-mp-copy-button');
    }
  }

  function setModalOpen(open) {
    resolveElements();
    if (!modal) return;

    modal.hidden = !open;
    modal.setAttribute('aria-hidden', open ? 'false' : 'true');
    document.body.classList.toggle('escortwp-mp-modal-open', open);

    if (!open) {
      window.clearTimeout(pollTimer);
      pollTimer = null;
      currentPaymentId = 0;
    }
  }

  function setStatus(status, text) {
    resolveElements();
    if (!statusEl) return;

    statusEl.className = 'escortwp-mp-modal-status is-' + status;
    statusEl.textContent = text;
  }

  function setLoading(button) {
    if (!button) return;

    button.dataset.originalText = button.textContent;
    button.disabled = true;
    button.textContent = cfg.strings.loading;
  }

  function clearLoading(button) {
    if (!button) return;

    button.disabled = false;
    if (button.dataset.originalText) {
      button.textContent = button.dataset.originalText;
    }
  }

  function formatTimestamp(ts) {
    if (!ts) return '';

    try {
      return new Date(ts * 1000).toLocaleString('pt-BR');
    } catch (error) {
      return '';
    }
  }

  function renderPayment(data, planKey) {
    resolveElements();
    if (!data) return;

    currentPaymentId = Number(data.id || 0);

    const titleMap = {
      premium: cfg.strings.modalTitlePremium,
      featured_boost: cfg.strings.modalTitleBoost
    };

    if (titleEl) {
      titleEl.textContent = titleMap[planKey] || cfg.strings.pending;
    }

    if (subtitleEl) {
      subtitleEl.textContent = cfg.strings.helpText;
    }

    setStatus(data.status || 'pending', data.status_label || cfg.strings.pending);

    if (qrEl) {
      qrEl.src = data.qr_code_base64 ? 'data:image/png;base64,' + data.qr_code_base64 : '';
      qrEl.style.display = data.qr_code_base64 ? 'block' : 'none';
    }

    if (codeEl) {
      codeEl.value = data.qr_code || '';
    }

    if (noteEl) {
      if (data.status === 'approved') {
        noteEl.textContent = 'Pagamento aprovado. O painel será atualizado em instantes.';
      } else if (data.status === 'rejected' || data.status === 'cancelled' || data.status === 'refunded') {
        noteEl.textContent = 'O pagamento não foi aprovado. Gere um novo PIX para continuar.';
      } else {
        const expiresAt = formatTimestamp(data.qr_expires_at);
        noteEl.textContent = expiresAt
          ? cfg.strings.awaitingText + ' PIX válido até ' + expiresAt + '.'
          : cfg.strings.awaitingText;
      }
    }

    setModalOpen(true);
    startPolling(planKey);
  }

  async function apiRequest(path, options) {
    const response = await fetch(cfg.restBase + path, Object.assign({
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
        'X-WP-Nonce': cfg.nonce
      }
    }, options || {}));

    const raw = await response.text();
    let data = {};

    if (raw) {
      const normalizedRaw = raw.replace(/^\uFEFF+/, '').trim();

      if (normalizedRaw) {
        try {
          data = JSON.parse(normalizedRaw);
        } catch (error) {
          data = {};
        }
      }
    }

    if (!response.ok) {
      throw new Error(data.message || cfg.strings.genericError);
    }

    return data;
  }

  function startPolling(planKey) {
    if (!currentPaymentId) return;
    window.clearTimeout(pollTimer);

    const tick = async function () {
      try {
        const data = await apiRequest('/' + currentPaymentId, { method: 'GET' });
        renderPayment(data, planKey);

        if (data.status === 'approved') {
          window.setTimeout(function () {
            window.location.reload();
          }, 1500);
          return;
        }

        if (['rejected', 'cancelled', 'refunded'].includes(data.status)) {
          return;
        }
      } catch (error) {
        if (noteEl) {
          noteEl.textContent = cfg.strings.pollError;
        }
      }

      pollTimer = window.setTimeout(tick, 5000);
    };

    pollTimer = window.setTimeout(tick, 5000);
  }

  async function handleTriggerClick(button) {
    resolveElements();

    const profileId = Number(button.getAttribute('data-profile-id') || 0);
    const planKey = button.getAttribute('data-plan-key') || '';
    if (!profileId || !planKey) return;

    try {
      setLoading(button);
      const data = await apiRequest('/pix', {
        method: 'POST',
        body: JSON.stringify({
          profile_id: profileId,
          plan_key: planKey
        })
      });

      renderPayment(data, planKey);
    } catch (error) {
      setStatus('rejected', error.message || cfg.strings.genericError);
      if (noteEl) {
        noteEl.textContent = '';
      }
      setModalOpen(true);
    } finally {
      clearLoading(button);
    }
  }

  document.addEventListener('click', function (event) {
    resolveElements();

    const trigger = event.target.closest('.escortwp-mp-payment-trigger');
    if (trigger) {
      event.preventDefault();
      handleTriggerClick(trigger);
      return;
    }

    if (event.target.closest('[data-mp-close="1"]')) {
      event.preventDefault();
      setModalOpen(false);
    }
  });

  resolveElements();
  if (copyButton) {
    copyButton.addEventListener('click', async function () {
      if (!codeEl || !codeEl.value) return;

      try {
        await navigator.clipboard.writeText(codeEl.value);
        copyButton.textContent = cfg.strings.copied;
        window.setTimeout(function () {
          copyButton.textContent = cfg.strings.copy;
        }, 1800);
      } catch (error) {
        codeEl.select();
        document.execCommand('copy');
      }
    });
  }

  function consumeAutoStartQuery() {
    try {
      const url = new URL(window.location.href);
      if (!url.searchParams.has('start_plan') && !url.searchParams.has('from_registration')) {
        return;
      }

      url.searchParams.delete('start_plan');
      url.searchParams.delete('from_registration');
      const nextUrl = url.pathname + (url.search ? url.search : '') + (url.hash ? url.hash : '');
      window.history.replaceState({}, document.title, nextUrl);
    } catch (error) {
      // no-op
    }
  }

  function maybeAutoStartPix() {
    const planKey = cfg.autoStartPlanKey || '';
    if (!['premium', 'featured_boost'].includes(planKey)) {
      return;
    }

    const trigger = document.querySelector('.escortwp-mp-payment-trigger[data-plan-key="' + planKey + '"]');
    if (!trigger) {
      return;
    }

    consumeAutoStartQuery();

    const planPanel = document.getElementById('planos-anuncio');
    if (planPanel && typeof planPanel.scrollIntoView === 'function') {
      planPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    window.setTimeout(function () {
      trigger.click();
    }, 450);
  }

  maybeAutoStartPix();
})();
