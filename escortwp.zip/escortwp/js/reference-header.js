(function () {
    var compactBreakpoint = 1220;

    function isCompactNav() {
        return window.innerWidth <= compactBreakpoint;
    }

    function resetMenu(nav, toggles) {
        nav.classList.remove('menu-open');
        toggles.forEach(function (toggle) {
            toggle.setAttribute('aria-expanded', 'false');
            var parent = toggle.closest('li');
            if (parent) {
                parent.classList.remove('is-open');
            }
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        var nav = document.querySelector('.reference-header-nav');
        if (!nav) {
            return;
        }

        var menuToggle = nav.querySelector('.reference-menu-toggle');
        var submenuToggles = Array.prototype.slice.call(nav.querySelectorAll('.reference-submenu-toggle'));

        if (menuToggle) {
            menuToggle.addEventListener('click', function () {
                var isOpen = nav.classList.toggle('menu-open');
                menuToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
            });
        }

        submenuToggles.forEach(function (toggle) {
            toggle.addEventListener('click', function (event) {
                if (!isCompactNav()) {
                    return;
                }

                event.preventDefault();
                event.stopPropagation();

                var parent = toggle.closest('li');
                if (!parent) {
                    return;
                }

                var isOpen = parent.classList.contains('is-open');
                submenuToggles.forEach(function (button) {
                    button.setAttribute('aria-expanded', 'false');
                    var buttonParent = button.closest('li');
                    if (buttonParent && buttonParent !== parent) {
                        buttonParent.classList.remove('is-open');
                    }
                });

                parent.classList.toggle('is-open', !isOpen);
                toggle.setAttribute('aria-expanded', !isOpen ? 'true' : 'false');
            });
        });

        document.addEventListener('click', function (event) {
            if (!nav.contains(event.target) && isCompactNav()) {
                resetMenu(nav, submenuToggles);
                if (menuToggle) {
                    menuToggle.setAttribute('aria-expanded', 'false');
                }
            }
        });

        window.addEventListener('resize', function () {
            if (!isCompactNav()) {
                resetMenu(nav, submenuToggles);
                if (menuToggle) {
                    menuToggle.setAttribute('aria-expanded', 'false');
                }
            }
        });
    });
})();
