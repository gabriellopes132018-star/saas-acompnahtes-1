(function ($) {
	var checkoutConfig = window.escortwpCheckoutBrazil || {};

	function onlyDigits(value) {
		return (value || '').replace(/\D+/g, '');
	}

	function maskPostcode(value) {
		var digits = onlyDigits(value).slice(0, 8);
		if (digits.length > 5) {
			return digits.slice(0, 5) + '-' + digits.slice(5);
		}
		return digits;
	}

	function maskPhone(value) {
		var digits = onlyDigits(value).slice(0, 11);
		if (digits.length <= 2) {
			return digits ? '(' + digits : '';
		}
		if (digits.length <= 6) {
			return '(' + digits.slice(0, 2) + ') ' + digits.slice(2);
		}
		if (digits.length <= 10) {
			return '(' + digits.slice(0, 2) + ') ' + digits.slice(2, 6) + '-' + digits.slice(6);
		}
		return '(' + digits.slice(0, 2) + ') ' + digits.slice(2, 7) + '-' + digits.slice(7);
	}

	function maskCpfCnpj(value) {
		var digits = onlyDigits(value).slice(0, 14);
		if (digits.length <= 11) {
			return digits
				.replace(/(\d{3})(\d)/, '$1.$2')
				.replace(/(\d{3})(\d)/, '$1.$2')
				.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
		}
		return digits
			.replace(/^(\d{2})(\d)/, '$1.$2')
			.replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3')
			.replace(/\.(\d{3})(\d)/, '.$1/$2')
			.replace(/(\d{4})(\d)/, '$1-$2');
	}

	function forceBrazilCountry() {
		var $country = $('#billing_country');
		if ($country.length) {
			$country.val('BR').trigger('change');
			$country.closest('.form-row').hide();
		}
	}

	function forceNativeStateSelect() {
		var $state = $('#billing_state');
		if (!$state.length) {
			return;
		}

		if ($state.hasClass('select2-hidden-accessible') && $.fn.selectWoo) {
			try {
				$state.selectWoo('destroy');
			} catch (error) {
				// Keep native select fallback even if selectWoo destroy fails.
			}
		}

		$state.removeClass('select2-hidden-accessible').show();
		$state.css({
			width: '100%',
			display: 'block'
		});

		$state.closest('.woocommerce-input-wrapper').css({
			display: 'block',
			width: '100%'
		});

		$state.parent().find('.select2, .selection, .select2-container').remove();
	}

	function stabilizeMercadoPagoMethods() {
		if (checkoutConfig.hasMercadoPagoPublicKey) {
			return;
		}

		var $customMethod = $('#payment_method_woo-mercado-pago-custom');
		var $customMethodItem = $customMethod.closest('li.payment_method_woo-mercado-pago-custom');
		var $pixMethod = $('#payment_method_woo-mercado-pago-pix');

		if ($customMethodItem.length) {
			$customMethodItem
				.addClass('escortwp-payment-method-disabled')
				.attr('aria-disabled', 'true');

			if (!$customMethodItem.find('.escortwp-payment-method-warning').length) {
				$customMethodItem.append(
					$('<div/>', {
						'class': 'escortwp-payment-method-warning',
						text: checkoutConfig.cardUnavailableMessage || 'Cartão temporariamente indisponível.'
					})
				);
			}
		}

		$customMethod.prop('checked', false).prop('disabled', true);
		$customMethodItem.find('.payment_box').hide();

		if ($pixMethod.length) {
			$pixMethod.prop('checked', true).trigger('change');
		}
	}

	function applyMasks() {
		var $postcode = $('#billing_postcode');
		var $phone = $('#billing_phone');
		var $cpfCnpj = $('#billing_cpf_cnpj');

		if ($postcode.length) {
			$postcode.val(maskPostcode($postcode.val()));
			$postcode.on('input', function () {
				this.value = maskPostcode(this.value);
			});
		}

		if ($phone.length) {
			$phone.val(maskPhone($phone.val()));
			$phone.on('input', function () {
				this.value = maskPhone(this.value);
			});
		}

		if ($cpfCnpj.length) {
			$cpfCnpj.val(maskCpfCnpj($cpfCnpj.val()));
			$cpfCnpj.on('input', function () {
				this.value = maskCpfCnpj(this.value);
			});
		}
	}

	function initialize() {
		forceBrazilCountry();
		forceNativeStateSelect();
		applyMasks();
		stabilizeMercadoPagoMethods();
	}

	$(document).ready(initialize);
	$(document.body).on('updated_checkout', initialize);
})(jQuery);
