(function () {
    'use strict';

    var modal = document.querySelector('[data-age-gate]');
    if (!modal) {
        return;
    }

    var storageKey = 'escortwp_age_gate_until';
    var rememberFor = 30 * 24 * 60 * 60 * 1000;

    try {
        if (window.localStorage) {
            var savedUntil = parseInt(window.localStorage.getItem(storageKey) || '0', 10);
            if (savedUntil && savedUntil > Date.now()) {
                document.cookie = 'escortwp_age_verified=1; path=/; max-age=' + (30 * 24 * 60 * 60) + '; SameSite=Lax';
            }
        }
    } catch (error) {
        // Ignore localStorage restrictions.
    }

    document.body.classList.add('escortwp-age-gate-open');
    window.requestAnimationFrame(function () {
        modal.classList.add('is-visible');
    });

    var dialog = modal.querySelector('.escortwp-age-gate__dialog');
    if (dialog && typeof dialog.focus === 'function') {
        dialog.focus();
    }

    var confirmForm = modal.querySelector('[data-age-gate-confirm]');
    if (confirmForm) {
        confirmForm.addEventListener('submit', function () {
            try {
                if (window.localStorage) {
                    window.localStorage.setItem(storageKey, String(Date.now() + rememberFor));
                }
            } catch (error) {
                // Ignore localStorage restrictions.
            }
        });
    }

    var declineLink = modal.querySelector('[data-age-gate-decline-link]');
    if (declineLink) {
        declineLink.addEventListener('click', function (event) {
            event.preventDefault();

            try {
                if (window.localStorage) {
                    window.localStorage.removeItem(storageKey);
                }
            } catch (error) {
                // Ignore localStorage restrictions.
            }

            document.cookie = 'escortwp_age_verified=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT; SameSite=Lax';
            document.cookie = 'tos18=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT; SameSite=Lax';

            window.location.replace(declineLink.getAttribute('href'));
        });
    }
})();
