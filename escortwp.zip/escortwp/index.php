<?php get_header(); ?>

<?php
$all_profiles_url = get_permalink(get_option('all_profiles_page_id'));
$premium_profiles_url = get_permalink(get_option('all_premium_profiles_page_id'));
$new_profiles_url = get_permalink(get_option('all_new_profiles_page_id'));

$all_profiles_url = $all_profiles_url ? $all_profiles_url : home_url('/');
$premium_profiles_url = $premium_profiles_url ? $premium_profiles_url : $all_profiles_url;
$new_profiles_url = $new_profiles_url ? $new_profiles_url : $all_profiles_url;
?>

<div class="reference-home-shell">
	<aside class="reference-home-sidebar reference-home-sidebar-left">
		<?php include get_template_directory() . '/home-country-list.php'; ?>
	</aside>

	<main class="reference-home-main">
		<div class="reference-home-body">
			<?php
			if (get_option('frontpageshowpremium') == 1) {
				$premium_args = array(
					'post_type' => $taxonomy_profile_url,
					'orderby' => 'meta_value_num',
					'meta_key' => 'premium_since',
					'meta_query' => array(
						array(
							'key' => 'premium',
							'value' => '1',
							'compare' => '=',
							'type' => 'NUMERIC',
						),
					),
					'posts_per_page' => max(4, (int) get_option('frontpageshowpremiumcols')) * 5,
				);
				$premium_profiles = new WP_Query($premium_args);
				if ($premium_profiles->have_posts()) :
					?>
					<div class="bodybox bodybox-homepage reference-home-showcase reference-home-showcase-premium">
						<h3 class="l"><?php esc_html_e('Área VIP', 'escortwp'); ?></h3>
						<a class="see-all-top pinkbutton rad25 r" href="<?php echo esc_url($premium_profiles_url); ?>"><?php esc_html_e('Ver área VIP', 'escortwp'); ?></a>
						<div class="clear"></div>
						<div class="reference-home-card-grid reference-home-card-grid-premium escortwp-profile-card-grid">
							<?php
							while ($premium_profiles->have_posts()) :
								$premium_profiles->the_post();
								include get_template_directory() . '/loop-show-profile.php';
							endwhile;
							?>
						</div>
						<div class="clear"></div>
						<a class="see-all-bottom pinkbutton rad25 text-center hide" href="<?php echo esc_url($premium_profiles_url); ?>"><?php esc_html_e('Ver área VIP', 'escortwp'); ?></a>
						<div class="see-more-button pinkbutton rad25 text-center hide"><?php esc_html_e('Ver mais', 'escortwp'); ?></div>
					</div>
					<?php
				endif;
				wp_reset_postdata();
			}
			?>

			<div class="bodybox bodybox-homepage reference-home-showcase reference-home-showcase-new">
				<h3 class="l"><?php esc_html_e('Novatas', 'escortwp'); ?></h3>
				<a class="see-all-top pinkbutton rad25 r" href="<?php echo esc_url($new_profiles_url); ?>"><?php esc_html_e('Ver novatas', 'escortwp'); ?></a>
				<div class="clear"></div>
				<div class="reference-home-card-grid reference-home-card-grid-new escortwp-profile-card-grid">
					<?php
					$new_args = array(
						'post_type' => $taxonomy_profile_url,
						'post_status' => 'publish',
						'orderby' => 'date',
						'order' => 'DESC',
						'posts_per_page' => max(4, (int) get_option('frontpageshownormalcols')) * 5,
					);

					$days_back = (int) get_option('newlabelperiod');
					if ($days_back < 1) {
						$days_back = 14;
					}

					$new_args['date_query'] = array(
						array(
							'after' => gmdate('Y-m-d H:i:s', strtotime('-' . $days_back . ' days')),
							'inclusive' => true,
						),
					);

					$new_profiles = new WP_Query($new_args);
					if ($new_profiles->have_posts()) :
						while ($new_profiles->have_posts()) :
							$new_profiles->the_post();
							include get_template_directory() . '/loop-show-profile.php';
						endwhile;
					else :
						printf(esc_html__('Ainda não há novas %s por aqui.', 'escortwp'), $taxonomy_profile_name_plural);
					endif;
					wp_reset_postdata();
					?>
				</div>
				<div class="clear"></div>
				<a class="see-all-bottom pinkbutton rad25 text-center hide" href="<?php echo esc_url($new_profiles_url); ?>"><?php esc_html_e('Ver novatas', 'escortwp'); ?></a>
				<div class="see-more-button pinkbutton rad25 text-center hide"><?php esc_html_e('Ver mais', 'escortwp'); ?></div>
			</div>

			<?php if (get_option('frontpageshownormal') == 1) { ?>
				<div class="bodybox bodybox-homepage reference-home-showcase reference-home-showcase-free">
					<h3 class="l"><?php esc_html_e('Acompanhantes', 'escortwp'); ?></h3>
					<a class="see-all-top pinkbutton rad25 r" href="<?php echo esc_url($all_profiles_url); ?>"><?php esc_html_e('Ver acompanhantes', 'escortwp'); ?></a>
					<div class="clear"></div>
					<div class="reference-home-card-grid reference-home-card-grid-free escortwp-profile-card-grid">
						<?php
						$free_args = array(
							'post_type' => $taxonomy_profile_url,
							'post_status' => 'publish',
							'orderby' => 'date',
							'order' => 'DESC',
							'meta_query' => array(
								array(
									'key' => 'premium',
									'value' => '0',
									'compare' => '=',
									'type' => 'NUMERIC',
								),
							),
							'posts_per_page' => max(4, (int) get_option('frontpageshownormalcols')) * 5,
						);
						$free_profiles = new WP_Query($free_args);
						if ($free_profiles->have_posts()) :
							while ($free_profiles->have_posts()) :
								$free_profiles->the_post();
								include get_template_directory() . '/loop-show-profile.php';
							endwhile;
						else :
							printf(esc_html__('Ainda não há %s por aqui.', 'escortwp'), $taxonomy_profile_name_plural);
						endif;
						wp_reset_postdata();
						?>
					</div>
					<div class="clear"></div>
					<a class="see-all-bottom pinkbutton rad25 text-center hide" href="<?php echo esc_url($all_profiles_url); ?>"><?php esc_html_e('Ver acompanhantes', 'escortwp'); ?></a>
					<div class="see-more-button pinkbutton rad25 text-center hide"><?php esc_html_e('Ver mais', 'escortwp'); ?></div>
				</div>
			<?php } ?>
		</div>
	</main>

	<aside class="reference-home-sidebar reference-home-sidebar-right">
		<?php include get_template_directory() . '/home-quicksearch.php'; ?>
	</aside>
</div>

<?php get_footer(); ?>
