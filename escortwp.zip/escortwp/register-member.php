<?php
/*
Template Name: Register - Member
*/

$current_user = wp_get_current_user();

if (is_user_logged_in() && !current_user_can('manage_options')) {
	escortwp_safe_template_redirect(escortwp_get_current_user_account_url(), home_url('/'));
}

$err = '';
$ok = '';
if (isset($_POST['action']) && $_POST['action'] === 'registermember') {
	include get_template_directory() . '/register-member-personal-info-process.php';
}

get_header();
?>

<div class="contentwrapper escortwp-auth-shell escortwp-auth-shell--editor">
	<div class="body escortwp-auth-main escortwp-auth-main--editor">
		<div class="bodybox registerform escortwp-workspace-box escortwp-workspace-box--member">
			<div class="escortwp-auth-header escortwp-auth-header--left">
				<div class="escortwp-auth-kicker"><?php _e('Conta de cliente', 'escortwp'); ?></div>
				<h3><?php _e('Cadastro de cliente', 'escortwp'); ?></h3>
				<p class="escortwp-register-intro"><?php _e('Esta conta é feita para navegar, favoritar perfis, enviar mensagens e acompanhar seus contatos no portal com clareza e segurança.', 'escortwp'); ?></p>
			</div>

			<nav class="escortwp-workspace-nav escortwp-workspace-nav--member" aria-label="<?php esc_attr_e('Seções do cadastro', 'escortwp'); ?>">
				<a href="#register-member-name"><?php _e('Dados básicos', 'escortwp'); ?></a>
				<a href="#register-member-email"><?php _e('E-mail', 'escortwp'); ?></a>
				<a href="#register-member-password"><?php _e('Senha', 'escortwp'); ?></a>
			</nav>

			<?php include get_template_directory() . '/register-member-personal-information-form.php'; ?>
			<div class="clear"></div>
		</div>
		<div class="clear"></div>
	</div>
</div>

<div class="clear"></div>
<?php get_footer(); ?>
