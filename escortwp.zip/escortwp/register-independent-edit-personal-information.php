<?php
/*
Template Name: Register Independent - Edit Personal Information
*/

global $taxonomy_profile_url, $taxonomy_location_url;
$current_user = wp_get_current_user();
if (!is_user_logged_in() || !escortwp_current_user_has_type($taxonomy_profile_url, $current_user->ID)) {
	wp_redirect(get_bloginfo('url'));
	exit;
}

$escort_post_id = (int) get_option('escortpostid' . $current_user->ID);
$escort_public_url = $escort_post_id ? get_permalink($escort_post_id) : '';

$err = '';
$ok = '';
if (isset($_POST['action']) && $_POST['action'] == 'register') {
	include get_template_directory() . '/register-independent-personal-info-process.php';
} else {
	$escort = get_post($escort_post_id);

	$aboutyou = $escort->post_content;
	$youremail = $current_user->user_email;
	$yourname = $current_user->display_name;

	$phone = get_post_meta($escort_post_id, 'phone', true);
	$phone_available_on = get_post_meta($escort_post_id, 'phone_available_on', true);
	$escortemail = get_post_meta($escort_post_id, 'escortemail', true);
	$website = get_post_meta($escort_post_id, 'website', true);
	$instagram = get_post_meta($escort_post_id, 'instagram', true);
	$snapchat = get_post_meta($escort_post_id, 'snapchat', true);
	$twitter = get_post_meta($escort_post_id, 'twitter', true);
	$facebook = get_post_meta($escort_post_id, 'facebook', true);

	$city_data = wp_get_post_terms($escort_post_id, $taxonomy_location_url);
	if ($city_data && !is_wp_error($city_data)) {
		if (get_option('locationdropdown') == '1') {
			$city = $city_data[0]->term_id;
		} else {
			$city = get_term($city_data[0]->term_id, $taxonomy_location_url);
			$city = $city_data[0]->name;
		}

		$state_data = get_term($city_data[0]->parent, $taxonomy_location_url);
		if ($state_data && !is_wp_error($state_data)) {
			if (get_option('locationdropdown') == '1') {
				$state = $state_data->term_id;
			} else {
				$state = get_term($state_data->term_id, $taxonomy_location_url);
				$state = $state_data->name;
			}
			$country_data = get_term($state_data->parent, $taxonomy_location_url);
			if (!is_wp_error($country_data)) {
				$country = $country_data->term_id;
			} else {
				$country = $state_data->term_id;
				unset($state);
			}
		}
	}

	$gender = get_post_meta($escort_post_id, 'gender', true);
	$birthday = get_post_meta($escort_post_id, 'birthday', true);
	$birthday = explode('-', $birthday);
	$dateyear = $birthday[0];
	$datemonth = $birthday[1];
	$dateday = $birthday[2];
	$ethnicity = get_post_meta($escort_post_id, 'ethnicity', true);
	$haircolor = get_post_meta($escort_post_id, 'haircolor', true);
	$hairlength = get_post_meta($escort_post_id, 'hairlength', true);
	$bustsize = get_post_meta($escort_post_id, 'bustsize', true);
	$height = get_post_meta($escort_post_id, 'height', true);
	$height2 = get_post_meta($escort_post_id, 'height2', true);
	$weight = get_post_meta($escort_post_id, 'weight', true);
	$build = get_post_meta($escort_post_id, 'build', true);
	$looks = get_post_meta($escort_post_id, 'looks', true);
	$smoker = get_post_meta($escort_post_id, 'smoker', true);
	$availability = get_post_meta($escort_post_id, 'availability', true);
	$language1 = get_post_meta($escort_post_id, 'language1', true);
	$language1level = get_post_meta($escort_post_id, 'language1level', true);
	$language2 = get_post_meta($escort_post_id, 'language2', true);
	$language2level = get_post_meta($escort_post_id, 'language2level', true);
	$language3 = get_post_meta($escort_post_id, 'language3', true);
	$language3level = get_post_meta($escort_post_id, 'language3level', true);
	$currency = get_post_meta($escort_post_id, 'currency', true);
	$rate30min_incall = get_post_meta($escort_post_id, 'rate30min_incall', true);
	$rate1h_incall = get_post_meta($escort_post_id, 'rate1h_incall', true);
	$rate2h_incall = get_post_meta($escort_post_id, 'rate2h_incall', true);
	$rate3h_incall = get_post_meta($escort_post_id, 'rate3h_incall', true);
	$rate6h_incall = get_post_meta($escort_post_id, 'rate6h_incall', true);
	$rate12h_incall = get_post_meta($escort_post_id, 'rate12h_incall', true);
	$rate24h_incall = get_post_meta($escort_post_id, 'rate24h_incall', true);
	$rate30min_outcall = get_post_meta($escort_post_id, 'rate30min_outcall', true);
	$rate1h_outcall = get_post_meta($escort_post_id, 'rate1h_outcall', true);
	$rate2h_outcall = get_post_meta($escort_post_id, 'rate2h_outcall', true);
	$rate3h_outcall = get_post_meta($escort_post_id, 'rate3h_outcall', true);
	$rate6h_outcall = get_post_meta($escort_post_id, 'rate6h_outcall', true);
	$rate12h_outcall = get_post_meta($escort_post_id, 'rate12h_outcall', true);
	$rate24h_outcall = get_post_meta($escort_post_id, 'rate24h_outcall', true);
	$services = get_post_meta($escort_post_id, 'services');
	$services = $services[0];
	$extraservices = get_post_meta($escort_post_id, 'extraservices', true);
	$secret = get_post_meta($escort_post_id, 'secret', true);
	$upload_folder = get_post_meta($escort_post_id, 'upload_folder', true);
	$education = get_post_meta($escort_post_id, 'education', true);
	$sports = get_post_meta($escort_post_id, 'sports', true);
	$hobbies = get_post_meta($escort_post_id, 'hobbies', true);
	$zodiacsign = get_post_meta($escort_post_id, 'zodiacsign', true);
	$sexualorientation = get_post_meta($escort_post_id, 'sexualorientation', true);
	$occupation = get_post_meta($escort_post_id, 'occupation', true);
}
$onboarding_step = isset($_GET['onboarding']) ? sanitize_text_field($_GET['onboarding']) : '';
if($onboarding_step == 'done') {
	wp_redirect(get_permalink(get_option('escort_edit_personal_info_page_id')));
	exit;
}

$workspace_class = "escortwp-workspace-box escortwp-workspace-box--dashboard";
if ($onboarding_step === 'fotos') {
    $workspace_class .= " escortwp-workspace-onboarding-fotos";
} elseif ($onboarding_step === 'video') {
    $workspace_class .= " escortwp-workspace-onboarding-video";
}

get_header();
?>

<style>
/* Forçar estilo das miniaturas para evitar bug de imagem gigante */
.escortwp-legacy-gallery-disabled .profile-img-thumb {
    position: relative;
    float: left;
    width: 154px;
    height: 180px;
    overflow: hidden;
    margin-right: 15px;
    margin-bottom: 15px;
    border: 3px solid #eee;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0,0,0,0.05);
}
.escortwp-legacy-gallery-disabled .profile-img-thumb img {
    width: 100%;
    height: 100%;
    object-fit: cover !important;
}
.escortwp-legacy-gallery-disabled .profile-img-thumb .edit-buttons {
    position: absolute;
    bottom: 5px;
    right: 5px;
    z-index: 10;
    display: flex;
    gap: 5px;
}
.escortwp-legacy-gallery-disabled .profile-img-thumb .edit-buttons .btn-action {
    background: rgba(0,0,0,0.78);
    color: #fff;
    padding: 6px 12px;
    border-radius: 20px;
    cursor: pointer;
    font-size: 13px;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 5px;
    transition: all 0.2s;
}
.escortwp-legacy-gallery-disabled .profile-img-thumb .edit-buttons .btn-action:hover {
    background: #ff0066;
}
.escortwp-legacy-gallery-disabled .profile-img-thumb .edit-buttons .btn-action i.icon {
    margin: 0;
    font-size: 14px;
}
.select2-container { width: 100% !important; }
.profile-page-no-media-wrapper-photos.col50 {
    width: 100% !important; /* expandir para 100% se painel de fotos ficar esmagado */
}
<?php if ($onboarding_step === 'fotos' || $onboarding_step === 'video') : ?>
/* Esconder inicialmente o formulário de dados de conta enquanto estiver no Onboarding, 
   permitindo exibição via JS caso mude de aba */
#register-form-main-container {
    display: none;
}
<?php endif; ?>
</style>

<style>
.escortwp-legacy-gallery-disabled .escortwp-managed-gallery-grid .profile-img-thumb-wrapper {
    width: auto !important;
    float: none !important;
    margin: 0 !important;
}

.escortwp-legacy-gallery-disabled .escortwp-managed-gallery-grid {
    display: grid !important;
    grid-template-columns: repeat(auto-fit, minmax(170px, 1fr));
    gap: 16px;
    align-items: stretch;
}

.escortwp-legacy-gallery-disabled .escortwp-managed-gallery-grid .profile-img-thumb {
    position: relative;
    float: none !important;
    width: 100% !important;
    height: auto !important;
    aspect-ratio: 3 / 4;
    overflow: hidden;
    margin: 0 !important;
    border: 1px solid rgba(222, 194, 162, 0.92) !important;
    border-radius: 22px !important;
    background: #ffffff;
    box-shadow: 0 18px 40px rgba(78, 47, 28, 0.12);
}

.escortwp-legacy-gallery-disabled .escortwp-managed-gallery-grid .profile-img-thumb img {
    width: 100% !important;
    height: 100% !important;
    object-fit: cover !important;
}

.escortwp-legacy-gallery-disabled .escortwp-managed-gallery-grid .profile-img-thumb .edit-buttons {
    position: absolute;
    top: 12px;
    right: 12px;
    bottom: auto;
    display: flex;
    flex-direction: column;
    gap: 8px;
    z-index: 12;
}

.escortwp-legacy-gallery-disabled .escortwp-managed-gallery-grid .profile-img-thumb .btn-action {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    min-height: 34px;
    padding: 0 14px;
    border-radius: 999px;
    background: rgba(61, 49, 43, 0.88);
    color: #fff;
    font-size: 12px;
    font-weight: 700;
    line-height: 1;
    cursor: pointer;
    box-shadow: 0 10px 22px rgba(61, 49, 43, 0.18);
}

.escortwp-legacy-gallery-disabled .escortwp-managed-gallery-grid .profile-img-thumb .btn-action.button-main-image {
    background: rgba(114, 136, 108, 0.94);
}

.escortwp-legacy-gallery-disabled .escortwp-managed-gallery-grid .profile-img-thumb .btn-action.button-delete {
    background: rgba(178, 108, 88, 0.94);
}

.escortwp-legacy-gallery-disabled .escortwp-managed-gallery-grid .escortwp-managed-gallery-badge {
    position: absolute;
    left: 12px;
    top: 12px;
    z-index: 12;
    display: inline-flex;
    align-items: center;
    min-height: 30px;
    padding: 0 12px;
    border-radius: 999px;
    background: rgba(255, 249, 244, 0.95);
    color: #7f5b42;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    box-shadow: 0 10px 20px rgba(70, 41, 24, 0.12);
}

.escortwp-legacy-gallery-disabled .escortwp-gallery-empty {
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 160px;
    padding: 20px;
    border: 1px dashed rgba(200, 168, 137, 0.6);
    border-radius: 22px;
    color: #7b5e4b;
    background: rgba(255, 250, 245, 0.75);
    text-align: center;
    line-height: 1.65;
}

@media (max-width: 767px) {
    .escortwp-legacy-gallery-disabled .escortwp-managed-gallery-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 12px;
    }

    .escortwp-legacy-gallery-disabled .escortwp-managed-gallery-grid .profile-img-thumb .edit-buttons {
        top: 10px;
        right: 10px;
    }

    .escortwp-legacy-gallery-disabled .escortwp-managed-gallery-grid .profile-img-thumb .btn-action {
        min-height: 30px;
        padding: 0 10px;
        font-size: 11px;
    }

    .escortwp-legacy-gallery-disabled .escortwp-managed-gallery-grid .escortwp-managed-gallery-badge {
        top: 10px;
        left: 10px;
        min-height: 28px;
        padding: 0 10px;
        font-size: 10px;
    }
}
</style>

<div class="contentwrapper escortwp-auth-shell escortwp-auth-shell--editor">
	<div class="body escortwp-auth-main escortwp-auth-main--editor">
		<div class="bodybox registerform <?php echo $workspace_class; ?>">
			<div class="escortwp-auth-header escortwp-auth-header--left escortwp-auth-header--compact">
				<div class="escortwp-auth-kicker"><?php _e('Painel da acompanhante', 'escortwp'); ?></div>
				<h3><?php _e('Painel do anúncio', 'escortwp'); ?></h3>
				<p class="escortwp-register-intro"><?php _e('Ajuste os dados essenciais do anúncio com uma navegação mais clara e profissional.', 'escortwp'); ?></p>
			</div>

			<?php
			if (!empty($escort_post_id) && function_exists('escortwp_render_profile_plan_management_panel_v2')) {
				echo escortwp_render_profile_plan_management_panel_v2($escort_post_id, array(
					'title' => __('Planos e destaque', 'escortwp'),
					'description' => __('Veja o status atual e ative o mensal ou o destaque semanal com menos ruído visual.', 'escortwp'),
					'panel_id' => 'planos-anuncio',
				));
			}
			if (!empty($escort_post_id) && function_exists('escortwp_render_video_verification_panel')) {
				echo escortwp_render_video_verification_panel($escort_post_id);
			}
			?>

			<?php if (!empty($escort_post_id)) { 
				$photos = get_children( array('post_parent' => $escort_post_id, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => 'ASC', 'orderby' => 'menu_order ID') );
				$photos_left = get_option('maximgupload') - count($photos); $photos_left = (int)$photos_left;
				if ($photos_left < 0) $photos_left = 0;
	
				$videos = get_children( array('post_parent' => $escort_post_id, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'video', 'order' => 'ASC', 'orderby' => 'menu_order ID') );
				$videos_left = get_option('maxvideoupload') - count($videos); $videos_left = (int)$videos_left;
				if ($videos_left < 0) $videos_left = 0;
			?>
				<section class="escortwp-dashboard-media-panel escortwp-form-section-heading" id="aba-fotos">
					<div class="escortwp-dashboard-media-panel__copy">
						<div class="escortwp-auth-kicker"><?php _e('Fotos do anúncio', 'escortwp'); ?></div>
						<h4><?php _e('Organizar fotos', 'escortwp'); ?></h4>
						<p><?php _e('Envie <b>fotos verticais (mínimo de 800x1200px)</b> com boa iluminação.', 'escortwp'); ?></p>
					</div>

					<div class="profile-media-tools escortwp-dashboard-media-tools">
						<div class="profile-page-no-media-wrapper profile-page-no-media-wrapper-photos <?=(get_option('allowvideoupload') == "1") ? " col50 l" : " col100"?>">
							<div class="profile-page-no-media profile-page-no-photos profile-page-no-photos-click rad3 col100 text-center" id="profile-page-no-photos">
								<div class="icon icon-picture"></div>
								<div class="for-browsers" data-mobile-text="<?php _e('Toque aqui para enviar fotos','escortwp'); ?>">
									<p><?php _e('Arraste as fotos ou <u>clique para selecionar</u>','escortwp'); ?></p>
								</div>
								<p class="max-photos"><?php printf(esc_html__('Limite: %s fotos','escortwp'), '<b>'.$photos_left.'</b>'); ?></p>
								<div class="clear"></div>
							</div>
							<div class="profile_photos_button_container hide"><input id="profile_photos_upload" name="file_upload" type="file" /></div>
						</div>

						<?php if(get_option('allowvideoupload') == "1") { ?>
						<div class="profile-page-no-media-wrapper profile-page-no-media-wrapper-videos col50 r">
							<div class="profile-page-no-media profile-page-no-videos profile-page-no-videos-click rad3 col100 text-center" id="profile-page-no-videos">
								<div class="icon icon-film"></div>
								<div class="for-browsers" data-mobile-text="<?php _e('Toque aqui para enviar vídeos','escortwp'); ?>">
									<p><?php _e('Arraste vídeos ou <u>clique para selecionar</u>','escortwp'); ?></p>
								</div>
								<p class="max-videos"><?php printf(esc_html__('Limite: %s vídeos','escortwp'), '<b>'.$videos_left.'</b>'); ?></p>
								<div class="clear"></div>
							</div>
							<div class="profile_videos_button_container hide"><input id="profile_videos_upload" name="file_upload" type="file" /></div>
						</div>
						<?php } ?>
					</div>
					<div class="clear20"></div>

					<div class="thumbs thumbs-count-<?php echo count($photos); ?> escortwp-managed-gallery-grid escortwp-dashboard-gallery-grid">
					<?php
					$main_image_id = get_post_meta($escort_post_id, "main_image_id", true);
					foreach ($photos as $photo) {
						$photo_th_url = wp_get_attachment_image_src($photo->ID, 'profile-thumb');
						$style_main_img_btn = ($photo->ID == $main_image_id) ? ' style="display: none"' : "";
						$cover_badge = ($photo->ID == $main_image_id) ? '<span class="escortwp-managed-gallery-badge">Capa atual</span>' : '<span class="escortwp-managed-gallery-badge" style="display:none">Capa atual</span>';
						$imagebuttons = '<span class="edit-buttons"><button type="button" class="btn-action button-main-image"'.$style_main_img_btn.'><i class="icon icon-ok"></i><span>Capa</span></button><button type="button" class="btn-action button-delete"><i class="icon icon-cancel"></i><span>Excluir</span></button></span>';
						echo '<div class="profile-img-thumb-wrapper escortwp-managed-gallery-card'.(($photo->ID == $main_image_id) ? ' is-main' : '').'"><div class="profile-img-thumb girl-single-thumb-manage" id="'.$photo->ID.'">';
						echo 	$cover_badge;
						echo 	$imagebuttons;
						echo 	'<img src="'.$photo_th_url[0].'" class="mobile-ready-img rad3" />';
						echo '</div></div>'."\n";
					}
					?>
					</div><div class="clear"></div>

					<?php 
					$userid = $current_user->ID;
					global $post;
					$original_post = $post;
					$post = get_post($escort_post_id);
					setup_postdata($post);

					include (get_template_directory() . '/register-agency-manage-escorts-option-buttons.php'); 

					wp_reset_postdata();
					$post = $original_post;
					?>
				</section>
				<?php } ?>
			<nav class="escortwp-workspace-nav">
				<a href="#planos-anuncio" class="active"><?php _e('Planos', 'escortwp'); ?></a>
				<a href="#aba-verificacao"><?php _e('Verificação', 'escortwp'); ?></a>
				<a href="#aba-fotos"><?php _e('Fotos', 'escortwp'); ?></a>
				<a href="#aba-conta"><?php _e('Conta', 'escortwp'); ?></a>
			</nav>

			<?php
			if ($ok) {
				echo '<div class="ok rad5 escortwp-workspace-success">' . __('Perfil atualizado com sucesso.', 'escortwp') . '</div>';
			}
			include get_template_directory() . '/register-independent-personal-information-form.php';
			?>
			<div class="clear"></div>
		</div>
		<div class="clear"></div>
	</div>
</div>

<div class="clear"></div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script>
jQuery(document).ready(function($) {
    var $navLinks = $('.escortwp-workspace-nav a');

    function initDashTabs() {
        var preselected = window.location.hash || '#aba-conta';
        if ($(preselected).length === 0) preselected = '#aba-conta';
        var onboardingStep = '<?php echo esc_js($onboarding_step); ?>';

        if (onboardingStep === 'fotos') {
            $('.escortwp-workspace-nav').hide();
            preselected = '#aba-fotos';
            showTab(preselected);
            if ($('#onboarding-next-video').length === 0) {
                $('#aba-fotos').append('<div class="clear20"></div><div class="text-center"><a href="?onboarding=video" id="onboarding-next-video" class="pinkbutton rad25" style="display:inline-block; padding: 15px 30px; font-size:16px;">Ir para o próximo passo (Vídeo Opcional)</a></div><div class="clear20"></div>');
            }
            $('#register_submit').hide();
        } else if (onboardingStep === 'video') {
            $('.escortwp-workspace-nav').hide();
            preselected = '#aba-verificacao';
            showTab(preselected);
            if ($('#onboarding-finish').length === 0) {
                $('#aba-verificacao').append('<div class="clear20"></div><div class="text-center"><a href="?onboarding=done" id="onboarding-finish" class="pinkbutton rad25" style="display:inline-block; padding: 15px 30px; font-size:16px;">Finalizar etapa e ir para o Painel</a></div><div class="clear20"></div>');
            }
            $('#register_submit').hide();
        } else {
            showTab(preselected);
        }
    }

    function showTab(anchorHref) {
        $navLinks.removeClass('active');
        $('.escortwp-workspace-nav a[href="' + anchorHref + '"]').addClass('active');

        var targetId = anchorHref.replace('#', '');
        
        $('#planos-anuncio, #aba-verificacao, #aba-fotos').hide();
        
        if (targetId == 'planos-anuncio' || targetId == 'aba-verificacao' || targetId == 'aba-fotos') {
            $('#' + targetId).show();
            $('#register-form-main-container').hide();
        } else {
            $('#register-form-main-container').show();
            
            // The main form is a single long vertical list.
            // Ensure all children are visible so the user can scroll normally.
            $('#register-form-main-container').children().show();
            
            // Trigger window resize to force TinyMCE and Select2 to recalculate
            setTimeout(function() {
                $(window).trigger('resize');
            }, 50);
        }
    }

    $navLinks.on('click', function(e) {
        e.preventDefault();
        var target = $(this).attr('href');
        history.pushState(null, null, target);
        showTab(target);
        
        // Native browser scroll works regardless of parent overflow contexts
        setTimeout(function() {
            var targetEl = document.querySelector(target);
            if (targetEl && targetEl.scrollIntoView) {
                // block: 'start' aligns the top of the element to the top of the viewpoint
                targetEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
                
                // Fallback for tricky fixed headers or older browsers
                var jQueryTarget = $(target);
                if (jQueryTarget.length && $('html, body').scrollTop() === 0) {
                     $('html, body').animate({ scrollTop: jQueryTarget.offset().top - 40 }, 300);
                }
            }
        }, 100);
    });

    
    $('#register-form-main-container').on('submit', function(e) {
        var firstInvalid = $(this).find(':invalid').first();
        if (firstInvalid.length > 0) {
            // Find which tab heading is before this element
            // We can iterate previous siblings to find the closest .escortwp-form-section-heading
            var section = firstInvalid.parent().prevAll('.escortwp-form-section-heading').first();
            if (section.length > 0) {
                showTab('#' + section.attr('id'));
                // Smooth scroll to the field
                $('html, body').animate({
                    scrollTop: firstInvalid.offset().top - 100
                }, 300);
            }
        }
        
        // Unmask rates before submit so PHP (int) cast works properly
        $(this).find('input[name^="rate"]').each(function() {
            var val = $(this).val();
            if (val) {
                val = val.replace(/\./g, '').split(',')[0];
                $(this).val(val);
            }
        });
    });

	// Input masks
	if($.fn.mask) {
		$('input[name="phone"]').attr('type', 'text').mask('(00) 00000-0000');
		$('input[name="height"]').attr('type', 'text').mask('000');
		$('input[name="weight"]').attr('type', 'text').mask('000');
		$('input[name^="rate"]').attr('type', 'text').mask('#.##0,00', {reverse: true});
	}

    initDashTabs();
});
</script>

<?php get_footer(); ?>
