<?php

if (!defined('ABSPATH')) {
	exit;
}

function escortwp_wc_option_update_if_needed($option_name, $value) {
	$current = get_option($option_name, null);
	if ($current !== $value) {
		update_option($option_name, $value, false);
	}
}

function escortwp_wc_is_checkout_or_cart_page() {
	if (is_admin() && !wp_doing_ajax()) {
		return false;
	}

	return (function_exists('is_checkout') && is_checkout()) || (function_exists('is_cart') && is_cart());
}

function escortwp_get_mercadopago_public_key($sandbox = null) {
	if (null === $sandbox) {
		$sandbox = defined('MERCADO_PAGO_SANDBOX') && MERCADO_PAGO_SANDBOX;
	}

	$candidate_values = array();

	if ($sandbox) {
		if (defined('MERCADO_PAGO_PUBLIC_KEY_TEST')) {
			$candidate_values[] = MERCADO_PAGO_PUBLIC_KEY_TEST;
		}
		$candidate_values[] = get_option('_mp_public_key_test', '');
	}

	if (defined('MERCADO_PAGO_PUBLIC_KEY')) {
		$candidate_values[] = MERCADO_PAGO_PUBLIC_KEY;
	}

	$candidate_values[] = get_option('_mp_public_key_prod', '');

	foreach ($candidate_values as $candidate) {
		$candidate = trim((string) $candidate);
		if ($candidate !== '') {
			return $candidate;
		}
	}

	return '';
}

function escortwp_bootstrap_brazil_checkout_settings() {
	if (!class_exists('WooCommerce')) {
		return;
	}

	escortwp_wc_option_update_if_needed('woocommerce_currency', 'BRL');
	escortwp_wc_option_update_if_needed('woocommerce_default_country', 'BR');
	escortwp_wc_option_update_if_needed('woocommerce_allowed_countries', 'specific');
	escortwp_wc_option_update_if_needed('woocommerce_specific_allowed_countries', array('BR'));
	escortwp_wc_option_update_if_needed('woocommerce_ship_to_countries', 'disabled');
	escortwp_wc_option_update_if_needed('woocommerce_customer_default_location', 'base');
}
add_action('init', 'escortwp_bootstrap_brazil_checkout_settings', 15);

function escortwp_force_brazil_currency($currency) {
	return 'BRL';
}
add_filter('woocommerce_currency', 'escortwp_force_brazil_currency', 20);

function escortwp_force_brazil_only_countries($countries) {
	if (!is_array($countries)) {
		return array();
	}

	$brazil = array();
	if (isset($countries['BR'])) {
		$brazil['BR'] = $countries['BR'];
	} else {
		$brazil['BR'] = 'Brasil';
	}

	return $brazil;
}
add_filter('woocommerce_countries_allowed_countries', 'escortwp_force_brazil_only_countries', 20);
add_filter('woocommerce_countries_shipping_countries', 'escortwp_force_brazil_only_countries', 20);

function escortwp_force_brazil_checkout_defaults($country) {
	return 'BR';
}
add_filter('default_checkout_billing_country', 'escortwp_force_brazil_checkout_defaults', 20);
add_filter('default_checkout_shipping_country', 'escortwp_force_brazil_checkout_defaults', 20);

function escortwp_force_brazil_default_address_fields($fields) {
	if (!is_array($fields)) {
		return $fields;
	}

	if (isset($fields['postcode'])) {
		$fields['postcode']['label'] = 'CEP';
		$fields['postcode']['placeholder'] = '00000-000';
		$fields['postcode']['required'] = true;
	}

	if (isset($fields['state'])) {
		$fields['state']['label'] = 'Estado';
		$fields['state']['required'] = true;
	}

	if (isset($fields['city'])) {
		$fields['city']['label'] = 'Cidade';
		$fields['city']['required'] = true;
	}

	if (isset($fields['address_1'])) {
		$fields['address_1']['label'] = 'Endereço';
		$fields['address_1']['required'] = true;
	}

	return $fields;
}
add_filter('woocommerce_default_address_fields', 'escortwp_force_brazil_default_address_fields', 20);

function escortwp_inject_classic_checkout_shortcodes($posts, $query) {
	if (is_admin() || !$query instanceof WP_Query || !$query->is_main_query() || empty($posts) || !class_exists('WooCommerce')) {
		return $posts;
	}

	$checkout_page_id = function_exists('wc_get_page_id') ? (int) wc_get_page_id('checkout') : 0;
	$cart_page_id = function_exists('wc_get_page_id') ? (int) wc_get_page_id('cart') : 0;

	foreach ($posts as $index => $post) {
		if (!($post instanceof WP_Post)) {
			continue;
		}

		if ($checkout_page_id && (int) $post->ID === $checkout_page_id) {
			$posts[$index]->post_content = '[woocommerce_checkout]';
		} elseif ($cart_page_id && (int) $post->ID === $cart_page_id) {
			$posts[$index]->post_content = '[woocommerce_cart]';
		}
	}

	return $posts;
}
add_filter('the_posts', 'escortwp_inject_classic_checkout_shortcodes', 1, 2);

function escortwp_force_classic_checkout_content($content) {
	if (!class_exists('WooCommerce') || !is_singular('page')) {
		return $content;
	}

	$checkout_page_id = function_exists('wc_get_page_id') ? (int) wc_get_page_id('checkout') : 0;
	$cart_page_id = function_exists('wc_get_page_id') ? (int) wc_get_page_id('cart') : 0;

	if ($checkout_page_id && is_page($checkout_page_id)) {
		return do_shortcode(shortcode_unautop('[woocommerce_checkout]'));
	}

	if ($cart_page_id && is_page($cart_page_id)) {
		return do_shortcode(shortcode_unautop('[woocommerce_cart]'));
	}

	return $content;
}
add_filter('the_content', 'escortwp_force_classic_checkout_content', 999);

function escortwp_translate_checkout_page_titles($title, $post_id = 0) {
	if (is_admin() || !class_exists('WooCommerce')) {
		return $title;
	}

	$checkout_page_id = function_exists('wc_get_page_id') ? (int) wc_get_page_id('checkout') : 0;
	$cart_page_id = function_exists('wc_get_page_id') ? (int) wc_get_page_id('cart') : 0;
	$account_page_id = function_exists('wc_get_page_id') ? (int) wc_get_page_id('myaccount') : 0;

	if ($checkout_page_id && (int) $post_id === $checkout_page_id) {
		return 'Finalizar compra';
	}

	if ($cart_page_id && (int) $post_id === $cart_page_id) {
		return 'Carrinho';
	}

	if ($account_page_id && (int) $post_id === $account_page_id) {
		return 'Minha conta';
	}

	return $title;
}
add_filter('the_title', 'escortwp_translate_checkout_page_titles', 20, 2);

function escortwp_translate_checkout_document_title($parts) {
	if (!class_exists('WooCommerce') || !is_array($parts) || empty($parts['title'])) {
		return $parts;
	}

	if (function_exists('is_checkout') && is_checkout()) {
		$parts['title'] = 'Finalizar compra';
	} elseif (function_exists('is_cart') && is_cart()) {
		$parts['title'] = 'Carrinho';
	}

	return $parts;
}
add_filter('document_title_parts', 'escortwp_translate_checkout_document_title', 20);

function escortwp_customize_brazil_checkout_fields($fields) {
	if (!is_array($fields)) {
		return $fields;
	}

	if (isset($fields['shipping'])) {
		$fields['shipping'] = array();
	}

	if (!isset($fields['billing']) || !is_array($fields['billing'])) {
		$fields['billing'] = array();
	}

	unset($fields['billing']['billing_company'], $fields['billing']['billing_address_2']);

	$fields['billing']['billing_country'] = array(
		'type' => 'hidden',
		'default' => 'BR',
		'required' => false,
		'priority' => 5,
	);

	if (!empty($fields['billing']['billing_first_name'])) {
		$fields['billing']['billing_first_name']['label'] = 'Nome';
		$fields['billing']['billing_first_name']['priority'] = 10;
	}

	if (!empty($fields['billing']['billing_last_name'])) {
		$fields['billing']['billing_last_name']['label'] = 'Sobrenome';
		$fields['billing']['billing_last_name']['priority'] = 20;
	}

	$fields['billing']['billing_cpf_cnpj'] = array(
		'label' => 'CPF ou CNPJ',
		'placeholder' => '000.000.000-00 ou 00.000.000/0000-00',
		'required' => true,
		'type' => 'text',
		'priority' => 30,
		'class' => array('form-row-wide'),
		'clear' => true,
	);

	if (!empty($fields['billing']['billing_postcode'])) {
		$fields['billing']['billing_postcode']['label'] = 'CEP';
		$fields['billing']['billing_postcode']['placeholder'] = '00000-000';
		$fields['billing']['billing_postcode']['priority'] = 40;
		$fields['billing']['billing_postcode']['class'] = array('form-row-first');
	}

	$fields['billing']['billing_neighborhood'] = array(
		'label' => 'Bairro',
		'placeholder' => 'Bairro',
		'required' => true,
		'type' => 'text',
		'priority' => 50,
		'class' => array('form-row-last'),
		'clear' => true,
	);

	if (!empty($fields['billing']['billing_address_1'])) {
		$fields['billing']['billing_address_1']['label'] = 'Endereço';
		$fields['billing']['billing_address_1']['placeholder'] = 'Rua, avenida e número';
		$fields['billing']['billing_address_1']['priority'] = 60;
		$fields['billing']['billing_address_1']['class'] = array('form-row-wide');
	}

	if (!empty($fields['billing']['billing_city'])) {
		$fields['billing']['billing_city']['label'] = 'Cidade';
		$fields['billing']['billing_city']['priority'] = 70;
		$fields['billing']['billing_city']['class'] = array('form-row-first');
	}

	$brazil_states = array();
	if (function_exists('WC') && WC()->countries) {
		$brazil_states = (array) WC()->countries->get_states('BR');
	}
	if (empty($brazil_states)) {
		$brazil_states = array(
			'AC' => 'Acre',
			'AL' => 'Alagoas',
			'AP' => 'Amapá',
			'AM' => 'Amazonas',
			'BA' => 'Bahia',
			'CE' => 'Ceará',
			'DF' => 'Distrito Federal',
			'ES' => 'Espírito Santo',
			'GO' => 'Goiás',
			'MA' => 'Maranhão',
			'MT' => 'Mato Grosso',
			'MS' => 'Mato Grosso do Sul',
			'MG' => 'Minas Gerais',
			'PA' => 'Pará',
			'PB' => 'Paraíba',
			'PR' => 'Paraná',
			'PE' => 'Pernambuco',
			'PI' => 'Piauí',
			'RJ' => 'Rio de Janeiro',
			'RN' => 'Rio Grande do Norte',
			'RS' => 'Rio Grande do Sul',
			'RO' => 'Rondônia',
			'RR' => 'Roraima',
			'SC' => 'Santa Catarina',
			'SP' => 'São Paulo',
			'SE' => 'Sergipe',
			'TO' => 'Tocantins',
		);
	}

	$fields['billing']['billing_state'] = array(
		'label' => 'Estado',
		'type' => 'select',
		'options' => array('' => 'Selecione uma opção...') + $brazil_states,
		'required' => true,
		'priority' => 80,
		'class' => array('form-row-last'),
		'clear' => true,
	);

	if (!empty($fields['billing']['billing_email'])) {
		$fields['billing']['billing_email']['label'] = 'E-mail';
		$fields['billing']['billing_email']['priority'] = 90;
		$fields['billing']['billing_email']['class'] = array('form-row-wide');
	}

	if (!empty($fields['billing']['billing_phone'])) {
		$fields['billing']['billing_phone']['label'] = 'Celular / WhatsApp';
		$fields['billing']['billing_phone']['placeholder'] = '(11) 99999-0000';
		$fields['billing']['billing_phone']['required'] = true;
		$fields['billing']['billing_phone']['priority'] = 100;
		$fields['billing']['billing_phone']['class'] = array('form-row-wide');
		$fields['billing']['billing_phone']['clear'] = true;
	}

	if (isset($fields['order']['order_comments'])) {
		$fields['order']['order_comments']['label'] = 'Observações do pedido';
	}

	return $fields;
}
add_filter('woocommerce_checkout_fields', 'escortwp_customize_brazil_checkout_fields', 20);

function escortwp_checkout_digits($value) {
	return preg_replace('/\D+/', '', (string) $value);
}

function escortwp_is_valid_cpf($cpf) {
	$cpf = escortwp_checkout_digits($cpf);
	if (strlen($cpf) !== 11 || preg_match('/^(\\d)\\1{10}$/', $cpf)) {
		return false;
	}

	for ($t = 9; $t < 11; $t++) {
		$d = 0;
		for ($c = 0; $c < $t; $c++) {
			$d += (int) $cpf[$c] * (($t + 1) - $c);
		}
		$d = ((10 * $d) % 11) % 10;
		if ((int) $cpf[$c] !== $d) {
			return false;
		}
	}

	return true;
}

function escortwp_is_valid_cnpj($cnpj) {
	$cnpj = escortwp_checkout_digits($cnpj);
	if (strlen($cnpj) !== 14 || preg_match('/^(\\d)\\1{13}$/', $cnpj)) {
		return false;
	}

	$lengths = array(5, 6);

	foreach ($lengths as $index => $initial_weight) {
		$sum = 0;
		$weight = $initial_weight;

		for ($i = 0; $i < 12 + $index; $i++) {
			$sum += (int) $cnpj[$i] * $weight;
			$weight--;
			if ($weight < 2) {
				$weight = 9;
			}
		}

		$digit = $sum % 11;
		$digit = $digit < 2 ? 0 : 11 - $digit;
		if ((int) $cnpj[12 + $index] !== $digit) {
			return false;
		}
	}

	return true;
}

function escortwp_is_valid_cpf_cnpj($document) {
	$digits = escortwp_checkout_digits($document);

	if (strlen($digits) === 11) {
		return escortwp_is_valid_cpf($digits);
	}

	if (strlen($digits) === 14) {
		return escortwp_is_valid_cnpj($digits);
	}

	return false;
}

function escortwp_validate_brazil_checkout_fields($data, $errors) {
	if (!$errors instanceof WP_Error) {
		return;
	}

	$cpf_cnpj = $data['billing_cpf_cnpj'] ?? '';
	$postcode = $data['billing_postcode'] ?? '';
	$phone = $data['billing_phone'] ?? '';
	$email = $data['billing_email'] ?? '';
	$neighborhood = $data['billing_neighborhood'] ?? '';

	if (!escortwp_is_valid_cpf_cnpj($cpf_cnpj)) {
		$errors->add('billing_cpf_cnpj', 'Informe um CPF ou CNPJ válido.');
	}

	if (strlen(escortwp_checkout_digits($postcode)) !== 8) {
		$errors->add('billing_postcode', 'Informe um CEP válido no formato 00000-000.');
	}

	$phone_digits = escortwp_checkout_digits($phone);
	if (!in_array(strlen($phone_digits), array(10, 11), true)) {
		$errors->add('billing_phone', 'Informe um telefone válido com DDD.');
	}

	if (!is_email($email)) {
		$errors->add('billing_email', 'Informe um e-mail válido.');
	}

	if (trim((string) $neighborhood) === '') {
		$errors->add('billing_neighborhood', 'Informe o bairro.');
	}
}
add_action('woocommerce_after_checkout_validation', 'escortwp_validate_brazil_checkout_fields', 20, 2);

function escortwp_save_brazil_checkout_meta($order, $data) {
	if (!$order instanceof WC_Order || !is_array($data)) {
		return;
	}

	if (isset($data['billing_cpf_cnpj'])) {
		$order->update_meta_data('_billing_cpf_cnpj', sanitize_text_field((string) $data['billing_cpf_cnpj']));
	}

	if (isset($data['billing_neighborhood'])) {
		$order->update_meta_data('_billing_neighborhood', sanitize_text_field((string) $data['billing_neighborhood']));
	}
}
add_action('woocommerce_checkout_create_order', 'escortwp_save_brazil_checkout_meta', 20, 2);

function escortwp_add_brazil_admin_billing_fields($fields) {
	if (!is_array($fields)) {
		$fields = array();
	}

	$fields['cpf_cnpj'] = array(
		'label' => 'CPF / CNPJ',
		'show' => true,
	);

	$fields['neighborhood'] = array(
		'label' => 'Bairro',
		'show' => true,
	);

	return $fields;
}
add_filter('woocommerce_admin_billing_fields', 'escortwp_add_brazil_admin_billing_fields', 20);

function escortwp_enqueue_brazil_checkout_assets() {
	if (!escortwp_wc_is_checkout_or_cart_page()) {
		return;
	}

	global $theme_version;
	$has_mp_public_key = escortwp_get_mercadopago_public_key() !== '';
	wp_enqueue_style(
		'escortwp-checkout-brazil',
		get_template_directory_uri() . '/css/escortwp-checkout-brazil.css',
		array(),
		$theme_version
	);
	wp_enqueue_script(
		'escortwp-checkout-brazil',
		get_template_directory_uri() . '/js/escortwp-checkout-brazil.js',
		array('jquery'),
		$theme_version,
		true
	);
	wp_localize_script(
		'escortwp-checkout-brazil',
		'escortwpCheckoutBrazil',
		array(
			'hasMercadoPagoPublicKey' => $has_mp_public_key,
			'cardUnavailableMessage' => 'Cartão temporariamente indisponível. Finalize com PIX enquanto a chave pública do Mercado Pago não é configurada.',
		)
	);
}
add_action('wp_enqueue_scripts', 'escortwp_enqueue_brazil_checkout_assets', 30);

function escortwp_cleanup_checkout_block_assets() {
	if (!escortwp_wc_is_checkout_or_cart_page()) {
		return;
	}

	$styles = array(
		'wc-blocks-style',
		'wc-blocks-style-all-products',
		'wc-blocks-style-cart',
		'wc-blocks-style-checkout',
		'wc-blocks-packages-style',
	);

	$scripts = array(
		'wc-settings-js',
		'wc-blocks-registry-js',
		'wc-blocks-middleware-js',
		'wc-blocks-data-store-js',
		'wc-cart-block-frontend-js',
		'wc-blocks-checkout',
		'wc-blocks-checkout-events',
		'wc-blocks-cart',
		'wc_mercadopago_basic_blocks-js',
		'wc_mercadopago_custom_blocks-js',
		'wc_mercadopago_credits_blocks-js',
		'wc_mercadopago_pix_blocks-js',
		'wc_mercadopago_ticket_blocks-js',
	);

	foreach ($styles as $handle) {
		wp_dequeue_style($handle);
		wp_deregister_style($handle);
	}

	foreach ($scripts as $handle) {
		wp_dequeue_script($handle);
		wp_deregister_script($handle);
	}
}
add_action('wp_enqueue_scripts', 'escortwp_cleanup_checkout_block_assets', 9999);

function escortwp_cleanup_checkout_preload_resources($resources) {
	if (!escortwp_wc_is_checkout_or_cart_page() || !is_array($resources)) {
		return $resources;
	}

	$blocked_fragments = array(
		'/woocommerce/assets/client/blocks/',
		'wc_mercadopago_basic_blocks',
		'wc_mercadopago_custom_blocks',
		'wc_mercadopago_credits_blocks',
		'wc_mercadopago_pix_blocks',
		'wc_mercadopago_ticket_blocks',
	);

	$filtered = array();

	foreach ($resources as $resource) {
		$resource_url = '';

		if (is_string($resource)) {
			$resource_url = $resource;
		} elseif (is_array($resource) && !empty($resource['href'])) {
			$resource_url = (string) $resource['href'];
		}

		$should_skip = false;
		foreach ($blocked_fragments as $fragment) {
			if ($resource_url !== '' && strpos($resource_url, $fragment) !== false) {
				$should_skip = true;
				break;
			}
		}

		if (!$should_skip) {
			$filtered[] = $resource;
		}
	}

	return $filtered;
}
add_filter('wp_preload_resources', 'escortwp_cleanup_checkout_preload_resources', 9999);

function escortwp_cleanup_checkout_resource_hints($urls, $relation_type) {
	if (!escortwp_wc_is_checkout_or_cart_page() || !is_array($urls) || $relation_type !== 'prefetch') {
		return $urls;
	}

	$blocked_fragments = array(
		'/woocommerce/assets/client/blocks/',
		'wc_mercadopago_basic_blocks',
		'wc_mercadopago_custom_blocks',
		'wc_mercadopago_credits_blocks',
		'wc_mercadopago_pix_blocks',
		'wc_mercadopago_ticket_blocks',
	);

	$filtered_urls = array();
	foreach ($urls as $url) {
		$url_value = is_array($url) ? (string) ($url['href'] ?? '') : (string) $url;
		$should_skip = false;

		foreach ($blocked_fragments as $fragment) {
			if ($url_value !== '' && strpos($url_value, $fragment) !== false) {
				$should_skip = true;
				break;
			}
		}

		if (!$should_skip) {
			$filtered_urls[] = $url;
		}
	}

	return $filtered_urls;
}
add_filter('wp_resource_hints', 'escortwp_cleanup_checkout_resource_hints', 9999, 2);

function escortwp_log_order_status_transition_for_checkout($order_id, $old_status, $new_status, $order) {
	if (function_exists('escortwp_log_payment_event')) {
		escortwp_log_payment_event('Status oficial do pedido alterado no WooCommerce.', array(
			'order_id' => (int) $order_id,
			'old_status' => sanitize_key((string) $old_status),
			'new_status' => sanitize_key((string) $new_status),
		));
	}
}
add_action('woocommerce_order_status_changed', 'escortwp_log_order_status_transition_for_checkout', 15, 4);

function escortwp_warn_admin_if_mercadopago_public_key_missing() {
	if (!is_admin() || !current_user_can('manage_options')) {
		return;
	}

	if (!class_exists('MercadoPago\\Woocommerce\\WoocommerceMercadoPago')) {
		return;
	}

	$custom_settings = get_option('woocommerce_woo-mercado-pago-custom_settings', array());
	$is_custom_enabled = is_array($custom_settings) && (($custom_settings['enabled'] ?? 'no') === 'yes');

	if (!$is_custom_enabled) {
		return;
	}

	if (escortwp_get_mercadopago_public_key() !== '') {
		return;
	}

	echo '<div class="notice notice-warning"><p>Mercado Pago: o checkout de cartão está ativo, mas a Public Key ainda não foi configurada. O PIX pode funcionar, mas o cartão não vai tokenizar corretamente sem essa chave.</p></div>';
}
add_action('admin_notices', 'escortwp_warn_admin_if_mercadopago_public_key_missing');

function escortwp_translate_plan_product_name_for_checkout($product_name, $cart_item = null, $cart_item_key = '') {
	if (!escortwp_wc_is_checkout_or_cart_page() || !is_array($cart_item) || empty($cart_item['data']) || !is_object($cart_item['data'])) {
		return $product_name;
	}

	$product_id = (int) $cart_item['data']->get_id();
	$payment_type = $product_id ? get_post_meta($product_id, 'payment_type', true) : '';

	$labels = array(
		'premium' => 'Plano mensal do anúncio',
		'featured_boost' => 'Impulsionamento do anúncio por 7 dias',
		'featured' => 'Destaque do anúncio',
		'indescreg' => 'Cadastro da acompanhante',
		'agescortreg' => 'Cadastro da acompanhante',
		'agreg' => 'Cadastro da agência',
	);

	if ($payment_type && isset($labels[$payment_type])) {
		return esc_html($labels[$payment_type]);
	}

	return $product_name;
}
add_filter('woocommerce_cart_item_name', 'escortwp_translate_plan_product_name_for_checkout', 20, 3);
