<?php

if (!defined('ABSPATH')) {
	exit;
}

function escortwp_vv_get_storage_root() {
	$base_path = trailingslashit(dirname(ABSPATH)) . 'private-verification-videos';
	return wp_normalize_path($base_path);
}

function escortwp_vv_ensure_storage_root() {
	$root = escortwp_vv_get_storage_root();
	if (!is_dir($root)) {
		wp_mkdir_p($root);
	}

	return $root;
}

function escortwp_vv_get_absolute_storage_path($stored_relative_path) {
	$stored_relative_path = ltrim(str_replace(array('../', '..\\'), '', (string) $stored_relative_path), '/\\');
	if ($stored_relative_path === '') {
		return '';
	}

	return wp_normalize_path(trailingslashit(escortwp_vv_get_storage_root()) . $stored_relative_path);
}

function escortwp_vv_get_stream_url($request_id) {
	$request_id = (int) $request_id;
	if ($request_id < 1 || !current_user_can('manage_options')) {
		return '';
	}

	return add_query_arg(array(
		'action' => 'escortwp_stream_verification_video',
		'id' => $request_id,
		'_wpnonce' => wp_create_nonce('escortwp_vv_stream_' . $request_id),
	), admin_url('admin-post.php'));
}

function escortwp_vv_get_status_label($status) {
	switch (sanitize_key($status)) {
		case 'approved':
			return __('Verificação aprovada', 'escortwp');
		case 'rejected':
			return __('Verificação rejeitada', 'escortwp');
		case 'pending':
		default:
			return __('Aguardando aprovação', 'escortwp');
	}
}

function escortwp_vv_get_status_description($status) {
	switch (sanitize_key($status)) {
		case 'approved':
			return __('Seu perfil recebeu o selo de verificada e já aparece com esse destaque no anúncio.', 'escortwp');
		case 'rejected':
			return __('A revisão foi rejeitada. Você pode enviar um novo vídeo corrigido a qualquer momento.', 'escortwp');
		case 'pending':
		default:
			return __('Vídeo enviado com sucesso. Nossa equipe vai revisar e atualizar o status assim que concluir a análise.', 'escortwp');
	}
}

function escortwp_vv_get_allowed_extensions() {
	return array('mp4', 'mov');
}

function escortwp_vv_get_allowed_mime_types() {
	return array('video/mp4', 'video/quicktime');
}

function escortwp_vv_get_max_upload_size_bytes() {
	return 50 * 1024 * 1024;
}

function escortwp_vv_can_manage_profile($profile_id, $user_id = 0) {
	$profile_id = (int) $profile_id;
	$user_id = $user_id ? (int) $user_id : get_current_user_id();

	if ($profile_id < 1 || $user_id < 1) {
		return false;
	}

	if (function_exists('escortwp_current_user_can_manage_post') && escortwp_current_user_can_manage_post($profile_id)) {
		return true;
	}

	$post = get_post($profile_id);
	return $post && (int) $post->post_author === $user_id;
}

function escortwp_vv_validate_uploaded_file($file) {
	if (empty($file) || !is_array($file)) {
		return new WP_Error('escortwp_vv_missing_file', __('Selecione um vídeo antes de enviar.', 'escortwp'), array('status' => 400));
	}

	if (!isset($file['error']) || (int) $file['error'] !== UPLOAD_ERR_OK) {
		return new WP_Error('escortwp_vv_upload_error', __('Não foi possível enviar o vídeo agora. Tente novamente.', 'escortwp'), array('status' => 400));
	}

	if (empty($file['tmp_name']) || !file_exists($file['tmp_name'])) {
		return new WP_Error('escortwp_vv_missing_tmp', __('O arquivo temporário do vídeo não foi encontrado.', 'escortwp'), array('status' => 400));
	}

	$file_size = isset($file['size']) ? (int) $file['size'] : 0;
	if ($file_size < 1) {
		return new WP_Error('escortwp_vv_empty_file', __('O vídeo enviado está vazio.', 'escortwp'), array('status' => 400));
	}

	if ($file_size > escortwp_vv_get_max_upload_size_bytes()) {
		return new WP_Error('escortwp_vv_file_too_large', __('O vídeo excede o limite de 50MB.', 'escortwp'), array('status' => 400));
	}

	$original_name = sanitize_file_name((string) $file['name']);
	$extension = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
	if (!in_array($extension, escortwp_vv_get_allowed_extensions(), true)) {
		return new WP_Error('escortwp_vv_invalid_extension', __('Envie apenas vídeos MP4 ou MOV.', 'escortwp'), array('status' => 400));
	}

	$wp_check = wp_check_filetype_and_ext($file['tmp_name'], $original_name, array(
		'mp4' => 'video/mp4',
		'mov' => 'video/quicktime',
	));
	$wp_ext = !empty($wp_check['ext']) ? strtolower($wp_check['ext']) : '';
	$wp_type = !empty($wp_check['type']) ? strtolower($wp_check['type']) : '';

	$finfo_type = '';
	if (function_exists('finfo_open')) {
		$finfo = finfo_open(FILEINFO_MIME_TYPE);
		if ($finfo) {
			$finfo_type = strtolower((string) finfo_file($finfo, $file['tmp_name']));
			finfo_close($finfo);
		}
	}

	$allowed_mimes = escortwp_vv_get_allowed_mime_types();
	$mime_type = $finfo_type && in_array($finfo_type, $allowed_mimes, true) ? $finfo_type : $wp_type;

	if (!in_array($mime_type, $allowed_mimes, true)) {
		return new WP_Error('escortwp_vv_invalid_mime', __('O arquivo enviado não é um vídeo MP4 ou MOV válido.', 'escortwp'), array('status' => 400));
	}

	return array(
		'original_name' => $original_name,
		'extension' => $wp_ext ?: $extension,
		'mime_type' => $mime_type,
		'file_size' => $file_size,
	);
}

function escortwp_vv_store_uploaded_file($file, $validated_file) {
	$storage_root = escortwp_vv_ensure_storage_root();
	if (!is_dir($storage_root) || !is_writable($storage_root)) {
		return new WP_Error('escortwp_vv_storage_unavailable', __('A pasta segura de verificação não está disponível para gravação.', 'escortwp'), array('status' => 500));
	}

	$subfolder = date('Y/m');
	$target_dir = wp_normalize_path(trailingslashit($storage_root) . $subfolder);
	if (!is_dir($target_dir)) {
		wp_mkdir_p($target_dir);
	}

	if (!is_dir($target_dir) || !is_writable($target_dir)) {
		return new WP_Error('escortwp_vv_storage_unavailable', __('Não foi possível preparar a pasta segura do vídeo.', 'escortwp'), array('status' => 500));
	}

	try {
		$random = bin2hex(random_bytes(18));
	} catch (Exception $e) {
		$random = wp_generate_password(24, false, false);
	}

	$stored_name = $random . '.' . $validated_file['extension'];
	$relative_path = $subfolder . '/' . $stored_name;
	$absolute_path = wp_normalize_path(trailingslashit($target_dir) . $stored_name);

	if (!move_uploaded_file($file['tmp_name'], $absolute_path)) {
		return new WP_Error('escortwp_vv_store_failed', __('Não foi possível salvar o vídeo em segurança.', 'escortwp'), array('status' => 500));
	}

	@chmod($absolute_path, 0640);

	return array(
		'stored_name' => $stored_name,
		'storage_path' => $relative_path,
	);
}

function escortwp_vv_mark_profile_status($profile_id, $request_id, $status) {
	$profile_id = (int) $profile_id;
	$request_id = (int) $request_id;
	$status = sanitize_key($status);

	update_post_meta($profile_id, 'escortwp_video_verification_status', $status);
	update_post_meta($profile_id, 'escortwp_video_verification_request_id', $request_id);

	if ($status === 'approved') {
		update_post_meta($profile_id, 'verified', '1');
		update_post_meta($profile_id, 'escortwp_video_verification_reviewed_at', current_time('timestamp'));
	} else {
		update_post_meta($profile_id, 'verified', '0');
	}
}

function escortwp_vv_notify_admin_new_request($request) {
	$request = escortwp_vv_normalize_request_row($request);
	if (!$request) {
		return;
	}

	$user = get_userdata((int) $request['user_id']);
	$profile_link = get_permalink((int) $request['profile_id']);
	$subject = __('Novo vídeo de verificação recebido', 'escortwp') . ' - ' . get_option('email_sitename');
	$body = __('Olá', 'escortwp') . ',<br /><br />';
	$body .= __('Uma acompanhante enviou um novo vídeo de verificação manual.', 'escortwp') . '<br /><br />';
	$body .= '<strong>' . esc_html__('Usuária', 'escortwp') . ':</strong> ' . esc_html($user ? $user->display_name : __('Conta removida', 'escortwp')) . '<br />';
	$body .= '<strong>' . esc_html__('Anúncio', 'escortwp') . ':</strong> <a href="' . esc_url($profile_link) . '">' . esc_html($profile_link) . '</a><br />';
	$body .= '<strong>' . esc_html__('Painel de revisão', 'escortwp') . ':</strong> <a href="' . esc_url(admin_url('admin.php?page=escortwp-video-verification')) . '">' . esc_html(admin_url('admin.php?page=escortwp-video-verification')) . '</a><br />';

	dolce_email('', '', get_bloginfo('admin_email'), $subject, $body);
}

function escortwp_vv_notify_user_status_change($request) {
	$request = escortwp_vv_normalize_request_row($request);
	if (!$request) {
		return;
	}

	$user = get_userdata((int) $request['user_id']);
	if (!$user || empty($user->user_email)) {
		return;
	}

	$subject = escortwp_vv_get_status_label($request['status']) . ' - ' . get_option('email_sitename');
	$body = __('Olá', 'escortwp') . ' ' . esc_html($user->display_name) . ',<br /><br />';
	$body .= escortwp_vv_get_status_description($request['status']) . '<br /><br />';
	$body .= '<strong>' . esc_html__('Seu anúncio', 'escortwp') . ':</strong> <a href="' . esc_url(get_permalink((int) $request['profile_id'])) . '">' . esc_html(get_permalink((int) $request['profile_id'])) . '</a><br />';

	if ($request['status'] === 'rejected' && !empty($request['rejection_reason'])) {
		$body .= '<br /><strong>' . esc_html__('Motivo informado', 'escortwp') . ':</strong><br />' . nl2br(esc_html($request['rejection_reason']));
	}

	dolce_email('', '', $user->user_email, $subject, $body);
}

function escortwp_vv_create_request($user_id, $profile_id, $file) {
	global $taxonomy_profile_url;

	$user_id = (int) $user_id;
	$profile_id = (int) $profile_id;
	if ($user_id < 1 || $profile_id < 1) {
		return new WP_Error('escortwp_vv_invalid_request', __('Não foi possível preparar a verificação por vídeo.', 'escortwp'), array('status' => 400));
	}

	if (!escortwp_current_user_has_type($taxonomy_profile_url, $user_id) || !escortwp_vv_can_manage_profile($profile_id, $user_id)) {
		return new WP_Error('escortwp_vv_forbidden', __('Você não pode enviar vídeo para este anúncio.', 'escortwp'), array('status' => 403));
	}

	$post = get_post($profile_id);
	if (!$post || $post->post_type !== $taxonomy_profile_url) {
		return new WP_Error('escortwp_vv_invalid_profile', __('O anúncio selecionado não foi encontrado.', 'escortwp'), array('status' => 404));
	}

	$latest = escortwp_vv_get_latest_request_for_profile($profile_id);
	if ($latest && $latest['status'] === 'pending') {
		return new WP_Error('escortwp_vv_pending_exists', __('Já existe um vídeo pendente de análise para este anúncio.', 'escortwp'), array('status' => 409));
	}
	if ($latest && $latest['status'] === 'approved') {
		return new WP_Error('escortwp_vv_already_approved', __('Este anúncio já está verificado. Se precisar revisar, fale com o suporte administrativo.', 'escortwp'), array('status' => 409));
	}

	$validated_file = escortwp_vv_validate_uploaded_file($file);
	if (is_wp_error($validated_file)) {
		return $validated_file;
	}

	$stored_file = escortwp_vv_store_uploaded_file($file, $validated_file);
	if (is_wp_error($stored_file)) {
		return $stored_file;
	}

	$request_id = escortwp_vv_insert_request(array(
		'user_id' => $user_id,
		'profile_id' => $profile_id,
		'status' => 'pending',
		'original_name' => $validated_file['original_name'],
		'stored_name' => $stored_file['stored_name'],
		'storage_path' => $stored_file['storage_path'],
		'mime_type' => $validated_file['mime_type'],
		'file_size' => $validated_file['file_size'],
	));

	$request = escortwp_vv_get_request($request_id);
	escortwp_vv_mark_profile_status($profile_id, $request_id, 'pending');
	escortwp_vv_add_log($request_id, 'video_uploaded', 'Vídeo de verificação enviado.', array(
		'user_id' => $user_id,
		'profile_id' => $profile_id,
		'file_size' => $validated_file['file_size'],
	));
	escortwp_vv_notify_admin_new_request($request);

	return $request;
}

function escortwp_vv_review_request($request_id, $status, $admin_id, $reason = '', $admin_note = '') {
	$request = escortwp_vv_get_request($request_id);
	$status = sanitize_key($status);
	$admin_id = (int) $admin_id;

	if (!$request) {
		return new WP_Error('escortwp_vv_not_found', __('O vídeo de verificação não foi encontrado.', 'escortwp'), array('status' => 404));
	}

	if (!current_user_can('manage_options')) {
		return new WP_Error('escortwp_vv_forbidden', __('Apenas administradores podem revisar vídeos.', 'escortwp'), array('status' => 403));
	}

	if (!in_array($status, array('approved', 'rejected'), true)) {
		return new WP_Error('escortwp_vv_invalid_status', __('O status informado para a revisão é inválido.', 'escortwp'), array('status' => 400));
	}

	$update = array(
		'status' => $status,
		'reviewed_by' => $admin_id,
		'reviewed_at' => current_time('mysql'),
		'rejection_reason' => $status === 'rejected' ? sanitize_textarea_field($reason) : '',
		'admin_note' => sanitize_textarea_field($admin_note),
	);

	escortwp_vv_update_request($request['id'], $update);
	$request = escortwp_vv_get_request($request['id']);
	escortwp_vv_mark_profile_status((int) $request['profile_id'], (int) $request['id'], $status);
	escortwp_vv_add_log($request['id'], 'video_reviewed', 'Vídeo revisado pelo administrador.', array(
		'status' => $status,
		'admin_id' => $admin_id,
		'reason' => $update['rejection_reason'],
	));
	escortwp_vv_notify_user_status_change($request);

	return $request;
}

function escortwp_vv_get_profile_status_summary($profile_id) {
	$profile_id = (int) $profile_id;
	$latest = escortwp_vv_get_latest_request_for_profile($profile_id);

	if (!$latest) {
		$current_verified = get_post_meta($profile_id, 'verified', true) === '1';
		return array(
			'status' => $current_verified ? 'approved' : 'not_verified',
			'label' => $current_verified ? __('Verificada', 'escortwp') : __('Perfil não verificado', 'escortwp'),
			'description' => $current_verified
				? __('Este anúncio já exibe o selo de verificada.', 'escortwp')
				: __('Este anúncio ainda não passou pela verificação manual em vídeo.', 'escortwp'),
			'request' => null,
		);
	}

	return array(
		'status' => $latest['status'],
		'label' => escortwp_vv_get_status_label($latest['status']),
		'description' => escortwp_vv_get_status_description($latest['status']),
		'request' => $latest,
	);
}

