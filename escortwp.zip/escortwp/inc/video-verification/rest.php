<?php

if (!defined('ABSPATH')) {
	exit;
}

function escortwp_vv_rest_can_upload() {
	global $taxonomy_profile_url;
	return is_user_logged_in() && escortwp_current_user_has_type($taxonomy_profile_url, get_current_user_id());
}

function escortwp_vv_prepare_request_response($request) {
	$request = escortwp_vv_normalize_request_row($request);
	if (!$request) {
		return array();
	}

	return array(
		'id' => (int) $request['id'],
		'user_id' => (int) $request['user_id'],
		'profile_id' => (int) $request['profile_id'],
		'status' => $request['status'],
		'status_label' => escortwp_vv_get_status_label($request['status']),
		'description' => escortwp_vv_get_status_description($request['status']),
		'original_name' => (string) $request['original_name'],
		'file_size' => (int) $request['file_size'],
		'submitted_at' => (string) $request['submitted_at'],
		'reviewed_at' => (string) $request['reviewed_at'],
		'rejection_reason' => (string) $request['rejection_reason'],
	);
}

function escortwp_vv_rest_upload(\WP_REST_Request $request) {
	$profile_id = (int) $request->get_param('profile_id');
	$file = isset($_FILES['verification_video']) ? $_FILES['verification_video'] : null;

	if ($profile_id < 1) {
		return new \WP_Error('escortwp_vv_missing_profile', __('Selecione o anúncio antes de enviar o vídeo.', 'escortwp'), array('status' => 400));
	}

	$result = escortwp_vv_create_request(get_current_user_id(), $profile_id, $file);
	if (is_wp_error($result)) {
		return $result;
	}

	return rest_ensure_response(escortwp_vv_prepare_request_response($result));
}

function escortwp_vv_rest_can_read_status(\WP_REST_Request $request) {
	$profile_id = (int) $request['profile_id'];
	if ($profile_id < 1) {
		return false;
	}

	if (current_user_can('manage_options')) {
		return true;
	}

	return escortwp_vv_can_manage_profile($profile_id, get_current_user_id());
}

function escortwp_vv_rest_get_status(\WP_REST_Request $request) {
	$profile_id = (int) $request['profile_id'];
	$summary = escortwp_vv_get_profile_status_summary($profile_id);
	$response = array(
		'status' => $summary['status'],
		'label' => $summary['label'],
		'description' => $summary['description'],
		'request' => $summary['request'] ? escortwp_vv_prepare_request_response($summary['request']) : null,
	);

	return rest_ensure_response($response);
}

function escortwp_vv_rest_can_admin_review() {
	return current_user_can('manage_options');
}

function escortwp_vv_rest_approve(\WP_REST_Request $request) {
	$request_id = (int) $request['id'];
	$admin_note = sanitize_textarea_field((string) $request->get_param('admin_note'));
	$result = escortwp_vv_review_request($request_id, 'approved', get_current_user_id(), '', $admin_note);
	if (is_wp_error($result)) {
		return $result;
	}

	return rest_ensure_response(escortwp_vv_prepare_request_response($result));
}

function escortwp_vv_rest_reject(\WP_REST_Request $request) {
	$request_id = (int) $request['id'];
	$reason = sanitize_textarea_field((string) $request->get_param('reason'));
	$admin_note = sanitize_textarea_field((string) $request->get_param('admin_note'));
	$result = escortwp_vv_review_request($request_id, 'rejected', get_current_user_id(), $reason, $admin_note);
	if (is_wp_error($result)) {
		return $result;
	}

	return rest_ensure_response(escortwp_vv_prepare_request_response($result));
}

function escortwp_vv_register_rest_routes() {
	register_rest_route('escortwp/v1', '/verify-video', array(
		'methods' => \WP_REST_Server::CREATABLE,
		'callback' => 'escortwp_vv_rest_upload',
		'permission_callback' => 'escortwp_vv_rest_can_upload',
		'args' => array(
			'profile_id' => array(
				'required' => true,
				'type' => 'integer',
			),
		),
	));

	register_rest_route('escortwp/v1', '/verify-video/status/(?P<profile_id>\d+)', array(
		'methods' => \WP_REST_Server::READABLE,
		'callback' => 'escortwp_vv_rest_get_status',
		'permission_callback' => 'escortwp_vv_rest_can_read_status',
	));

	register_rest_route('escortwp/v1', '/verify-video/admin/(?P<id>\d+)/approve', array(
		'methods' => \WP_REST_Server::CREATABLE,
		'callback' => 'escortwp_vv_rest_approve',
		'permission_callback' => 'escortwp_vv_rest_can_admin_review',
	));

	register_rest_route('escortwp/v1', '/verify-video/admin/(?P<id>\d+)/reject', array(
		'methods' => \WP_REST_Server::CREATABLE,
		'callback' => 'escortwp_vv_rest_reject',
		'permission_callback' => 'escortwp_vv_rest_can_admin_review',
	));
}

add_action('rest_api_init', 'escortwp_vv_register_rest_routes');

function escortwp_vv_serve_clean_json($served, $result, $request, $server) {
	if (!($request instanceof \WP_REST_Request)) {
		return $served;
	}

	$route = (string) $request->get_route();
	if (strpos($route, '/escortwp/v1/verify-video') !== 0) {
		return $served;
	}

	while (ob_get_level() > 0) {
		ob_end_clean();
	}

	$response = rest_ensure_response($result);
	$data = $server->response_to_data($response, false);
	echo wp_json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

	return true;
}

add_filter('rest_pre_serve_request', 'escortwp_vv_serve_clean_json', 1000, 4);

