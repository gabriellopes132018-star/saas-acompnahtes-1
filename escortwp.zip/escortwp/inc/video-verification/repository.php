<?php

if (!defined('ABSPATH')) {
	exit;
}

function escortwp_vv_get_requests_table_name() {
	global $wpdb;
	return $wpdb->prefix . 'escortwp_video_verifications';
}

function escortwp_vv_get_logs_table_name() {
	global $wpdb;
	return $wpdb->prefix . 'escortwp_video_verification_logs';
}

function escortwp_vv_install_schema() {
	global $wpdb;

	$installed_version = get_option('escortwp_vv_schema_version');
	if ($installed_version === '1.0.0') {
		return;
	}

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';

	$charset_collate = $wpdb->get_charset_collate();
	$requests_table = escortwp_vv_get_requests_table_name();
	$logs_table = escortwp_vv_get_logs_table_name();

	$sql_requests = "CREATE TABLE {$requests_table} (
		id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
		profile_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
		status VARCHAR(20) NOT NULL DEFAULT 'pending',
		original_name VARCHAR(255) NOT NULL DEFAULT '',
		stored_name VARCHAR(255) NOT NULL DEFAULT '',
		storage_path TEXT NULL,
		mime_type VARCHAR(80) NOT NULL DEFAULT '',
		file_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
		rejection_reason TEXT NULL,
		admin_note TEXT NULL,
		reviewed_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
		submitted_at DATETIME NOT NULL,
		reviewed_at DATETIME NULL,
		created_at DATETIME NOT NULL,
		updated_at DATETIME NOT NULL,
		PRIMARY KEY (id),
		KEY user_status (user_id, status),
		KEY profile_status (profile_id, status),
		KEY submitted_at (submitted_at)
	) {$charset_collate};";

	$sql_logs = "CREATE TABLE {$logs_table} (
		id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		verification_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
		level VARCHAR(16) NOT NULL DEFAULT 'info',
		event VARCHAR(80) NOT NULL DEFAULT '',
		message TEXT NULL,
		context_json LONGTEXT NULL,
		created_at DATETIME NOT NULL,
		PRIMARY KEY (id),
		KEY verification_id (verification_id),
		KEY level_event (level, event)
	) {$charset_collate};";

	dbDelta($sql_requests);
	dbDelta($sql_logs);

	update_option('escortwp_vv_schema_version', '1.0.0', false);
}

add_action('init', 'escortwp_vv_install_schema', 19);

function escortwp_vv_normalize_request_row($row) {
	if (!$row) {
		return null;
	}

	if (is_object($row)) {
		$row = (array) $row;
	}

	$row['id'] = (int) $row['id'];
	$row['user_id'] = (int) $row['user_id'];
	$row['profile_id'] = (int) $row['profile_id'];
	$row['reviewed_by'] = (int) $row['reviewed_by'];
	$row['file_size'] = (int) $row['file_size'];

	return $row;
}

function escortwp_vv_insert_request($data) {
	global $wpdb;

	$table = escortwp_vv_get_requests_table_name();
	$now = current_time('mysql');

	$row = wp_parse_args($data, array(
		'user_id' => 0,
		'profile_id' => 0,
		'status' => 'pending',
		'original_name' => '',
		'stored_name' => '',
		'storage_path' => '',
		'mime_type' => '',
		'file_size' => 0,
		'rejection_reason' => '',
		'admin_note' => '',
		'reviewed_by' => 0,
		'submitted_at' => $now,
		'reviewed_at' => null,
	));

	$row['created_at'] = $now;
	$row['updated_at'] = $now;

	$wpdb->insert(
		$table,
		$row,
		array(
			'%d', '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%d', '%s', '%s', '%s', '%s',
		)
	);

	return (int) $wpdb->insert_id;
}

function escortwp_vv_update_request($request_id, $data) {
	global $wpdb;

	$request_id = (int) $request_id;
	if ($request_id < 1 || !$data) {
		return false;
	}

	$data['updated_at'] = current_time('mysql');

	$formats_map = array(
		'user_id' => '%d',
		'profile_id' => '%d',
		'status' => '%s',
		'original_name' => '%s',
		'stored_name' => '%s',
		'storage_path' => '%s',
		'mime_type' => '%s',
		'file_size' => '%d',
		'rejection_reason' => '%s',
		'admin_note' => '%s',
		'reviewed_by' => '%d',
		'submitted_at' => '%s',
		'reviewed_at' => '%s',
		'updated_at' => '%s',
	);

	$formats = array();
	foreach ($data as $key => $value) {
		if (isset($formats_map[$key])) {
			$formats[] = $formats_map[$key];
		}
	}

	return $wpdb->update(
		escortwp_vv_get_requests_table_name(),
		$data,
		array('id' => $request_id),
		$formats,
		array('%d')
	);
}

function escortwp_vv_get_request($request_id) {
	global $wpdb;

	$request_id = (int) $request_id;
	if ($request_id < 1) {
		return null;
	}

	$table = escortwp_vv_get_requests_table_name();
	$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d LIMIT 1", $request_id));
	return escortwp_vv_normalize_request_row($row);
}

function escortwp_vv_get_latest_request_for_profile($profile_id) {
	global $wpdb;

	$profile_id = (int) $profile_id;
	if ($profile_id < 1) {
		return null;
	}

	$table = escortwp_vv_get_requests_table_name();
	$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE profile_id = %d ORDER BY id DESC LIMIT 1", $profile_id));
	return escortwp_vv_normalize_request_row($row);
}

function escortwp_vv_get_recent_requests($limit = 50, $status = '') {
	global $wpdb;

	$limit = max(1, min(200, (int) $limit));
	$table = escortwp_vv_get_requests_table_name();

	if ($status) {
		$query = $wpdb->prepare("SELECT * FROM {$table} WHERE status = %s ORDER BY submitted_at DESC, id DESC LIMIT %d", sanitize_key($status), $limit);
	} else {
		$query = $wpdb->prepare("SELECT * FROM {$table} ORDER BY submitted_at DESC, id DESC LIMIT %d", $limit);
	}

	$rows = $wpdb->get_results($query);
	if (!$rows) {
		return array();
	}

	return array_map('escortwp_vv_normalize_request_row', $rows);
}

function escortwp_vv_add_log($verification_id, $event, $message = '', $context = array(), $level = 'info') {
	global $wpdb;

	$wpdb->insert(
		escortwp_vv_get_logs_table_name(),
		array(
			'verification_id' => (int) $verification_id,
			'level' => sanitize_key($level),
			'event' => sanitize_key($event),
			'message' => wp_strip_all_tags((string) $message),
			'context_json' => $context ? wp_json_encode($context) : '',
			'created_at' => current_time('mysql'),
		),
		array('%d', '%s', '%s', '%s', '%s', '%s')
	);
}
