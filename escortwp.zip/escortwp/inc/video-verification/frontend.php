<?php

if (!defined('ABSPATH')) {
	exit;
}

function escortwp_vv_enqueue_frontend_assets() {
	if (is_admin() || !is_user_logged_in()) {
		return;
	}

	global $taxonomy_profile_url;
	$current_user = wp_get_current_user();
	if (!$current_user || empty($current_user->ID) || !escortwp_current_user_has_type($taxonomy_profile_url, $current_user->ID)) {
		return;
	}

	wp_enqueue_script(
		'escortwp-video-verification',
		get_template_directory_uri() . '/js/escortwp-video-verification.js',
		array(),
		$GLOBALS['theme_version'],
		true
	);

	wp_localize_script('escortwp-video-verification', 'escortwpVideoVerification', array(
		'nonce' => wp_create_nonce('wp_rest'),
		'restBase' => esc_url_raw(rest_url('escortwp/v1/verify-video')),
		'strings' => array(
			'uploading' => __('Enviando vídeo...', 'escortwp'),
			'success' => __('Vídeo enviado, aguardando aprovação.', 'escortwp'),
			'genericError' => __('Não foi possível enviar o vídeo agora. Tente novamente em alguns instantes.', 'escortwp'),
		),
	));
}

add_action('wp_enqueue_scripts', 'escortwp_vv_enqueue_frontend_assets', 31);

function escortwp_render_video_verification_panel($profile_id) {
	$profile_id = (int) $profile_id;
	if ($profile_id < 1) {
		return '';
	}

	$summary = escortwp_vv_get_profile_status_summary($profile_id);
	$status = !empty($summary['status']) ? $summary['status'] : 'not_verified';
	$request = !empty($summary['request']) ? $summary['request'] : null;
	$can_upload = in_array($status, array('not_verified', 'rejected'), true);

	ob_start();
	?>
	<section id="aba-verificacao" class="escortwp-video-verification-card escortwp-video-verification-card--<?php echo esc_attr($status); ?>">
		<div class="escortwp-video-verification-head">
			<span class="escortwp-form-section-kicker"><?php esc_html_e('Verificação', 'escortwp'); ?></span>
			<h4><?php esc_html_e('Verificação por vídeo', 'escortwp'); ?></h4>
			<p><?php esc_html_e('Envie um vídeo curto para análise manual. Quando a revisão for aprovada, o selo de verificada aparece automaticamente no anúncio.', 'escortwp'); ?></p>
		</div>

		<div class="escortwp-video-verification-status">
			<span class="escortwp-video-verification-badge escortwp-video-verification-badge--<?php echo esc_attr($status); ?>">
				<?php echo esc_html($summary['label']); ?>
			</span>
			<p><?php echo esc_html($summary['description']); ?></p>
			<?php if ($request && !empty($request['submitted_at'])) { ?>
				<small><?php printf(esc_html__('Último envio em %s', 'escortwp'), esc_html(date_i18n('d/m/Y H:i', strtotime($request['submitted_at'])))); ?></small>
			<?php } ?>
			<?php if ($request && $status === 'rejected' && !empty($request['rejection_reason'])) { ?>
				<div class="escortwp-video-verification-reason">
					<strong><?php esc_html_e('Motivo da rejeição', 'escortwp'); ?>:</strong>
					<span><?php echo esc_html($request['rejection_reason']); ?></span>
				</div>
			<?php } ?>
		</div>

		<?php if ($can_upload) { ?>
			<form class="escortwp-video-verification-form" data-profile-id="<?php echo esc_attr($profile_id); ?>">
				<label for="escortwp-verification-video-<?php echo esc_attr($profile_id); ?>"><?php esc_html_e('Vídeo para verificação', 'escortwp'); ?></label>
				<input
					type="file"
					id="escortwp-verification-video-<?php echo esc_attr($profile_id); ?>"
					name="verification_video"
					accept=".mp4,.mov,video/mp4,video/quicktime"
					required
				/>
				<small><?php esc_html_e('Aceitamos MP4 ou MOV com até 50MB. Grave o rosto com boa luz e mostre o rosto de forma clara.', 'escortwp'); ?></small>
				<div class="escortwp-video-verification-actions">
					<button type="submit" class="greenbutton payment-button rad25 escortwp-video-verification-submit"><?php esc_html_e('Enviar vídeo para análise', 'escortwp'); ?></button>
				</div>
				<div class="escortwp-video-verification-feedback" aria-live="polite"></div>
			</form>
		<?php } ?>
	</section>
	<?php
	return ob_get_clean();
}

