<?php

if (!defined('ABSPATH')) {
	exit;
}

function escortwp_vv_register_admin_menu() {
	if (!current_user_can('manage_options')) {
		return;
	}

	add_menu_page(
		__('Verificacao por video', 'escortwp'),
		__('Verificacao por video', 'escortwp'),
		'manage_options',
		'escortwp-video-verification',
		'escortwp_vv_render_admin_page',
		'dashicons-video-alt3',
		58
	);
}

add_action('admin_menu', 'escortwp_vv_register_admin_menu');

function escortwp_vv_admin_handle_decision() {
	if (!current_user_can('manage_options')) {
		wp_die(__('Acesso negado.', 'escortwp'));
	}

	$request_id = isset($_POST['request_id']) ? (int) $_POST['request_id'] : 0;
	$decision = isset($_POST['decision']) ? sanitize_key($_POST['decision']) : '';
	$reason = isset($_POST['reason']) ? wp_unslash($_POST['reason']) : '';
	$admin_note = isset($_POST['admin_note']) ? wp_unslash($_POST['admin_note']) : '';

	check_admin_referer('escortwp_vv_decision_' . $request_id);

	$result = escortwp_vv_review_request($request_id, $decision, get_current_user_id(), $reason, $admin_note);
	$args = array('page' => 'escortwp-video-verification');

	if (is_wp_error($result)) {
		$args['vv_notice'] = 'error';
		$args['vv_message'] = rawurlencode($result->get_error_message());
	} else {
		$args['vv_notice'] = $decision === 'approved' ? 'approved' : 'rejected';
	}

	wp_safe_redirect(add_query_arg($args, admin_url('admin.php')));
	exit;
}

add_action('admin_post_escortwp_vv_decision', 'escortwp_vv_admin_handle_decision');

function escortwp_vv_stream_video() {
	if (!current_user_can('manage_options')) {
		wp_die(__('Acesso negado.', 'escortwp'));
	}

	$request_id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
	if (!wp_verify_nonce(isset($_GET['_wpnonce']) ? $_GET['_wpnonce'] : '', 'escortwp_vv_stream_' . $request_id)) {
		wp_die(__('Link invalido para assistir ao video.', 'escortwp'));
	}

	$request = escortwp_vv_get_request($request_id);
	if (!$request) {
		wp_die(__('Video nao encontrado.', 'escortwp'));
	}

	$absolute_path = escortwp_vv_get_absolute_storage_path($request['storage_path']);
	if (!$absolute_path || !file_exists($absolute_path) || !is_readable($absolute_path)) {
		wp_die(__('Arquivo de video nao encontrado.', 'escortwp'));
	}

	while (ob_get_level() > 0) {
		ob_end_clean();
	}

	if (function_exists('set_time_limit')) {
		@set_time_limit(0);
	}

	ignore_user_abort(true);

	$size = (int) filesize($absolute_path);
	$start = 0;
	$end = max(0, $size - 1);
	$length = $size;
	$filename = sanitize_file_name($request['original_name']);
	$mime_type = !empty($request['mime_type']) ? $request['mime_type'] : 'video/mp4';

	nocache_headers();
	header('Content-Type: ' . $mime_type);
	header('Content-Disposition: inline; filename="' . $filename . '"');
	header('Accept-Ranges: bytes');
	header('X-Content-Type-Options: nosniff');
	header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
	header('Pragma: no-cache');
	header('Expires: 0');

	if (!empty($_SERVER['HTTP_RANGE']) && preg_match('/bytes=(\d*)-(\d*)/i', (string) $_SERVER['HTTP_RANGE'], $matches)) {
		if ($matches[1] !== '') {
			$start = max(0, (int) $matches[1]);
		}
		if ($matches[2] !== '') {
			$end = min($end, (int) $matches[2]);
		}

		if ($start > $end || $start >= $size) {
			status_header(416);
			header('Content-Range: bytes */' . $size);
			exit;
		}

		$length = $end - $start + 1;
		status_header(206);
		header('Content-Range: bytes ' . $start . '-' . $end . '/' . $size);
		header('Content-Length: ' . $length);
	} else {
		status_header(200);
		header('Content-Length: ' . $size);
	}

	$handle = fopen($absolute_path, 'rb');
	if (!$handle) {
		status_header(500);
		exit;
	}

	fseek($handle, $start);
	$buffer_size = 1024 * 128;
	$remaining = $length;

	while (!feof($handle) && $remaining > 0) {
		$read_length = min($buffer_size, $remaining);
		$data = fread($handle, $read_length);
		if ($data === false) {
			break;
		}

		echo $data;
		$remaining -= strlen($data);

		if (function_exists('flush')) {
			flush();
		}
	}

	fclose($handle);
	exit;
}

add_action('admin_post_escortwp_stream_verification_video', 'escortwp_vv_stream_video');

function escortwp_vv_render_admin_notice() {
	if (empty($_GET['page']) || $_GET['page'] !== 'escortwp-video-verification' || empty($_GET['vv_notice'])) {
		return;
	}

	$class = $_GET['vv_notice'] === 'error' ? 'notice notice-error' : 'notice notice-success';
	$message = '';

	if ($_GET['vv_notice'] === 'approved') {
		$message = __('Video aprovado e selo de verificada aplicado ao anuncio.', 'escortwp');
	} elseif ($_GET['vv_notice'] === 'rejected') {
		$message = __('Video rejeitado. A acompanhante ja pode enviar um novo arquivo.', 'escortwp');
	} elseif (!empty($_GET['vv_message'])) {
		$message = sanitize_text_field(wp_unslash($_GET['vv_message']));
	}

	if ($message) {
		echo '<div class="' . esc_attr($class) . '"><p>' . esc_html($message) . '</p></div>';
	}
}

function escortwp_vv_render_admin_page() {
	$requests = escortwp_vv_get_recent_requests(50);
	?>
	<div class="wrap escortwp-vv-admin-page">
		<h1><?php esc_html_e('Verificacao por video', 'escortwp'); ?></h1>
		<?php escortwp_vv_render_admin_notice(); ?>
		<p><?php esc_html_e('Revise os videos enviados pelas acompanhantes, aprove ou rejeite a solicitacao e acompanhe o status atual do selo de verificada.', 'escortwp'); ?></p>
		<style>
			.escortwp-vv-admin-list{display:grid;gap:18px;margin-top:20px}
			.escortwp-vv-admin-card{display:grid;grid-template-columns:minmax(0,1.3fr) minmax(280px,.9fr);gap:18px;padding:18px;background:#fff;border:1px solid #ddd;border-radius:14px;box-shadow:0 8px 22px rgba(30,20,12,.05)}
			.escortwp-vv-admin-meta dt{font-weight:700;margin:0 0 4px}
			.escortwp-vv-admin-meta dd{margin:0 0 12px}
			.escortwp-vv-admin-badge{display:inline-flex;padding:6px 12px;border-radius:999px;font-weight:700}
			.escortwp-vv-admin-badge--pending{background:#efe6dc;color:#7a553b}
			.escortwp-vv-admin-badge--approved{background:#dff3e5;color:#246640}
			.escortwp-vv-admin-badge--rejected{background:#f8dfdf;color:#8c2d2d}
			.escortwp-vv-admin-player video{display:block;width:100%;border-radius:12px;background:#111}
			.escortwp-vv-admin-player .button{margin-top:10px}
			.escortwp-vv-admin-actions form{display:grid;gap:10px;margin-top:14px}
			.escortwp-vv-admin-actions textarea{width:100%;min-height:78px}
			.escortwp-vv-admin-buttons{display:flex;gap:10px;flex-wrap:wrap}
			.escortwp-vv-admin-buttons button{min-width:140px}
			@media (max-width: 960px){.escortwp-vv-admin-card{grid-template-columns:1fr}}
		</style>

		<div class="escortwp-vv-admin-list">
			<?php if (!$requests) { ?>
				<div class="notice notice-info inline"><p><?php esc_html_e('Ainda nao ha videos enviados para revisao.', 'escortwp'); ?></p></div>
			<?php } ?>

			<?php foreach ($requests as $request) {
				$user = get_userdata((int) $request['user_id']);
				$profile_link = get_permalink((int) $request['profile_id']);
				$stream_url = escortwp_vv_get_stream_url((int) $request['id']);
				$status_class = in_array($request['status'], array('approved', 'rejected'), true) ? $request['status'] : 'pending';
				?>
				<section class="escortwp-vv-admin-card">
					<div class="escortwp-vv-admin-meta">
						<span class="escortwp-vv-admin-badge escortwp-vv-admin-badge--<?php echo esc_attr($status_class); ?>">
							<?php echo esc_html(escortwp_vv_get_status_label($request['status'])); ?>
						</span>
						<dl>
							<dt><?php esc_html_e('Acompanhante', 'escortwp'); ?></dt>
							<dd><?php echo esc_html($user ? $user->display_name : __('Conta removida', 'escortwp')); ?></dd>

							<dt><?php esc_html_e('Anuncio', 'escortwp'); ?></dt>
							<dd><a href="<?php echo esc_url($profile_link); ?>" target="_blank" rel="noopener"><?php echo esc_html(get_the_title((int) $request['profile_id'])); ?></a></dd>

							<dt><?php esc_html_e('Enviado em', 'escortwp'); ?></dt>
							<dd><?php echo esc_html(date_i18n('d/m/Y H:i', strtotime($request['submitted_at']))); ?></dd>

							<dt><?php esc_html_e('Arquivo original', 'escortwp'); ?></dt>
							<dd><?php echo esc_html($request['original_name']); ?> (<?php echo esc_html(size_format((int) $request['file_size'])); ?>)</dd>

							<?php if (!empty($request['rejection_reason'])) { ?>
								<dt><?php esc_html_e('Motivo da rejeicao', 'escortwp'); ?></dt>
								<dd><?php echo nl2br(esc_html($request['rejection_reason'])); ?></dd>
							<?php } ?>
						</dl>

						<?php if ($request['status'] !== 'approved') { ?>
							<div class="escortwp-vv-admin-actions">
								<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
									<?php wp_nonce_field('escortwp_vv_decision_' . (int) $request['id']); ?>
									<input type="hidden" name="action" value="escortwp_vv_decision" />
									<input type="hidden" name="request_id" value="<?php echo esc_attr((int) $request['id']); ?>" />
									<input type="hidden" name="decision" value="approved" />
									<textarea name="admin_note" placeholder="<?php echo esc_attr__('Observacao interna opcional', 'escortwp'); ?>"></textarea>
									<div class="escortwp-vv-admin-buttons">
										<button type="submit" class="button button-primary"><?php esc_html_e('Aprovar e aplicar selo', 'escortwp'); ?></button>
									</div>
								</form>
								<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
									<?php wp_nonce_field('escortwp_vv_decision_' . (int) $request['id']); ?>
									<input type="hidden" name="action" value="escortwp_vv_decision" />
									<input type="hidden" name="request_id" value="<?php echo esc_attr((int) $request['id']); ?>" />
									<input type="hidden" name="decision" value="rejected" />
									<textarea name="reason" placeholder="<?php echo esc_attr__('Motivo da rejeicao para a usuaria', 'escortwp'); ?>"></textarea>
									<textarea name="admin_note" placeholder="<?php echo esc_attr__('Observacao interna opcional', 'escortwp'); ?>"></textarea>
									<div class="escortwp-vv-admin-buttons">
										<button type="submit" class="button"><?php esc_html_e('Rejeitar e liberar novo envio', 'escortwp'); ?></button>
									</div>
								</form>
							</div>
						<?php } ?>
					</div>

					<div class="escortwp-vv-admin-player">
						<video controls preload="metadata" playsinline src="<?php echo esc_url($stream_url); ?>"></video>
						<p><a href="<?php echo esc_url($stream_url); ?>" target="_blank" rel="noopener" class="button button-secondary"><?php esc_html_e('Abrir video em nova aba', 'escortwp'); ?></a></p>
					</div>
				</section>
			<?php } ?>
		</div>
	</div>
	<?php
}
