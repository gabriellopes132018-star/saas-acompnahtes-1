﻿<?php

if (!defined('ABSPATH')) {
	exit;
}

function escortwp_mp_get_platform_id() {
	return defined('MP_PLATFORM_ID') ? (string) MP_PLATFORM_ID : '';
}

function escortwp_mp_get_product_id() {
	if (defined('MP_PRODUCT_ID_MOBILE') && wp_is_mobile()) {
		return (string) MP_PRODUCT_ID_MOBILE;
	}

	return defined('MP_PRODUCT_ID_DESKTOP') ? (string) MP_PRODUCT_ID_DESKTOP : '';
}

function escortwp_mp_get_integrator_id() {
	$integrator_id = get_option('_mp_integrator_id', '');
	return is_string($integrator_id) ? trim($integrator_id) : '';
}

function escortwp_mp_get_sdk_instance() {
	static $sdk = null;

	if ($sdk !== null) {
		return $sdk;
	}

	$config = escortwp_mp_get_config();
	if (empty($config['access_token'])) {
		return new WP_Error('escortwp_mp_missing_token', __('Defina o ACCESS_TOKEN do Mercado Pago antes de cobrar via PIX.', 'escortwp'));
	}

	if (!escortwp_mp_bootstrap_sdk()) {
		return new WP_Error('escortwp_mp_missing_sdk', __('O SDK oficial do Mercado Pago nÃ£o foi encontrado na instalaÃ§Ã£o atual.', 'escortwp'));
	}

	$sdk = new \MercadoPago\PP\Sdk\Sdk(
		$config['access_token'],
		escortwp_mp_get_platform_id() ?: null,
		escortwp_mp_get_product_id() ?: null,
		escortwp_mp_get_integrator_id() ?: null
	);
	return $sdk;
}

function escortwp_mp_get_plan_price_value($plan_key) {
	$price = (float) payment_plans($plan_key, 'price');
	if ($price > 0) {
		return $price;
	}

	if ($plan_key === 'premium') {
		return 49.00;
	}

	if ($plan_key === 'featured_boost') {
		return 9.99;
	}

	return 0;
}

function escortwp_mp_get_plan_title($plan_key) {
	switch ($plan_key) {
		case 'premium':
			return __('Plano mensal de 30 dias', 'escortwp');
		case 'featured_boost':
			return __('Impulsionamento por 1 semana', 'escortwp');
		default:
			return __('Pagamento PIX', 'escortwp');
	}
}

function escortwp_mp_get_plan_description($plan_key, $profile_id = 0) {
	$profile_name = $profile_id ? get_the_title($profile_id) : '';

	if ($plan_key === 'premium') {
		return $profile_name
        ? sprintf(__('Plano mensal de 30 dias para o anúncio %s', 'escortwp'), $profile_name)
			: __('Plano mensal de 30 dias', 'escortwp');
	}

	if ($plan_key === 'featured_boost') {
		return $profile_name
        ? sprintf(__('Impulsionamento de 7 dias para o anúncio %s', 'escortwp'), $profile_name)
			: __('Impulsionamento de 7 dias', 'escortwp');
	}

	return __('Pagamento PIX', 'escortwp');
}

function escortwp_mp_get_pix_expiration_timestamp() {
	$config = escortwp_mp_get_config();
	return current_time('timestamp') + ((int) $config['pix_expiration_minutes'] * MINUTE_IN_SECONDS);
}

function escortwp_mp_format_iso8601_utc($timestamp) {
	$timestamp = (int) $timestamp;
	if ($timestamp < 1) {
		$timestamp = time();
	}

	return gmdate('Y-m-d\TH:i:s\Z', $timestamp);
}

function escortwp_mp_normalize_remote_payload($payload) {
	if (is_array($payload)) {
		return $payload;
	}

	if (is_object($payload)) {
		return json_decode(wp_json_encode($payload), true);
	}

	return array();
}

function escortwp_mp_extract_remote_payment_id($payload) {
	$payload = escortwp_mp_normalize_remote_payload($payload);
	return !empty($payload['id']) ? (int) $payload['id'] : 0;
}

function escortwp_mp_extract_remote_status($payload) {
	$payload = escortwp_mp_normalize_remote_payload($payload);
	return !empty($payload['status']) ? sanitize_key($payload['status']) : 'pending';
}

function escortwp_mp_extract_remote_qr_code($payload) {
	$payload = escortwp_mp_normalize_remote_payload($payload);
	return isset($payload['point_of_interaction']['transaction_data']['qr_code']) ? (string) $payload['point_of_interaction']['transaction_data']['qr_code'] : '';
}

function escortwp_mp_extract_remote_qr_base64($payload) {
	$payload = escortwp_mp_normalize_remote_payload($payload);
	return isset($payload['point_of_interaction']['transaction_data']['qr_code_base64']) ? (string) $payload['point_of_interaction']['transaction_data']['qr_code_base64'] : '';
}

function escortwp_mp_build_external_reference($payment_id, $profile_id, $user_id, $plan_key) {
	return sprintf(
		'escortwp-mp-%d-%d-%d-%s',
		(int) $payment_id,
		(int) $profile_id,
		(int) $user_id,
		sanitize_key($plan_key)
	);
}

function escortwp_mp_mark_payment_as_pending($payment) {
	$payment = escortwp_mp_normalize_payment_row($payment);
	if (!$payment || empty($payment['profile_id']) || empty($payment['plan_key'])) {
		return false;
	}

	$profile_id = (int) $payment['profile_id'];
	$mp_payment_id = !empty($payment['mp_payment_id']) ? (int) $payment['mp_payment_id'] : (int) $payment['id'];

	if ($payment['plan_key'] === 'premium') {
		escortwp_update_post_plan_state($profile_id, array(
			'plan_key' => 'premium',
			'plan_type' => 'one_time',
			'plan_status' => 'pending-payment',
			'started_at' => 0,
			'expires_at' => 0,
			'order_id' => $mp_payment_id,
			'product_id' => 0,
			'subscription_id' => 0,
			'subscription_status' => '',
		));

		return true;
	}

	if ($payment['plan_key'] === 'featured_boost') {
		$post = get_post($profile_id);
		if (!$post) {
			return false;
		}

		if (function_exists('escortwp_capture_featured_legacy_state')) {
			escortwp_capture_featured_legacy_state($profile_id);
		}

		if (function_exists('escortwp_upsert_featured_boost_record')) {
			escortwp_upsert_featured_boost_record(array(
				'order_id' => $mp_payment_id,
				'order_item_id' => 0,
				'product_id' => 0,
				'profile_id' => $profile_id,
				'user_id' => (int) $post->post_author,
				'payment_status' => 'pending',
				'boost_status' => 'pending',
				'amount' => (float) $payment['valor'],
				'currency' => !empty($payment['currency']) ? $payment['currency'] : 'BRL',
				'notes' => 'mercadopago_pix_pending:' . (int) $payment['id'],
			));
		}

		update_post_meta($profile_id, 'escortwp_featured_boost_status', 'pending');
		update_post_meta($profile_id, 'escortwp_featured_boost_started_at', 0);
		update_post_meta($profile_id, 'escortwp_featured_boost_expires_at', 0);

		return true;
	}

	return false;
}

function escortwp_mp_rate_limit_key($user_id, $profile_id, $plan_key) {
	return 'escortwp_mp_rate_' . md5((int) $user_id . '|' . (int) $profile_id . '|' . sanitize_key($plan_key));
}

function escortwp_mp_check_create_rate_limit($user_id, $profile_id, $plan_key) {
	$key = escortwp_mp_rate_limit_key($user_id, $profile_id, $plan_key);
	$attempts = (int) get_transient($key);
	if ($attempts >= 10) {
		return new WP_Error('escortwp_mp_rate_limited', __('Muitas tentativas de pagamento em sequÃªncia. Aguarde um minuto e tente novamente.', 'escortwp'), array('status' => 429));
	}

	set_transient($key, $attempts + 1, MINUTE_IN_SECONDS);
	return true;
}

function escortwp_mp_create_pix_payment($user_id, $profile_id, $plan_key) {
	$user_id = (int) $user_id;
	$profile_id = (int) $profile_id;
	$plan_key = sanitize_key($plan_key);

	if ($user_id < 1 || $profile_id < 1 || !in_array($plan_key, array('premium', 'featured_boost'), true)) {
		return new WP_Error('escortwp_mp_invalid_request', __('NÃ£o foi possÃ­vel preparar o pagamento solicitado.', 'escortwp'), array('status' => 400));
	}

	if (!escortwp_current_user_can_manage_post($profile_id)) {
		return new WP_Error('escortwp_mp_forbidden', __('VocÃª nÃ£o tem permissÃ£o para contratar este plano.', 'escortwp'), array('status' => 403));
	}

	$rate_limit = escortwp_mp_check_create_rate_limit($user_id, $profile_id, $plan_key);
	if (is_wp_error($rate_limit)) {
		return $rate_limit;
	}

	$existing_pending = escortwp_mp_get_latest_reusable_pending_payment($user_id, $profile_id, $plan_key);
	if ($existing_pending) {
		escortwp_mp_mark_payment_as_pending($existing_pending);
		escortwp_mp_log_event('pix_payment_reused', 'Pagamento PIX pendente reutilizado.', $existing_pending, 'info', $existing_pending['id']);
		return $existing_pending;
	}

	$amount = escortwp_mp_get_plan_price_value($plan_key);
	if ($amount <= 0) {
		return new WP_Error('escortwp_mp_invalid_amount', __('O valor deste plano ainda nÃ£o foi configurado.', 'escortwp'), array('status' => 400));
	}

	$sdk = escortwp_mp_get_sdk_instance();
	if (is_wp_error($sdk)) {
		return $sdk;
	}

	$payment_id = escortwp_mp_insert_payment(array(
		'user_id' => $user_id,
		'profile_id' => $profile_id,
		'plan_key' => $plan_key,
		'valor' => $amount,
		'currency' => 'BRL',
		'status' => 'pending',
		'qr_expires_at' => escortwp_mp_get_pix_expiration_timestamp(),
	));

	$external_reference = escortwp_mp_build_external_reference($payment_id, $profile_id, $user_id, $plan_key);
	escortwp_mp_update_payment($payment_id, array('mp_external_reference' => $external_reference));

	$user = get_userdata($user_id);
	$user_name = $user ? trim((string) $user->display_name) : '';
	$name_parts = preg_split('/\s+/', $user_name);
	$first_name = !empty($name_parts[0]) ? $name_parts[0] : __('Cliente', 'escortwp');
	$last_name = count($name_parts) > 1 ? trim(implode(' ', array_slice($name_parts, 1))) : 'EscortWP';

	try {
		$remote_payment = $sdk->getPaymentInstance();
		$remote_payment->payment_method_id = 'pix';
		$remote_payment->transaction_amount = $amount;
		$remote_payment->description = escortwp_mp_get_plan_description($plan_key, $profile_id);
		$remote_payment->external_reference = $external_reference;
		$remote_payment->notification_url = escortwp_mp_get_config()['notification_url'];
		$remote_payment->date_of_expiration = escortwp_mp_format_iso8601_utc(escortwp_mp_get_pix_expiration_timestamp());
		$remote_payment->payer->email = $user ? $user->user_email : '';
		$remote_payment->payer->first_name = $first_name;
		$remote_payment->payer->last_name = $last_name;
		$remote_payment->point_of_interaction->type = 'CHECKOUT';
		$remote_payment->metadata = array(
			'source' => 'escortwp_theme',
			'profile_id' => $profile_id,
			'user_id' => $user_id,
			'plan_key' => $plan_key,
			'local_payment_id' => $payment_id,
		);

		$remote_response = $remote_payment->save();
		$remote_data = escortwp_mp_normalize_remote_payload($remote_response);

		$remote_payment_id = escortwp_mp_extract_remote_payment_id($remote_data);
		$remote_status = escortwp_mp_extract_remote_status($remote_data);
		$qr_code = escortwp_mp_extract_remote_qr_code($remote_data);
		$qr_base64 = escortwp_mp_extract_remote_qr_base64($remote_data);
		$qr_expires_at = !empty($remote_data['date_of_expiration']) ? strtotime($remote_data['date_of_expiration']) : escortwp_mp_get_pix_expiration_timestamp();

		escortwp_mp_update_payment($payment_id, array(
			'status' => $remote_status ?: 'pending',
			'mp_payment_id' => $remote_payment_id,
			'qr_code' => $qr_code,
			'qr_code_base64' => $qr_base64,
			'qr_expires_at' => $qr_expires_at,
			'provider_payload' => wp_json_encode($remote_data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
			'last_synced_at' => current_time('timestamp'),
		));

		$local_payment = escortwp_mp_get_payment($payment_id);
		if ($local_payment && $local_payment['status'] === 'pending') {
			escortwp_mp_mark_payment_as_pending($local_payment);
		} elseif ($local_payment && $local_payment['status'] === 'approved') {
			escortwp_mp_apply_payment_effects($local_payment);
		}
		escortwp_mp_log_event('pix_payment_created', 'CobranÃ§a PIX criada com sucesso.', array('remote' => $remote_data), 'info', $payment_id);
		return $local_payment;
	} catch (Exception $exception) {
		escortwp_mp_update_payment($payment_id, array(
			'status' => 'rejected',
			'last_error' => $exception->getMessage(),
		));
		escortwp_mp_log_event('pix_payment_error', $exception->getMessage(), array(
			'profile_id' => $profile_id,
			'user_id' => $user_id,
			'plan_key' => $plan_key,
		), 'error', $payment_id);

		return new WP_Error('escortwp_mp_create_failed', __('NÃ£o foi possÃ­vel gerar o PIX agora. Tente novamente em instantes.', 'escortwp'), array('status' => 500));
	}
}

function escortwp_mp_fetch_remote_payment($mp_payment_id) {
	$mp_payment_id = (int) $mp_payment_id;
	if ($mp_payment_id < 1) {
		return new WP_Error('escortwp_mp_invalid_payment_id', __('Identificador de pagamento invÃ¡lido.', 'escortwp'));
	}

	$sdk = escortwp_mp_get_sdk_instance();
	if (is_wp_error($sdk)) {
		return $sdk;
	}

	try {
		$payment = $sdk->getPaymentInstance();
		$response = $payment->read(array('id' => $mp_payment_id));
		return escortwp_mp_normalize_remote_payload($response);
	} catch (Exception $exception) {
		escortwp_mp_log_event('pix_payment_fetch_error', $exception->getMessage(), array('mp_payment_id' => $mp_payment_id), 'error');
		return new WP_Error('escortwp_mp_fetch_failed', __('NÃ£o foi possÃ­vel consultar o pagamento no Mercado Pago.', 'escortwp'));
	}
}

function escortwp_mp_map_remote_status($remote_status) {
	$remote_status = sanitize_key($remote_status);

	if (in_array($remote_status, array('approved'), true)) {
		return 'approved';
	}

	if (in_array($remote_status, array('pending', 'in_process', 'in_mediation', 'authorized'), true)) {
		return 'pending';
	}

	if (in_array($remote_status, array('cancelled'), true)) {
		return 'cancelled';
	}

	if (in_array($remote_status, array('refunded', 'charged_back'), true)) {
		return 'refunded';
	}

	if (in_array($remote_status, array('rejected'), true)) {
		return 'rejected';
	}

	if ($remote_status === 'expired') {
		return 'rejected';
	}

	return 'pending';
}

function escortwp_mp_sync_payment($local_payment, $mark_webhook_verified = false) {
	if (!$local_payment) {
		return new WP_Error('escortwp_mp_missing_local_payment', __('Pagamento local nÃ£o encontrado.', 'escortwp'));
	}

	if (!is_array($local_payment)) {
		$local_payment = escortwp_mp_normalize_payment_row($local_payment);
	}

	if (empty($local_payment['mp_payment_id'])) {
		return new WP_Error('escortwp_mp_missing_remote_id', __('O pagamento ainda nÃ£o recebeu um identificador remoto.', 'escortwp'));
	}

	$remote = escortwp_mp_fetch_remote_payment($local_payment['mp_payment_id']);
	if (is_wp_error($remote)) {
		return $remote;
	}

	$mapped_status = escortwp_mp_map_remote_status(escortwp_mp_extract_remote_status($remote));
	$update = array(
		'status' => $mapped_status,
		'provider_payload' => wp_json_encode($remote, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
		'last_synced_at' => current_time('timestamp'),
		'qr_code' => escortwp_mp_extract_remote_qr_code($remote),
		'qr_code_base64' => escortwp_mp_extract_remote_qr_base64($remote),
	);

	$remote_expiration = !empty($remote['date_of_expiration']) ? strtotime($remote['date_of_expiration']) : 0;
	if ($remote_expiration > 0) {
		$update['qr_expires_at'] = $remote_expiration;
	}

	if ($mark_webhook_verified) {
		$update['webhook_verified'] = 1;
	}

	if ($mapped_status === 'approved' && empty($local_payment['paid_at'])) {
		$update['paid_at'] = current_time('timestamp');
	}

	escortwp_mp_update_payment($local_payment['id'], $update);
	$local_payment = escortwp_mp_get_payment($local_payment['id']);

	escortwp_mp_apply_payment_effects($local_payment);
	escortwp_mp_log_event('pix_payment_synced', 'Status sincronizado com o Mercado Pago.', array('remote_status' => $remote['status'] ?? ''), 'info', $local_payment['id']);

	return $local_payment;
}

function escortwp_mp_apply_payment_effects($payment) {
	if (!$payment || empty($payment['profile_id']) || empty($payment['plan_key'])) {
		return false;
	}

	if ($payment['status'] === 'approved') {
		if ($payment['plan_key'] === 'premium') {
			return escortwp_mp_apply_premium_approval($payment);
		}

		if ($payment['plan_key'] === 'featured_boost') {
			return escortwp_mp_apply_boost_approval($payment);
		}
	}

	if (in_array($payment['status'], array('cancelled', 'refunded', 'rejected'), true)) {
		if ($payment['plan_key'] === 'featured_boost') {
			escortwp_revoke_featured_boost_payment((int) $payment['mp_payment_id'], 0, $payment['status']);
		}

		if ($payment['plan_key'] === 'premium') {
			escortwp_mp_recalculate_premium_state($payment['profile_id']);
		}
	}

	return true;
}

function escortwp_mp_apply_premium_approval($payment) {
	$payment = escortwp_mp_normalize_payment_row($payment);
	if (!$payment || empty($payment['profile_id'])) {
		return false;
	}

	$starts_at = (int) $payment['starts_at'];
	$expires_at = (int) $payment['expires_at'];
	$now = current_time('timestamp');
	$duration = escortwp_get_payment_duration_seconds('premium');
	if ($duration < DAY_IN_SECONDS) {
		$duration = 30 * DAY_IN_SECONDS;
	}

	if ($starts_at < 1 || $expires_at < 1) {
		$active_rows = escortwp_mp_get_approved_active_payments_for_plan($payment['profile_id'], 'premium');
		$latest_expiration = 0;
		if ($active_rows) {
			foreach ($active_rows as $active_row) {
				if ((int) $active_row->id === (int) $payment['id']) {
					continue;
				}
				$latest_expiration = max($latest_expiration, (int) $active_row->expires_at);
			}
		}

		$current_plan_expiration = (int) get_post_meta($payment['profile_id'], 'premium_expire', true);
		$starts_at = max($now, $latest_expiration, $current_plan_expiration);
		$expires_at = $starts_at + $duration;

		escortwp_mp_update_payment($payment['id'], array(
			'starts_at' => $starts_at,
			'expires_at' => $expires_at,
		));
	}

	escortwp_mp_recalculate_premium_state($payment['profile_id']);
	return true;
}

function escortwp_mp_recalculate_premium_state($profile_id) {
	$profile_id = (int) $profile_id;
	if ($profile_id < 1 || !get_post($profile_id)) {
		return false;
	}

	$active_rows = escortwp_mp_get_approved_active_payments_for_plan($profile_id, 'premium');
	if ($active_rows) {
		$latest = escortwp_mp_normalize_payment_row($active_rows[0]);
		$now = current_time('timestamp');
		update_post_meta($profile_id, 'premium', '1');
		update_post_meta($profile_id, 'premium_since', $latest['starts_at'] ? $latest['starts_at'] : $now);
		update_post_meta($profile_id, 'premium_txn_id', $latest['mp_payment_id']);
		update_post_meta($profile_id, 'premium_expire', $latest['expires_at']);
		delete_post_meta($profile_id, 'premium_renew');
		escortwp_update_post_plan_state($profile_id, array(
			'plan_key' => 'premium',
			'plan_type' => 'one_time',
			'plan_status' => 'active',
			'started_at' => $latest['starts_at'] ? $latest['starts_at'] : $now,
			'expires_at' => $latest['expires_at'],
			'order_id' => $latest['mp_payment_id'],
			'product_id' => 0,
			'subscription_id' => 0,
			'subscription_status' => '',
		));
		return true;
	}

	update_post_meta($profile_id, 'premium', '0');
	delete_post_meta($profile_id, 'premium_since');
	delete_post_meta($profile_id, 'premium_txn_id');
	delete_post_meta($profile_id, 'premium_expire');
	delete_post_meta($profile_id, 'premium_renew');
	escortwp_sync_post_plan_state_from_legacy($profile_id, escortwp_get_registration_plan_key_for_post($profile_id));
	return true;
}

function escortwp_mp_apply_boost_approval($payment) {
	$payment = escortwp_mp_normalize_payment_row($payment);
	if (!$payment || empty($payment['profile_id'])) {
		return false;
	}

	$starts_at = (int) $payment['starts_at'];
	$expires_at = (int) $payment['expires_at'];
	$now = current_time('timestamp');

	if ($starts_at < 1 || $expires_at < 1) {
		$current_expires_at = (int) get_post_meta($payment['profile_id'], 'escortwp_featured_boost_expires_at', true);
		if ($current_expires_at < $now) {
			$current_expires_at = 0;
		}

		$starts_at = $current_expires_at > $now ? $current_expires_at : $now;
		$expires_at = $starts_at + escortwp_get_featured_boost_duration_seconds();
		escortwp_mp_update_payment($payment['id'], array(
			'starts_at' => $starts_at,
			'expires_at' => $expires_at,
		));
	}

	$post = get_post($payment['profile_id']);
	escortwp_capture_featured_legacy_state($payment['profile_id']);
	escortwp_upsert_featured_boost_record(array(
		'order_id' => (int) $payment['mp_payment_id'],
		'order_item_id' => 0,
		'product_id' => 0,
		'profile_id' => (int) $payment['profile_id'],
		'user_id' => $post ? (int) $post->post_author : 0,
		'payment_status' => 'approved',
		'boost_status' => 'active',
		'amount' => (float) $payment['valor'],
		'currency' => $payment['currency'],
		'starts_at' => $starts_at,
		'expires_at' => $expires_at,
		'notes' => 'mercadopago_pix:' . (int) $payment['id'],
	));

	escortwp_apply_featured_boost_state($payment['profile_id'], $starts_at, $expires_at, (int) $payment['mp_payment_id']);
	escortwp_schedule_featured_boost_expiration($payment['profile_id'], $expires_at);
	return true;
}

function escortwp_mp_get_payment_status_label($status) {
	switch (sanitize_key($status)) {
		case 'approved':
			return __('Pagamento aprovado', 'escortwp');
		case 'rejected':
			return __('Pagamento recusado', 'escortwp');
		case 'cancelled':
			return __('Pagamento cancelado', 'escortwp');
		case 'refunded':
			return __('Pagamento reembolsado', 'escortwp');
		case 'pending':
		default:
			return __('Aguardando pagamento', 'escortwp');
	}
}

function escortwp_mp_expire_stale_pending_payments() {
	global $wpdb;

	$table = escortwp_mp_get_payments_table_name();
	$now = current_time('timestamp');
	$expired_rows = $wpdb->get_results($wpdb->prepare(
		"SELECT * FROM {$table} WHERE status = %s AND qr_expires_at > 0 AND qr_expires_at <= %d",
		'pending',
		$now
	));

	if(!$expired_rows) {
		return;
	}

	foreach($expired_rows as $row) {
		$payment = escortwp_mp_normalize_payment_row($row);
		escortwp_mp_update_payment($payment['id'], array(
			'status' => 'rejected',
			'last_error' => __('PIX expirado sem pagamento confirmado.', 'escortwp'),
			'last_synced_at' => $now,
		));
		$payment = escortwp_mp_get_payment($payment['id']);
		if ($payment) {
			escortwp_mp_apply_payment_effects($payment);
		}
		escortwp_mp_log_event('pix_payment_expired', 'PIX pendente expirado automaticamente.', array(), 'warning', $payment['id']);
	}
}

function escortwp_mp_run_payment_maintenance() {
	static $running = false;

	if($running) {
		return;
	}

	$running = true;
	escortwp_mp_expire_stale_pending_payments();

	global $wpdb;
	$table = escortwp_mp_get_payments_table_name();
	$premium_profiles = $wpdb->get_col($wpdb->prepare(
		"SELECT DISTINCT profile_id FROM {$table} WHERE plan_key = %s AND profile_id > 0",
		'premium'
	));

	if($premium_profiles) {
		foreach($premium_profiles as $profile_id) {
			escortwp_mp_recalculate_premium_state((int)$profile_id);
		}
	}

	if(function_exists('escortwp_expire_due_featured_boosts')) {
		escortwp_expire_due_featured_boosts();
	}

	$running = false;
}
add_action('init', 'escortwp_mp_run_payment_maintenance', 25);

