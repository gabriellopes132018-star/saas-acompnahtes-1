<?php

if (!defined('ABSPATH')) {
	exit;
}

function escortwp_mp_prepare_payment_response($payment) {
	$payment = escortwp_mp_normalize_payment_row($payment);
	if (!$payment) {
		return array();
	}

	return array(
		'id' => (int) $payment['id'],
		'profile_id' => (int) $payment['profile_id'],
		'plan_key' => $payment['plan_key'],
		'valor' => (float) $payment['valor'],
		'status' => $payment['status'],
		'status_label' => escortwp_mp_get_payment_status_label($payment['status']),
		'mp_payment_id' => (int) $payment['mp_payment_id'],
		'qr_code' => (string) $payment['qr_code'],
		'qr_code_base64' => (string) $payment['qr_code_base64'],
		'qr_expires_at' => (int) $payment['qr_expires_at'],
		'starts_at' => (int) $payment['starts_at'],
		'expires_at' => (int) $payment['expires_at'],
		'created_at' => (string) $payment['created_at'],
	);
}

function escortwp_mp_rest_can_create_payments() {
	return is_user_logged_in();
}

function escortwp_mp_rest_create_payment(\WP_REST_Request $request) {
	$profile_id = (int) $request->get_param('profile_id');
	$plan_key = sanitize_key($request->get_param('plan_key'));
	$current_user_id = get_current_user_id();

	if (!$profile_id || !$plan_key) {
		return new \WP_Error('escortwp_mp_missing_params', __('Informe o anúncio e o plano antes de gerar o PIX.', 'escortwp'), array('status' => 400));
	}

	$result = escortwp_mp_create_pix_payment($current_user_id, $profile_id, $plan_key);
	if (is_wp_error($result)) {
		return $result;
	}

	return rest_ensure_response(escortwp_mp_prepare_payment_response($result));
}

function escortwp_mp_rest_can_read_payment(\WP_REST_Request $request) {
	$payment_id = (int) $request['id'];
	$payment = escortwp_mp_get_payment($payment_id);
	if (!$payment) {
		return new \WP_Error('escortwp_mp_not_found', __('Pagamento não encontrado.', 'escortwp'), array('status' => 404));
	}

	if (current_user_can('manage_options')) {
		return true;
	}

	return is_user_logged_in() && (int) $payment['user_id'] === (int) get_current_user_id();
}

function escortwp_mp_rest_get_payment(\WP_REST_Request $request) {
	$payment_id = (int) $request['id'];
	$payment = escortwp_mp_get_payment($payment_id);
	if (!$payment) {
		return new \WP_Error('escortwp_mp_not_found', __('Pagamento não encontrado.', 'escortwp'), array('status' => 404));
	}

	if ($payment['status'] === 'pending' && !empty($payment['mp_payment_id'])) {
		$synced = escortwp_mp_sync_payment($payment, false);
		if (!is_wp_error($synced)) {
			$payment = $synced;
		}
	}

	return rest_ensure_response(escortwp_mp_prepare_payment_response($payment));
}

function escortwp_mp_extract_webhook_payment_id(\WP_REST_Request $request) {
	$body_params = $request->get_json_params();
	if (!$body_params) {
		$body_params = $request->get_body_params();
	}

	if (!empty($body_params['data']['id'])) {
		return (int) preg_replace('/\D+/', '', (string) $body_params['data']['id']);
	}

	if (!empty($body_params['data_id'])) {
		return (int) preg_replace('/\D+/', '', (string) $body_params['data_id']);
	}

	if (!empty($body_params['id']) && (!empty($body_params['topic']) || !empty($body_params['type']))) {
		return (int) preg_replace('/\D+/', '', (string) $body_params['id']);
	}

	$query_params = $request->get_query_params();
	if (!empty($query_params['data.id'])) {
		return (int) preg_replace('/\D+/', '', (string) $query_params['data.id']);
	}
	if (!empty($query_params['id'])) {
		return (int) preg_replace('/\D+/', '', (string) $query_params['id']);
	}

	return 0;
}

function escortwp_mp_validate_webhook_signature(\WP_REST_Request $request, $payment_id) {
	$config = escortwp_mp_get_config();
	if (empty($config['webhook_secret'])) {
		return true;
	}

	$signature = $request->get_header('x-signature');
	$request_id = $request->get_header('x-request-id');
	if (!$signature || !$request_id || !$payment_id) {
		return false;
	}

	$parts = array();
	foreach (explode(',', $signature) as $piece) {
		$piece = trim($piece);
		if (strpos($piece, '=') === false) {
			continue;
		}
		list($key, $value) = array_map('trim', explode('=', $piece, 2));
		$parts[$key] = $value;
	}

	if (empty($parts['ts']) || empty($parts['v1'])) {
		return false;
	}

	$manifest = sprintf('id:%s;request-id:%s;ts:%s;', $payment_id, $request_id, $parts['ts']);
	$expected = hash_hmac('sha256', $manifest, $config['webhook_secret']);
	return hash_equals($expected, $parts['v1']);
}

function escortwp_mp_rest_webhook(\WP_REST_Request $request) {
	$payment_id = escortwp_mp_extract_webhook_payment_id($request);
	if (!$payment_id) {
		escortwp_mp_log_event('webhook_invalid', 'Webhook recebido sem payment_id.', array('body' => $request->get_body()), 'warning');
		return new \WP_REST_Response(array('ok' => false), 202);
	}

	if (!escortwp_mp_validate_webhook_signature($request, $payment_id)) {
		escortwp_mp_log_event('webhook_invalid_signature', 'Assinatura do webhook inválida.', array('payment_id' => $payment_id), 'warning');
		return new \WP_REST_Response(array('ok' => false), 403);
	}

	$remote = escortwp_mp_fetch_remote_payment($payment_id);
	if (is_wp_error($remote)) {
		return new \WP_REST_Response(array('ok' => false), 422);
	}

	$local_payment = escortwp_mp_get_payment_by_mp_payment_id($payment_id);
	if (!$local_payment && !empty($remote['external_reference'])) {
		$local_payment = escortwp_mp_get_payment_by_external_reference($remote['external_reference']);
	}

	if (!$local_payment) {
		escortwp_mp_log_event('webhook_payment_not_found', 'Pagamento não localizado na base local.', array(
			'payment_id' => $payment_id,
			'external_reference' => $remote['external_reference'] ?? '',
		), 'warning');
		return new \WP_REST_Response(array('ok' => true), 202);
	}

	$synced = escortwp_mp_sync_payment($local_payment, true);
	if (is_wp_error($synced)) {
		return new \WP_REST_Response(array('ok' => false), 422);
	}

	return new \WP_REST_Response(array('ok' => true), 200);
}

function escortwp_mp_register_rest_routes() {
	register_rest_route('escortwp/v1', '/payments/pix', array(
		'methods' => \WP_REST_Server::CREATABLE,
		'callback' => 'escortwp_mp_rest_create_payment',
		'permission_callback' => 'escortwp_mp_rest_can_create_payments',
		'args' => array(
			'profile_id' => array(
				'required' => true,
				'type' => 'integer',
			),
			'plan_key' => array(
				'required' => true,
				'type' => 'string',
			),
		),
	));

	register_rest_route('escortwp/v1', '/payments/(?P<id>\d+)', array(
		'methods' => \WP_REST_Server::READABLE,
		'callback' => 'escortwp_mp_rest_get_payment',
		'permission_callback' => 'escortwp_mp_rest_can_read_payment',
	));

	register_rest_route('escortwp/v1', '/payments/webhook/mercadopago', array(
		'methods' => \WP_REST_Server::CREATABLE,
		'callback' => 'escortwp_mp_rest_webhook',
		'permission_callback' => '__return_true',
	));
}

add_action('rest_api_init', 'escortwp_mp_register_rest_routes');

