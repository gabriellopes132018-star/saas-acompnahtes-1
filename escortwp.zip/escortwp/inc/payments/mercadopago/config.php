<?php

if (!defined('ABSPATH')) {
	exit;
}

function escortwp_mp_get_env_value($key, $default = '') {
	$candidates = array($key, strtoupper($key), strtolower($key));

	foreach ($candidates as $candidate) {
		if (defined($candidate)) {
			$value = constant($candidate);
			if ($value !== '' && $value !== null) {
				return $value;
			}
		}

		$server_value = isset($_SERVER[$candidate]) ? $_SERVER[$candidate] : null;
		if ($server_value !== null && $server_value !== '') {
			return $server_value;
		}

		$env_value = getenv($candidate);
		if ($env_value !== false && $env_value !== '') {
			return $env_value;
		}

		if (isset($_ENV[$candidate]) && $_ENV[$candidate] !== '') {
			return $_ENV[$candidate];
		}
	}

	return $default;
}

function escortwp_mp_env_bool($key, $default = null) {
	$value = escortwp_mp_get_env_value($key, null);
	if ($value === null || $value === '') {
		return $default;
	}

	$normalized = strtolower(trim((string) $value));
	return in_array($normalized, array('1', 'true', 'yes', 'on'), true);
}

function escortwp_mp_get_sdk_autoload_path() {
	static $autoload_path = null;

	if ($autoload_path !== null) {
		return $autoload_path;
	}

	$paths = array(
		WP_CONTENT_DIR . '/plugins/woocommerce-mercadopago/vendor/autoload.php',
		WP_PLUGIN_DIR . '/woocommerce-mercadopago/vendor/autoload.php',
	);

	foreach ($paths as $path) {
		if (file_exists($path)) {
			$autoload_path = $path;
			return $autoload_path;
		}
	}

	$autoload_path = '';
	return $autoload_path;
}

function escortwp_mp_bootstrap_sdk() {
	if (class_exists('MercadoPago\\PP\\Sdk\\Sdk')) {
		return true;
	}

	$autoload_path = escortwp_mp_get_sdk_autoload_path();
	if (!$autoload_path) {
		return false;
	}

	require_once $autoload_path;
	return class_exists('MercadoPago\\PP\\Sdk\\Sdk');
}

function escortwp_mp_get_config() {
	static $config = null;

	if ($config !== null) {
		return $config;
	}

	$sandbox = escortwp_mp_env_bool('MERCADO_PAGO_SANDBOX', null);
	if ($sandbox === null) {
		$sandbox = escortwp_mp_env_bool('MERCADOPAGO_SANDBOX', null);
	}
	if ($sandbox === null) {
		$sandbox = get_option('checkbox_checkout_test_mode', 'yes') === 'yes';
	}

	$access_token = $sandbox
		? escortwp_mp_get_env_value('MERCADO_PAGO_ACCESS_TOKEN_TEST')
		: escortwp_mp_get_env_value('MERCADO_PAGO_ACCESS_TOKEN');

	if (!$access_token) {
		$access_token = escortwp_mp_get_env_value('MERCADOPAGO_ACCESS_TOKEN');
	}

	if (!$access_token) {
		$access_token = $sandbox ? get_option('_mp_access_token_test', '') : get_option('_mp_access_token_prod', '');
	}

	$webhook_secret = escortwp_mp_get_env_value('MERCADO_PAGO_WEBHOOK_SECRET');
	if (!$webhook_secret) {
		$webhook_secret = escortwp_mp_get_env_value('MERCADOPAGO_WEBHOOK_SECRET');
	}

	$pix_expiration_minutes = (int) escortwp_mp_get_env_value('MERCADO_PAGO_PIX_EXPIRATION_MINUTES', 30);
	if ($pix_expiration_minutes < 5) {
		$pix_expiration_minutes = 30;
	}

	$config = array(
		'enabled' => !empty($access_token),
		'access_token' => $access_token,
		'sandbox' => (bool) $sandbox,
		'webhook_secret' => (string) $webhook_secret,
		'pix_expiration_minutes' => $pix_expiration_minutes,
		'notification_url' => rest_url('escortwp/v1/payments/webhook/mercadopago'),
		'sdk_autoload' => escortwp_mp_get_sdk_autoload_path(),
		'currency' => 'BRL',
	);

	return $config;
}

function escortwp_mp_is_ready() {
	$config = escortwp_mp_get_config();
	return !empty($config['enabled']) && escortwp_mp_bootstrap_sdk();
}

function escortwp_mp_get_webhook_validation_mode() {
	$config = escortwp_mp_get_config();
	return !empty($config['webhook_secret']) ? 'signature+api' : 'api';
}

