<?php

if (!defined('ABSPATH')) {
	exit;
}

function escortwp_mp_log_event($event, $message = '', $context = array(), $level = 'info', $payment_id = 0) {
	global $wpdb;

	$table = escortwp_mp_get_payment_logs_table_name();
	$wpdb->insert(
		$table,
		array(
			'payment_id' => (int) $payment_id,
			'level' => sanitize_key($level),
			'event' => sanitize_key($event),
			'message' => is_scalar($message) ? sanitize_textarea_field((string) $message) : '',
			'context_json' => wp_json_encode($context, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
			'created_at' => current_time('mysql'),
		),
		array('%d', '%s', '%s', '%s', '%s', '%s')
	);

	if (defined('WP_DEBUG_LOG') && WP_DEBUG_LOG) {
		error_log('[escortwp-mp][' . sanitize_key($event) . '] ' . wp_json_encode($context));
	}
}

