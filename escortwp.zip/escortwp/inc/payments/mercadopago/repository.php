<?php

if (!defined('ABSPATH')) {
	exit;
}

function escortwp_mp_get_payments_table_name() {
	global $wpdb;
	return $wpdb->prefix . 'escortwp_mp_payments';
}

function escortwp_mp_get_payment_logs_table_name() {
	global $wpdb;
	return $wpdb->prefix . 'escortwp_mp_payment_logs';
}

function escortwp_mp_install_schema() {
	global $wpdb;

	$installed_version = get_option('escortwp_mp_schema_version');
	if ($installed_version === '1.0.2') {
		return;
	}

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';

	$charset_collate = $wpdb->get_charset_collate();
	$payments_table = escortwp_mp_get_payments_table_name();
	$logs_table = escortwp_mp_get_payment_logs_table_name();

	$sql_payments = "CREATE TABLE {$payments_table} (
		id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
		profile_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
		plan_key VARCHAR(64) NOT NULL DEFAULT '',
		valor DECIMAL(12,2) NOT NULL DEFAULT 0.00,
		currency VARCHAR(12) NOT NULL DEFAULT 'BRL',
		status VARCHAR(32) NOT NULL DEFAULT 'pending',
		mp_payment_id BIGINT UNSIGNED NULL DEFAULT NULL,
		mp_external_reference VARCHAR(191) NULL DEFAULT NULL,
		qr_code LONGTEXT NULL,
		qr_code_base64 LONGTEXT NULL,
		qr_expires_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
		starts_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
		expires_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
		paid_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
		last_synced_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
		webhook_verified TINYINT(1) NOT NULL DEFAULT 0,
		provider_payload LONGTEXT NULL,
		last_error TEXT NULL,
		created_at DATETIME NOT NULL,
		updated_at DATETIME NOT NULL,
		PRIMARY KEY  (id),
		UNIQUE KEY mp_payment_id (mp_payment_id),
		UNIQUE KEY mp_external_reference (mp_external_reference),
		KEY profile_plan_status (profile_id, plan_key, status),
		KEY user_status (user_id, status),
		KEY qr_expires_at (qr_expires_at),
		KEY expires_at (expires_at)
	) {$charset_collate};";

	$sql_logs = "CREATE TABLE {$logs_table} (
		id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		payment_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
		level VARCHAR(16) NOT NULL DEFAULT 'info',
		event VARCHAR(80) NOT NULL DEFAULT '',
		message TEXT NULL,
		context_json LONGTEXT NULL,
		created_at DATETIME NOT NULL,
		PRIMARY KEY (id),
		KEY payment_id (payment_id),
		KEY level_event (level, event)
	) {$charset_collate};";

	dbDelta($sql_payments);
	dbDelta($sql_logs);

	$wpdb->query("ALTER TABLE {$payments_table} MODIFY mp_payment_id BIGINT UNSIGNED NULL DEFAULT NULL");
	$wpdb->query("ALTER TABLE {$payments_table} MODIFY mp_external_reference VARCHAR(191) NULL DEFAULT NULL");
	$wpdb->query("UPDATE {$payments_table} SET mp_payment_id = NULL WHERE mp_payment_id = 0");
	$wpdb->query("UPDATE {$payments_table} SET mp_external_reference = NULL WHERE mp_external_reference = ''");

	update_option('escortwp_mp_schema_version', '1.0.2', false);
}

add_action('init', 'escortwp_mp_install_schema', 18);

function escortwp_mp_normalize_payment_row($row) {
	if (!$row) {
		return null;
	}

	if (is_object($row)) {
		$row = (array) $row;
	}

	$row['id'] = (int) $row['id'];
	$row['user_id'] = (int) $row['user_id'];
	$row['profile_id'] = (int) $row['profile_id'];
	$row['valor'] = (float) $row['valor'];
	$row['mp_payment_id'] = isset($row['mp_payment_id']) && $row['mp_payment_id'] !== null ? (int) $row['mp_payment_id'] : 0;
	$row['mp_external_reference'] = isset($row['mp_external_reference']) && $row['mp_external_reference'] !== null ? (string) $row['mp_external_reference'] : '';
	$row['qr_expires_at'] = (int) $row['qr_expires_at'];
	$row['starts_at'] = (int) $row['starts_at'];
	$row['expires_at'] = (int) $row['expires_at'];
	$row['paid_at'] = (int) $row['paid_at'];
	$row['last_synced_at'] = (int) $row['last_synced_at'];
	$row['webhook_verified'] = !empty($row['webhook_verified']);

	return $row;
}

function escortwp_mp_insert_payment($data) {
	global $wpdb;

	$table = escortwp_mp_get_payments_table_name();
	$now_mysql = current_time('mysql');
	$defaults = array(
		'user_id' => 0,
		'profile_id' => 0,
		'plan_key' => '',
		'valor' => 0,
		'currency' => 'BRL',
		'status' => 'pending',
		'mp_payment_id' => null,
		'mp_external_reference' => null,
		'qr_code' => '',
		'qr_code_base64' => '',
		'qr_expires_at' => 0,
		'starts_at' => 0,
		'expires_at' => 0,
		'paid_at' => 0,
		'last_synced_at' => 0,
		'webhook_verified' => 0,
		'provider_payload' => '',
		'last_error' => '',
	);

	$row = wp_parse_args($data, $defaults);
	$row['created_at'] = $now_mysql;
	$row['updated_at'] = $now_mysql;

	if (!isset($row['mp_payment_id']) || $row['mp_payment_id'] === null || (int) $row['mp_payment_id'] < 1) {
		unset($row['mp_payment_id']);
	}

	if (!isset($row['mp_external_reference']) || $row['mp_external_reference'] === null || $row['mp_external_reference'] === '') {
		unset($row['mp_external_reference']);
	}

	$formats_map = array(
		'user_id' => '%d',
		'profile_id' => '%d',
		'plan_key' => '%s',
		'valor' => '%f',
		'currency' => '%s',
		'status' => '%s',
		'mp_payment_id' => '%d',
		'mp_external_reference' => '%s',
		'qr_code' => '%s',
		'qr_code_base64' => '%s',
		'qr_expires_at' => '%d',
		'starts_at' => '%d',
		'expires_at' => '%d',
		'paid_at' => '%d',
		'last_synced_at' => '%d',
		'webhook_verified' => '%d',
		'provider_payload' => '%s',
		'last_error' => '%s',
		'created_at' => '%s',
		'updated_at' => '%s',
	);

	$formats = array();
	foreach ($row as $key => $value) {
		if (isset($formats_map[$key])) {
			$formats[] = $formats_map[$key];
		}
	}

	$wpdb->insert($table, $row, $formats);

	return (int) $wpdb->insert_id;
}

function escortwp_mp_update_payment($payment_id, $data) {
	global $wpdb;

	$payment_id = (int) $payment_id;
	if ($payment_id < 1 || !$data) {
		return false;
	}

	$table = escortwp_mp_get_payments_table_name();
	$data['updated_at'] = current_time('mysql');

	return $wpdb->update($table, $data, array('id' => $payment_id));
}

function escortwp_mp_get_payment($payment_id) {
	global $wpdb;

	$payment_id = (int) $payment_id;
	if ($payment_id < 1) {
		return null;
	}

	$table = escortwp_mp_get_payments_table_name();
	$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d LIMIT 1", $payment_id));
	return escortwp_mp_normalize_payment_row($row);
}

function escortwp_mp_get_payment_by_mp_payment_id($mp_payment_id) {
	global $wpdb;

	$mp_payment_id = (int) $mp_payment_id;
	if ($mp_payment_id < 1) {
		return null;
	}

	$table = escortwp_mp_get_payments_table_name();
	$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE mp_payment_id = %d LIMIT 1", $mp_payment_id));
	return escortwp_mp_normalize_payment_row($row);
}

function escortwp_mp_get_payment_by_external_reference($external_reference) {
	global $wpdb;

	$external_reference = trim((string) $external_reference);
	if ($external_reference === '') {
		return null;
	}

	$table = escortwp_mp_get_payments_table_name();
	$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE mp_external_reference = %s LIMIT 1", $external_reference));
	return escortwp_mp_normalize_payment_row($row);
}

function escortwp_mp_get_latest_payment_for_plan($profile_id, $plan_key, $statuses = array()) {
	global $wpdb;

	$profile_id = (int) $profile_id;
	$plan_key = sanitize_key($plan_key);
	if ($profile_id < 1 || $plan_key === '') {
		return null;
	}

	$table = escortwp_mp_get_payments_table_name();
	$where = $wpdb->prepare("profile_id = %d AND plan_key = %s", $profile_id, $plan_key);

	if ($statuses) {
		$statuses = array_map('sanitize_key', (array) $statuses);
		$placeholders = implode(', ', array_fill(0, count($statuses), '%s'));
		$where .= $wpdb->prepare(" AND status IN ($placeholders)", ...$statuses);
	}

	$row = $wpdb->get_row("SELECT * FROM {$table} WHERE {$where} ORDER BY id DESC LIMIT 1");
	return escortwp_mp_normalize_payment_row($row);
}

function escortwp_mp_get_latest_reusable_pending_payment($user_id, $profile_id, $plan_key) {
	global $wpdb;

	$user_id = (int) $user_id;
	$profile_id = (int) $profile_id;
	$plan_key = sanitize_key($plan_key);
	if ($user_id < 1 || $profile_id < 1 || $plan_key === '') {
		return null;
	}

	$now = current_time('timestamp');
	$table = escortwp_mp_get_payments_table_name();
	$row = $wpdb->get_row($wpdb->prepare(
		"SELECT * FROM {$table}
		WHERE user_id = %d
		  AND profile_id = %d
		  AND plan_key = %s
		  AND status = 'pending'
		  AND qr_expires_at > %d
		ORDER BY id DESC
		LIMIT 1",
		$user_id,
		$profile_id,
		$plan_key,
		$now
	));

	return escortwp_mp_normalize_payment_row($row);
}

function escortwp_mp_get_approved_active_payments_for_plan($profile_id, $plan_key) {
	global $wpdb;

	$profile_id = (int) $profile_id;
	$plan_key = sanitize_key($plan_key);
	$now = current_time('timestamp');
	$table = escortwp_mp_get_payments_table_name();

	return $wpdb->get_results($wpdb->prepare(
		"SELECT * FROM {$table}
		WHERE profile_id = %d
		  AND plan_key = %s
		  AND status = 'approved'
		  AND expires_at > %d
		ORDER BY expires_at DESC, id DESC",
		$profile_id,
		$plan_key,
		$now
	));
}
