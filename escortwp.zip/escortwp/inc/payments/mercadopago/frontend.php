<?php

if (!defined('ABSPATH')) {
	exit;
}

function escortwp_mp_render_payment_button($plan_key, $profile_id, $text = '') {
	$plan_key = sanitize_key($plan_key);
	$profile_id = (int) $profile_id;
	$text = $text ? $text : __('Ir para o checkout', 'escortwp');

	if (!$profile_id || !in_array($plan_key, array('premium', 'featured_boost'), true)) {
		return '';
	}

	if (!is_user_logged_in()) {
		return '<a href="' . esc_url(escortwp_get_login_url(get_permalink($profile_id))) . '" class="greenbutton payment-button rad25">' . esc_html($text) . '</a>';
	}

	if (!escortwp_mp_is_ready()) {
		return '<div class="escortwp-payment-readiness-note is-warning is-front"><strong>' . esc_html__('Mercado Pago indisponível', 'escortwp') . '</strong><p>' . esc_html__('Defina o access token do Mercado Pago para liberar o checkout com PIX e cartão.', 'escortwp') . '</p></div>';
	}

	if (!function_exists('escortwp_generate_woocommerce_payment_button')) {
		return '';
	}

	return escortwp_generate_woocommerce_payment_button($plan_key, $profile_id, $text);
}

function escortwp_mp_enqueue_frontend_assets() {
	// O checkout segue pelo WooCommerce/Mercado Pago.
	// Não carregamos mais o modal legado de PIX separado.
	return;
}

add_action('wp_enqueue_scripts', 'escortwp_mp_enqueue_frontend_assets', 30);

function escortwp_mp_render_modal_markup() {
	return;
}

add_action('wp_footer', 'escortwp_mp_render_modal_markup', 5);
