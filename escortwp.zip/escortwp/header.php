<?php
if ( ! defined( 'error_reporting' ) ) { define( 'error_reporting', '0' ); }
ini_set( 'display_errors', error_reporting );
if ( error_reporting == '1' ) { error_reporting( E_ALL ); }
if ( isdolcetheme !== 1 ) { die(); }

upgrade_theme();
escortwp_maybe_run_time_check_expired();

global $taxonomy_profile_url, $taxonomy_agency_url, $taxonomy_location_url;

$home_url         = home_url( '/' );
$search_url       = get_permalink( get_option( 'search_page_id' ) );
$contact_url      = get_permalink( get_option( 'contact_page_id' ) );
$telegram_url     = 'https://t.me/GarotasDF';
$partnerships_url = 'https://t.me/GarotasDF?text=' . rawurlencode( 'Olá, quero falar sobre parcerias.' );
$register_url     = get_permalink( get_option( 'main_reg_page_id' ) );
$login_url        = function_exists( 'escortwp_get_login_url' ) ? escortwp_get_login_url( function_exists( 'get_current_url' ) ? get_current_url() : $home_url ) : wp_login_url( $home_url );
$logout_url       = function_exists( 'escortwp_get_logout_url' ) ? escortwp_get_logout_url( $home_url ) : wp_logout_url( $home_url );

$current_user    = wp_get_current_user();
$current_user_id = is_user_logged_in() ? (int) $current_user->ID : 0;
$is_admin_user   = $current_user_id && user_can( $current_user, 'manage_options' );
$account_url     = escortwp_get_current_user_account_url();
$account_url     = $account_url ? $account_url : ( $register_url ? $register_url : $home_url );

$search_url   = $search_url ? $search_url : $home_url;
$contact_url  = $contact_url ? $contact_url : $home_url;
$site_logo_markup = function_exists( 'escortwp_get_brand_logo_markup' )
	? escortwp_get_brand_logo_markup( 'garotas-df-default-logo' )
	: esc_html( get_bloginfo( 'name' ) );
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo esc_html( wp_get_document_title() ); ?></title>
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php if ( function_exists( 'wp_body_open' ) ) { wp_body_open(); } ?>
<?php
license_check();
install_theme_wizard();
generate_demo_data();
if ( defined( 'escortwp_demo_theme' ) && function_exists( 'escortwp_theme_options' ) ) { escortwp_theme_options(); }
?>
<script type="text/javascript">
window.escortwpAjax = window.escortwpAjax || {};
window.escortwpAjax.nonce = "<?php echo esc_js( escortwp_get_frontend_ajax_nonce() ); ?>";
</script>
<header class="reference-header reference-header--premium-nav">
	<div class="reference-header-shell">
		<div class="reference-header-brand">
			<h1><a href="<?php echo esc_url( $home_url ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"><?php echo $site_logo_markup; ?></a></h1>
		</div>

		<div class="reference-header-main">
			<nav class="reference-header-nav" aria-label="<?php esc_attr_e( 'Navegação principal', 'escortwp' ); ?>">
				<button class="reference-menu-toggle" type="button" aria-expanded="false" aria-controls="reference-header-list">
					<span class="icon icon-menu"></span>
					<span><?php esc_html_e( 'Menu', 'escortwp' ); ?></span>
				</button>

				<ul id="reference-header-list" class="reference-header-list">
					<li class="<?php echo get_option( 'search_page_id' ) == get_the_ID() ? 'current_page_item' : ''; ?>">
						<a href="<?php echo esc_url( $search_url ); ?>"><span class="icon icon-search"></span><?php esc_html_e( 'Pesquisar', 'escortwp' ); ?></a>
					</li>
					<li class="<?php echo is_front_page() ? 'current_page_item' : ''; ?>">
						<a href="<?php echo esc_url( $home_url ); ?>"><?php esc_html_e( 'Início', 'escortwp' ); ?></a>
					</li>
					<li class="reference-header-announce-item <?php echo get_option( 'main_reg_page_id' ) == get_the_ID() ? 'current_page_item' : ''; ?>">
						<a href="<?php echo esc_url( $account_url ); ?>"><?php esc_html_e( 'Anuncie grátis', 'escortwp' ); ?></a>
					</li>
					<li class="reference-header-telegram-item">
						<a href="<?php echo esc_url( $telegram_url ); ?>" target="_blank" rel="nofollow noopener">
							<span class="reference-header-link-stack">
								<span class="reference-header-link-primary"><?php esc_html_e( 'Grupo Telegram', 'escortwp' ); ?></span>
								<span class="reference-header-link-secondary"><?php esc_html_e( 'Resenha e Putaria', 'escortwp' ); ?></span>
							</span>
						</a>
					</li>
					<li class="<?php echo get_option( 'contact_page_id' ) == get_the_ID() ? 'current_page_item' : ''; ?>">
						<a href="<?php echo esc_url( $contact_url ); ?>"><?php esc_html_e( 'Contato', 'escortwp' ); ?></a>
					</li>
					<li class="reference-header-partnerships-item">
						<a href="<?php echo esc_url( $partnerships_url ); ?>" target="_blank" rel="nofollow noopener">
							<span class="reference-header-link-stack">
								<span class="reference-header-link-primary"><?php esc_html_e( 'Parcerias', 'escortwp' ); ?></span>
								<span class="reference-header-link-secondary"><?php esc_html_e( 'Chamar no Telegram', 'escortwp' ); ?></span>
							</span>
						</a>
					</li>
				</ul>
			</nav>

			<div class="reference-header-utilities">
				<?php if ( is_user_logged_in() ) { ?>
					<a class="reference-header-action reference-header-action--button" href="<?php echo esc_url( $account_url ); ?>"><span class="icon icon-cog"></span><?php echo $is_admin_user ? esc_html__( 'Painel WordPress', 'escortwp' ) : esc_html__( 'Conta', 'escortwp' ); ?></a>
					<a class="reference-header-action reference-header-action--button" href="<?php echo esc_url( $logout_url ); ?>"><span class="icon icon-logout"></span><?php esc_html_e( 'Sair', 'escortwp' ); ?></a>
				<?php } else { ?>
					<a class="reference-header-action reference-header-action--button reference-header-action--register" href="<?php echo esc_url( $register_url ? $register_url : $home_url ); ?>"><span class="icon icon-plus-circled"></span><?php esc_html_e( 'Criar conta', 'escortwp' ); ?></a>
					<a class="reference-header-action reference-header-action--button" href="<?php echo esc_url( $login_url ); ?>"><span class="icon icon-key-outline"></span><?php esc_html_e( 'Entrar', 'escortwp' ); ?></a>
				<?php } ?>
			</div>
		</div>
	</div>

	<?php check_if_user_has_validated_his_email(); ?>

	<?php
	if ( defined( 'showslider' ) && showslider == 1 ) {
		include get_template_directory() . '/header-slider.php';
	}
	?>
</header>

<div class="all all-body">
