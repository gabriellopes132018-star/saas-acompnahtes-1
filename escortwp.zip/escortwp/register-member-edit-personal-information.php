<?php
/*
Template Name: Member Edit Personal Information
*/

$current_user = wp_get_current_user();
if (!is_user_logged_in() || !escortwp_current_user_has_type("member", $current_user->ID)) { wp_redirect(get_bloginfo("url")); exit; }

$err = ""; $ok = "";
$member_registered_now = !empty($_GET['member_registered']) && $_GET['member_registered'] === '1';
if (isset($_POST['action']) && $_POST['action'] == 'registermember') {
	$member_edit_page = "yes";
	include (get_template_directory() . '/register-member-personal-info-process.php');
} else {
	$membername = $current_user->display_name;
	$memberemail = $current_user->user_email;
}

get_header(); ?>

	<div class="contentwrapper">
	<div class="body">
    	<div class="bodybox registerform">
        	<h3><?php _e('Minha conta','escortwp'); ?></h3>
			<?php
			if ($member_registered_now) {
				echo "<div class=\"ok rad25\">".__('Cadastro concluido com sucesso. Agora voce ja pode gerenciar sua conta.','escortwp')."</div>";
			} elseif ($ok) {
				echo "<div class=\"ok rad25\">".__('Conta atualizada com sucesso.','escortwp')."</div>";
			}

			$member_edit_page = "yes";
			include (get_template_directory() . '/register-member-personal-information-form.php');
			?>
            <div class="clear"></div>
        </div> <!-- BODY BOX -->
        <div class="clear"></div>
    </div> <!-- BODY -->
	</div> <!-- contentwrapper -->

	<?php get_sidebar("left"); ?>
	<?php get_sidebar("right"); ?>

	<div class="clear"></div>

<?php get_footer(); ?>
