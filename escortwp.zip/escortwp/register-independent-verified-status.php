<?php
/*
Template Name: Register Independent Verified Status
*/

global $taxonomy_profile_url;
$current_user = wp_get_current_user();
if (!is_user_logged_in() || !escortwp_current_user_has_type($taxonomy_profile_url, $current_user->ID)) {
	wp_redirect(get_bloginfo('url'));
	exit;
}

$escort_post_id = (int) get_option('escortpostid' . $current_user->ID);
$start_plan = escortwp_get_registration_plan_intent(isset($_GET['start_plan']) ? wp_unslash($_GET['start_plan']) : '');
$gallery_url = $escort_post_id ? get_permalink($escort_post_id) . '#gerenciar-galeria' : '';
$continue_url = get_option('escort_edit_personal_info_page_id') ? get_permalink(get_option('escort_edit_personal_info_page_id')) : escortwp_get_current_user_account_url();
if ($start_plan) {
	$continue_url = add_query_arg(
		array(
			'start_plan' => $start_plan,
			'from_registration' => 1,
		),
		$continue_url
	);
}
$checkout_button_markup = '';
if ($start_plan && $escort_post_id && function_exists('generate_payment_buttons')) {
	$checkout_button_label = $start_plan === 'featured_boost'
		? __('Continuar para o checkout do destaque', 'escortwp')
		: __('Continuar para o checkout do plano mensal', 'escortwp');
	$checkout_button_markup = generate_payment_buttons($start_plan, $escort_post_id, $checkout_button_label);
}
get_header();
?>

<div class="contentwrapper escortwp-auth-shell escortwp-auth-shell--editor">
	<div class="body escortwp-auth-main escortwp-auth-main--editor">
		<div class="bodybox registerform escortwp-workspace-box escortwp-workspace-box--dashboard">
			<div class="escortwp-auth-header escortwp-auth-header--left escortwp-auth-header--compact">
				<div class="escortwp-auth-kicker"><?php _e('Painel da acompanhante', 'escortwp'); ?></div>
				<h3><?php _e('Verificação por vídeo', 'escortwp'); ?></h3>
				<p class="escortwp-register-intro"><?php _e('Envie um vídeo curto para análise manual da equipe. Quando for aprovado, o selo de verificada passa a aparecer no seu anúncio.', 'escortwp'); ?></p>
			</div>

			<?php if ($gallery_url) { ?>
				<section class="escortwp-dashboard-media-panel escortwp-dashboard-media-panel--verification">
					<div class="escortwp-dashboard-media-panel__copy">
						<div class="escortwp-auth-kicker"><?php _e('Antes do vÃ­deo', 'escortwp'); ?></div>
						<h4><?php _e('Envie as fotos do anúncio', 'escortwp'); ?></h4>
						<p><?php _e('As fotos principais do perfil podem ser enviadas agora, antes da etapa de verificaÃ§Ã£o por vÃ­deo.', 'escortwp'); ?></p>
					</div>
					<div class="escortwp-dashboard-media-panel__actions">
						<a href="<?php echo esc_url($gallery_url); ?>" class="payment-button escortwp-dashboard-media-panel__button">
							<?php _e('Abrir galeria do anúncio', 'escortwp'); ?>
						</a>
						<div class="escortwp-dashboard-media-panel__specs">
							<span><?php _e('Formato vertical 3:4', 'escortwp'); ?></span>
							<span><?php _e('Recomendado: 1200 x 1600 px', 'escortwp'); ?></span>
							<span><?php _e('Boa luz e rosto visÃ­vel', 'escortwp'); ?></span>
						</div>
					</div>
				</section>
			<?php } ?>

			<?php
			if ($escort_post_id && function_exists('escortwp_render_video_verification_panel')) {
				echo escortwp_render_video_verification_panel($escort_post_id);
			}
			?>

			<div class="escortwp-video-verification-next-step">
				<p><?php _e('A verificação por vídeo é opcional. Você pode enviar agora ou continuar para finalizar o restante do anúncio.', 'escortwp'); ?></p>
				<?php if ($checkout_button_markup) { ?>
					<?php echo $checkout_button_markup; ?>
				<?php } else { ?>
					<a href="<?php echo esc_url($continue_url); ?>" class="greenbutton payment-button rad25">
						<?php echo $start_plan ? esc_html__('Continuar para o pagamento', 'escortwp') : esc_html__('Continuar para o painel do anúncio', 'escortwp'); ?>
					</a>
				<?php } ?>
			</div>

			<div class="clear"></div>
		</div>
		<div class="clear"></div>
	</div>
</div>

<div class="clear"></div>

<?php get_footer(); ?>

