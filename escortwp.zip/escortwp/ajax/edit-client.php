<?php
ini_set( 'display_errors', 0 );
require( '../../../../wp-load.php' );
if (!is_user_logged_in() || !escortwp_verify_frontend_ajax_nonce()) { status_header(403); exit; }

$clientid = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($clientid == 0) { die(); }

$client = get_post($clientid);
if ($client instanceof WP_Post && escortwp_current_user_can_manage_post($clientid)) {
	$bcemail = get_post_meta($clientid,'email', true);
	$bcphone = get_post_meta($clientid,'phone', true);
	$bcnote = get_post_meta($clientid,'note', true);
	$editclient = "yes";
	include (get_template_directory() . '/blacklist-clients-form.php');
}
?>
