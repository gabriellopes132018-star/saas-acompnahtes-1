<?php
ini_set( 'display_errors', 0 );
require( '../../../../wp-load.php' );
if (!is_user_logged_in() || !escortwp_verify_frontend_ajax_nonce()) { status_header(403); exit; }

$current_user = wp_get_current_user();
$postid = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$userid = $current_user->ID;
$post = get_post($postid);

if($post instanceof WP_Post && ((int) $post->post_author === (int) $userid || current_user_can('manage_options'))) {
	delete_post_meta($postid, 'verified_status');
	_e('Your image has been deleted','escortwp');
}
?>
