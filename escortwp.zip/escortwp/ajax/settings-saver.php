<?php
ini_set('display_errors', 0);
require('../../../../wp-load.php');

if (!current_user_can('level_10') || !escortwp_verify_frontend_ajax_nonce()) {
	status_header(403);
	exit;
}

if (isset($_GET['hide_demo_data_alert']) && $_GET['hide_demo_data_alert'] === 'yes') {
	update_option('generate_demo_data_alert', 'hide');
	echo 'ok';
}
