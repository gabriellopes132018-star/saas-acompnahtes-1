<?php
ini_set( 'display_errors', 0 );
require( '../../../../wp-load.php' );
if (!is_user_logged_in() || !escortwp_verify_frontend_ajax_nonce()) { status_header(403); exit; }

$tourid = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($tourid == 0) { die(); }

$tour = get_post($tourid);
if ($tour instanceof WP_Post && escortwp_current_user_can_manage_post($tourid)) {
	wp_delete_post( $tourid, true );
	_e('Tour deleted','escortwp');
}
?>
