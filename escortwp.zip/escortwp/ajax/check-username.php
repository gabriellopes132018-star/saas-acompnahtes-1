<?php
ini_set( 'display_errors', 0 );
require( '../../../../wp-load.php' );

if (!escortwp_verify_frontend_ajax_nonce()) {
	status_header(403);
	exit;
}

$username = isset($_GET['user']) ? sanitize_user(wp_unslash($_GET['user'])) : '';

if (strlen($username) > 3 && strlen($username) <= 30) {
	if (username_exists($username)) {
		echo '<span class="checkusererr">'.__('This username already exists.','escortwp').'<br />'.__('Please choose another one','escortwp').'</span>';
	} else {
		echo '<span class="checkuserok">'.__('This username is available','escortwp').'</span>';
	}
}
?>
