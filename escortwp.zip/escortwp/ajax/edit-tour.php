<?php
ini_set( 'display_errors', 0 );
require( '../../../../wp-load.php' );
if (!is_user_logged_in() || !escortwp_verify_frontend_ajax_nonce()) { status_header(403); exit; }

$tourid = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$escortid = isset($_GET['escort_id']) ? (int) $_GET['escort_id'] : 0;
if ($tourid == 0) { die(); }

global $taxonomy_location_url;
$tour = get_post($tourid);
$escort = get_post(get_post_meta( $tourid, 'belongstoescortid', true));
if ($escort instanceof WP_Post && escortwp_current_user_can_manage_post($escort->ID)) {
	$tourcountry = get_post_meta($tourid, 'country', true);
	if(showfield('state')) {
		$tourstate = get_post_meta($tourid,'state', true);
	}
	$tourcity = get_post_meta($tourid,'city', true);

	if(get_option('locationdropdown') != "1") {
		if(showfield('state')) {
			$tourstate = get_term($tourstate, $taxonomy_location_url);
			$tourstate = $tourstate->name;
		}

		$tourcity = get_term($tourcity, $taxonomy_location_url);
		$tourcity = $tourcity->name;
	}




	$start = get_post_meta($tourid,'start', true);
	$end = get_post_meta($tourid,'end', true);
	$tourphone = get_post_meta($tourid,'phone', true);
	$edittour = "yes";
	if (!empty($_GET['edit_tour_in_escort_page']) && sanitize_text_field(wp_unslash($_GET['edit_tour_in_escort_page'])) == "yes") {
		$is_escort_page = "yes";
		$escort_post_id_for_tours = isset($_GET['escort_id_to_redirect']) ? (int) $_GET['escort_id_to_redirect'] : 0;
	}
	include (get_template_directory() . '/register-independent-add-tour-form.php');
}
?>
