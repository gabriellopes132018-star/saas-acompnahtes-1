<?php
ini_set( 'display_errors', 0 );
require( '../../../../wp-load.php' );
if (!is_user_logged_in() || !escortwp_verify_frontend_ajax_nonce()) { status_header(403); exit; }

$attachmentid = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($attachmentid == 0) { die('nope'); }

$post = get_post($attachmentid);
$post_parent = $post ? get_post($post->post_parent) : null;

if ($post instanceof WP_Post && $post_parent instanceof WP_Post && escortwp_current_user_can_manage_post($post_parent->ID))  {
	$ffmpeg_command = get_post_meta($attachmentid, 'ffmpeg_command', true);
	$parent_id = (int) $post->post_parent;
	$was_main_image = ((int) get_post_meta($parent_id, 'main_image_id', true) === $attachmentid);
	wp_delete_attachment($attachmentid, true);
	
	if($ffmpeg_command) {
		$preview_path = get_attached_file($attachmentid).".jpg";
		if ($preview_path && file_exists($preview_path)) {
			unlink($preview_path);
		}
		$message = __('Seu vídeo foi excluído.', 'escortwp');
		if (!empty($_GET['escortwp_json'])) {
			wp_send_json(array(
				'success' => true,
				'message' => $message,
				'deleted_id' => $attachmentid,
				'new_main_id' => 0,
			));
		}
		_e('Seu vídeo foi excluído.','escortwp');
	} else {
		$new_main_id = 0;
		if ($was_main_image) {
			$remaining_photos = get_children(array(
				'post_parent' => $parent_id,
				'post_status' => 'inherit',
				'post_type' => 'attachment',
				'post_mime_type' => 'image',
				'numberposts' => 1,
				'order' => 'ASC',
				'orderby' => 'menu_order ID',
			));

			if ($remaining_photos) {
				$first_photo = array_shift($remaining_photos);
				$new_main_id = (int) $first_photo->ID;
				update_post_meta($parent_id, 'main_image_id', $new_main_id);
			} else {
				delete_post_meta($parent_id, 'main_image_id');
			}
		}

		$message = __('Sua imagem foi excluída.', 'escortwp');
		if (!empty($_GET['escortwp_json'])) {
			wp_send_json(array(
				'success' => true,
				'message' => $message,
				'deleted_id' => $attachmentid,
				'new_main_id' => $new_main_id,
			));
		}
		_e('Sua imagem foi excluída.','escortwp');
	}
}
?>
