<?php
ini_set( 'display_errors', 0 );
require( '../../../../wp-load.php' );
if (!is_user_logged_in() || !escortwp_verify_frontend_ajax_nonce()) { status_header(403); exit; }

$attachmentid = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($attachmentid == 0) { die(); }

global $taxonomy_agency_url;
$current_user = wp_get_current_user();
$userid = $current_user->ID;

$userstatus = get_option("escortid".$userid);
$agpostid = get_option("agencypostid".$userid);
$post = get_post($attachmentid);
if ($post instanceof WP_Post && (($agpostid == $post->post_parent && $userstatus == $taxonomy_agency_url) || current_user_can('manage_options'))) {
	wp_delete_attachment( $attachmentid, true );
	_e('Your image has been deleted','escortwp');
}

?>
