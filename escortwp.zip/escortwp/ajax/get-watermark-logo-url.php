<?php
ini_set('display_errors', 0);
require('../../../../wp-load.php');

if (!current_user_can('level_10') || !escortwp_verify_frontend_ajax_nonce()) {
	status_header(403);
	exit;
}

echo esc_url_raw((string) get_option('watermarklogourl'));
