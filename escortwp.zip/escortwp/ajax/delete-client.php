<?php
ini_set( 'display_errors', 0 );
require( '../../../../wp-load.php' );
if (!is_user_logged_in() || !escortwp_verify_frontend_ajax_nonce()) { status_header(403); exit; }

$clientid = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($clientid == 0) { die(); }

$client = get_post($clientid);
if ($client instanceof WP_Post && escortwp_current_user_can_manage_post($clientid)) {
	wp_delete_post( $clientid, true );
	_e('Client deleted','escortwp');;
}
?>
