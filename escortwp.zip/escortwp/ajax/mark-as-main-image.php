<?php
ini_set( 'display_errors', 0 );
require( '../../../../wp-load.php' );
if (!is_user_logged_in() || !escortwp_verify_frontend_ajax_nonce()) { status_header(403); exit; }

$attachmentid = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($attachmentid == 0) { die(); }

$post = get_post($attachmentid);
$post_parent = $post ? get_post($post->post_parent) : null;

if ($post instanceof WP_Post && $post_parent instanceof WP_Post && escortwp_current_user_can_manage_post($post_parent->ID)) {
	update_post_meta($post->post_parent, "main_image_id", $attachmentid);
	$imgurl = wp_get_attachment_image_src($attachmentid, 'main-image-thumb');
	wp_send_json(array(
		'message' => __('Capa do anúncio atualizada com sucesso.','escortwp'),
		'imgurl' => $imgurl ? $imgurl[0] : '',
	));
}

status_header(403);
wp_send_json(array(
	'message' => __('Não foi possível definir esta imagem como capa.','escortwp'),
), 403);
?>
