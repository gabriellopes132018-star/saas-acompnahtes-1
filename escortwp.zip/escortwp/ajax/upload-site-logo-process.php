<?php
ini_set('display_errors', 0);
require('../../../../wp-load.php');

if (!current_user_can('level_10') || !escortwp_verify_frontend_ajax_nonce()) {
	status_header(403);
	exit;
}

if (empty($_FILES['Filedata']) || !is_array($_FILES['Filedata'])) {
	status_header(400);
	exit;
}

$folder = isset($_REQUEST['folder']) ? sanitize_text_field(wp_unslash($_REQUEST['folder'])) : '';
$secret = preg_replace('/([^a-zA-Z0-9])/', '', basename($folder));
if ($secret !== (string) get_option('secret_to_upload_site_logo')) {
	status_header(403);
	exit;
}

escortwp_delete_uploaded_option_file('sitelogo');

$file = $_FILES['Filedata'];
$file_size = isset($file['size']) ? (int) $file['size'] : 0;
$max_size = 9242880;
if ($file_size > $max_size) {
	wp_die('The file is too large');
}
if ($file_size < 1) {
	wp_die("The file can't have 0Kb");
}

$image_info = @getimagesize($file['tmp_name']);
if (!$image_info || empty($image_info['mime'])) {
	wp_die('Wrong file extension');
}

$allowed_extensions = array('gif', 'png', 'jpg', 'jpeg', 'webp');
$extension = strtolower(str_replace('image/', '', $image_info['mime']));
$extension = $extension === 'jpeg' ? 'jpg' : $extension;
if (!in_array($extension, $allowed_extensions, true)) {
	wp_die('Wrong file extension');
}

$upload_dir = wp_upload_dir();
if (!empty($upload_dir['error'])) {
	wp_die($upload_dir['error']);
}

if (!is_dir($upload_dir['basedir']) && !wp_mkdir_p($upload_dir['basedir'])) {
	wp_die('Failed to create folder for the images!');
}

$target_file = time() . rand(1, 999) . '.' . $extension;
$target_path = trailingslashit($upload_dir['basedir']) . $target_file;

if (move_uploaded_file($file['tmp_name'], $target_path)) {
	update_option('sitelogo', trailingslashit($upload_dir['baseurl']) . $target_file);
	echo sanitize_file_name($target_file);
}
