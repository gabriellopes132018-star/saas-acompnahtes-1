<?php
ini_set( 'display_errors', 0 );
require( '../../../../wp-load.php' );
if (!is_user_logged_in() || !escortwp_verify_frontend_ajax_nonce()) { status_header(403); exit; }

$escortid = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if (!$escortid || $escortid < 1) { die(); }

$escort = get_post($escortid);
$status = $escort instanceof WP_Post ? $escort->post_status : '';

if ($escort instanceof WP_Post && escortwp_current_user_can_manage_post($escortid)) {
	if ($status == "publish") {
		$status = "private";
		$ok = __('Set to','escortwp')." <strong>".__('INACTIVE','escortwp')."</strong>";
	} else {
		$status = "publish";
		$ok = __('Set to','escortwp')." <strong>".__('ACTIVE','escortwp')."</strong>";
	}

	$post_escort = array( 'ID' => $escortid, 'post_status' => $status );
	wp_update_post( $post_escort );
	echo $ok;
}
?>
