<?php
ini_set( 'display_errors', 0 );
require( '../../../../wp-load.php' );

global $taxonomy_location_url;
$id = (int) ($_GET['id'] ?? 0);
if (!term_exists( $id, $taxonomy_location_url ) || (function_exists('escortwp_is_allowed_location_term_id') && !escortwp_is_allowed_location_term_id($id))) {
	die(__('The country you selected doesn\'t exist in our database','escortwp'));
}

//selected city
$city = (int) ($_GET['selected'] ?? 0);
if (!$city || !term_exists( $city, $taxonomy_location_url ) || (function_exists('escortwp_is_allowed_location_term_id') && !escortwp_is_allowed_location_term_id($city))) {
	$city = 0;
}

$class = (!empty($_GET['class']) ? " ".substr(preg_replace("/([^a-zA-Z0-9])/", "", (string) $_GET['class']), 0, 20) : "");
$hide_empty = (int) substr((string) ($_GET['hide_empty'] ?? '0'), 0, 1);
$use_select2 = (($_GET['select2'] ?? '') === "yes");
$is_state_request = !empty($_GET['state']);
$is_escort_page = (($_GET['is_escort_page'] ?? '') === "yes");
$is_tour = (($_GET['is_tour'] ?? '') === "yes");
$is_agency_page = (($_GET['is_agency_page'] ?? '') === "yes");

if($use_select2) {
	$class .= " select2";
}

$dropdown_text = $is_state_request ? __('Select state','escortwp') : __('Select city','escortwp');
$dropdown_id = $is_state_request ? 'state' : 'city';
$args = array(
	'show_option_all'    => '',
	'show_option_none'   => $dropdown_text,
	'orderby'            => 'name', 
	'order'              => 'ASC',
	'show_last_update'   => 0,
	'show_count'         => 0,
	'hide_empty'         => $hide_empty,
	'child_of'           => $id,
	'exclude'            => '',
	'echo'               => 1,
	'selected'           => $city,
	'hierarchical'       => 1, 
	'name'               => $dropdown_id,
	'id'                 => '',
	'class'              => $dropdown_id.$class,
	'depth'              => 1,
	'tab_index'          => 0,
	'taxonomy'           => $taxonomy_location_url,
	'hide_if_empty'      => false );

if ($is_escort_page || $is_tour) {
	$args['name'] = "tour".$args['name'];
	$args['id'] = "tour".$args['id'];
	$args['class'] = "tour".$args['class'].$class;
}
if ($is_agency_page) {
	$args['name'] = "citymeeting";
	$args['id'] = "citymeeting";
	$args['class'] = "citymeeting".$class;
}
wp_dropdown_categories( $args );
?>
