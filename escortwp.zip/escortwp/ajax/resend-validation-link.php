<?php
ini_set('display_errors', 0);
require('../../../../wp-load.php');

if (!is_user_logged_in() || !escortwp_verify_frontend_ajax_nonce()) {
	status_header(403);
	exit;
}

$current_user = wp_get_current_user();
$emailhash = get_user_meta($current_user->ID, 'emailhash', true);

if (!$emailhash) {
	echo '<div class="err rad25">'.esc_html__('Seu e-mail já foi validado.', 'escortwp').'</div>';
	exit;
}

$last_email_validation_sent = (int) get_user_meta($current_user->ID, 'last_email_validation_sent', true);
if (time() < $last_email_validation_sent) {
	echo '<div class="err rad25">'.esc_html__('Você só pode reenviar um e-mail a cada 30 segundos.', 'escortwp').'</div>';
	exit;
}

$validation_url = home_url('/?ekey='.$emailhash);
$body = 'Olá '.$current_user->display_name.'<br /><br />'
	.'Antes de usar o site, você precisa validar seu endereço de e-mail.<br /><br />'
	.'Se você não validar o e-mail nos próximos 3 dias, sua conta será excluída.<br /><br />'
	.'Valide seu endereço de e-mail clicando no link abaixo: '
	.'<a href="'.$validation_url.'">'.$validation_url.'</a>';

dolce_email('', '', $current_user->user_email, 'Link de validação de e-mail '.get_option('email_sitename'), $body);

update_user_meta($current_user->ID, 'last_email_validation_sent', time() + 30);

echo '<div class="ok rad25">'.esc_html__('Enviamos outro link de validação para o seu endereço de e-mail:', 'escortwp').' '.esc_html($current_user->user_email).'</div>';
