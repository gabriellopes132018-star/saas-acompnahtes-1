<?php
if (!defined('error_reporting')) { define('error_reporting', '0'); }
ini_set('display_errors', error_reporting);
if (error_reporting == '1') { error_reporting(E_ALL); }
if (isdolcetheme !== 1) { die(); }

global $taxonomy_profile_name_plural, $taxonomy_location_url;
?>
<div class="reference-home-panel reference-home-country-panel">
	<h4><?php esc_html_e('Regiões atendidas', 'escortwp'); ?></h4>
	<ul class="reference-home-country-list">
		<?php
		$location_sections = function_exists('escortwp_get_brazil_location_sections') ? escortwp_get_brazil_location_sections() : array();
		foreach ($location_sections as $section) {
			$state = $section['state'];
			$cities = $section['cities'];
			?>
			<li class="reference-home-country-item cat-item cat-item-<?php echo (int) $state->term_id; ?>">
				<a class="reference-home-country-link" href="<?php echo esc_url(get_term_link($state)); ?>"><?php echo esc_html(escortwp_translate_runtime_label($state->name)); ?></a>
				<?php if (!empty($cities)) { ?>
					<ul class="reference-home-city-list">
						<?php foreach ($cities as $city) { ?>
							<li class="reference-home-city-item cat-item cat-item-<?php echo (int) $city->term_id; ?>">
								<a class="reference-home-city-link" href="<?php echo esc_url(get_term_link($city)); ?>"><?php echo esc_html(escortwp_translate_runtime_label($city->name)); ?></a>
							</li>
						<?php } ?>
					</ul>
				<?php } ?>
			</li>
			<?php
		}
		?>
	</ul>
</div>
