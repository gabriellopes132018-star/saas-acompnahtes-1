<?php
/*
Template Name: Payment Settings
*/

$current_user = wp_get_current_user();
if (!current_user_can('level_10')) { wp_redirect(get_bloginfo("url")); exit; }
$err = ""; $ok = "";
$payment_plans = payment_plans();
if (isset($_POST['action']) && $_POST['action'] == 'paymentsettings') {
	$show_coupon_checkout = (int)$_POST['show_coupon_checkout'];
	update_option('show_coupon_checkout', $show_coupon_checkout);
	$show_address_checkout = (int)$_POST['show_address_checkout'];
	update_option('show_address_checkout', $show_address_checkout);

	foreach ($payment_plans as $plan_name => $plan) {
		if(isset($_POST[$plan_name]) && $_POST[$plan_name]) {
            $payment_plans[$plan_name]['price'] = filter_var($_POST[$plan_name]['price'], FILTER_SANITIZE_NUMBER_FLOAT,FILTER_FLAG_ALLOW_FRACTION);
            if(!$payment_plans[$plan_name]['price']) {
            	if($payment_plans[$plan_name]['woo_product_id']) {
            		wp_delete_post($payment_plans[$plan_name]['woo_product_id']);
            	}
            	$payment_plans[$plan_name]['woo_product_id'] = '';
				if(array_key_exists('extra', $payment_plans[$plan_name])) {
					foreach ($payment_plans[$plan_name]['extra'] as $key => $value) {
						$payment_plans[$plan_name]['extra'][$key] = "0";
					}
				}
	            continue;
            }

            if(array_key_exists('duration', $payment_plans[$plan_name])) {
            	if(!empty($payment_plans[$plan_name]['lock_duration'])) {
            		$payment_plans[$plan_name]['duration'] = (int)$payment_plans[$plan_name]['lock_duration'];
            	} else {
            		$payment_plans[$plan_name]['duration'] = isset($_POST[$plan_name]['duration']) ? (int)$_POST[$plan_name]['duration'] : 0;
            	}
            }
            if(array_key_exists('exp', $payment_plans[$plan_name])) $payment_plans[$plan_name]['exp'] = isset($_POST[$plan_name]['exp']) ? (int)$_POST[$plan_name]['exp'] : 0;
            if(array_key_exists('extra', $payment_plans[$plan_name])) {
            	foreach ($payment_plans[$plan_name]['extra'] as $key => $value) {
		            $payment_plans[$plan_name]['extra'][$key] = isset($_POST[$plan_name]['extra'][$key]) ? (int)$_POST[$plan_name]['extra'][$key] : 0;
            	}
            }

            $wooo_product = get_post((int)$payment_plans[$plan_name]['woo_product_id']);
            if(!$payment_plans[$plan_name]['woo_product_id'] || !$wooo_product || $wooo_product->post_type != "product") {
				$product_args = array(
					'post_title' => sprintf(esc_html__($payment_plans[$plan_name]['woo_product_name'][0],'escortwp'),${$payment_plans[$plan_name]['woo_product_name'][1]}),
					'post_content' => sprintf(esc_html__($payment_plans[$plan_name]['woo_product_name'][0],'escortwp'),${$payment_plans[$plan_name]['woo_product_name'][1]}),
					'post_name' => sprintf(esc_html__($payment_plans[$plan_name]['woo_product_name'][0],'escortwp'),${$payment_plans[$plan_name]['woo_product_name'][1]}),
					'post_status' => 'publish',
					'post_author' => $current_user->ID,
					'post_type' => 'product',
					'ping_status' => 'closed',
				);
				// Insert the post into the database
				$product_id = wp_insert_post($product_args);
	            $payment_plans[$plan_name]['woo_product_id'] = $product_id;
	            update_post_meta($product_id, '_virtual', 'yes');
	            update_post_meta($product_id, '_downloadable', 'no');
            } else {
				$product_id = $wooo_product->ID;
            }
            update_post_meta($product_id, '_regular_price', $payment_plans[$plan_name]['price']);
            update_post_meta($product_id, '_price', $payment_plans[$plan_name]['price']);
            update_post_meta($product_id, 'payment_type', $plan_name);
            if($plan_name == 'featured_boost') {
				wp_set_object_terms($product_id, 'simple', 'product_type');
				delete_post_meta($product_id, '_subscription_price');
				delete_post_meta($product_id, '_subscription_sign_up_fee');
				delete_post_meta($product_id, '_subscription_period');
				delete_post_meta($product_id, '_subscription_period_interval');
				delete_post_meta($product_id, '_subscription_length');
				delete_post_meta($product_id, '_subscription_trial_period');
				delete_post_meta($product_id, '_subscription_trial_length');
            }
		}
	}
	update_option('payment_plans', $payment_plans);
	$GLOBALS['escortwp_payment_plans_cache_override'] = $payment_plans;
	$ok = "ok";
}
$show_address_checkout = get_option('show_address_checkout');
$show_coupon_checkout = get_option('show_coupon_checkout');

$currency = get_option('woocommerce_currency');

get_header(); ?>

<div class="contentwrapper">
	<div class="body">
		<div class="bodybox payment-settings-page">
			<?php
			if(function_exists('escortwp_render_payment_environment_panel')) {
				echo escortwp_render_payment_environment_panel(array(
					'context' => 'admin',
					'title' => __('Pronto para publicar e cobrar', 'escortwp'),
					'description' => __('Use este painel para verificar se o tema já está pronto para vender o plano mensal de 30 dias e o impulsionamento semanal via PIX do Mercado Pago. Se algo estiver faltando, ajuste aqui antes de conectar as credenciais finais.', 'escortwp'),
				));
			}
			?>
			<?php
			if(!is_woocommerce_active) {
				$action = 'install-plugin';
				$slug = 'woocommerce';
				$install_link = wp_nonce_url(
				    add_query_arg(
				        array(
				            'action' => $action,
				            'plugin' => $slug
				        ),
				        admin_url( 'update.php' )
				    ),
				    $action.'_'.$slug
				);
				echo "<div class=\"ok rad25\">";
					echo __('A area de pagamentos depende do plugin gratuito WooCommerce.','escortwp')."<br />";
					echo __('Instale e ative o WooCommerce antes de configurar o Mercado Pago PIX, os planos e o fluxo de cobrança.','escortwp')."<br />";
					echo __('Ou, se preferir, use a instalacao automatica abaixo.','escortwp')."<br />";
					echo '<a href="'.$install_link.'">'.__('Instalar WooCommerce automaticamente','escortwp').'</a>';
				echo "</div>";
			} else {
			?>
				<?php if ($err) { echo "<div class=\"err rad25\">$err</div>"; } ?>
				<?php if ($ok) { echo "<div class=\"ok rad25\">".__('Suas configuracoes foram salvas.','escortwp')."</div>"; } ?>
				<form action="<?php echo get_permalink(get_the_ID()); ?>" method="post" class="form-styling" novalidate>
					<input type="hidden" name="action" value="paymentsettings" />

		      		<h3 class="settingspagetitle"><?php _e('Configuracoes de pagamento','escortwp'); ?></h3>
					<div class="clear30"></div>
					<div class="text-center"><input type="submit" name="submit" value="<?php _e('Salvar configuracoes','escortwp'); ?>" class="pinkbutton rad3" /></div> <!--center-->
	        		<div class="clear20"></div>
	        		<?php foreach ($payment_plans as $plan_name => $plan) { ?>
						<fieldset class="fieldset rad5">
							<legend class="rad25"><?=ucfirst(strtolower(sprintf(esc_html__($plan['title'][0],'escortwp'),(isset($plan['title'][1]) ? ${$plan['title'][1]} : ""),(isset($plan['title'][2]) ? ${$plan['title'][2]} : ""))))?></legend>
							<div class="form-label">
								<label><?=ucfirst(strtolower(sprintf(esc_html__($plan['label'][0],'escortwp'),(isset($plan['label'][1]) ? ${$plan['label'][1]} : ""),(isset($plan['label'][2]) ? ${$plan['label'][2]} : ""))))?></label>
							</div>
							<div class="form-input">
								<?php
								if($plan['woo_product_id']) {
									$plan['price'] = get_post_meta($plan['woo_product_id'], '_price', true);
								}
								?>
								<input type="number" min="1" step="any" name="<?=$plan_name?>[price]" id="<?=$plan_name?>price" class="input" value="<?=$plan['price']?>" /> <?=$currency?>
								<div class="clear"></div>
								<?php
								if($plan['label_help']) {
									echo '<small><i>!</i> '.sprintf(esc_html__($plan['label_help'][0],'escortwp'),(isset($plan['label_help'][1]) ? ${$plan['label_help'][1]} : "")).'</small>';
								}
								?>
							</div> <!-- price --> <div class="formseparator"></div>

							<?php
							$woo_product = wc_get_product($plan['woo_product_id']);
							if($plan['woo_product_id'] && empty($plan['lock_duration']) && class_exists('WC_Subscriptions') && get_post_meta($plan['woo_product_id'], '_subscription_price', true)) {
							} else {
								if(array_key_exists('duration', $plan) ) { ?>
									<div class="form-label">
										<label><?php _e('O preco vale pelo periodo de','escortwp'); ?></label>
									</div>
									<div class="form-input">
										<?php if(!empty($plan['lock_duration'])) { ?>
											<input type="hidden" name="<?=$plan_name?>[duration]" value="<?=esc_attr($plan['lock_duration'])?>" />
											<strong><?php echo esc_html(__($payment_duration_a[$plan['lock_duration']][0],'escortwp')); ?></strong>
											<div class="clear10"></div>
											<small><i>!</i> <?php _e('Este impulsionamento é sempre avulso e dura exatamente 1 semana.','escortwp'); ?></small>
										<?php } else { ?>
											<select name="<?=$plan_name?>[duration]">
												<option value=""><?php _e('Para sempre','escortwp'); ?></option>
										    	<?php
													foreach($payment_duration_a as $key => $p) {
														$selected = $plan['duration'] == $key ? ' selected="selected"' : "";
														echo '<option value="'.$key.'"'.$selected.'>'.__($p[0],'escortwp').'</option>'."\n";
														unset($selected);
													}
												?>
											</select>
											<div class="clear10"></div>
										<?php } ?>
										<?php
											if(empty($plan['lock_duration'])) {
											echo '<small>';
											if($plan_name == 'premium') {
												_e('Este plano mensal usa renovacao manual. Quando o periodo terminar, a acompanhante pode pagar novamente para somar mais 30 dias ao anuncio.', 'escortwp');
											} else {
												_e('A duracao escolhida define quando este pagamento expira automaticamente.', 'escortwp');
											}
											echo '</small>';
											}
										?>
									</div> <!-- duration --> <div class="formseparator"></div>
								<?php }
							}
							?>

							<?php if(array_key_exists('exp', $plan) ) { ?>
							<div class="form-label">
								<label class="nopadding"><?=sprintf(esc_html__($plan['exp_text'][0],'escortwp'),(isset($plan['exp_text'][1]) ? ${$plan['exp_text'][1]} : ""))?></label>
							</div>
							<div class="form-input">
								<label for="<?=$plan_name?>expdelete"><input type="radio" name="<?=$plan_name?>[exp]" id="<?=$plan_name?>expdelete" value="1"<?php if($plan['exp'] == "1") { echo ' checked="checked"'; } ?> /> <?=__('Excluir anuncio','escortwp')?></label>
								<div class="clear10"></div>
								<label for="<?=$plan_name?>expprivate"><input type="radio" name="<?=$plan_name?>[exp]" id="<?=$plan_name?>expprivate" value="2"<?php if($plan['exp'] == "2") { echo ' checked="checked"'; } ?>  /> <?=__('Ocultar anuncio','escortwp')?></label>
							</div> <!-- expiration --> <div class="formseparator"></div>
							<?php } ?>

							<?php if($plan_name == "vip") { ?>
								<div class="form-label">
									<label class="nopadding"><?php _e('Keep the following profile sections locked until payment is made','escortwp'); ?></label>
								</div>
								<div class="form-input">
									<label for="hide_photos">
										<input type="checkbox" name="<?=$plan_name?>[extra][hide_photos]" value="1" id="hide_photos"<?php if($plan['extra']['hide_photos'] == "1") { echo ' checked'; } ?> />
										<?php _e('All photos except the main one','escortwp'); ?>
									</label><div class="clear5"></div>

									<label for="hide_contact_info">
										<input type="checkbox" name="<?=$plan_name?>[extra][hide_contact_info]" value="1" id="hide_contact_info"<?php if($plan['extra']['hide_contact_info'] == "1") { echo ' checked'; } ?> />
										<?php _e('Contact information','escortwp'); ?>
									</label><div class="clear5"></div>

									<label for="hide_review_form">
										<input type="checkbox" name="<?=$plan_name?>[extra][hide_review_form]" value="1" id="hide_review_form"<?php if($plan['extra']['hide_review_form'] == "1") { echo ' checked'; } ?> />
										<?php _e('Add review section','escortwp'); ?>
									</label><div class="clear5"></div>
								</div> <!-- --> <div class="formseparator"></div>
							<?php } ?>

							<?php
							if($plan['woo_product_id'] && class_exists('WC_Subscriptions') && get_post_meta($plan['woo_product_id'], '_subscription_price', true)) {
								echo '<div class="text-center">';
									echo '<div class="clear20"></div>';
									_e('Este produto esta pronto para cobranca mensal manual. Se precisar, ajuste preco e duracao direto no WordPress / WooCommerce.');
								echo '</div>';
							}
							if($plan['woo_product_id']) {
								echo '<div class="text-center edit-payment-link-wrapper">';
								edit_post_link(__('Editar produto de pagamento no WordPress','escortwp'), '<div class="clear5"></div>', '<div class="clear"></div>', $plan['woo_product_id']);
								echo '</div>';
							}
							?>
						</fieldset> <!-- paymentpackage <?=$plan_name?> -->
						<div class="clear30"></div>
	        		<?php } ?>

					<div class="form-label">
				    	<label><?=__('Mostrar campo de cupom no checkout', 'escortwp')?></label>
				    </div>
					<div class="form-input">
					    <label for="show_coupon_checkoutyes"><input type="radio" name="show_coupon_checkout" value="1" id="show_coupon_checkoutyes"<?php if($show_coupon_checkout == "1") { echo ' checked'; } ?> /> <?php _e('Yes','escortwp'); ?></label>
			    		<label for="show_coupon_checkoutno"><input type="radio" name="show_coupon_checkout" value="2" id="show_coupon_checkoutno"<?php if($show_coupon_checkout == '2') { echo ' checked'; } ?> /> <?php _e('No','escortwp'); ?></label>
			    		<small><i>!</i> <?php _e('Alguns gateways exigem endereco no checkout.','escortwp'); ?></small>
				    </div> <!-- show coupon in checkout --> <div class="formseparator"></div>

					<div class="form-label">
				    	<label><?=__('Mostrar campos de endereco no checkout', 'escortwp')?></label>
				    </div>
					<div class="form-input">
					    <label for="show_address_checkoutyes"><input type="radio" name="show_address_checkout" value="1" id="show_address_checkoutyes"<?php if($show_address_checkout == "1") { echo ' checked'; } ?> /> <?php _e('Yes','escortwp'); ?></label>
			    		<label for="show_address_checkoutno"><input type="radio" name="show_address_checkout" value="2" id="show_address_checkoutno"<?php if($show_address_checkout == '2') { echo ' checked'; } ?> /> <?php _e('No','escortwp'); ?></label>
			    		<small><i>!</i> <?php _e('Alguns gateways exigem endereco no checkout.','escortwp'); ?></small>
				    </div> <!-- show address in checkout --> <div class="formseparator"></div>


					<div class="clear20"></div>
					<div class="text-center"><input type="submit" name="submit" value="<?php _e('Salvar configuracoes','escortwp'); ?>" class="pinkbutton rad3" /></div> <!--center-->
		        </form>
		    <?php } // woocommerce is active or not ?>
		</div> <!-- BODY BOX -->
	</div> <!-- BODY -->
</div> <!-- contentwrapper -->

<?php get_sidebar("left"); ?>
<?php get_sidebar("right"); ?>
<div class="clear"></div>
<?php get_footer(); ?>
