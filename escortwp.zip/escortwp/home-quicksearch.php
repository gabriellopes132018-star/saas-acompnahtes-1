﻿<?php
if (!defined('error_reporting')) { define('error_reporting', '0'); }
ini_set('display_errors', error_reporting);
if (error_reporting == '1') { error_reporting(E_ALL); }
if (isdolcetheme !== 1) { die(); }

global $taxonomy_location_url, $gender_a, $settings_theme_genders;

if (get_option('quickescortsearch') != '1') {
	return;
}
?>
<div class="reference-home-panel reference-home-quicksearch">
	<script type="text/javascript">
		jQuery(document).ready(function($) {
			var c = ".search-country";
			var parent_div = ".reference-home-quicksearch";
			var country = $(parent_div + " " + c).val();
			<?php if (showfield('state')) { ?>
				var city_div = ".search-states-input";
				var state_c = "#state";
				var state_div = ".search-cities-input";
			<?php } else { ?>
				var city_div = ".search-cities-input";
			<?php } ?>

			if (country > 0) { show_search_cities(c); }
			$(parent_div + " " + c).change(function(){ show_search_cities(c); });

			function show_search_cities(e) {
				var selectedCountry = $(parent_div + " " + e).val();
				$(parent_div + " " + city_div).text("");
				<?php if (showfield('state')) { ?>
					$(parent_div + " " + state_div).text("");
				<?php } ?>

				if (selectedCountry < 1) { return true; }

				loader($(e).parents(parent_div).find(city_div));
				$.ajax({
					type: "GET",
					url: "<?php bloginfo('template_url'); ?>/ajax/get-cities.php",
					<?php if (showfield('state')) { ?>
						data: "id=" + selectedCountry + "&selected=&hide_empty=0&class=col100&state=yes&select2=yes",
					<?php } else { ?>
						data: "id=" + selectedCountry + "&selected=&hide_empty=0&class=col100&select2=yes",
					<?php } ?>
					success: function(data){
						$(e).parents(parent_div).find(city_div).html(data + '<div class="formseparator"><'+'/div>');
						if ($(window).width() > 960) {
							$('.select2').select2({minimumResultsForSearch: 20, width: '100%'});
						}
					}
				});
			}

			<?php if (showfield('state')) { ?>
				$(parent_div).on("change", state_c, function() {
					show_search_cities_when_states(state_c);
				});

				function show_search_cities_when_states(e) {
					var selectedState = $(parent_div + " " + e).val();
					$(parent_div + " " + state_div).text("");
					if (selectedState < 1) {
						return true;
					}

					loader($(e).parents(parent_div).find(state_div));
					$.ajax({
						type: "GET",
						url: "<?php bloginfo('template_url'); ?>/ajax/get-cities.php",
						data: "id=" + selectedState + "&selected=&hide_empty=0&class=col100&select2=yes",
						success: function(data){
							$(parent_div).find(state_div).html(data + '<div class="formseparator"><'+'/div>');
							if ($(window).width() > 960) {
								$('.select2').select2({minimumResultsForSearch: 20, width: '100%'});
							}
						}
					});
				}
			<?php } ?>
		});
	</script>

	<h4><?php esc_html_e('Busca rápida', 'escortwp'); ?></h4>
	<form action="<?php echo esc_url(get_permalink(get_option('search_page_id'))); ?>" method="get" class="form-styling escortwp-quicksearch-form">
		<input type="hidden" name="search_action" value="1" />
		<?php
		$args = array(
			'show_option_none' => __('Selecione o estado', 'escortwp'),
			'orderby' => 'name',
			'order' => 'ASC',
			'show_last_update' => 0,
			'show_count' => 0,
			'hide_empty' => 0,
			'selected' => 0,
			'hierarchical' => 1,
			'name' => 'country',
			'id' => '',
			'class' => 'search-country col100 select2',
			'depth' => 1,
			'tab_index' => 0,
			'taxonomy' => $taxonomy_location_url,
		);

		$categories_count_array = array(
			'show_option_all' => '',
			'show_count' => '0',
			'hide_empty' => '0',
			'show_option_none' => '',
			'pad_counts' => '0',
			'taxonomy' => $taxonomy_location_url,
			'parent' => 0,
			'number' => '2',
			'fields' => 'ids',
		);
		$categories_count_data = get_categories($categories_count_array);
		sort($categories_count_data);

		if (count($categories_count_data) == 1) {
			unset($categories_count_array['fields']);
			$country_list = get_categories($categories_count_array);
			$country_list = array_values($country_list);
			echo '<div class="reference-home-fixed-country">' . esc_html(escortwp_translate_runtime_label($country_list[0]->name)) . '</div>';
			echo '<input type="hidden" name="country" class="search-country" value="' . esc_attr($country_list[0]->term_id) . '" />';
			?>
			<script type="text/javascript">jQuery(document).ready(function($) { $('.reference-home-quicksearch .search-country').trigger('change'); });</script>
			<?php
		} else {
			echo '<div class="form-input col100">';
			wp_dropdown_categories($args);
			echo '</div><div class="formseparator"></div>';
		}
		?>

		<?php if (showfield('state')) { ?>
			<div class="search-states-input form-input col100"></div>
		<?php } ?>

		<div class="search-cities-input form-input col100"></div>

		<div class="form-input col100">
			<select name="gender" class="select2">
				<?php
				foreach ($gender_a as $key => $gender) {
					if (in_array($key, $settings_theme_genders)) {
						echo '<option value="' . esc_attr($key) . '">' . esc_html(__($gender, 'escortwp')) . '</option>';
					}
				}
				?>
			</select>
		</div>
		<div class="formseparator"></div>

		<div class="form-input col100">
			<label for="home-premium">
				<input type="checkbox" name="premium" value="1" id="home-premium" />
				<?php _e('Somente destaques', 'escortwp'); ?>
			</label>
		</div>
		<div class="formseparator"></div>

		<div class="form-input col100">
			<label for="home-independent">
				<input type="checkbox" name="independent" value="1" id="home-independent" />
				<?php _e('Somente independentes', 'escortwp'); ?>
			</label>
		</div>
		<div class="formseparator"></div>

		<div class="form-input col100">
			<label for="home-verified">
				<input type="checkbox" name="verified" value="1" id="home-verified" />
				<?php _e('Somente verificadas', 'escortwp'); ?>
			</label>
		</div>
		<div class="formseparator"></div>

		<div class="center col100 escortwp-quicksearch-footer">
			<input type="submit" name="submit" value="<?php _e('Pesquisar', 'escortwp'); ?>" class="submit-button pinkbutton rad25" />
			<div class="clear10"></div>
			<a href="<?php echo esc_url(get_permalink(get_option('search_page_id'))); ?>" class="adv"><span class="icon icon-search"></span><?php _e('Busca avançada', 'escortwp'); ?></a>
		</div>
	</form>
</div>

