<?php
if(!defined('error_reporting')) { define('error_reporting', '0'); }
ini_set( 'display_errors', error_reporting );
if(error_reporting == '1') { error_reporting( E_ALL ); }
if(isdolcetheme !== 1) { die(); }

global $taxonomy_profile_name_plural, $taxonomy_location_url;
?>
<div class="sidebar-left l">
	<div class="countries">
    	<h4><?php esc_html_e('Regiões atendidas','escortwp'); ?><span class="dots">:</span><span class="icon icon-down-dir"></span></h4>
        <ul class="country-list country-list--expanded">
			<?php
			$location_sections = function_exists('escortwp_get_brazil_location_sections') ? escortwp_get_brazil_location_sections() : array();
			foreach ($location_sections as $section) {
				$state = $section['state'];
				$cities = $section['cities'];
				?>
				<li class="cat-item cat-item-<?php echo (int) $state->term_id; ?>">
					<a href="<?php echo esc_url(get_term_link($state)); ?>"><?php echo esc_html(escortwp_translate_runtime_label($state->name)); ?></a>
					<?php if (!empty($cities)) { ?>
						<ul class="children country-list-children country-list-children--expanded">
							<?php foreach ($cities as $city) { ?>
								<li class="cat-item cat-item-<?php echo (int) $city->term_id; ?>">
									<a href="<?php echo esc_url(get_term_link($city)); ?>"><?php echo esc_html(escortwp_translate_runtime_label($city->name)); ?></a>
								</li>
							<?php } ?>
						</ul>
					<?php } ?>
				</li>
				<?php
			}
			?>
        </ul>
		<div class="clear"></div>
	</div> <!-- COUNTRIES -->
	<div class="clear"></div>

	<?php if ( is_active_sidebar('widget-sidebar-left') || current_user_can('level_10')) : ?>
    <div class="widgetbox-wrapper">
    	<?php if ( !dynamic_sidebar('Sidebar Left') && current_user_can('level_10')) : ?>
		<?php _e('Go to your','escortwp'); ?> <a href="<?php echo admin_url('widgets.php'); ?>"><?php _e('widgets page','escortwp'); ?></a> <?php _e('to add content here','escortwp'); ?>.
		<?php endif; ?>
	</div> <!-- SIDEBAR BOX -->
	<?php endif; ?>

	<?php dynamic_sidebar('Left Ads'); ?>
</div> <!-- SIDEBAR LEFT -->
