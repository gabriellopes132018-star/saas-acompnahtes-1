<?php
if (!defined('error_reporting')) { define('error_reporting', '0'); }
ini_set('display_errors', error_reporting);
if (error_reporting == '1') { error_reporting(E_ALL); }
if (isdolcetheme !== 1) { die(); }

if (!isset($err)) { $err = ''; }
if (!isset($member_edit_page)) { $member_edit_page = ''; }
if (!isset($memberemail)) { $memberemail = ''; }
if (!isset($membername)) { $membername = ''; }
if (!isset($user)) { $user = ''; }

$is_member_edit = ($member_edit_page === 'yes');
$tos_checked = !empty($_POST['tos_accept']) && $_POST['tos_accept'] == '1';
$frontend_messages = array(
	'email_required' => 'Preencha seu e-mail.',
	'email_invalid' => 'E-mail inválido.',
	'name_required' => 'Preencha seu nome.',
	'username_required' => 'Preencha seu nome de usuário.',
	'username_length' => 'O nome de usuário deve ter entre 4 e 30 caracteres.',
	'username_format' => 'O nome de usuário deve conter apenas letras e números.',
	'password_required' => 'Senha obrigatória.',
	'password_length' => 'A senha deve ter entre 6 e 50 caracteres.',
	'tos_required' => 'Você precisa aceitar os termos para continuar.',
);

$form_url = $is_member_edit ? get_permalink(get_option('member_edit_personal_info_page_id')) : get_permalink(get_option('member_register_page_id'));
?>
<?php if (!empty($err)) { echo '<div class="err rad25 register-form-member-errors">'.$err.'</div>'; } else { echo '<div class="err rad25 register-form-member-errors hide"></div>'; } ?>
<script type="text/javascript">
jQuery(document).ready(function($) {
	var form = $('.register-form-member');
	if(!form.length) {
		return;
	}

	var errorBox = form.find('.register-form-member-errors');
	var submitButton = form.find('.registersubmit');
	var messages = <?php echo wp_json_encode($frontend_messages); ?>;

	function setFieldError(field, hasError) {
		if(!field.length) {
			return;
		}

		field.toggleClass('input-error', hasError);
		field.attr('aria-invalid', hasError ? 'true' : 'false');
	}

	function renderErrors(errors) {
		if(!errors.length) {
			errorBox.addClass('hide').html('');
			return;
		}

		errorBox.removeClass('hide').html(errors.join('<br />'));
		$('html, body').animate({ scrollTop: errorBox.offset().top - 20 }, 200);
	}

	function collectValidationErrors() {
		var errors = [];
		var emailField = form.find('#memberemail');
		var nameField = form.find('#membername');
		var userField = form.find('#user');
		var passField = form.find('#pass');
		var email = $.trim(emailField.val());
		var memberName = $.trim(nameField.val());
		var username = userField.length ? $.trim(userField.val()) : '';
		var password = passField.length ? passField.val() : '';
		var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
		var usernameRegex = /^[a-zA-Z0-9]+$/;

		setFieldError(emailField, false);
		setFieldError(nameField, false);
		setFieldError(userField, false);
		setFieldError(passField, false);

		if(!email) {
			errors.push(messages.email_required);
			setFieldError(emailField, true);
		} else if(!emailRegex.test(email)) {
			errors.push(messages.email_invalid);
			setFieldError(emailField, true);
		}

		if(!memberName) {
			errors.push(messages.name_required);
			setFieldError(nameField, true);
		}

		if(userField.length) {
			if(!username) {
				errors.push(messages.username_required);
				setFieldError(userField, true);
			} else if(username.length < 4 || username.length > 30) {
				errors.push(messages.username_length);
				setFieldError(userField, true);
			} else if(!usernameRegex.test(username)) {
				errors.push(messages.username_format);
				setFieldError(userField, true);
			}
		}

		if(passField.length) {
			if(!password) {
				errors.push(messages.password_required);
				setFieldError(passField, true);
			} else if(password.length < 6 || password.length > 50) {
				errors.push(messages.password_length);
				setFieldError(passField, true);
			}
		}

		if(form.find('input[name="tos_accept"]').length && !form.find('input[name="tos_accept"]').is(':checked')) {
			$('.register-form-member .form-input-accept-tos').addClass('form-input-accept-tos-err');
			errors.push(messages.tos_required);
		} else {
			$('.register-form-member .form-input-accept-tos').removeClass('form-input-accept-tos-err');
		}

		return errors;
	}

	function validateMemberForm(showErrors) {
		var errors = collectValidationErrors();
		if(showErrors) {
			renderErrors(errors);
		}

		return !errors.length;
	}

	function updateSubmitState() {
		submitButton.prop('disabled', !validateMemberForm(false));
	}

	form.find('#user').on('keyup change', function() {
		var user = $.trim($(this).val());
		var userlength = user.length;

		if(userlength >= 4 && userlength <= 30) {
			$('.checkuser').empty();
			$.ajax({
				type: 'GET',
				url: "<?php bloginfo('template_url'); ?>/ajax/check-username.php",
				data: { user: user, escortwp_nonce: window.escortwpAjax ? window.escortwpAjax.nonce : '' },
				success: function(data) {
					$('.checkuser').html(data);
				}
			});
		} else {
			$('.checkuser').html('<?php echo esc_js(__('Between 4 and 30 characters','escortwp')); ?>');
		}
	});

	form.on('input change', 'input', function() {
		updateSubmitState();
		if(!errorBox.hasClass('hide')) {
			validateMemberForm(true);
		}
	});

	form.on('submit', function(event) {
		if(!validateMemberForm(true)) {
			event.preventDefault();
			return false;
		}

		submitButton.prop('disabled', true).addClass('is-loading');
	});

	updateSubmitState();
});
</script>
<form action="<?php echo esc_url($form_url); ?>" method="post" class="form-styling register-form-member" novalidate>
	<div class="text-center"><small class="mandatory"><?php _e('Fields marked with <i>*</i> are mandatory','escortwp'); ?></small></div>
	<div class="clear20"></div>
	<input type="hidden" name="action" value="registermember" />
	<?php wp_nonce_field('escortwp_member_register', 'escortwp_member_register_nonce'); ?>
	<input type="text" name="emails" value="" class="hide" tabindex="-1" autocomplete="off" />

	<div class="form-label" id="register-member-email">
		<label for="memberemail"><?php _e('E-mail','escortwp'); ?><i>*</i></label>
	</div>
	<div class="form-input">
		<input type="email" name="memberemail" id="memberemail" class="input longinput" value="<?php echo esc_attr($memberemail); ?>" inputmode="email" autocomplete="email" required />
	</div> <!-- email --> <div class="formseparator"></div>

	<div class="form-label" id="register-member-name">
		<label for="membername"><?php _e('Nome','escortwp'); ?><i>*</i></label>
		<small><?php _e('será mostrado publicamente','escortwp'); ?></small>
	</div>
	<div class="form-input">
		<input type="text" name="membername" id="membername" class="input longinput" value="<?php echo esc_attr($membername); ?>" autocomplete="name" required />
	</div> <!-- name --> <div class="formseparator"></div>

	<?php if(!$is_member_edit) { ?>
		<div class="form-label">
			<label for="user"><?php _e('Nome de usuário','escortwp'); ?><i>*</i></label>
			<small class="checkuser"><?php _e('Entre 4 e 30 caracteres','escortwp'); ?></small>
		</div>
		<div class="form-input">
			<input type="text" name="user" id="user" class="input longinput" minlength="4" maxlength="30" pattern="[A-Za-z0-9]+" value="<?php echo esc_attr($user); ?>" autocomplete="username" required />
		</div> <!-- user --> <div class="formseparator"></div>

		<div class="form-label" id="register-member-password">
			<label for="pass"><?php _e('Senha','escortwp'); ?><i>*</i></label>
			<small><?php _e('Entre 6 e 30 caracteres','escortwp'); ?></small>
		</div>
		<div class="form-input">
			<input type="password" name="pass" id="pass" class="input longinput" minlength="6" maxlength="50" autocomplete="new-password" required />
		</div> <!-- password --> <div class="formseparator"></div>
	<?php } ?>

	<?php if(get_option('recaptcha_sitekey') && get_option('recaptcha_secretkey') && !is_user_logged_in() && get_option('recaptcha4')) { ?>
		<div class="form-input">
			<div class="g-recaptcha" data-sitekey="<?php echo esc_attr(get_option('recaptcha_sitekey')); ?>"></div>
		</div> <!-- captcha --> <div class="formseparator"></div>
	<?php } ?>

	<?php
	$tos_page_data = get_post(get_option('tos_page_id'));
	$data_protection_page_data = get_post(get_option('data_protection_page_id'));
	if (($tos_page_data || $data_protection_page_data) && !is_user_logged_in()) {
		if ($tos_page_data && $data_protection_page_data) {
			$message = sprintf(
				__('Concordo com %s e %s deste site', 'escortwp'),
				'<a href="'.get_permalink(get_option('tos_page_id')).'" target="_blank">'.$tos_page_data->post_title.'</a>',
				'<a href="'.get_permalink(get_option('data_protection_page_id')).'" target="_blank">'.$data_protection_page_data->post_title.'</a>'
			);
		} elseif ($tos_page_data) {
			$message = sprintf(
				__('Concordo com %s deste site', 'escortwp'),
				'<a href="'.get_permalink(get_option('tos_page_id')).'" target="_blank">'.$tos_page_data->post_title.'</a>'
			);
		} else {
			$message = sprintf(
				__('Concordo com %s deste site', 'escortwp'),
				'<a href="'.get_permalink(get_option('data_protection_page_id')).'" target="_blank">'.$data_protection_page_data->post_title.'</a>'
			);
		}
	?>
	<div class="formseparator"></div>
	<div class="form-input col100 center form-input-accept-tos">
		<label for="tos_checkbox" class="rad25">
			<input type="checkbox" name="tos_accept" value="1" id="tos_checkbox"<?php if($tos_checked) { echo ' checked'; } ?> />
			<?php echo $message; ?>
		</label>
	</div> <!-- message --> <div class="clear15"></div>
	<?php } ?>

	<div class="text-center"><input type="submit" name="submit" value="<?php if($is_member_edit) { _e('Atualizar','escortwp'); } else { _e('Criar conta','escortwp'); } ?>" class="pinkbutton rad3 registersubmit" /></div> <!--center-->
</form>
