		<input type="url" name="facebook" id="facebook" class="input longinput" placeholder="https://" value="<?php echo $facebook; ?>" />
		<small><?=__('Facebook profile/page url','escortwp')?></small>
	</div> <!-- facebook --> <div class="formseparator"></div>
   	<?php } ?>

	<?php if (!empty($escort_post_id) || !empty($agencyid)) { ?>

	<?php if(get_option('locationdropdown') == "1") { ?>
	<script type="text/javascript">
		jQuery(document).ready(function($) {
			//get cities from the selected country in the countries dropdown
			var c = ".country";
			var parent_div = ".register-form";
			<?php if(showfield('state')) { ?>
				var city_div = '.inputstates';

				var state_c = '.state';
				var state_div = '.inputcities';
			<?php } else { ?>
				var city_div = '.inputcities';
			<?php } ?>

			show_search_cities(c);
			$(parent_div+' '+c).change(function(){ show_search_cities(c); });
			function show_search_cities(e) {
				var country = $(parent_div+' '+e).val();
				$(parent_div+' '+city_div).text($(city_div).data('text'));
				<?php if(showfield('state')) { ?>
					$(parent_div+' '+state_div).text($(state_div).data('text'));
				<?php } ?>

				if(country < 1) return true;

				loader($(e).parents(parent_div).find(city_div));
				$.ajax({
					type: "GET",
					url: "<?php bloginfo('template_url'); ?>/ajax/get-cities.php",
					<?php if(showfield('state')) { ?>
						data: "id=" + country +"&hide_empty=0&state=yes&select2=yes",
					<?php } else { ?>
						data: "id=" + country +"&hide_empty=0&select2=yes",
					<?php } ?>
					success: function(data){
						$(e).parents(parent_div).find(city_div).html(data);
						if($(window).width() > "960") { $('.select2').select2(); }
					}
				});
			}

			<?php if(showfield('state')) { ?>
				$(parent_div).on("change", state_c, function(){
					show_search_cities_when_states(state_c);
				});
				function show_search_cities_when_states(e) {
					var state = $(parent_div+' '+e).val();
					$(parent_div+' '+state_div).text($(state_div).data('text'));
					if(state < 1) {
						return true;
					}

					loader($(e).parents(parent_div).find(state_div));
					$.ajax({
						type: "GET",
						url: "<?php bloginfo('template_url'); ?>/ajax/get-cities.php",
						data: "id=" + state +"&hide_empty=0&select2=yes",
						success: function(data){
							$(e).parents(parent_div).find(state_div).html(data);
							if($(window).width() > "960") { $('.select2').select2(); }
						}
					});
				}
			<?php } // if showfield('state') ?>
		});
	</script>
	<?php } // if the city and state need to be dropdowns ?>
	<div id="aba-localizacao" class="escortwp-form-section-heading">
		<span class="escortwp-form-section-kicker"><?php _e('Localização', 'escortwp'); ?></span>
		<h4><?php _e('Região principal do anúncio', 'escortwp'); ?></h4>
		<p><?php _e('Selecione a região certa para que o perfil apareça nas buscas corretas e mantenha a navegação do site organizada.', 'escortwp'); ?></p>
	</div>
	<div class="form-label">
		<label for="country"><?php _e('Estado','escortwp'); ?><i>*</i></label>
	</div>
	<div class="form-input">
		<?php
		$args = array(
			'show_option_none'   => __('Selecione o estado','escortwp'),
		    'orderby'            => 'name',
		    'order'              => 'ASC',
			'hide_empty'         => 0,
			'echo'               => 1,
			'selected'           => $country,
			'hierarchical'       => 1,
			'name'               => 'country',
			'id'                 => 'country',
			'class'              => 'country select2',
			'depth'              => 1,
			'taxonomy'           => $taxonomy_location_url
		);

		$categories_count_array = array(
			'show_option_all' => '',
			'show_count' => '0',
			'hide_empty' => '0',
			'show_option_none' => '',
			'pad_counts' => '0',
			'taxonomy' => $taxonomy_location_url,
			'parent' => 0,
			'number' => '2',
			'fields' => 'ids'
		);
		$categories_count_data = get_categories($categories_count_array);
		if(count($categories_count_data) == "1") {
			unset($categories_count_array['fields']);
			$country_list = get_categories($categories_count_array);
			$country_list = array_values($country_list);
			echo '<div class="clear10"></div>'.escortwp_translate_runtime_label($country_list[0]->name);
			echo '<input type="hidden" name="country" class="country" value="'.$country_list[0]->term_id.'" />';
			?>
			<script type="text/javascript"> jQuery(document).ready(function($) { $('.register-form .country').trigger('change'); }); </script>
			<?php
		} else {
			wp_dropdown_categories( $args );
		}
		$city_parent = $country;
		?>
    </div> <!-- country --> <div class="formseparator"></div>

	<?php if(showfield('state')) { ?>
	<div class="form-label">
		<label for="state"><?php _e('Região','escortwp'); ismand('state'); ?></label>
	</div>
	<div class="form-input inputstates" data-text="<?=__('Selecione um estado primeiro','escortwp')?>">
		<?php if(get_option('locationdropdown') == "1") {
				if($country > 0) {
					$city_parent = $state;
					$args = array(
						'show_option_all'    => '',
					'show_option_none'   => __('Selecione a região','escortwp'),
						'show_last_update'   => 0,
						'show_count'         => 0,
						'parent'			 => $country,
						'hide_empty'         => 0,
						'exclude'            => '',
						'echo'               => 1,
						'selected'           => $state,
						'hierarchical'       => 1, 
						'name'               => 'state',
						'id'                 => '',
						'class'              => 'state select2',
						'depth'              => 1,
						'tab_index'          => 0,
					    'orderby'            => 'name',
					    'order'              => 'ASC',
						'taxonomy'           => $taxonomy_location_url );
					wp_dropdown_categories( $args );
				} else {
					_e('Selecione um estado primeiro','escortwp');
				}
		} else { ?>
			<input type="text" name="state" id="state" class="input longinput" value="<?php echo $state; ?>" />
		<?php } ?>
	</div> <!-- state --> <div class="formseparator"></div>
   	<?php } ?>

    <div class="form-label">
		<label for="city"><?php _e('Cidade','escortwp'); ?> <i>*</i></label>
	</div>
	<?php
	if(showfield('state')) {
		$city_text = __('Selecione uma região primeiro','escortwp');
	} else {
		$city_text = __('Selecione um estado primeiro','escortwp');
	}
	?>
	<div class="form-input inputcities" data-text="<?=$city_text?>">
		<?php if(get_option('locationdropdown') == "1") {
			if(($country > 0 && !showfield('state')) || ($state > 0 && showfield('state'))) {
				$args = array(
					'show_option_all'    => '',
					'show_option_none'   => __('Selecione a cidade','escortwp'),
					'show_last_update'   => 0,
					'show_count'         => 0,
					'parent'			 => $city_parent,
					'hide_empty'         => 0,
					'exclude'            => '',
					'echo'               => 1,
					'selected'           => $city,
					'hierarchical'       => 1, 
					'name'               => 'city',
					'id'                 => '',
					'class'              => 'city select2',
					'depth'              => 1,
					'tab_index'          => 0,
				    'orderby'            => 'name',
				    'order'              => 'ASC',
					'taxonomy'           => $taxonomy_location_url );
				wp_dropdown_categories( $args );
			} else {
				echo $city_text;
			}
		} else { ?>
			<input type="text" name="city" id="city" class="input longinput" value="<?php echo $city; ?>" />
		<?php } ?>
	</div> <!-- city --> <div class="formseparator"></div>

	<div class="form-label">
		<label><?php _e('Gender','escortwp'); ?><i>*</i></label>
	</div>
	<div class="form-input" id="gender">
		<?php
		foreach($gender_a as $key=>$g) {
			if(in_array($key, $settings_theme_genders)) {
		?>
		<label for="gender<?php echo $key ?>">
			<input type="radio" name="gender" value="<?php echo $key; ?>" id="gender<?php echo $key ?>"<?php if($gender == $key) { echo ' checked'; } ?> />
			<?php _e($g,'escortwp'); ?><br />
		</label>
		<?php
			} // if in_array
		} // foreach
		?>
	</div> <!-- GENDER --> <div class="formseparator"></div>

	<div class="form-label">
		<label class="with-help"><?php _e('Date of birth','escortwp'); ?><i>*</i></label>
		<small><?php _e('we\'ll calculate your age from this','escortwp'); ?></small>
	</div>
	<div class="form-input">
		<select name="dateday" id="dateday" class="birthday select col33 l">
			<option value=""><?php _e('Day','escortwp'); ?></option>
			<?php
			for($i=1;$i<=31;$i+=1) {
				$selected = $dateday == $i ? ' selected="selected"' : "";
				echo '<option value="'.$i.'"'.$selected.'>'.$i.'</option>';
			}
			?>
		</select>
		<select name="datemonth" id="datemonth" class="birthday select col33 l">
			<option value=""><?php _e('Month','escortwp'); ?></option>
			<option value="1"<?php if($datemonth == "1") { echo ' selected="selected"'; } ?>><?php _e('January','escortwp'); ?></option>
			<option value="2"<?php if($datemonth == "2") { echo ' selected="selected"'; } ?>><?php _e('February','escortwp'); ?></option>
			<option value="3"<?php if($datemonth == "3") { echo ' selected="selected"'; } ?>><?php _e('March','escortwp'); ?></option>
			<option value="4"<?php if($datemonth == "4") { echo ' selected="selected"'; } ?>><?php _e('April','escortwp'); ?></option>
			<option value="5"<?php if($datemonth == "5") { echo ' selected="selected"'; } ?>><?php _e('May','escortwp'); ?></option>
			<option value="6"<?php if($datemonth == "6") { echo ' selected="selected"'; } ?>><?php _e('June','escortwp'); ?></option>
			<option value="7"<?php if($datemonth == "7") { echo ' selected="selected"'; } ?>><?php _e('July','escortwp'); ?></option>
			<option value="8"<?php if($datemonth == "8") { echo ' selected="selected"'; } ?>><?php _e('August','escortwp'); ?></option>
			<option value="9"<?php if($datemonth == "9") { echo ' selected="selected"'; } ?>><?php _e('September','escortwp'); ?></option>
			<option value="10"<?php if($datemonth == "10") { echo ' selected="selected"'; } ?>><?php _e('October','escortwp'); ?></option>
			<option value="11"<?php if($datemonth == "11") { echo ' selected="selected"'; } ?>><?php _e('November','escortwp'); ?></option>
			<option value="12"<?php if($datemonth == "12") { echo ' selected="selected"'; } ?>><?php _e('December','escortwp'); ?></option>
		</select>
		<select name="dateyear" id="dateyear" class="birthday select col33 l">
			<option value=""><?php _e('Year','escortwp'); ?></option>
			<?php
			$startyear = date('Y') - 18;
			$endyear = date('Y') - 100;
			for($i=$startyear;$i>=$endyear;$i--) {
				$selected = $dateyear == $i ? ' selected="selected"' : "";
				echo '<option value="'.$i.'"'.$selected.'>'.$i.'</option>';
			}
			?>
		</select>
	</div> <!-- DATE OF BIRTH --> <div class="formseparator"></div>

	<?php if(showfield('ethnicity')) { ?>
	<div class="form-label">
		<label for="ethnicity"><?php _e('Etnia','escortwp'); ismand('ethnicity'); ?></label>
	</div>
	<div class="form-input">
		<select name="ethnicity" id="ethnicity">
			<option value=""><?php _e('Selecione','escortwp'); ?></option>
			<?php foreach($ethnicity_a as $key=>$s) { ?>
				<option value="<?php echo $key; ?>"<?php if($ethnicity == $key) { echo ' selected="selected"'; } ?>><?php _e($s,'escortwp'); ?></option>
			<?php } ?>
		</select>
	</div> <!-- SKIN COLOR --> <div class="formseparator"></div>
	<?php } // showfield ?>


	<?php if(showfield('height')) { ?>
	<div class="form-label">
		<label for="height"><?php _e('Altura','escortwp'); ismand('height'); ?></label>
	</div>
	<div class="form-input">
		<input type="number" name="height" size="4" maxlength="4" id="height" class="input smallinput text-center" value="<?php echo $height; ?>" /> &nbsp; <?=get_option('heightscale') == "imperial" ? "ft" : "cm"?>
		<?php if(get_option('heightscale') == "imperial") { ?>
		&nbsp;&nbsp;<input type="number" name="height2" size="2" maxlength="2" id="height2" class="input smallinput text-center" value="<?php echo $height2; ?>" /> &nbsp; inches
		<?php } ?>
	</div> <!-- HEIGHT --> <div class="formseparator"></div>
	<?php } // showfield ?>

	<?php if(showfield('weight')) { ?>
	<div class="form-label">
		<label for="weight"><?php _e('Peso','escortwp'); ismand('weight'); ?></label>
	</div>
	<div class="form-input">
		<input type="number" step="0.01" name="weight" size="4" id="weight" class="input smallinput text-center" value="<?php echo $weight; ?>" /> &nbsp; <?=get_option('heightscale') == "imperial" ? "lb" : "kg"?>
	</div> <!-- WEIGHT --> <div class="formseparator"></div>
	<?php } // showfield ?>

	<?php if(showfield('build')) { ?>
	<div class="form-label">
		<label for="build"><?php _e('Porte físico','escortwp'); ismand('build'); ?></label>
	</div>
	<div class="form-input">
		<select name="build" id="build" class="build">
			<option value=""><?php _e('Selecione','escortwp'); ?></option>
			<?php foreach($build_a as $key=>$b) { ?>
				<option value="<?php echo $key; ?>"<?php if($build == $key) { echo ' selected="selected"'; } ?>><?php _e($b,'escortwp'); ?></option>
			<?php } ?>
		</select>
	</div> <!-- BUILT --> <div class="formseparator"></div>
	<?php } // showfield ?>


	<?php
	if(showfield('availability')) {
		if(!$availability) { $availability = array(); }
	?>
	<div class="form-label">
		<label><?php _e('Disponibilidade','escortwp'); ismand('availability'); ?></label>
	</div>
	<div class="form-input">
		<label for="incall">
			<input type="checkbox" name="availability[]" value="1" id="incall"<?php if( in_array("1", $availability) ) { echo ' checked'; } ?> />
			<?php _e('No local','escortwp'); ?>
		</label>
		<label for="outcall">
			<input type="checkbox" name="availability[]" value="2" id="outcall"<?php if( in_array("2", $availability) ) { echo ' checked'; } ?> />
			<?php _e('Atendimento externo','escortwp'); ?>
		</label>
	</div> <!-- AVAILABILITY --> <div class="formseparator"></div>
	<?php } // showfield ?>


	<div id="aba-perfil" class="escortwp-form-section-heading">
		<span class="escortwp-form-section-kicker"><?php _e('Perfil', 'escortwp'); ?></span>
		<h4><?php _e('Apresentação pública da acompanhante', 'escortwp'); ?></h4>
		<p><?php _e('Preencha os dados do perfil com clareza para gerar mais confiança e facilitar o entendimento de quem visita o anúncio.', 'escortwp'); ?></p>
	</div>

	<?php if(showfield('aboutyou')) { ?>
	<div class="form-label">
		<?php
			$labeltext = __('Apresentação do anúncio','escortwp');
			if ($agencyid || current_user_can('level_10')) { $labeltext = sprintf(esc_html__('Apresentação da %s','escortwp'),$taxonomy_profile_name); }
		?>
		<label for="aboutyou"><?php echo $labeltext; ismand('aboutyou'); ?></label>
	</div>
	<div class="form-input">
		<textarea name="aboutyou" id="aboutyou" class="textarea longtextarea" rows="7" required><?php echo strip_tags($aboutyou); ?></textarea>
		<small><?php _e('Qualquer código HTML será removido','escortwp'); ?></small>
	</div> <!-- about you --> <div class="formseparator"></div>
	<?php } // showfield ?>


	<div id="aba-valores" class="escortwp-form-section-heading">
		<span class="escortwp-form-section-kicker"><?php _e('Valores', 'escortwp'); ?></span>
		<h4><?php _e('Tabela de atendimento', 'escortwp'); ?></h4>
		<p><?php _e('Informe apenas os valores que realmente serão praticados. Isso ajuda o painel a montar um anúncio mais profissional e transparente.', 'escortwp'); ?></p>
	</div>

	<?php if(showfield('rates')) { ?>
	<div class="form-label">
		<label><?php _e('Valores','escortwp'); ismand('rates'); ?></label>
		<?php if(ismand('rates', 'no')) { echo '<small>'.__('informe pelo menos um valor','escortwp').'</small>'; } ?>
	</div>
	<div class="form-input">
		<div class="col30 l currency-label-text"><?php _e('Moeda','escortwp'); ?>:</div>
		<div class="col60 l currency-label-dropdown">
			<input type="hidden" name="currency" value="1" />
			<select name="currency_display" id="currency" class="col100" disabled="disabled">
				<option value="1" selected="selected">BRL - Real</option>
			</select>
		</div>
		<div class="clear20"></div>

		<div class="rates l">
			<div class="col30 l">&nbsp;</div>
			<div class="col30 text-center l hide-incall"><b><?php _e('No local','escortwp'); ?></b></div>
			<div class="col30 text-center l hide-outcall"><b><?php _e('Atendimento externo','escortwp'); ?></b></div>
		</div>
		<div class="clear10"></div>
		<div class="rates l">
			<div class="col30 l rates-label"><?php echo "30 ".__('minutos','escortwp'); ?></div>
			<div class="col30 l hide-incall"><input type="number" name="rate30min_incall" maxlength="15" value="<?php echo $rate30min_incall; ?>" class="input" /></div>
			<div class="col30 l hide-outcall"><input type="number" name="rate30min_outcall" maxlength="15" value="<?php echo $rate30min_outcall; ?>" class="input" /></div>
		</div>
		<div class="rates l">
			<div class="col30 l rates-label"><?php echo "1 ".__('hora','escortwp'); ?></div>
			<div class="col30 l hide-incall"><input type="number" name="rate1h_incall" maxlength="15" value="<?php echo $rate1h_incall; ?>" class="input" /></div>
			<div class="col30 l hide-outcall"><input type="number" name="rate1h_outcall" maxlength="15" value="<?php echo $rate1h_outcall; ?>" class="input" /></div>
		</div>
		<div class="rates l">
			<div class="col30 l rates-label"><?php echo "2 ".__('horas','escortwp'); ?></div>
			<div class="col30 l hide-incall"><input type="number" name="rate2h_incall" maxlength="15" value="<?php echo $rate2h_incall; ?>" class="input" /></div>
			<div class="col30 l hide-outcall"><input type="number" name="rate2h_outcall" maxlength="15" value="<?php echo $rate2h_outcall; ?>" class="input" /></div>
		</div>
		<div class="rates l">
			<div class="col30 l rates-label"><?php echo "3 ".__('horas','escortwp'); ?></div>
			<div class="col30 l hide-incall"><input type="number" name="rate3h_incall" maxlength="15" value="<?php echo $rate3h_incall; ?>" class="input" /></div>
			<div class="col30 l hide-outcall"><input type="number" name="rate3h_outcall" maxlength="15" value="<?php echo $rate3h_outcall; ?>" class="input" /></div>
		</div>
		<div class="rates l">
			<div class="col30 l rates-label"><?php echo "6 ".__('horas','escortwp'); ?></div>
			<div class="col30 l hide-incall"><input type="number" name="rate6h_incall" maxlength="15" value="<?php echo $rate6h_incall; ?>" class="input" /></div>
			<div class="col30 l hide-outcall"><input type="number" name="rate6h_outcall" maxlength="15" value="<?php echo $rate6h_outcall; ?>" class="input" /></div>
		</div>
		<div class="rates l">
			<div class="col30 l rates-label"><?php echo "12 ".__('horas','escortwp'); ?></div>
			<div class="col30 l hide-incall"><input type="number" name="rate12h_incall" maxlength="15" value="<?php echo $rate12h_incall; ?>" class="input" /></div>
			<div class="col30 l hide-outcall"><input type="number" name="rate12h_outcall" maxlength="15" value="<?php echo $rate12h_outcall; ?>" class="input" /></div>
		</div>
		<div class="rates l">
			<div class="col30 l rates-label"><?php echo "24 ".__('horas','escortwp'); ?></div>
			<div class="col30 l hide-incall"><input type="number" name="rate24h_incall" maxlength="15" value="<?php echo $rate24h_incall; ?>" class="input" /></div>
			<div class="col30 l hide-outcall"><input type="number" name="rate24h_outcall" maxlength="15" value="<?php echo $rate24h_outcall; ?>" class="input" /></div>
		</div>
		<div class="clear"></div>
	</div> <!-- RATES --> <div class="formseparator"></div>
	<?php } // showfield ?>

	<div id="aba-servicos" class="escortwp-form-section-heading">
		<span class="escortwp-form-section-kicker"><?php _e('Serviços', 'escortwp'); ?></span>
		<h4><?php _e('Serviços do anúncio', 'escortwp'); ?></h4>
		<p><?php _e('Escreva livremente os serviços e combinações que deseja mostrar no perfil. Cada linha pode virar um item do anúncio.', 'escortwp'); ?></p>
	</div>

	<?php if(showfield('services') || showfield('extraservices')) { ?>
	<div class="form-label">
		<label for="service_line_1"><?php _e('Serviços oferecidos','escortwp'); ?></label>
	</div>
	<div class="form-input escortwp-service-lines">
		<?php for($service_line_index = 0; $service_line_index < 6; $service_line_index++) { ?>
			<input
				type="text"
				name="service_lines[]"
				id="service_line_<?php echo $service_line_index + 1; ?>"
				class="input longinput escortwp-service-line"
				value="<?php echo esc_attr($service_lines_values[$service_line_index] ?? ''); ?>"
				placeholder="<?php echo esc_attr(sprintf(__('Serviço %d', 'escortwp'), $service_line_index + 1)); ?>"
			/>
			<div class="clear10"></div>
		<?php } ?>
		<textarea name="extraservices" id="extraservices" class="textarea longtextarea" rows="7" placeholder="<?php echo esc_attr__('Exemplo: Massagem relaxante&#10;Atendimento a casais&#10;Pernoite sob consulta','escortwp'); ?>"><?php echo esc_textarea($extraservices ?? ''); ?></textarea>
		<input type="hidden" name="services_freeform_mode" value="1" />
		<small><?php _e('Preencha apenas os serviços que deseja exibir. Cada linha vira um item separado no anúncio.', 'escortwp'); ?></small>
	</div> <!-- services --> <div class="formseparator"></div>
	<?php } // showfield ?>

	<?php } // End if(!empty($escort_post_id) || !empty($agencyid)) ?>
