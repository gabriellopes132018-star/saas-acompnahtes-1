<?php
/*
Template Name: Contact page
*/

$err = '';
$ok = '';
$contactformname = '';
$contactformemail = '';
$contactformwebsite = '';
$contactformmess = '';
$current_user = wp_get_current_user();
$site_email = get_option('admin_email') ? get_option('admin_email') : get_bloginfo('admin_email');
$site_email_safe = antispambot($site_email);
$partnerships_url = 'https://t.me/GarotasDF?text=' . rawurlencode('Olá, quero falar sobre parcerias.');

if (isset($_POST['action']) && $_POST['action'] == 'contactus') {
	if (!empty($_POST['emails'])) {
		$err .= '.';
	}

	$contactformname = !empty($_POST['contactformname']) ? wp_strip_all_tags($_POST['contactformname']) : '';
	if (!$contactformname && !empty($_POST['yourname'])) {
		$contactformname = wp_strip_all_tags($_POST['yourname']);
	}
	if (!$contactformname) {
		$err .= __('Informe seu nome', 'escortwp') . "<br />";
	}

	$contactformemail = !empty($_POST['contactformemail']) ? $_POST['contactformemail'] : '';
	if (!$contactformemail && !empty($_POST['youremail'])) {
		$contactformemail = $_POST['youremail'];
	}
	if ($contactformemail) {
		if (!is_email($contactformemail)) {
			$err .= __('O e-mail informado parece inválido', 'escortwp') . "<br />";
		}
	} else {
		$err .= __('Informe seu e-mail', 'escortwp') . "<br />";
	}

	$contactformwebsite = !empty($_POST['contactformwebsite']) ? substr(wp_strip_all_tags($_POST['contactformwebsite']), 0, 200) : '';
	if (!$contactformwebsite && !empty($_POST['yourwebsite'])) {
		$contactformwebsite = substr(wp_strip_all_tags($_POST['yourwebsite']), 0, 200);
	}

	$contactformmess = !empty($_POST['contactformmess']) ? substr(stripslashes(wp_kses($_POST['contactformmess'], array())), 0, 5000) : '';
	if (!$contactformmess && !empty($_POST['yourmessage'])) {
		$contactformmess = substr(stripslashes(wp_kses($_POST['yourmessage'], array())), 0, 5000);
	}
	if (!$contactformmess) {
		$err .= __('Escreva sua mensagem', 'escortwp') . "<br />";
	}

	if (get_option('recaptcha_sitekey') && get_option('recaptcha_secretkey') && get_option('recaptcha1')) {
		$err .= verify_recaptcha();
	}

	if (!$err) {
		$body = __('Olá', 'escortwp') . ',<br /><br />'
			. __('Você recebeu uma nova mensagem pelo formulário de contato do site.', 'escortwp') . '<br /><br />'
			. __('Nome', 'escortwp') . ': <b>' . $contactformname . '</b><br />'
			. __('E-mail', 'escortwp') . ': <b>' . $contactformemail . '</b><br />'
			. __('Website', 'escortwp') . ': <b>' . $contactformwebsite . '</b><br />'
			. __('Mensagem', 'escortwp') . ':<br />' . $contactformmess . '<br /><br />'
			. __('Você pode responder esta pessoa diretamente retornando este e-mail.', 'escortwp');

		dolce_email($contactformname, $contactformemail, get_bloginfo('admin_email'), __('Mensagem de contato', 'escortwp') . ' - ' . get_option('email_sitename'), $body, $contactformmess);
		$ok = __('Mensagem enviada com sucesso.', 'escortwp');
	}
}

if (is_user_logged_in() && !isset($_POST['action'])) {
	$contactformname = $current_user->display_name;
	$contactformemail = $current_user->user_email;
}

get_header();
?>

<div class="contentwrapper">
	<div class="body">
		<div class="bodybox escortwp-contact-page">
			<h3><?php _e('Contato', 'escortwp'); ?></h3>
			<div class="escortwp-contact-hero">
				<div class="escortwp-contact-card">
					<span class="escortwp-contact-label"><?php _e('E-mail principal', 'escortwp'); ?></span>
					<h4><a href="mailto:<?php echo esc_attr($site_email_safe); ?>"><?php echo esc_html($site_email_safe); ?></a></h4>
					<p><?php _e('Use este endereço para dúvidas gerais, suporte comercial e assuntos do portal.', 'escortwp'); ?></p>
				</div>
				<div class="escortwp-contact-card">
					<span class="escortwp-contact-label"><?php _e('Parcerias', 'escortwp'); ?></span>
					<h4><?php _e('Atendimento no Telegram', 'escortwp'); ?></h4>
					<p><?php _e('Para propostas comerciais, parcerias e mídia, fale direto pelo nosso Telegram.', 'escortwp'); ?></p>
					<a class="escortwp-contact-telegram" href="<?php echo esc_url($partnerships_url); ?>" target="_blank" rel="nofollow noopener"><?php _e('Falar sobre parcerias', 'escortwp'); ?></a>
				</div>
			</div>

			<?php if (have_posts()) : ?>
				<div class="clear"></div>
				<?php while (have_posts()) : the_post(); ?>
					<?php the_content(); ?><?php edit_post_link(__('Adicionar texto nesta página', 'escortwp'), '<br />', ''); ?>
				<?php endwhile; ?>
			<?php endif; ?>

			<div class="clear"></div>
			<?php if ($err) { echo '<div class="err rad25">' . $err . '</div>'; } ?>
			<?php if ($ok) { echo '<div class="ok rad25">' . $ok . '</div>'; } ?>

			<form action="<?php echo esc_url(get_permalink(get_the_ID())); ?>" method="post" class="form-styling escortwp-contact-form">
				<input type="hidden" name="action" value="contactus" />
				<input type="text" name="emails" value="" style="display:none;" />

				<div class="form-label">
					<label for="contactformname"><?php _e('Nome', 'escortwp'); ?>: <i>*</i></label>
				</div>
				<div class="form-input">
					<input type="text" name="contactformname" id="contactformname" class="input" value="<?php echo esc_attr($contactformname); ?>" />
				</div><div class="formseparator"></div>

				<div class="form-label">
					<label for="contactformemail"><?php _e('E-mail', 'escortwp'); ?>: <i>*</i></label>
				</div>
				<div class="form-input">
					<input type="email" name="contactformemail" id="contactformemail" class="input" value="<?php echo esc_attr($contactformemail); ?>" />
				</div><div class="formseparator"></div>

				<div class="form-label">
					<label for="contactformwebsite"><?php _e('Website', 'escortwp'); ?>:</label>
				</div>
				<div class="form-input">
					<input type="text" name="contactformwebsite" id="contactformwebsite" class="input" value="<?php echo esc_attr($contactformwebsite); ?>" />
				</div><div class="formseparator"></div>

				<div class="form-label">
					<label for="contactformmess"><?php _e('Mensagem', 'escortwp'); ?>: <i>*</i></label>
				</div>
				<div class="form-input">
					<textarea name="contactformmess" id="contactformmess" class="textarea" rows="7" cols="42"><?php echo esc_textarea($contactformmess); ?></textarea><br /><small><?php _e('Código HTML será removido.', 'escortwp'); ?></small>
				</div><div class="formseparator"></div>

				<?php if (get_option('recaptcha_sitekey') && get_option('recaptcha_secretkey') && get_option('recaptcha1')) { ?>
					<div class="form-input">
						<div class="g-recaptcha" data-sitekey="<?php echo esc_attr(get_option('recaptcha_sitekey')); ?>"></div>
					</div><div class="formseparator"></div>
				<?php } ?>

				<div class="clear"></div>
				<div class="text-center"><input type="submit" name="submit" value="<?php _e('Enviar mensagem', 'escortwp'); ?>" class="pinkbutton rad3" /></div>
			</form>
			<div class="clear"></div>
		</div>
	</div>
</div>

<?php get_sidebar('left'); ?>
<?php get_sidebar('right'); ?>
<div class="clear"></div>

<?php get_footer(); ?>
