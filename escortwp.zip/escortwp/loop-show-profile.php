<?php
if(!defined('error_reporting')) { define('error_reporting', '0'); }
ini_set( 'display_errors', error_reporting );
if(error_reporting == '1') { error_reporting( E_ALL ); }
if(isdolcetheme !== 1) { die(); }

global $taxonomy_location_url;
$i = isset($i) ? (int) $i : 1;
$category = wp_get_post_terms(get_the_ID(), $taxonomy_location_url);

$linktitle = get_the_title();
$imagealt = get_the_title();

$premium = get_post_meta(get_the_ID(), "premium", true);
$thumbclass = ($premium == "1") ? " girlpremium" : "";

$location = array();
$city = wp_get_post_terms(get_the_ID(), $taxonomy_location_url);
if($city) {
	$location[] = escortwp_translate_runtime_label($city[0]->name);

	$state = get_term($city[0]->parent, $taxonomy_location_url);
	if($state) {
		$location[] = escortwp_translate_runtime_label($state->name);

		$country = get_term($state->parent, $taxonomy_location_url);
		if(!is_wp_error($country)) {
			$location[] = escortwp_translate_runtime_label($country->name);
		}
	}
}
$location = array_values(array_unique(array_filter($location)));
$card_location = array_slice($location, 0, 2);
$card_location_label = implode(', ', $card_location);
$full_location_label = implode(', ', $location);

$videos = get_children( array('post_parent' => get_the_ID(), 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'video', 'numberposts' => '1') );
?>
    <div class="girl escortwp-profile-card" itemscope itemtype ="http://schema.org/Person">
		<div class="thumb rad3 escortwp-profile-card-surface<?php echo $thumbclass; ?>">
			<div class="thumbwrapper escortwp-profile-card-wrapper">
        		<a href="<?php the_permalink(); ?>" title="<?php echo $linktitle; ?>" class="escortwp-profile-card-link">
					<span class="escortwp-profile-card-media">
						<img class="mobile-ready-img rad3 escortwp-profile-card-image" src="<?php echo get_first_image(get_the_ID(), '5'); ?>" srcset="<?php echo get_first_image(get_the_ID(), '5'); ?> 170w, <?php echo get_first_image(get_the_ID()); ?> 280w, <?php echo get_first_image(get_the_ID(), '4'); ?> 400w" data-responsive-img-url="<?php echo get_first_image(get_the_ID(), '5'); ?>" alt="<?php echo $imagealt; ?>" itemprop="image" />
					</span>
					<span class="escortwp-profile-card-overlay">
						<?php
						if(count($videos) > 0) {
							echo '<span class="label-video"><img src="'.get_template_directory_uri().'/i/video-th-icon.png" alt="" /></span>';
						}
						?>
						<span class="model-info escortwp-profile-card-badges">
							<?php echo get_escort_labels(get_the_ID()); ?>
							<div class="clear"></div>
						</span>
						<?php
						if ($premium == "1") {
							echo '<div class="premiumlabel rad3 escortwp-profile-card-ribbon"><span>'.__('VIP','escortwp').'</span></div>';
						}
						?>
					</span>
					<div class="desc escortwp-profile-card-footer">
						<div class="girl-name escortwp-card-name escortwp-profile-card-name" title="<?php echo $linktitle; ?>" itemprop="name"><?php the_title(); ?></div>
						<div class="clear"></div>
						<div class="girl-desc-location escortwp-card-location escortwp-profile-card-location" itemprop="homeLocation" title="<?php echo esc_attr($full_location_label); ?>"><span class="icon-location"></span><?php echo esc_html($card_location_label); ?></div>
					</div>
				</a>
				<div class="clear"></div>
			</div>
			<?php if(isset($agency_manage_escort_buttons)) echo $agency_manage_escort_buttons;; ?>
		</div> <!-- THUMB --> <div class="clear"></div>
    </div> <!-- GIRL -->
<?php
if($i % 5) { } else { echo '<div class="show-separator show5profiles clear"></div>'; }
if($i % 4) { } else { echo '<div class="show-separator show4profiles clear hide"></div>'; }
if($i % 3) { } else { echo '<div class="show-separator show3profiles clear hide"></div>'; }
if($i % 2) { } else { echo '<div class="show-separator show2profiles clear hide"></div>'; }
$i++;
unset($escort_label, $belongstoescortid, $class);
?>
