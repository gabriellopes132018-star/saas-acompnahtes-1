<?php
if (!defined('error_reporting')) { define('error_reporting', '0'); }
ini_set('display_errors', error_reporting);
if (error_reporting == '1') { error_reporting(E_ALL); }
if (isdolcetheme !== 1) { die(); }

if (!isset($err)) { $err = ''; }
if (!isset($ok)) { $ok = ''; }
if (!isset($member_edit_page)) { $member_edit_page = ''; }

$current_user = wp_get_current_user();
$is_member_edit = ($member_edit_page === 'yes');
$user = isset($_POST['user']) ? sanitize_user(wp_unslash($_POST['user']), true) : '';
$pass = isset($_POST['pass']) ? (string) wp_unslash($_POST['pass']) : '';
$membername = isset($_POST['membername']) ? sanitize_text_field(wp_unslash($_POST['membername'])) : '';
$memberemail = isset($_POST['memberemail']) ? sanitize_email(wp_unslash($_POST['memberemail'])) : '';
$emails = isset($_POST['emails']) ? trim((string) wp_unslash($_POST['emails'])) : '';
$tos_accept = isset($_POST['tos_accept']) ? (int) $_POST['tos_accept'] : 0;
$new_memberemail = '';

if (
	empty($_POST['escortwp_member_register_nonce']) ||
	!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['escortwp_member_register_nonce'])), 'escortwp_member_register')
) {
	$err .= 'Sua sessão expirou. Recarregue a página e tente novamente.<br />';
}

if (!$is_member_edit) {
	if (!$user) {
		$err .= 'Preencha seu nome de usuário.<br />';
	} elseif (strlen($user) < 4 || strlen($user) > 30) {
		$err .= 'O nome de usuário deve ter entre 4 e 30 caracteres.<br />';
	} elseif (!preg_match('/^[a-zA-Z0-9]+$/', $user)) {
		$err .= 'O nome de usuário deve conter apenas letras e números.<br />';
	} elseif (username_exists($user)) {
		$err .= 'Esse nome de usuário já está em uso. Escolha outro.<br />';
	}

	if ($pass === '') {
		$err .= 'Senha obrigatória.<br />';
	} elseif (strlen($pass) < 6 || strlen($pass) > 50) {
		$err .= 'A senha deve ter entre 6 e 50 caracteres.<br />';
	} elseif (false !== strpos(stripslashes($pass), '\\')) {
		$err .= 'A senha não pode conter o caractere "\\".<br />';
	}
}

if (!$membername) {
	$err .= 'Preencha seu nome.<br />';
}

if (!$memberemail) {
	$err .= 'Preencha seu e-mail.<br />';
} elseif (!is_email($memberemail)) {
	$err .= 'E-mail inválido.<br />';
} elseif (email_exists($memberemail) && $memberemail !== $current_user->user_email) {
	$err .= 'Esse e-mail já está sendo usado por outra conta.<br />';
} elseif ($is_member_edit && $memberemail !== $current_user->user_email) {
	$new_memberemail = $memberemail;
}

if ($emails !== '') {
	$err .= 'Não foi possível concluir o cadastro. Atualize a página e tente novamente.<br />';
}

if (get_option('recaptcha_sitekey') && get_option('recaptcha_secretkey') && !is_user_logged_in() && get_option('recaptcha4')) {
	$err .= verify_recaptcha();
}

$tos_page_data = get_post(get_option('tos_page_id'));
$data_protection_page_data = get_post(get_option('data_protection_page_id'));
if (($tos_page_data || $data_protection_page_data) && !is_user_logged_in() && $tos_accept !== 1) {
	$err .= 'Você precisa aceitar os termos para continuar.<br />';
}

if (!$err) {
	if ($is_member_edit) {
		$new_user_id = (int) $current_user->ID;
	} else {
		$new_user_id = wp_create_user($user, $pass, $memberemail);

		if (is_wp_error($new_user_id)) {
			foreach ($new_user_id->get_error_messages() as $error_message) {
				$err .= esc_html($error_message).'<br />';
			}
		}
	}

	if (!$err) {
		$updated_user = wp_update_user(
			array(
				'ID' => $new_user_id,
				'nickname' => $membername,
				'display_name' => $membername,
			)
		);

		if (is_wp_error($updated_user)) {
			foreach ($updated_user->get_error_messages() as $error_message) {
				$err .= esc_html($error_message).'<br />';
			}
		}
	}

	if (!$err && $new_memberemail) {
		$email_update = wp_update_user(
			array(
				'ID' => $new_user_id,
				'user_email' => $new_memberemail,
			)
		);

		if (is_wp_error($email_update)) {
			foreach ($email_update->get_error_messages() as $error_message) {
				$err .= esc_html($error_message).'<br />';
			}
		}
	}

	if (!$err && !$is_member_edit) {
		$emailhash = md5($new_user_id.$user.$memberemail);
		update_user_meta($new_user_id, 'emailhash', $emailhash);
		escortwp_set_user_type($new_user_id, 'member');

		$body = 'Olá '.$user.',<br /><br />
Antes de usar o site, você precisa validar seu endereço de e-mail.
<br /><br />
Se você não validar o e-mail nos próximos 3 dias, sua conta será excluída.
<br /><br />
Valide seu endereço de e-mail clicando no link abaixo:
<a href="'.get_bloginfo('url').'/?ekey='.$emailhash.'">'.get_bloginfo('url').'/?ekey='.$emailhash.'</a>';
		dolce_email('', '', $memberemail, 'Link de validação de e-mail '.get_option('email_sitename'), $body);

		wp_clear_auth_cookie();
		wp_set_auth_cookie($new_user_id, true, is_ssl());
	}

	if (!$err) {
		if ($is_member_edit) {
			$ok = 'ok';
		} else {
			$redirect_url = get_permalink(get_option('member_edit_personal_info_page_id'));
			if (!$redirect_url) {
				$redirect_url = home_url('/');
			}

			wp_safe_redirect(add_query_arg('member_registered', '1', $redirect_url));
			exit;
		}
	}
}
