<?php
if (!defined('error_reporting')) { define('error_reporting', '0'); }
ini_set('display_errors', error_reporting);
if (error_reporting == '1') { error_reporting(E_ALL); }
if (isdolcetheme !== 1) { die(); }

$footer_home = home_url('/');
$footer_contact = get_permalink(get_option('contact_page_id'));
$footer_register = get_permalink(get_option('main_reg_page_id'));
$footer_search = get_permalink(get_option('search_page_id'));
$footer_telegram = 'https://t.me/GarotasDF';
$footer_partnerships = 'https://t.me/GarotasDF?text=' . rawurlencode('Olá, quero falar sobre parcerias.');
$footer_email = get_option('admin_email') ? get_option('admin_email') : get_bloginfo('admin_email');
?>
	<div class="clear10"></div>

	<?php if (is_active_sidebar('widget-footer')) : ?>
	<div class="footer">
		<?php dynamic_sidebar('Footer'); ?>
		<div class="clear"></div>
	</div>
	<?php endif; ?>

	<footer class="escortwp-site-footer">
		<div class="escortwp-site-footer-grid">
			<div class="escortwp-site-footer-column">
				<h4><?php _e('Garotas DF', 'escortwp'); ?></h4>
				<p><?php _e('Portal focado em anúncios de acompanhantes com navegação clara, gestão de planos, contato direto e apresentação profissional em todas as telas.', 'escortwp'); ?></p>
			</div>
			<div class="escortwp-site-footer-column">
				<h4><?php _e('Navegação', 'escortwp'); ?></h4>
				<ul class="escortwp-site-footer-links">
					<li><a href="<?php echo esc_url($footer_home); ?>"><?php _e('Início', 'escortwp'); ?></a></li>
					<li><a href="<?php echo esc_url($footer_search ? $footer_search : $footer_home); ?>"><?php _e('Pesquisar', 'escortwp'); ?></a></li>
					<li><a href="<?php echo esc_url($footer_register ? $footer_register : $footer_home); ?>"><?php _e('Anuncie grátis', 'escortwp'); ?></a></li>
					<li><a href="<?php echo esc_url($footer_contact ? $footer_contact : $footer_home); ?>"><?php _e('Contato', 'escortwp'); ?></a></li>
				</ul>
			</div>
			<div class="escortwp-site-footer-column">
				<h4><?php _e('Atendimento', 'escortwp'); ?></h4>
				<ul class="escortwp-site-footer-links">
					<li><a href="mailto:<?php echo esc_attr(antispambot($footer_email)); ?>"><?php echo esc_html(antispambot($footer_email)); ?></a></li>
					<li><a href="<?php echo esc_url($footer_telegram); ?>" target="_blank" rel="nofollow noopener"><?php _e('Grupo Telegram', 'escortwp'); ?></a></li>
					<li><a href="<?php echo esc_url($footer_partnerships); ?>" target="_blank" rel="nofollow noopener"><?php _e('Parcerias', 'escortwp'); ?></a></li>
				</ul>
			</div>
		</div>
	</footer>

	<div class="underfooter">
		<div>
			&copy; <?php echo date('Y'); ?> <?php bloginfo('site_name'); ?>
		</div><div class="clear"></div>
	</div>
</div>
<?php wp_footer(); ?>
<?php if (function_exists('escortwp_should_render_age_gate') && escortwp_should_render_age_gate()) {
	include get_template_directory() . '/footer-tos-18years-agreement-overlay.php';
} ?>
</body>
</html>
