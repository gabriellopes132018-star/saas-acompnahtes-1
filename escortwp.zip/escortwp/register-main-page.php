<?php
/*
Template Name: Register Main Page
*/

if (is_user_logged_in()) {
	escortwp_safe_template_redirect(escortwp_get_current_user_account_url(), home_url('/'));
}

if (get_option('hide2') == '1' && get_option('hide9') == '1') {
	escortwp_safe_template_redirect(home_url('/'));
}

global $taxonomy_profile_name;

$show_monthly_plan = (string) payment_plans('premium', 'price') !== '';
$show_featured_boost = (string) payment_plans('featured_boost', 'price') !== '';
$escort_register_url = escortwp_get_escort_registration_url_with_intent('');
$escort_monthly_register_url = escortwp_get_escort_registration_url_with_intent('premium');
$escort_boost_register_url = escortwp_get_escort_registration_url_with_intent('featured_boost');
$member_register_url = get_option('member_register_page_id') ? get_permalink(get_option('member_register_page_id')) : home_url('/');

get_header();
?>

<div class="registerpage escortwp-register-choice-page escortwp-auth-shell">
	<div class="escortwp-auth-main escortwp-auth-main--plans">
		<div class="escortwp-auth-header">
			<div class="escortwp-auth-kicker"><?php _e('Entrada no portal', 'escortwp'); ?></div>
			<h3 class="pagetitle"><?php _e('Escolha como entrar no portal', 'escortwp'); ?></h3>
			<p class="escortwp-register-intro"><?php _e('Acompanhantes anunciam e gerenciam perfis. Clientes salvam favoritos, enviam mensagens e falam com os anúncios.', 'escortwp'); ?></p>
		</div>

		<div class="escortwp-register-plan-overview">
			<div class="escortwp-register-plan-card escortwp-register-plan-card-free">
				<div class="escortwp-register-plan-label"><?php _e('Plano inicial', 'escortwp'); ?></div>
				<h4><?php _e('Plano grátis', 'escortwp'); ?></h4>
				<p><?php _e('Comece sem cobrança inicial e escolha apenas o tipo de conta certo para o seu uso dentro da plataforma.', 'escortwp'); ?></p>
				<div class="escortwp-register-plan-price"><?php _e('Grátis', 'escortwp'); ?></div>
				<div class="escortwp-register-plan-actions escortwp-register-plan-actions-free">
					<?php if (get_option('hide2') != '1') { ?>
						<a class="escortwp-register-plan-button escortwp-register-plan-button-primary escortwp-register-plan-button-violet" href="<?php echo esc_url($escort_register_url); ?>"><?php printf(esc_html__('Sou %s', 'escortwp'), ucwords($taxonomy_profile_name)); ?></a>
					<?php } ?>
					<?php if (get_option('hide9') != '1') { ?>
						<a class="escortwp-register-plan-button escortwp-register-plan-button-secondary" href="<?php echo esc_url($member_register_url); ?>"><?php _e('Sou cliente', 'escortwp'); ?></a>
					<?php } ?>
				</div>
				<div class="escortwp-register-plan-support"><?php _e('A acompanhante publica anúncios e contrata planos. O cliente salva favoritos, envia mensagens e acompanha avaliações.', 'escortwp'); ?></div>
			</div>

			<?php if ($show_monthly_plan) { ?>
				<div class="escortwp-register-plan-card escortwp-register-plan-card-monthly">
					<div class="escortwp-register-plan-label"><?php _e('Plano mensal', 'escortwp'); ?></div>
					<h4><?php _e('Plano mensal de 30 dias', 'escortwp'); ?></h4>
					<p><?php _e('Cadastro + pagamento manual para manter o anúncio premium por 30 dias, com prioridade e mais visibilidade.', 'escortwp'); ?></p>
					<div class="escortwp-register-plan-price"><?php echo format_price('premium', 'small'); ?></div>
					<div class="escortwp-register-plan-actions">
						<a class="escortwp-register-plan-button escortwp-register-plan-button-violet" href="<?php echo esc_url($escort_monthly_register_url); ?>"><?php _e('Quero plano mensal', 'escortwp'); ?></a>
					</div>
					<div class="escortwp-register-plan-support"><?php _e('Você faz o cadastro da acompanhante e segue direto para gerar o PIX do plano mensal.', 'escortwp'); ?></div>
				</div>
			<?php } ?>

			<?php if ($show_featured_boost) { ?>
				<div class="escortwp-register-plan-card escortwp-register-plan-card-boost">
					<div class="escortwp-register-plan-label"><?php _e('Destaque', 'escortwp'); ?></div>
					<h4><?php _e('7 dias em destaque', 'escortwp'); ?></h4>
					<p><?php _e('Cadastro + pagamento único para colocar o anúncio em destaque por 7 dias, sem renovação automática.', 'escortwp'); ?></p>
					<div class="escortwp-register-plan-price"><?php echo format_price('featured_boost', 'small'); ?></div>
					<div class="escortwp-register-plan-actions">
						<a class="escortwp-register-plan-button escortwp-register-plan-button-violet" href="<?php echo esc_url($escort_boost_register_url); ?>"><?php _e('Quero destaque semanal', 'escortwp'); ?></a>
					</div>
					<div class="escortwp-register-plan-support"><?php _e('Você faz o cadastro da acompanhante e segue direto para gerar o PIX do destaque semanal.', 'escortwp'); ?></div>
				</div>
			<?php } ?>
		</div>

		<div class="escortwp-register-plan-note">
			<?php _e('Você pode começar grátis ou já seguir para o cadastro da acompanhante com o mensal ou o destaque semanal prontos para pagamento.', 'escortwp'); ?>
		</div>
	</div>
</div>

<div class="clear"></div>
<?php get_footer(); ?>
