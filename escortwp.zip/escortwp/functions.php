<?php
$error_reporting = 0;
// $error_reporting = 1; // uncomment this line to turn on error reporting
if($error_reporting == '1') {
	error_reporting( E_ALL );
}
define('error_reporting', $error_reporting);
ini_set( 'display_errors', $error_reporting);

function escortwp_strip_rest_leading_bom($output) {
	return preg_replace('/^\xEF\xBB\xBF+/', '', (string) $output);
}

if (!ob_get_level()) {
	ob_start('escortwp_strip_rest_leading_bom');
}

add_filter('locale', 'escortwp_force_pt_br_locale', 1);
add_filter('determine_locale', 'escortwp_force_pt_br_locale', 1);
function escortwp_force_pt_br_locale($locale) {
	return 'pt_BR';
}

function escortwp_force_hide_agency_accounts() {
	return '1';
}
add_filter('pre_option_hide3', 'escortwp_force_hide_agency_accounts');

function escortwp_register_account_roles() {
	add_role(
		'escortwp_member',
		'Cliente',
		array(
			'read' => true,
		)
	);

	add_role(
		'escortwp_escort',
		'Acompanhante',
		array(
			'read' => true,
			'upload_files' => true,
		)
	);
}
add_action('init', 'escortwp_register_account_roles', 5);

function escortwp_sync_legacy_account_roles_once() {
	if (get_option('escortwp_account_roles_synced_v1')) {
		return;
	}

	$user_ids = get_users(
		array(
			'fields' => 'ID',
			'number' => 500,
		)
	);

	foreach ($user_ids as $user_id) {
		$user_id = (int) $user_id;
		if ($user_id < 1) {
			continue;
		}

		$user_type = get_option('escortid'.$user_id);
		if ($user_type) {
			escortwp_set_user_type($user_id, $user_type);
		}
	}

	update_option('escortwp_account_roles_synced_v1', 1, false);
}
add_action('init', 'escortwp_sync_legacy_account_roles_once', 6);

function escortwp_get_user_type($user_id = 0) {
	global $taxonomy_profile_url, $taxonomy_agency_url;

	$user_id = (int) $user_id;
	if (!$user_id) {
		$user_id = get_current_user_id();
	}

	if (!$user_id) {
		return '';
	}

	$legacy_type = get_option('escortid'.$user_id);
	if (!empty($legacy_type)) {
		return $legacy_type;
	}

	$user = get_userdata($user_id);
	if (!$user || empty($user->roles)) {
		return '';
	}

	if (in_array('escortwp_escort', (array) $user->roles, true)) {
		return $taxonomy_profile_url;
	}

	if (in_array('escortwp_member', (array) $user->roles, true) || in_array('subscriber', (array) $user->roles, true)) {
		return 'member';
	}

	if ($taxonomy_agency_url && get_option('agencypostid'.$user_id)) {
		return $taxonomy_agency_url;
	}

	if ($taxonomy_profile_url && get_option('escortpostid'.$user_id)) {
		return $taxonomy_profile_url;
	}

	return '';
}

function escortwp_set_user_type($user_id, $user_type) {
	global $taxonomy_profile_url, $taxonomy_agency_url;

	$user_id = (int) $user_id;
	if (!$user_id || !$user_type) {
		return false;
	}

	update_option('escortid'.$user_id, $user_type);

	$user = get_userdata($user_id);
	if (!$user || user_can($user, 'manage_options')) {
		return true;
	}

	$wp_user = new WP_User($user_id);
	if ($user_type === 'member') {
		$wp_user->set_role('escortwp_member');
	} elseif ($user_type === $taxonomy_profile_url) {
		$wp_user->set_role('escortwp_escort');
	} elseif ($user_type === $taxonomy_agency_url) {
		$wp_user->set_role('subscriber');
	}

	return true;
}

function escortwp_current_user_has_type($expected_type, $user_id = 0) {
	if (!$expected_type) {
		return false;
	}

	return escortwp_get_user_type($user_id) === $expected_type;
}

function escortwp_get_login_url($redirect_to = '') {
	$redirect_to = $redirect_to ? $redirect_to : escortwp_get_current_request_url();
	return wp_login_url($redirect_to);
}

function escortwp_get_logout_url($redirect_to = '') {
	$redirect_to = $redirect_to ? $redirect_to : home_url('/');
	return wp_logout_url($redirect_to);
}

function escortwp_redirect_disabled_agency_routes() {
	global $taxonomy_agency_url;

	$blocked_page_ids = array_filter(array_map('intval', array(
		get_option('agency_reg_page_id'),
		get_option('nav_reviews_agencies_page_id'),
		get_option('agency_edit_personal_info_page_id'),
		get_option('agency_upload_logo_page_id'),
		get_option('agency_manage_escorts_page_id'),
	)));

	if(($blocked_page_ids && is_page($blocked_page_ids)) || ($taxonomy_agency_url && is_singular($taxonomy_agency_url))) {
		escortwp_safe_template_redirect(home_url('/'));
	}
}
add_action('template_redirect', 'escortwp_redirect_disabled_agency_routes', 1);

add_action('after_setup_theme', 'escortwp_theme_translate');
function escortwp_theme_translate(){
    load_theme_textdomain('escortwp', get_template_directory() . '/languages');
    escortwp_bootstrap_pt_br_theme_translations();
}

function escortwp_should_use_pt_br_translations() {
	static $should_translate = null;

	if ($should_translate !== null) {
		return $should_translate;
	}

	$locale = function_exists('determine_locale') ? determine_locale() : get_locale();
	$should_translate = is_string($locale) && stripos($locale, 'pt_BR') === 0;

	return $should_translate;
}

function escortwp_mojibake_score($text) {
	if (!is_string($text) || $text === '') {
		return 0;
	}

	return substr_count($text, "\xC3\x83")
		+ substr_count($text, "\xC3\x82")
		+ substr_count($text, "\xC3\xA2")
		+ substr_count($text, "\xEF\xBF\xBD");
}

function escortwp_is_likely_mojibake($text) {
	return escortwp_mojibake_score($text) > 0;
}

function escortwp_fix_mojibake_fragments($text) {
	if (!is_string($text) || $text === '') {
		return $text;
	}

	static $fragment_fixes = null;

	if ($fragment_fixes === null) {
		$fragment_fixes = array(
			'ÃƒÆ’Ã‚â‚¬' => 'À',
			'ÃƒÆ’Ã‚Â' => 'Á',
			'ÃƒÆ’Ã‚â€š' => 'Â',
			'ÃƒÆ’Ã‚Æ’' => 'Ã',
			'ÃƒÆ’Ã‚â€¡' => 'Ç',
			'ÃƒÆ’Ã‚â€°' => 'É',
			'ÃƒÆ’Ã‚Â¡' => 'á',
			'ÃƒÆ’Ã‚Â¢' => 'â',
			'ÃƒÆ’Ã‚Â£' => 'ã',
			'ÃƒÆ’Ã‚Â§' => 'ç',
			'ÃƒÆ’Ã‚Â©' => 'é',
			'ÃƒÆ’Ã‚Âª' => 'ê',
			'ÃƒÆ’Ã‚Â­' => 'í',
			'ÃƒÆ’Ã‚Â³' => 'ó',
			'ÃƒÆ’Ã‚Â´' => 'ô',
			'ÃƒÆ’Ã‚Âµ' => 'õ',
			'ÃƒÆ’Ã‚Âº' => 'ú',
			'ÃƒÆ’Ã¢â‚¬Â¡' => 'Ç',
			'ÃƒÆ’Ã¢â‚¬Â°' => 'É',
			'ÃƒÆ’Ã¢â‚¬Å“' => 'Ó',
			'Ãƒâ‚¬' => 'À',
			'ÃƒÂ' => 'Á',
			'Ãƒâ€š' => 'Â',
			'ÃƒÆ’' => 'Ã',
			'Ãƒâ€¡' => 'Ç',
			'Ãƒâ€°' => 'É',
			'ÃƒÂ¡' => 'á',
			'ÃƒÂ¢' => 'â',
			'ÃƒÂ£' => 'ã',
			'ÃƒÂ§' => 'ç',
			'ÃƒÂ©' => 'é',
			'ÃƒÂª' => 'ê',
			'ÃƒÂ­' => 'í',
			'ÃƒÂ³' => 'ó',
			'ÃƒÂ´' => 'ô',
			'ÃƒÂµ' => 'õ',
			'ÃƒÂº' => 'ú',
			'Ã‚Âª' => 'ª',
			'Ã‚Âº' => 'º',
			'Ã‚Â°' => '°',
			'Ã‚ ' => ' ',
			'Ã¢â‚¬Å“' => '“',
			'Ã¢â‚¬Â' => '”',
			'Ã¢â‚¬Ëœ' => '‘',
			'Ã¢â‚¬â„¢' => '’',
			'Ã¢â‚¬â€œ' => '–',
			'Ã¢â‚¬â€' => '—',
			'Ã¢â‚¬Â¦' => '…',
			'Fran?a' => 'França',
			'It?lia' => 'Itália',
			'Pa?ses Baixos' => 'Países Baixos',
			'?ltimas' => 'Últimas',
			'Coment?rios' => 'Comentários',
			'P?gina' => 'Página',
			'f?sico' => 'físico',
			'Capric?rnio' => 'Capricórnio',
			'er?tica' => 'erótica',
			'dan?a' => 'dança',
			'n?o' => 'não',
			'?ustria' => 'Áustria',
			'Inï¿½cio' => 'Início',
			'Goiï¿½s' => 'Goiás',
			'Regiï¿½es' => 'Regiões',
			'Busca rï¿½pida' => 'Busca rápida',
			'Busca avanï¿½ada' => 'Busca avançada',
			'Navegaï¿½ï¿½o principal' => 'Navegação principal',
			'ï¿½ltimas avaliaï¿½ï¿½es' => 'Últimas avaliações',
			'avaliaï¿½ï¿½o' => 'avaliação',
			'avaliaï¿½ï¿½es' => 'avaliações',
			'Cï¿½u Azul' => 'Céu Azul',
			'Sï¿½o Sebastiï¿½o' => 'São Sebastião',
			'Anï¿½polis' => 'Anápolis',
			'Guarï¿½' => 'Guará',
			'Brazlï¿½ndia' => 'Brazlândia',
			'Ceilï¿½ndia' => 'Ceilândia',
			'Paranoï¿½' => 'Paranoá',
			'Goiï¿½nia' => 'Goiânia',
			'Luziï¿½nia' => 'Luziânia',
			'Santo Antï¿½nio do Descoberto' => 'Santo Antônio do Descoberto',
			'Valparaï¿½so' => 'Valparaíso',
			'ÃƒÂguas' => 'Águas',
			'GoiÃƒÂ¡s' => 'Goiás',
			'BrazlÃƒÂ¢ndia' => 'Brazlândia',
			'CeilÃƒÂ¢ndia' => 'Ceilândia',
			'GuarÃƒÂ¡' => 'Guará',
			'ParanoÃƒÂ¡' => 'Paranoá',
			'SÃƒÂ£o SebastiÃƒÂ£o' => 'São Sebastião',
			'GoiÃƒÂ¢nia' => 'Goiânia',
			'LuziÃƒÂ¢nia' => 'Luziânia',
			'CÃƒÂ©u Azul' => 'Céu Azul',
			'AnÃƒÂ¡polis' => 'Anápolis',
			'Santo AntÃƒÂ´nio do Descoberto' => 'Santo Antônio do Descoberto',
			'ValparaÃƒÂ­so' => 'Valparaíso',
			'FranÃƒÂ§a' => 'França',
			'ItÃƒÂ¡lia' => 'Itália',
			'PaÃƒÂ­ses Baixos' => 'Países Baixos',
			'ComentÃƒÂ¡rios' => 'Comentários',
			'PÃƒÂ¡gina' => 'Página',
			'InformaÃƒÂ§ÃƒÂµes' => 'Informações',
			'PosiÃƒÂ§ÃƒÂ£o' => 'Posição',
			'SeÃƒÂ§ÃƒÂ£o' => 'Seção',
			'Fotografia, danÃƒÂ§a' => 'Fotografia, dança',
			'Busca rÃƒÂ¡pida' => 'Busca rápida',
			'Busca avanÃƒÂ§ada' => 'Busca avançada',
			'NavegaÃƒÂ§ÃƒÂ£o principal' => 'Navegação principal',
			'ÃƒÅ¡ltimas avaliaÃƒÂ§ÃƒÂµes' => 'Últimas avaliações',
			'avaliaÃƒÂ§ÃƒÂ£o' => 'avaliação',
			'avaliaÃƒÂ§ÃƒÂµes' => 'avaliações',
			'OlÃƒÂ¡, mundo!' => 'Olá, mundo!',
		'PreÃ§o' => 'Preço',
		'grÃ¡tis' => 'grátis',
		'anÃºncio' => 'anúncio',
		'anÃºncios' => 'anúncios',
		'an�ncio' => 'anúncio',
		'an�ncios' => 'anúncios',
		'usuÃ¡rio' => 'usuário',
		'usuÃ¡rios' => 'usuários',
		'usu�rio' => 'usuário',
		'usu�rios' => 'usuários',
		'confirmaÃ§Ã£o' => 'confirmação',
		'validaÃ§Ã£o' => 'validação',
		'confirma��o' => 'confirmação',
		'valida��o' => 'validação',
		'descriÃ§Ã£o' => 'descrição',
		'ediÃ§Ã£o' => 'edição',
		'aprovaÃ§Ã£o' => 'aprovação',
			'cobranÃ§a' => 'cobrança',
			'recorrÃªncia' => 'recorrência',
			'prÃ³ximos' => 'próximos',
			'apÃ³s' => 'após',
			'nÃ£o' => 'não',
			'vÃ¡lido' => 'válido',
		'atÃ©' => 'até',
		'inÃ­cio' => 'início',
		'D�lar da Nova Zel�ndia' => 'Dolar da Nova Zelandia',
		'Lamber �nus' => 'Lamber anus',
		'Rimming Anal (Lamber �nus)' => 'Rimming anal (lamber anus)',
		'prÃªmio' => 'prêmio',
			'impulsionamento aguardando confirmaÃ§Ã£o' => 'impulsionamento aguardando confirmação',
		);
	}

	$fixed = $text;
	for ($i = 0; $i < 3; $i++) {
		$updated = strtr($fixed, $fragment_fixes);
		if ($updated === $fixed) {
			break;
		}
		$fixed = $updated;
	}

	return $fixed;
}

function escortwp_fix_mojibake_text($text) {
	if (!is_string($text) || $text === '') {
		return $text;
	}

	$fixed = escortwp_fix_mojibake_fragments($text);
	if (!escortwp_is_likely_mojibake($fixed)) {
		return $fixed;
	}

	for ($i = 0; $i < 3; $i++) {
		$score_before = escortwp_mojibake_score($fixed);
		if ($score_before === 0) {
			break;
		}

		$reencoded = @iconv('UTF-8', 'Windows-1252//IGNORE', $fixed);
		if (!is_string($reencoded) || $reencoded === '' || $reencoded === $fixed) {
			break;
		}

		$score_after = escortwp_mojibake_score($reencoded);
		if ($score_after > $score_before) {
			break;
		}

		$fixed = $reencoded;
	}

	$manual_fixes = array(
		"N\xC3\xA3ome de Acompanhante" => 'Nome da acompanhante',
		'NÂ£ome de Acompanhante' => 'Nome da acompanhante',
		'Fran?a' => "Fran\xC3\xA7a",
		'It?lia' => "It\xC3\xA1lia",
		'Pa?ses Baixos' => "Pa\xC3\xADses Baixos",
		'?ltimas' => "\xC3\x9Altimas",
		'Coment?rios recentes' => "Coment\xC3\xA1rios recentes",
		'P?gina' => "P\xC3\xA1gina",
		'Porte f?sico' => "Porte f\xC3\xADsico",
		'Capric?rnio' => "Capric\xC3\xB3rnio",
		'Massagem er?tica' => "Massagem er\xC3\xB3tica",
		'Fotografia, dan?a' => "Fotografia, dan\xC3\xA7a",
		'prefiro n?o informar' => "prefiro n\xC3\xA3o informar",
		'mar?o' => "mar\xC3\xA7o",
		'?ustria' => "\xC3\x81ustria",
	);

	$fixed = isset($manual_fixes[$fixed]) ? $manual_fixes[$fixed] : $fixed;

	return escortwp_fix_mojibake_fragments($fixed);
}

function escortwp_fix_mojibake_deep($value) {
	if (is_array($value)) {
		$fixed = array();
		foreach ($value as $key => $item) {
			$fixed_key = is_string($key) ? escortwp_fix_mojibake_text($key) : $key;
			$fixed[$fixed_key] = escortwp_fix_mojibake_deep($item);
		}

		return $fixed;
	}

	return is_string($value) ? escortwp_fix_mojibake_text($value) : $value;
}

function escortwp_is_brazil_only_location_mode_enabled() {
	return true;
}

function escortwp_get_brazil_only_location_version() {
	return '20260403-brasil-df-goias';
}

function escortwp_get_brazil_location_config() {
	static $config = null;

	if ($config !== null) {
		return $config;
	}

	$config = array(
		'country' => 'Brasil',
		'states' => array(
			'Distrito Federal' => array(
				'Ãguas Claras',
				'Arniqueiras',
				'Asa Norte',
				'Asa Sul',
				'Bandeirante',
				'BrazlÃ¢ndia',
				'CeilÃ¢ndia',
				'Gama',
				'GuarÃ¡',
				'ParanoÃ¡',
				'Planaltina',
				'Recanto das Emas',
				'Riacho Fundo',
				'Samambaia',
				'Santa Maria',
				'SÃ£o SebastiÃ£o',
				'Sobradinho',
				'Sudoeste',
				'Taguatinga',
				'Vicente Pires',
			),
			'GoiÃ¡s' => array(
				'Ãguas Lindas',
				'AnÃ¡polis',
				'CÃ©u Azul',
				'Formosa',
				'GoiÃ¢nia',
				'Jardim IngÃ¡',
				'LuziÃ¢nia',
				'Novo Gama',
				'Ocidental',
				'Planaltina',
				'Santo AntÃ´nio do Descoberto',
				'ValparaÃ­so',
			),
		),
	);

	$config = escortwp_fix_mojibake_deep($config);

	return $config;
}

function escortwp_is_syncing_brazil_locations() {
	return !empty($GLOBALS['escortwp_syncing_brazil_locations']);
}

function escortwp_set_syncing_brazil_locations($syncing) {
	$GLOBALS['escortwp_syncing_brazil_locations'] = $syncing ? 1 : 0;
}

function escortwp_normalize_location_label($label) {
	$label = escortwp_fix_mojibake_text((string) $label);
	$label = remove_accents($label);
	$label = strtolower($label);
	$label = preg_replace('/[^a-z0-9]+/u', ' ', $label);
	$label = trim(preg_replace('/\s+/u', ' ', $label));

	return $label;
}

function escortwp_get_location_term_by_name_and_parent($name, $taxonomy, $parent = 0) {
	$terms = get_terms(array(
		'taxonomy' => $taxonomy,
		'hide_empty' => false,
		'parent' => (int) $parent,
		'name' => $name,
		'number' => 1,
	));

	if (is_wp_error($terms) || empty($terms)) {
		return false;
	}

	return $terms[0];
}

function escortwp_ensure_location_term($name, $taxonomy, $parent = 0, $slug = '') {
	$existing = escortwp_get_location_term_by_name_and_parent($name, $taxonomy, $parent);
	if ($existing) {
		return $existing;
	}

	$args = array(
		'parent' => (int) $parent,
		'description' => 'escortwp_brazil_only_location',
	);
	if ($slug) {
		$args['slug'] = $slug;
	}

	$inserted = wp_insert_term($name, $taxonomy, $args);
	if (is_wp_error($inserted)) {
		if ($inserted->get_error_code() === 'term_exists') {
			$term_id = (int) $inserted->get_error_data();
			$term = get_term($term_id, $taxonomy);
			if ($term && !is_wp_error($term)) {
				return $term;
			}
		}

		return escortwp_get_location_term_by_name_and_parent($name, $taxonomy, $parent);
	}

	return get_term((int) $inserted['term_id'], $taxonomy);
}

function escortwp_get_brazil_location_term_map($force_refresh = false) {
	static $term_map = null;

	if ($term_map !== null && !$force_refresh) {
		return $term_map;
	}

	global $taxonomy_location_url;

	$term_map = array(
		'country' => null,
		'states' => array(),
		'states_by_id' => array(),
		'cities' => array(),
		'cities_by_id' => array(),
		'ordered_cities' => array(),
		'allowed_ids' => array(),
	);

	if (!$taxonomy_location_url || !taxonomy_exists($taxonomy_location_url)) {
		return $term_map;
	}

	$config = escortwp_get_brazil_location_config();
	escortwp_set_syncing_brazil_locations(true);

	$country = escortwp_ensure_location_term($config['country'], $taxonomy_location_url, 0, 'brasil');
	if ($country && !is_wp_error($country)) {
		$term_map['country'] = $country;
		$term_map['allowed_ids'][] = (int) $country->term_id;

		foreach ($config['states'] as $state_name => $cities) {
			$state_term = escortwp_ensure_location_term($state_name, $taxonomy_location_url, $country->term_id, sanitize_title($state_name));
			if (!$state_term || is_wp_error($state_term)) {
				continue;
			}

			$term_map['states'][$state_name] = $state_term;
			$term_map['states_by_id'][(int) $state_term->term_id] = $state_term;
			$term_map['cities'][$state_name] = array();
			$term_map['allowed_ids'][] = (int) $state_term->term_id;

			foreach ($cities as $city_name) {
				$city_term = escortwp_ensure_location_term($city_name, $taxonomy_location_url, $state_term->term_id);
				if (!$city_term || is_wp_error($city_term)) {
					continue;
				}

				$term_map['cities'][$state_name][$city_name] = $city_term;
				$term_map['cities_by_id'][(int) $city_term->term_id] = array(
					'country' => $country,
					'state' => $state_term,
					'city' => $city_term,
				);
				$term_map['ordered_cities'][] = array(
					'country' => $country,
					'state' => $state_term,
					'city' => $city_term,
				);
				$term_map['allowed_ids'][] = (int) $city_term->term_id;
			}
		}
	}

	$term_map['allowed_ids'] = array_values(array_unique(array_map('intval', $term_map['allowed_ids'])));
	escortwp_set_syncing_brazil_locations(false);

	return $term_map;
}

function escortwp_get_brazil_menu_locations() {
	$term_map = escortwp_get_brazil_location_term_map();

	return !empty($term_map['states']) ? array_values($term_map['states']) : array();
}

function escortwp_get_brazil_location_sections() {
	$term_map = escortwp_get_brazil_location_term_map();
	$config = escortwp_get_brazil_location_config();
	$sections = array();

	foreach ($config['states'] as $state_name => $city_names) {
		if (empty($term_map['states'][$state_name])) {
			continue;
		}

		$section = array(
			'state' => $term_map['states'][$state_name],
			'cities' => array(),
		);

		foreach ($city_names as $city_name) {
			if (!empty($term_map['cities'][$state_name][$city_name])) {
				$section['cities'][] = $term_map['cities'][$state_name][$city_name];
			}
		}

		$sections[] = $section;
	}

	return $sections;
}

function escortwp_is_allowed_location_term_id($term_id) {
	$term_id = (int) $term_id;
	if ($term_id < 1) {
		return false;
	}

	$term_map = escortwp_get_brazil_location_term_map();

	return in_array($term_id, $term_map['allowed_ids'], true);
}

function escortwp_get_brazil_location_assignment_by_city_id($city_id) {
	$city_id = (int) $city_id;
	$term_map = escortwp_get_brazil_location_term_map();

	return isset($term_map['cities_by_id'][$city_id]) ? $term_map['cities_by_id'][$city_id] : false;
}

function escortwp_get_default_brazil_location_assignment($seed = 0, $preferred_state_id = 0) {
	$preferred_state_id = (int) $preferred_state_id;
	$term_map = escortwp_get_brazil_location_term_map();

	if ($preferred_state_id > 0 && !empty($term_map['states_by_id'][$preferred_state_id])) {
		$state_name = $term_map['states_by_id'][$preferred_state_id]->name;
		$state_cities = array_values($term_map['cities'][$state_name]);
		if (!empty($state_cities)) {
			$index = abs((int) $seed) % count($state_cities);
			$city_term = $state_cities[$index];

			return array(
				'country' => $term_map['country'],
				'state' => $term_map['states_by_id'][$preferred_state_id],
				'city' => $city_term,
			);
		}
	}

	if (empty($term_map['ordered_cities'])) {
		return false;
	}

	$index = abs((int) $seed) % count($term_map['ordered_cities']);

	return $term_map['ordered_cities'][$index];
}

function escortwp_resolve_brazil_location_assignment($seed = 0, $country_id = 0, $state_id = 0, $city_id = 0) {
	$city_assignment = escortwp_get_brazil_location_assignment_by_city_id($city_id);
	if ($city_assignment) {
		return $city_assignment;
	}

	if (escortwp_is_allowed_location_term_id($state_id)) {
		return escortwp_get_default_brazil_location_assignment($seed, $state_id);
	}

	return escortwp_get_default_brazil_location_assignment($seed, $country_id);
}

function escortwp_filter_location_terms_to_brazil($terms, $taxonomies, $args, $term_query) {
	global $taxonomy_location_url;

	if (!escortwp_is_brazil_only_location_mode_enabled() || escortwp_is_syncing_brazil_locations()) {
		return $terms;
	}

	if (empty($terms) || is_wp_error($terms) || !$taxonomy_location_url) {
		return $terms;
	}

	$requested_taxonomies = is_array($taxonomies) ? $taxonomies : array($taxonomies);
	if (!in_array($taxonomy_location_url, $requested_taxonomies, true)) {
		return $terms;
	}

	$allowed_ids = escortwp_get_brazil_location_term_map()['allowed_ids'];
	if (empty($allowed_ids)) {
		return $terms;
	}

	$filtered_terms = array();
	foreach ($terms as $key => $term) {
		$term_id = 0;
		if ($term instanceof WP_Term || (is_object($term) && isset($term->term_id))) {
			$term_id = (int) $term->term_id;
		} elseif (is_numeric($term)) {
			$term_id = (int) $term;
		} elseif (is_array($term) && isset($term['term_id'])) {
			$term_id = (int) $term['term_id'];
		}

		if ($term_id > 0 && in_array($term_id, $allowed_ids, true)) {
			$filtered_terms[$key] = $term;
		}
	}

	return $filtered_terms;
}
add_filter('get_terms', 'escortwp_filter_location_terms_to_brazil', 10, 4);

function escortwp_apply_brazil_location_settings() {
	if (!escortwp_is_brazil_only_location_mode_enabled()) {
		return;
	}

	$location_dropdown = get_option('locationdropdown');
	if ($location_dropdown !== '1') {
		update_option('locationdropdown', '1');
	}

	$fields = get_option('regfieldsescort');
	if (!is_array($fields)) {
		return;
	}

	$changed = false;
	foreach (array('country', 'state', 'city') as $field_name) {
		if (!isset($fields[$field_name]) || !is_array($fields[$field_name])) {
			continue;
		}

		if ((string) $fields[$field_name][1] !== '3') {
			$fields[$field_name][1] = '3';
			$changed = true;
		}
		if ((string) $fields[$field_name][2] !== '3') {
			$fields[$field_name][2] = '3';
			$changed = true;
		}
		if ((string) $fields[$field_name][3] !== '3') {
			$fields[$field_name][3] = '3';
			$changed = true;
		}
	}

	if ($changed) {
		update_option('regfieldsescort', $fields);
	}
}

function escortwp_migrate_existing_content_to_brazil_locations() {
	global $taxonomy_profile_url, $taxonomy_agency_url, $taxonomy_location_url;

	if (!$taxonomy_location_url) {
		return;
	}

	$post_types = array_filter(array(
		$taxonomy_profile_url,
		$taxonomy_agency_url,
		'tour',
		'ad',
		'b'.$taxonomy_profile_url,
	));

	foreach ($post_types as $post_type) {
		$post_ids = get_posts(array(
			'post_type' => $post_type,
			'post_status' => array('publish', 'private', 'draft', 'pending', 'future'),
			'posts_per_page' => -1,
			'fields' => 'ids',
			'no_found_rows' => true,
			'suppress_filters' => true,
		));

		if (empty($post_ids)) {
			continue;
		}

		foreach ($post_ids as $post_id) {
			$current_country = (int) get_post_meta($post_id, 'country', true);
			$current_state = (int) get_post_meta($post_id, 'state', true);
			$current_city = (int) get_post_meta($post_id, 'city', true);
			$assignment = escortwp_resolve_brazil_location_assignment($post_id, $current_country, $current_state, $current_city);

			if (!$assignment || empty($assignment['city']) || empty($assignment['state']) || empty($assignment['country'])) {
				continue;
			}

			$needs_meta_update = (
				$current_country !== (int) $assignment['country']->term_id ||
				$current_state !== (int) $assignment['state']->term_id ||
				$current_city !== (int) $assignment['city']->term_id
			);

			$current_terms = wp_get_post_terms($post_id, $taxonomy_location_url, array('fields' => 'ids'));
			$has_correct_city_term = !is_wp_error($current_terms) && in_array((int) $assignment['city']->term_id, array_map('intval', (array) $current_terms), true);

			if ($needs_meta_update || !$has_correct_city_term) {
				update_post_meta($post_id, 'country', (int) $assignment['country']->term_id);
				update_post_meta($post_id, 'state', (int) $assignment['state']->term_id);
				update_post_meta($post_id, 'city', (int) $assignment['city']->term_id);
				wp_set_post_terms($post_id, array((int) $assignment['city']->term_id), $taxonomy_location_url, false);
			}
		}
	}
}

function escortwp_bootstrap_brazil_only_locations() {
	if (!escortwp_is_brazil_only_location_mode_enabled()) {
		return;
	}

	escortwp_get_brazil_location_term_map(true);
	escortwp_apply_brazil_location_settings();

	$current_version = get_option('escortwp_brazil_only_location_version');
	$target_version = escortwp_get_brazil_only_location_version();
	if ($current_version !== $target_version) {
		escortwp_migrate_existing_content_to_brazil_locations();
		update_option('escortwp_brazil_only_location_version', $target_version);
		flush_rewrite_rules(false);
	}
}
add_action('init', 'escortwp_bootstrap_brazil_only_locations', 30);

function escortwp_get_pt_br_translation_overrides() {
	static $overrides = null;

	if ($overrides !== null) {
		return $overrides;
	}

	$overrides = array(
		'% Comments' => '% comentários',
		'%1$s profiles have been created for each %2$s profile' => 'Foram criados perfis %1$s para cada perfil %2$s',
		'%s country list' => 'Lista de países de %s',
		'%s has new review' => '%s tem uma nova avaliação',
		'%s reviews' => 'Avaliações de %s',
		'%s rating' => 'Avaliação de %s',
		'%s on tour' => '%s em turnê',
		'1 Comment' => '1 comentário',
		'Add featured status for' => 'Adicionar status de destaque para',
		'Add review section' => 'Adicionar seção de avaliações',
		'Add some text here' => 'Adicione algum texto aqui',
		'add reviews to %s profiles' => 'adicionar avaliações aos perfis de %s',
		'Admin Links' => 'Links administrativos',
		'After you buy a featured position you will be placed in the header slider for maximum visibility.' => 'Depois de comprar uma posição de destaque, você aparecerá no slider do cabeçalho para ter visibilidade máxima.',
		'All newly created %s' => 'Todos os %s recém-criados',
		'All verified %s' => 'Todos os %s verificados',
		'Are you sure you want to delete this review?' => 'Tem certeza de que deseja excluir esta avaliação?',
		'call me' => 'Ligar',
		'Client review' => 'Avaliação do cliente',
		'Contact info' => 'Informações de contato',
		'Contact info:' => 'Informações de contato:',
		'Country/City pages only show featured profiles from that location' => 'As páginas de país/cidade mostram apenas perfis em destaque daquele local.',
		'Delete Featured' => 'Remover destaque',
		'Disabling member registration will also disable the reviews' => 'Desativar o cadastro de membros também desativará as avaliações.',
		'Edit review' => 'Editar avaliação',
		'Extend featured' => 'Estender destaque',
		'featured' => 'DESTAQUE',
		'Featured expiration:' => 'Expiração do destaque:',
		'Featured position' => 'Posição de destaque',
		'Featured position for a profile' => 'Posição de destaque para um perfil',
		'Featured status is active <b>forever</b>' => 'O status de destaque está ativo <b>para sempre</b>',
		'Filter search' => 'Filtrar busca',
		'How many characters to show from each review?' => 'Quantos caracteres mostrar de cada avaliação?',
		'If you choose "yes" you will be notified by email each time someone<br />adds a new review. The email will have a link to the review' => 'Se você escolher "sim", receberá um e-mail sempre que alguém adicionar uma nova avaliação.<br />O e-mail incluirá um link para a avaliação.',
		'Latest %s Reviews' => 'Últimas avaliações de %s',
		'Manually activate reviews for %s?' => 'Ativar manualmente as avaliações de %s?',
		'My Reviews' => 'Minhas avaliações',
		'No reviews yet' => 'Ainda não há avaliações',
		'Number of reviews to show' => 'Número de avaliações para exibir',
		'On search pages' => 'Nas páginas de busca',
		'On the reviews pages' => 'Nas páginas de avaliações',
		'Only show verified %s?' => 'Mostrar apenas %s verificados?',
		'Photo Gallery' => 'Galeria de fotos',
		'Photography, Dancing' => 'Fotografia, dança',
		'PHOTO GALLERY' => 'GALERIA DE FOTOS',
		'Please write an email or a phone number for the search' => 'Informe um e-mail ou um número de telefone para a busca.',
		'Quick Search' => 'Busca rápida',
		'Read/Edit the review here' => 'Leia/edite a avaliação aqui',
		'Register Member - See Reviews' => 'Cadastro de membro - ver avaliações',
		'Review details' => 'Detalhes da avaliação',
		'review for' => 'avaliação para',
		'Review for %s' => 'Avaliação para %s',
		'Review the %s' => 'Avaliar %s',
		'reviews' => 'avaliações',
		'Reviews - Agencies (nav link)' => 'Avaliações - Agências (link de navegação)',
		'Reviews - Escorts (nav link)' => 'Avaliações - Acompanhantes (link de navegação)',
		'Reviews content box' => 'Caixa de conteúdo de avaliações',
		'Search %s' => 'Pesquisar %s',
		'Search for %s' => 'Buscar %s',
		'Search for this Client' => 'Buscar este cliente',
		'Search page' => 'Página de busca',
		'See all reviews' => 'Ver todas as avaliações',
		'see the review' => 'ver a avaliaÃƒÂ§ÃƒÂ£o',
		'Show "Quick %s Search" widget in right sidebar?' => 'Mostrar o widget "Busca rÃƒÂ¡pida de %s" na barra lateral direita?',
		'Someone added a new review to your profile' => 'AlguÃƒÂ©m adicionou uma nova avaliaÃƒÂ§ÃƒÂ£o ao seu perfil.',
		'Someone wrote a %s review on' => 'AlguÃƒÂ©m escreveu uma avaliaÃƒÂ§ÃƒÂ£o de %s em',
		'Someone wrote a %s review on.' => 'AlguÃƒÂ©m escreveu uma avaliaÃƒÂ§ÃƒÂ£o de %s.',
		'Someone wrote an %s review on.' => 'AlguÃƒÂ©m escreveu uma avaliaÃƒÂ§ÃƒÂ£o de %s.',
		'The featured status for one of your %s has expired and has been removed from their profile.' => 'O destaque de um dos seus %s expirou e foi removido do perfil.',
		'The featured status for one of your %s will expire very soon.' => 'O destaque de um dos seus %s vai expirar em breve.',
		'The featured status for this profile is active until' => 'O destaque deste perfil fica ativo atÃƒÂ©',
		'The FEATURED status has been remove from your profile.' => 'O status de destaque foi removido do seu perfil.',
		'Tap or click on a photo to enlarge' => 'Toque ou clique em uma foto para ampliar',
		'This profile has no public images yet.' => 'Este perfil ainda nÃƒÂ£o tem imagens pÃƒÂºblicas.',
		'Manage gallery' => 'Gerenciar galeria',
		'Upload new photos or videos without interrupting the public presentation of the profile.' => 'Envie novas fotos ou vÃƒÂ­deos sem interromper a apresentaÃƒÂ§ÃƒÂ£o pÃƒÂºblica do perfil.',
		'Tap here to upload your images' => 'Toque aqui para enviar suas imagens',
		'Drag your images here to upload them' => 'Arraste suas imagens aqui para enviÃƒÂ¡-las',
		'or <u>Select from a folder</u>' => 'ou <u>selecione em uma pasta</u>',
		'You can upload a maximum of %s images' => 'VocÃƒÂª pode enviar no mÃƒÂ¡ximo %s imagens',
		'Tap here to upload your videos' => 'Toque aqui para enviar seus vÃƒÂ­deos',
		'Drag your videos here to upload them' => 'Arraste seus vÃƒÂ­deos aqui para enviÃƒÂ¡-los',
		'You can upload a maximum of %s videos' => 'VocÃƒÂª pode enviar no mÃƒÂ¡ximo %s vÃƒÂ­deos',
		'to be able to post a review' => 'para poder publicar uma avaliaÃƒÂ§ÃƒÂ£o',
		'to be able to view this review' => 'para poder ver esta avaliaÃƒÂ§ÃƒÂ£o',
		'Use in search page' => 'Usar na pÃƒÂ¡gina de busca',
		'verified' => 'verificado',
		'Verified status' => 'Status verificado',
		'Verified status image upload' => 'Envio da imagem de verificaÃƒÂ§ÃƒÂ£o',
		'When admin manually adds Premium, Featured or Verified to a profile' => 'Quando o administrador adiciona manualmente Premium, Destaque ou Verificado a um perfil',
		'You are now a featured %s.' => 'Agora vocÃƒÂª ÃƒÂ© um %s em destaque.',
		'You can purchase a featured status again at any time by visiting the profile page' => 'VocÃƒÂª pode comprar o destaque novamente a qualquer momento na pÃƒÂ¡gina do perfil.',
		'You didn\'t write a review' => 'VocÃƒÂª nÃƒÂ£o escreveu uma avaliaÃƒÂ§ÃƒÂ£o.',
		'You featured status is active until' => 'Seu status de destaque fica ativo atÃƒÂ©',
		'You have a new review on' => 'VocÃƒÂª tem uma nova avaliaÃƒÂ§ÃƒÂ£o em',
		'You need to be a VIP member to be able to post a review' => 'VocÃƒÂª precisa ser membro VIP para publicar uma avaliaÃƒÂ§ÃƒÂ£o.',
		'Your featured status has expired and it has been removed from your profile.' => 'Seu destaque expirou e foi removido do seu perfil.',
		'Your featured status will be active for' => 'Seu destaque ficarÃƒÂ¡ ativo por',
		'Your featured status will expire very soon.' => 'Seu destaque vai expirar em breve.',
		'Your profile has been upgraded to a FEATURED profile.' => 'Seu perfil foi atualizado para um perfil em destaque.',
		'Your review needs to be approved by an admin before being published.' => 'Sua avaliaÃƒÂ§ÃƒÂ£o precisa ser aprovada por um administrador antes de ser publicada.',
		'Your review will be read by our staff and published soon.' => 'Sua avaliaÃƒÂ§ÃƒÂ£o serÃƒÂ¡ analisada pela nossa equipe e publicada em breve.',
		'Your Reviews' => 'Suas avaliaÃƒÂ§ÃƒÂµes',
		'Your user type is not allowed to post a review here' => 'Seu tipo de usuÃƒÂ¡rio nÃƒÂ£o pode publicar avaliaÃƒÂ§ÃƒÂµes aqui.',
		'Services:' => 'ServiÃƒÂ§os:',
		'Rates:' => 'Valores:',
		'Extra Services' => 'ServiÃƒÂ§os extras',
		'About me' => 'Sobre mim',
		'Languages spoken' => 'Idiomas falados',
		'Contact us' => 'Fale conosco',
		'Send message' => 'Enviar mensagem',
		'EscortWP.com' => 'EscortWP.com',
		'Quick %s Search' => 'Busca rÃƒÂ¡pida de %s',
	);

	$overrides = array_merge(
		$overrides,
		array(
			'After you buy a featured position you will be placed in the header slider for maximum visibility.' => 'Depois de comprar uma posicao de destaque, voce aparecera no slider do cabecalho para ter visibilidade maxima.',
			'If you choose "yes" you will be notified by email each time someone<br />adds a new review. The email will have a link to the review' => 'Se voce escolher "sim", recebera um e-mail sempre que alguem adicionar uma nova avaliacao.<br />O e-mail incluira um link para a avaliacao.',
			'Latest %s Reviews' => 'Ultimas avaliacoes de %s',
			'My Reviews' => 'Minhas avaliacoes',
			'No reviews yet' => 'Ainda nao ha avaliacoes',
			'Payment Settings' => 'Configuracoes de pagamento',
			'Save settings' => 'Salvar configuracoes',
			'Please write an email or a phone number for the search' => 'Informe um e-mail ou um numero de telefone para a busca.',
			'Quick Search' => 'Busca rapida',
			'Search page' => 'Pagina de busca',
			'The payments section works with the help of the free plugin WooCommerce.' => 'A area de pagamentos depende do plugin gratuito WooCommerce.',
			'Go to your Plugins section and install WooCommerce first' => 'Instale e ative o WooCommerce antes de configurar checkout, planos e gateways.',
			'Click here to install WooCommerce automatically' => 'Instalar WooCommerce automaticamente',
			'The price is for a period of' => 'O preco vale pelo periodo de',
			'Forever' => 'Para sempre',
			'If you would like to set up this payment as a recurring payment then you will first need to install the %s plugin.' => 'Este tema agora usa plano mensal manual. A anunciante pode pagar novamente quando o periodo terminar, sem precisar de assinatura recorrente.',
			'After this you will be able to set up the payment as recurring by editing the payment in the WordPress section.' => 'Depois que o periodo acabar, a anunciante pode renovar manualmente o plano no painel do anuncio.',
			'Delete profile' => 'Excluir anuncio',
			'Set profile to private' => 'Ocultar anuncio',
			'This is a recurring payment. Edit the duration from the WordPress section.' => 'Este produto esta configurado como plano mensal manual. Ajuste preco e duracao no WordPress / WooCommerce.',
			'recurring payment' => 'cobranca recorrente',
			'monthly manual renewal' => 'renovacao mensal manual',
			'Seu anÃƒÂºncio ficou em destaque atÃƒÂ© %s.' => 'Seu anuncio ficou em destaque ate %s.',
			'You are now a premium %s.' => 'Seu %s agora esta com o plano mensal ativo.',
			'Edit payment plan in WordPress' => 'Editar produto de pagamento no WordPress',
			'Show coupon field in checkout page' => 'Mostrar campo de cupom no checkout',
			'Show address fields in checkout page' => 'Mostrar campos de endereco no checkout',
			'Some payment processors require an address' => 'Alguns gateways exigem endereco no checkout',
			'Este impulsionamento ÃƒÂ© sempre avulso e dura exatamente 1 semana.' => 'Este impulsionamento e sempre avulso e dura exatamente 1 semana.',
			'Show "Quick %s Search" widget in right sidebar?' => 'Mostrar o widget "Busca rapida de %s" na barra lateral direita?',
			'The featured status for this profile is active until' => 'O destaque deste perfil fica ativo ate',
			'This profile has no public images yet.' => 'Este perfil ainda nao tem imagens publicas.',
			'Upload new photos or videos without interrupting the public presentation of the profile.' => 'Envie novas fotos ou videos sem interromper a apresentacao publica do perfil.',
			'Drag your images here to upload them' => 'Arraste suas imagens aqui para envia-las',
			'You can upload a maximum of %s images' => 'Voce pode enviar no maximo %s imagens',
			'Tap here to upload your videos' => 'Toque aqui para enviar seus videos',
			'Drag your videos here to upload them' => 'Arraste seus videos aqui para envia-los',
			'You can upload a maximum of %s videos' => 'Voce pode enviar no maximo %s videos',
			'Verified status image upload' => 'Envio da imagem de verificacao',
			'You are now a featured %s.' => 'Agora voce e um %s em destaque.',
			'You can purchase a featured status again at any time by visiting the profile page' => 'Voce pode comprar o destaque novamente a qualquer momento na pagina do perfil.',
			'You didn\'t write a review' => 'Voce nao escreveu uma avaliacao.',
			'You featured status is active until' => 'Seu status de destaque fica ativo ate',
			'You have a new review on' => 'Voce tem uma nova avaliacao em',
			'You need to be a VIP member to be able to post a review' => 'Voce precisa ser membro VIP para publicar uma avaliacao.',
			'Your featured status will be active for' => 'Seu destaque ficara ativo por',
		)
	);

	$overrides = escortwp_fix_mojibake_deep($overrides);

	return $overrides;
}

function escortwp_get_pt_br_global_overrides() {
	static $overrides = null;

	if ($overrides !== null) {
		return $overrides;
	}

	$overrides = array(
		'A WordPress Commenter' => 'Um comentarista do WordPress',
		'Acompanhante Name' => 'Nome da acompanhante',
		'NÃƒÆ’Ã‚Â£ome de Acompanhante' => 'Nome da acompanhante',
		'Age' => 'Idade',
		'Archives' => 'Arquivos',
		'Availability' => 'Disponibilidade',
		'Average' => 'Na mÃƒÂ©dia',
		'Bald' => 'Careca',
		'Bellow average' => 'Abaixo da mÃƒÂ©dia',
		'Bicycle, Dance' => 'Bicicleta, danÃƒÂ§a',
		'Black' => 'Negra',
		'Blonde' => 'Loiro',
		'Brown' => 'Castanho',
		'Brunette' => 'Morena',
		'Build' => 'Porte fÃƒÂ­sico',
		'Bump into the profile page' => 'Ir para a pÃƒÂ¡gina do perfil',
		'Bust size' => 'Tamanho do busto',
		'Capricorn' => 'CapricÃƒÂ³rnio',
		'Categories' => 'Categorias',
		'Caucasian' => 'Caucasiana',
		'Chestnut' => 'Castanho claro',
		'City' => 'Cidade',
		'College' => 'Ensino superior',
		'Construir' => 'Porte fÃƒÂ­sico',
		'Conversational' => 'IntermediÃƒÂ¡rio',
		'Country' => 'PaÃƒÂ­s',
		'Couples' => 'Casais',
		'Curvy' => 'CurvilÃƒÂ­nea',
		'Dark-blonde' => 'Loiro escuro',
		'Domination' => 'DominaÃƒÂ§ÃƒÂ£o',
		'Education' => 'Escolaridade',
		'English' => 'InglÃƒÂªs',
		'Erotic massage' => 'Massagem erÃƒÂ³tica',
		'Ethnicity' => 'Etnia',
		'Extraball (Having sex multiple times)' => 'Extraball (fazer sexo vÃƒÂ¡rias vezes)',
		'Fat' => 'Gordinha',
		'Female' => 'Feminino',
		'Fluent' => 'Fluente',
		'Foot fetish' => 'Fetiche por pÃƒÂ©s',
		'GFE (Girlfriend experience)' => 'GFE (experiÃƒÂªncia de namorada)',
		'Golden shower' => 'Chuva dourada',
		'Hair Color' => 'Cor do cabelo',
		'Hair color' => 'Cor do cabelo',
		'Hair length' => 'Comprimento do cabelo',
		'Hello world!' => 'OlÃƒÂ¡, mundo!',
		'Height' => 'Altura',
		'Hobbies' => 'Passatempos',
		'Incall' => 'Atende no local',
		'Indian' => 'Indiana',
		'Italian' => 'Italiano',
		'Languages spoken' => 'Idiomas falados',
		'Large(C)' => 'Grande (C)',
		'Latin' => 'Latina',
		'Looks' => 'AparÃƒÂªncia',
		'LT (Long Time; Usually overnight)' => 'LT (longa duraÃƒÂ§ÃƒÂ£o; geralmente durante a noite)',
		'Medium(B)' => 'MÃƒÂ©dio (B)',
		'MiddleEast' => 'Oriente MÃƒÂ©dio',
		'Minimal' => 'BÃƒÂ¡sico',
		'Native American' => 'Nativo-americana',
		'Next page' => 'PrÃƒÂ³xima pÃƒÂ¡gina',
		'Nothing Special' => 'Comum',
		'Occupation' => 'OcupaÃƒÂ§ÃƒÂ£o',
		'O-Level (Oral sex)' => 'NÃƒÂ­vel O (sexo oral)',
		'Online' => 'Online',
		'Other' => 'Outra',
		'Outcall' => 'Atende fora',
		'Owo (Oral without condom)' => 'OWO (oral sem camisinha)',
		'OWO (Oral without condom)' => 'OWO (oral sem camisinha)',
		'Passion' => 'PaixÃƒÂ£o',
		'Photo Gallery' => 'Galeria de fotos',
		'Photography, Dancing' => 'Fotografia, danÃƒÆ’Ã‚Â§a',
		'Previous page' => 'PÃƒÂ¡gina anterior',
		'Quick Search' => 'Busca rÃƒÂ¡pida',
		'Recent Comments' => 'ComentÃƒÂ¡rios recentes',
		'Recent Posts' => 'Posts recentes',
		'Regular' => 'Regular',
		'rather not say' => 'prefiro nÃƒÂ£o informar',
		'Red' => 'Ruivo',
		'Search' => 'Pesquisar',
		'Select' => 'Selecione',
		'Select City' => 'Selecione a cidade',
		'Select country' => 'Selecione o paÃƒÂ­s',
		'Select State' => 'Selecione o estado',
		'Services' => 'ServiÃƒÂ§os',
		'Sex toys' => 'Brinquedos sexuais',
		'Sexual orientation' => 'OrientaÃƒÂ§ÃƒÂ£o sexual',
		'Shoulder' => 'Na altura dos ombros',
		'Ombro' => 'Na altura dos ombros',
		'Silver' => 'Prateado',
		'Skinny' => 'Muito magra',
		'Magrelo' => 'Muito magra',
		'Slim' => 'Esbelta',
		'Small(A)' => 'Pequeno (A)',
		'Smoker' => 'Fumante',
		'Sports' => 'Esportes',
		'State' => 'Estado',
		'Your Email' => 'Seu e-mail',
		'Send verification email' => 'Enviar e-mail de validaÃ§Ã£o',
		'Must be between 6 and 30 characters' => 'Deve ter entre 6 e 30 caracteres',
		'Deve ter entre 6 e 30 caracteres' => 'Deve ter entre 6 e 30 caracteres',
		'Hair Color' => 'Cor do cabelo',
		'Hair length' => 'Comprimento do cabelo',
		'Bust size' => 'Tamanho do busto',
		'mandatory only for females' => 'obrigatÃ³rio apenas para perfis femininos',
		'Height' => 'Altura',
		'Weight' => 'Peso',
		'Build' => 'Porte fÃ­sico',
		'Looks' => 'AparÃªncia',
		'Availability' => 'Disponibilidade',
		'Smoker' => 'Fumante',
		'About you' => 'Sobre vocÃª',
		'About the %s' => 'Sobre %s',
		'html code will be removed' => 'cÃ³digo HTML serÃ¡ removido',
		'Education' => 'EducaÃ§Ã£o',
		'Sports' => 'Esportes',
		'Hobbies' => 'Hobbies',
		'Zodiac sign' => 'Signo',
		'Sexual orientation' => 'OrientaÃ§Ã£o sexual',
		'Occupation' => 'OcupaÃ§Ã£o',
		'Languages spoken' => 'Idiomas falados',
		'Select level' => 'Selecione o nÃ­vel',
		'Rates' => 'Valores',
		'at least one rate' => 'preencha pelo menos um valor',
		'Currency' => 'Moeda',
		'A conta de acompanhante ÃƒÂ© voltada para publicaÃƒÂ§ÃƒÂ£o e gestÃƒÂ£o do anÃƒÂºncio. A conta de cliente ÃƒÂ© para navegaÃƒÂ§ÃƒÂ£o, favoritos e contato com os perfis.' => 'A conta de acompanhante Ã© voltada para publicaÃ§Ã£o e gestÃ£o do anÃºncio. A conta de cliente Ã© para navegaÃ§Ã£o, favoritos e contato com os perfis.',
		'Comece sem cobranÃƒÂ§a inicial e escolha apenas o tipo de conta certo para o seu uso dentro da plataforma.' => 'Comece sem cobranÃ§a inicial e escolha apenas o tipo de conta certo para o seu uso dentro da plataforma.',
		'Conta de acompanhante: cria perfil, publica anÃƒÂºncio, gerencia fotos e contrata planos. Conta de cliente: acessa favoritos, mensagens e avaliaÃƒÂ§ÃƒÂµes.' => 'Conta de acompanhante: cria perfil, publica anÃºncio, gerencia fotos e contrata planos. Conta de cliente: acessa favoritos, mensagens e avaliaÃ§Ãµes.',
		'Pagamento mensal manual para manter o anÃƒÂºncio premium, com prioridade e benefÃƒÂ­cios ativos durante 30 dias.' => 'Pagamento mensal manual para manter o anÃºncio premium, com prioridade e benefÃ­cios ativos durante 30 dias.',
		'Criar conta grÃƒÂ¡tis primeiro' => 'Criar conta grÃ¡tis primeiro',
		'A contrataÃƒÂ§ÃƒÂ£o acontece no painel do anÃƒÂºncio. Quando o perÃƒÂ­odo acabar, basta pagar novamente para renovar por mais 30 dias.' => 'A contrataÃ§Ã£o acontece no painel do anÃºncio. Quando o perÃ­odo acabar, basta pagar novamente para renovar por mais 30 dias.',
		'Pagamento ÃƒÂºnico para colocar o anÃƒÂºncio em destaque por 7 dias. NÃƒÂ£o vira mensalidade e nÃƒÂ£o renova sozinho.' => 'Pagamento único para colocar o anúncio em destaque por 7 dias. Não vira mensalidade e não renova sozinho.',
		'O pagamento e a ativaÃƒÂ§ÃƒÂ£o do destaque acontecem no painel do anÃƒÂºncio, depois do cadastro grÃƒÂ¡tis.' => 'O pagamento e a ativação do destaque acontecem no painel do anúncio, depois do cadastro grátis.',
		'Nesta etapa vocÃƒÂª escolhe apenas o tipo de conta gratuita. O plano mensal e o impulsionamento semanal aparecem depois, dentro do painel da acompanhante.' => 'Nesta etapa você escolhe apenas o tipo de conta gratuita. O plano mensal e o impulsionamento semanal aparecem depois, dentro do painel da acompanhante.',
		'Esta conta ÃƒÂ© feita para navegar, favoritar perfis, enviar mensagens e acompanhar seus contatos no portal com clareza e seguranÃƒÂ§a.' => 'Esta conta é feita para navegar, favoritar perfis, enviar mensagens e acompanhar seus contatos no portal com clareza e segurança.',
		'SeÃƒÂ§ÃƒÂµes do cadastro' => 'Seções do cadastro',
		'Dados bÃƒÂ¡sicos' => 'Dados básicos',
		'Esta conta ÃƒÂ© voltada para anÃƒÂºncio profissional: criar perfil, publicar conteÃƒÂºdo, gerenciar fotos e contratar planos dentro do painel.' => 'Esta conta é voltada para anúncio profissional: criar perfil, publicar conteúdo, gerenciar fotos e contratar planos dentro do painel.',
		'Crie seu acesso com e-mail e senha vÃƒÂ¡lidos.' => 'Crie seu acesso com e-mail e senha válidos.',
		'Preencha os dados pÃƒÂºblicos do anÃƒÂºncio com clareza.' => 'Preencha os dados públicos do anúncio com clareza.',
		'LocalizaÃƒÂ§ÃƒÂ£o' => 'Localização',
		'ServiÃƒÂ§os' => 'Serviços',
		'Preencha os dados de acesso com atenÃƒÂ§ÃƒÂ£o. Eles controlam login, recuperaÃƒÂ§ÃƒÂ£o de senha e a entrada no painel da acompanhante.' => 'Preencha os dados de acesso com atenção. Eles controlam login, recuperação de senha e a entrada no painel da acompanhante.',
		'RegiÃƒÂ£o principal do anÃƒÂºncio' => 'Região principal do anúncio',
		'Selecione a regiÃƒÂ£o certa para que o perfil apareÃƒÂ§a nas buscas corretas e mantenha a navegaÃƒÂ§ÃƒÂ£o do site organizada.' => 'Selecione a região certa para que o perfil apareça nas buscas corretas e mantenha a navegação do site organizada.',
		'ApresentaÃƒÂ§ÃƒÂ£o pÃƒÂºblica da acompanhante' => 'Apresentação pública da acompanhante',
		'Preencha os dados do perfil com clareza para gerar mais confianÃƒÂ§a e facilitar o entendimento de quem visita o anÃƒÂºncio.' => 'Preencha os dados do perfil com clareza para gerar mais confiança e facilitar o entendimento de quem visita o anúncio.',
		'Informe apenas os valores que realmente serÃƒÂ£o praticados. Isso ajuda o painel a montar um anÃƒÂºncio mais profissional e transparente.' => 'Informe apenas os valores que realmente serão praticados. Isso ajuda o painel a montar um anúncio mais profissional e transparente.',
		'ServiÃƒÂ§os e extras do anÃƒÂºncio' => 'Serviços e extras do anúncio',
		'Selecione sÃƒÂ³ o que faz sentido para o perfil. Um painel mais limpo deixa o anÃƒÂºncio mais forte e mais fÃƒÂ¡cil de entender.' => 'Selecione só o que faz sentido para o perfil. Um painel mais limpo deixa o anúncio mais forte e mais fácil de entender.',
		'Portal focado em anÃƒÂºncios de acompanhantes com navegaÃƒÂ§ÃƒÂ£o clara, gestÃƒÂ£o de planos, contato direto e apresentaÃƒÂ§ÃƒÂ£o profissional em todas as telas.' => 'Portal focado em anúncios de acompanhantes com navegação clara, gestão de planos, contato direto e apresentação profissional em todas as telas.',
		'NavegaÃƒÂ§ÃƒÂ£o' => 'Navegação',
		'InÃƒÂ­cio' => 'Início',
		'Anuncie grÃƒÂ¡tis' => 'Anuncie grátis',
		'Striptease/Lapdance' => 'Striptease/lap dance',
		'Swallow' => 'Engolir',
		'Threesome' => 'Sexo a três',
		'Uncategorized' => 'Sem categoria',
		'Very Large(D)' => 'Muito grande (D)',
		'Very Long' => 'Muito longo',
		'Very small' => 'Muito pequeno',
		'Website' => 'Site',
		'Weight' => 'Peso',
		'White' => 'Branca',
		'Zodiac sign' => 'Signo do zodíaco',
		'%s Name' => 'Nome de %s',
		'%s name' => 'nome de %s',
		'69 (69 sex position)' => '69 (posição sexual 69)',
		'A-Level (Anal sex)' => 'Nível A (sexo anal)',
		'Anal Rimming (Licking anus)' => 'Rimming anal (lamber anus)',
		'Auburn' => 'Acobreado',
		'Bald' => 'Careca',
		'Black' => 'Preto',
		'Bore' => 'Tedioso',
		'COB (Come on body)' => 'COB (gozar no corpo)',
		'COF (Come on face)' => 'COF (gozar no rosto)',
		'CIM (Come in mouth)' => 'CIM (gozar na boca)',
		'DFK (Deep french kissing)' => 'DFK (beijo francês profundo)',
		'English' => 'Inglês',
		'French' => 'Francês',
		'Gay' => 'Gay',
		'German' => 'Alemão',
		'Grey' => 'Cinza',
		'Male' => 'Masculino',
		'Message' => 'Mensagem',
		'Name' => 'Nome',
		'No' => 'Não',
		'Spanish' => 'Espanhol',
		'Transsexual' => 'Transexual',
		'Very small' => 'Muito pequeno',
		'Yes' => 'Sim',
	);

	$overrides = escortwp_fix_mojibake_deep($overrides);

	return $overrides;
}

function escortwp_get_pt_br_translation_map() {
	static $map = null;

	if ($map !== null) {
		return $map;
	}

	$map = array();

	if (!escortwp_should_use_pt_br_translations()) {
		return $map;
	}

	$map_path = get_template_directory() . '/languages/pt_BR-theme-map.json';
	if (!file_exists($map_path)) {
		return $map;
	}

	$map_contents = file_get_contents($map_path);
	if ($map_contents) {
		$map_contents = preg_replace('/^\xEF\xBB\xBF/', '', $map_contents);
	}

	$raw_map = json_decode($map_contents, true);
	if (!is_array($raw_map)) {
		return $map;
	}

	foreach ($raw_map as $entry) {
		if (!is_array($entry) || !isset($entry['key']) || !array_key_exists('value', $entry)) {
			continue;
		}

		$map[escortwp_fix_mojibake_text((string) $entry['key'])] = escortwp_fix_mojibake_text((string) $entry['value']);
	}

	return $map;
}

function escortwp_translate_runtime_label($text) {
	if (!escortwp_should_use_pt_br_translations()) {
		return $text;
	}

	$text = (string) $text;
	if ($text === '') {
		return $text;
	}

	static $runtime_labels = null;
	if ($runtime_labels === null) {
		$runtime_labels = array(
			'France' => 'FranÃƒÂ§a',
			'Germany' => 'Alemanha',
			'Italy' => 'ItÃƒÂ¡lia',
			'Netherlands' => 'PaÃƒÂ­ses Baixos',
			'Spain' => 'Espanha',
			'Austria' => 'ÃƒÂustria',
			'United States' => 'Estados Unidos',
			'Marseille' => 'Marselha',
			'Munich' => 'Munique',
			'Hamburg' => 'Hamburgo',
			'Turin' => 'Turim',
			'Cologne' => 'ColÃƒÂ´nia',
			'Rome' => 'Roma',
			'Florence' => 'FlorenÃƒÂ§a',
			'Venice' => 'Veneza',
			'Naples' => 'NÃƒÂ¡poles',
			'Vienna' => 'Viena',
			'Brussels' => 'Bruxelas',
			'Lisbon' => 'Lisboa',
			'Seville' => 'Sevilha',
			'Valencia' => 'ValÃƒÂªncia',
		);

		$runtime_labels = escortwp_fix_mojibake_deep($runtime_labels);
	}

	return isset($runtime_labels[$text]) ? $runtime_labels[$text] : $text;
}

function escortwp_translate_general_text($text) {
	if (!escortwp_should_use_pt_br_translations()) {
		return $text;
	}

	$text = (string) $text;
	if ($text === '') {
		return $text;
	}

	$text = escortwp_fix_mojibake_text($text);

	$overrides = escortwp_get_pt_br_global_overrides();
	if (isset($overrides[$text])) {
		return escortwp_fix_mojibake_text($overrides[$text]);
	}

	return escortwp_fix_mojibake_text(escortwp_translate_runtime_label($text));
}

function escortwp_translate_textdomain_string($text) {
	$text = escortwp_fix_mojibake_text((string) $text);

	$overrides = escortwp_get_pt_br_translation_overrides();
	if (isset($overrides[$text])) {
		return escortwp_fix_mojibake_text($overrides[$text]);
	}

	$map = escortwp_get_pt_br_translation_map();
	if (isset($map[$text]) && $map[$text] !== '') {
		return escortwp_fix_mojibake_text(escortwp_translate_general_text($map[$text]));
	}

	return escortwp_fix_mojibake_text(escortwp_translate_general_text($text));
}

function escortwp_pt_br_gettext_filter($translated, $text, $domain) {
	if (!escortwp_should_use_pt_br_translations()) {
		return escortwp_fix_mojibake_text($translated);
	}

	if ($domain === 'escortwp') {
		return escortwp_translate_textdomain_string($text);
	}

	$translated = escortwp_fix_mojibake_text(escortwp_translate_general_text($translated));
	if ($translated !== '') {
		return $translated;
	}

	return escortwp_fix_mojibake_text(escortwp_translate_general_text($text));
}

function escortwp_pt_br_gettext_with_context_filter($translated, $text, $context, $domain) {
	if (!escortwp_should_use_pt_br_translations()) {
		return escortwp_fix_mojibake_text($translated);
	}

	if (stripos((string) $context, 'slug') !== false || stripos((string) $context, 'url') !== false) {
		return escortwp_fix_mojibake_text($translated);
	}

	if ($domain === 'escortwp') {
		return escortwp_translate_textdomain_string($text);
	}

	return escortwp_fix_mojibake_text(escortwp_translate_general_text($translated));
}

function escortwp_pt_br_list_cats_filter($cat_name) {
	return escortwp_translate_general_text($cat_name);
}

function escortwp_safe_utf8_preg_replace($pattern, $replacement, $subject) {
	$result = preg_replace($pattern, $replacement, $subject);
	return is_string($result) ? $result : $subject;
}

function escortwp_translate_frontend_output($html) {
	if (!escortwp_should_use_pt_br_translations() || !is_string($html) || $html === '' || stripos($html, '<html') === false) {
		return $html;
	}

	$original_html = $html;

	$replacements = array(
		'This site is built with the premium WordPress theme from EscortWP.com' => 'Este site foi criado com o tema premium WordPress da EscortWP.com',
		'Hello world!' => 'OlÃ¡, mundo!',
		'A WordPress Commenter</a> on <a' => 'Um comentarista do WordPress</a> em <a',
		'A WordPress Commenter' => 'Um comentarista do WordPress',
		'Recent Posts' => 'Posts recentes',
		'Recent Comments' => 'ComentÃ¡rios recentes',
		'Archives' => 'Arquivos',
		'Categories' => 'Categorias',
		'Uncategorized' => 'Sem categoria',
		'Website' => 'Site',
		'April 2026' => 'abril de 2026',
		'NÃ£ome de Acompanhante' => 'Nome da acompanhante',
		'Photography, Dancing' => 'Fotografia, danÃ§a',
		'Magrelo' => 'Muito magra',
		'Ombro' => 'Na altura dos ombros',
		'>France<' => '>FranÃ§a<',
		'>Germany<' => '>Alemanha<',
		'>Italy<' => '>ItÃ¡lia<',
		'>Netherlands<' => '>PaÃ­ses Baixos<',
		'>Spain<' => '>Espanha<',
		'>Marseille<' => '>Marselha<',
		'>Hamburg<' => '>Hamburgo<',
		'>Munich<' => '>Munique<',
		'>Turin<' => '>Turim<',
		', France<' => ', FranÃ§a<',
		', Germany<' => ', Alemanha<',
		', Italy<' => ', ItÃ¡lia<',
		', Netherlands<' => ', PaÃ­ses Baixos<',
		', Spain<' => ', Espanha<',
		'title="France"' => 'title="FranÃ§a"',
		'title="Germany"' => 'title="Alemanha"',
		'title="Italy"' => 'title="ItÃ¡lia"',
		'title="Netherlands"' => 'title="PaÃ­ses Baixos"',
		'title="Spain"' => 'title="Espanha"',
		'title="Marseille"' => 'title="Marselha"',
		'title="Hamburg"' => 'title="Hamburgo"',
		'title="Munich"' => 'title="Munique"',
		'title="Turin"' => 'title="Turim"',
	);

	$replacements = escortwp_fix_mojibake_deep($replacements);
	$html = strtr($html, $replacements);
	$html = escortwp_safe_utf8_preg_replace('/\bJanuary\s+(\d{4})\b/u', 'janeiro de $1', $html);
	$html = escortwp_safe_utf8_preg_replace('/\bFebruary\s+(\d{4})\b/u', 'fevereiro de $1', $html);
	$html = escortwp_safe_utf8_preg_replace('/\bMarch\s+(\d{4})\b/u', "mar\xC3\xA7o de \$1", $html);
	$html = escortwp_safe_utf8_preg_replace('/\bApril\s+(\d{4})\b/u', 'abril de $1', $html);
	$html = escortwp_safe_utf8_preg_replace('/\bMay\s+(\d{4})\b/u', 'maio de $1', $html);
	$html = escortwp_safe_utf8_preg_replace('/\bJune\s+(\d{4})\b/u', 'junho de $1', $html);
	$html = escortwp_safe_utf8_preg_replace('/\bJuly\s+(\d{4})\b/u', 'julho de $1', $html);
	$html = escortwp_safe_utf8_preg_replace('/\bAugust\s+(\d{4})\b/u', 'agosto de $1', $html);
	$html = escortwp_safe_utf8_preg_replace('/\bSeptember\s+(\d{4})\b/u', 'setembro de $1', $html);
	$html = escortwp_safe_utf8_preg_replace('/\bOctober\s+(\d{4})\b/u', 'outubro de $1', $html);
	$html = escortwp_safe_utf8_preg_replace('/\bNovember\s+(\d{4})\b/u', 'novembro de $1', $html);
	$html = escortwp_safe_utf8_preg_replace('/\bDecember\s+(\d{4})\b/u', 'dezembro de $1', $html);
	$html = escortwp_fix_mojibake_fragments($html);

	return is_string($html) ? $html : $original_html;
}

function escortwp_start_pt_br_output_buffer() {
	if (!escortwp_should_use_pt_br_translations() || is_admin() || wp_doing_ajax() || is_feed() || is_robots() || is_trackback()) {
		return;
	}

	if (defined('REST_REQUEST') && REST_REQUEST) {
		return;
	}

	ob_start('escortwp_translate_frontend_output');
}

function escortwp_bootstrap_pt_br_theme_translations() {
	if (!escortwp_should_use_pt_br_translations()) {
		return;
	}

	add_filter('gettext', 'escortwp_pt_br_gettext_filter', 20, 3);
	add_filter('gettext_with_context', 'escortwp_pt_br_gettext_with_context_filter', 20, 4);
add_filter('list_cats', 'escortwp_pt_br_list_cats_filter', 20, 1);
add_action('template_redirect', 'escortwp_start_pt_br_output_buffer', 0);
}

add_theme_support('woocommerce');
add_theme_support('wc-product-gallery-slider');
add_theme_support('wc-product-gallery-zoom');
add_theme_support('wc-product-gallery-lightbox');


if(isset($_GET['install']) && $_GET['install'] == "yes") { // only hide the header bar if we are on the installation page
	function dolce_temp_remove_admin_login_header() { remove_action('wp_head', '_admin_bar_bump_cb'); }
	add_action('get_header', 'dolce_temp_remove_admin_login_header');
}

// Add new constant that returns true if WooCommerce is active
define('is_woocommerce_active', class_exists('WooCommerce'));

if(!current_user_can('level_10')) add_filter('show_admin_bar', '__return_false'); // disable admin bar
remove_action('wp_head', 'wp_generator'); // remove the generator tag
remove_action('wp_head', 'print_emoji_detection_script', 7); // disable emojies
remove_action('wp_print_styles', 'print_emoji_styles'); // disable emojies
remove_action('wp_head', 'rsd_link'); // removes EditURI/RSD (Really Simple Discovery) link.
remove_action('wp_head', 'wlwmanifest_link'); // removes wlwmanifest (Windows Live Writer) link.
remove_action('wp_head', 'rest_output_link_wp_head', 10);

// setting a value to istheme to make sure all the included files can't be loaded by themselves in the browser
define('isdolcetheme', 1);
$theme_version = "499";

// escortwp.zip for Hudson Firmino de AraÃƒÂºjo GonÃƒÂ§alves
$license_key = '2e2210wwtl739gkmual7pc4o27oo5n0mx5pjfmcc8r971814hi16xnm8055yj4ttewy66wr28qc6rlyb';

include(get_template_directory().'/functions-settings.php');
include(get_template_directory().'/functions-payments.php');
if (file_exists(get_template_directory().'/inc/woocommerce-checkout-brazil.php')) {
	include_once get_template_directory().'/inc/woocommerce-checkout-brazil.php';
}
include(get_template_directory().'/functions-mobile-detect.php');
if (file_exists(get_template_directory().'/inc/payments/mercadopago/config.php')) {
	include_once get_template_directory().'/inc/payments/mercadopago/config.php';
}
if (file_exists(get_template_directory().'/inc/payments/mercadopago/repository.php')) {
	include_once get_template_directory().'/inc/payments/mercadopago/repository.php';
}
if (file_exists(get_template_directory().'/inc/payments/mercadopago/logger.php')) {
	include_once get_template_directory().'/inc/payments/mercadopago/logger.php';
}
if (file_exists(get_template_directory().'/inc/payments/mercadopago/service.php')) {
	include_once get_template_directory().'/inc/payments/mercadopago/service.php';
}
if (file_exists(get_template_directory().'/inc/payments/mercadopago/rest.php')) {
	include_once get_template_directory().'/inc/payments/mercadopago/rest.php';
}
if (file_exists(get_template_directory().'/inc/payments/mercadopago/frontend.php')) {
	include_once get_template_directory().'/inc/payments/mercadopago/frontend.php';
}
if (file_exists(get_template_directory().'/inc/video-verification/repository.php')) {
	include_once get_template_directory().'/inc/video-verification/repository.php';
}
if (file_exists(get_template_directory().'/inc/video-verification/service.php')) {
	include_once get_template_directory().'/inc/video-verification/service.php';
}
if (file_exists(get_template_directory().'/inc/video-verification/rest.php')) {
	include_once get_template_directory().'/inc/video-verification/rest.php';
}
if (file_exists(get_template_directory().'/inc/video-verification/frontend.php')) {
	include_once get_template_directory().'/inc/video-verification/frontend.php';
}
if (file_exists(get_template_directory().'/inc/video-verification/admin.php')) {
	include_once get_template_directory().'/inc/video-verification/admin.php';
}

$detect = new Mobile_Detect;
if($detect->isMobile() && !$detect->isTablet()) {
	$isphone = true;
}

// add the necesarry javascript and css files to the header of the theme
function add_js_css() {
	global $taxonomy_profile_url, $taxonomy_agency_url, $isphone, $taxonomy_location_url;
	wp_dequeue_style( 'wp-block-library' );
	wp_enqueue_style('open-sans-font', '//fonts.googleapis.com/css?family=Open+Sans:400,600,700&display=swap');
	wp_enqueue_style('reference-display-font', 'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@600;700&display=swap', array(), null);
	wp_enqueue_style('main-css-file', get_bloginfo('stylesheet_url'), array());

	if(isset($_GET['install']) && $_GET['install'] == "yes") {
		wp_enqueue_style('install-theme', get_bloginfo('template_url').'/css/style-install-theme.css', array());
	}
	wp_enqueue_style('icon-font', get_bloginfo('template_url').'/css/icon-font/style.css', array());
	wp_enqueue_style('responsive', get_bloginfo('template_url').'/css/responsive.css', array());
	if($isphone) {
		wp_enqueue_style('responsive', get_bloginfo('template_url').'/css/responsive-isphone.css');
	}
	wp_enqueue_style('select2', get_bloginfo('template_url').'/css/select2.min.css');
	wp_enqueue_style('reference-refresh', get_bloginfo('template_url').'/css/reference-refresh.css', array(), $GLOBALS['theme_version']);
	wp_enqueue_script('reference-header', get_bloginfo('template_url').'/js/reference-header.js', array(), $GLOBALS['theme_version'], true);
	wp_enqueue_script('escortwp-age-gate', get_bloginfo('template_url').'/js/escortwp-age-gate.js', array(), $GLOBALS['theme_version'], true);
	wp_enqueue_script('select2', get_bloginfo('template_url').'/js/select2.min.js', array('jquery'));
	wp_enqueue_script('dolcejs', get_bloginfo('template_url').'/js/dolceescort.js', array('jquery'));
	wp_enqueue_script('js-cookie', get_bloginfo('template_url').'/js/js.cookie.js');
	wp_enqueue_script('jquery-uploadifive', get_bloginfo('template_url').'/js/jquery.uploadifive.min.js', array('jquery'));
	wp_enqueue_script('jquery-mobile-custom', get_bloginfo('template_url').'/js/jquery.mobile.custom.min.js', array('jquery'));

	wp_enqueue_script('checkator', get_bloginfo('template_url').'/js/checkator.jquery.js', array('jquery'));

	if (get_post_type() == $taxonomy_profile_url || get_post_type() == "b".$taxonomy_profile_url || get_post_type() == "ad" || get_the_ID() == get_option('escort_verified_status_page_id')) {
		wp_enqueue_script('jquery-fancybox', get_bloginfo('template_url').'/js/jquery.fancybox.min.js', array('jquery'));
		wp_enqueue_style('jquery-fancybox', get_bloginfo('template_url').'/css/jquery.fancybox.min.css');
	}
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) { 
        wp_enqueue_script( 'comment-reply');
    }
	if (get_option("showheaderslider") == 1) {
		if (get_option("showheadersliderall") == 1) {
			$showslider = 1;
		} else {
			if(is_front_page() && get_option("showheadersliderfront") == 1) { $showslider = 1; }
			if(is_tax($taxonomy_location_url) && get_option("showheaderslideresccat") == 1) { $showslider = 1; }
			if(get_post_type() == $taxonomy_profile_url && get_option("showheadersliderescprof") == 1) { $showslider = 1; }
			if(get_post_type() == $taxonomy_agency_url && get_option("showheaderslideragprof") == 1) { $showslider = 1; }
			if(is_page(get_option('search_page_id')) && get_option("showheaderslidersearch") == 1) { $showslider = 1; }

			if(get_option("showheadersliderct") == 1) {
				if (is_page(get_option('city_tours_page_id')) || get_post_type() == 'tour') { $showslider = 1; }
			}

			if(get_option("showheadersliderrev") == 1) {
				if (is_page(get_option('nav_reviews_page_id')) || is_page(get_option('nav_reviews_agencies_page_id')) || get_post_type() == 'review') { $showslider = 1; }
			}

			if(get_option("showheadersliderads") == 1) {
				if (is_page(get_option('see_all_ads_page_id')) || is_page(get_option('see_offering_ads_page_id')) || is_page(get_option('see_looking_ads_page_id')) || get_post_type() == 'ad') { $showslider = 1; }
			}
		}
	} // if slider activated
	if(get_option('recaptcha_sitekey') && get_option('recaptcha_secretkey') && (in_array(get_the_ID(), array(get_option('contact_page_id'), get_option('escort_reg_page_id'), get_option('agency_reg_page_id'), get_option('member_register_page_id'))) || (is_single() && (get_option('recaptcha5') || get_option('recaptcha6'))))) {
		wp_enqueue_script('reCAPTCHA', '//www.google.com/recaptcha/api.js');
	}
	if(isset($showslider) && $showslider == "1") {
		wp_enqueue_style('owl-carousel-css', get_bloginfo('template_url').'/css/owl.carousel.min.css');
		wp_enqueue_script('owl-carousel-js', get_bloginfo('template_url').'/js/owl.carousel.min.js');
		define('showslider', 1);
	} else {
		define('showslider', 0);
	}
	//if edit registration fields page - enable iOS style checkboxes
	if(get_option('edit_registration_form_escort') == get_the_ID()) {
		wp_enqueue_style('ios-checkboxes', get_bloginfo('template_url').'/css/ios-checkboxes-switchery.min.css');
		wp_enqueue_script('ios-checkboxes', get_bloginfo('template_url').'/js/ios-checkboxes-switchery.min.js', array('jquery'));
	}
}

add_filter('body_class', 'dolce_extra_body_class');
// Add specific CSS class by filter
function dolce_extra_body_class($classes) {
	global $taxonomy_profile_name, $taxonomy_agency_name;
	if(in_array(get_post_type(), array($taxonomy_profile_name, $taxonomy_agency_name))) {
		$classes[] = 'single-profile-page';
	}
	return $classes;
}

// Add theme settings pages links to the admin bar on frontpage
add_action('admin_bar_menu', 'add_toolbar_items', 100);
function add_toolbar_items($admin_bar){
	global $taxonomy_profile_name, $taxonomy_agency_name, $taxonomy_location_url;
	$admin_bar->add_menu(array(
		'id'    => 'wp-escortwp-menu',
		'title' => '<span class="icon icon-menu"></span> '.__('EscortWP Menu','escortwp'),
		'href'  => '',
		'meta'  => array(
			'title' => __('EscortWP Menu','escortwp'),
		),
	));
	$admin_bar->add_menu(array(
		'id'    => 'wp-escortwp-menu-site-settings',
		'parent'=> 'wp-escortwp-menu',
		'title' => '<span class="icon icon-cog-alt"></span> '.__('Site Settings','escortwp'),
		'href'  => get_permalink(get_option('site_settings_page_id')),
	));

	$admin_bar->add_menu(array(
		'id'    => 'wp-escortwp-menu-content-settings',
		'parent'=> 'wp-escortwp-menu',
		'title' => '<span class="icon icon-cog-alt"></span> '.__('Content settings','escortwp'),
		'href'  => get_permalink(get_option('content_settings_page_id')),
	));

	$admin_bar->add_menu(array(
		'id'    => 'wp-escortwp-menu-reg-form',
		'parent'=> 'wp-escortwp-menu',
		'title' => '<span class="icon icon-cog-alt"></span> '.__('Registration Form','escortwp'),
		'href'  => get_permalink(get_option('edit_registration_form_escort')),
	));

	$admin_bar->add_menu(array(
		'id'    => 'wp-escortwp-menu-payment-settings',
		'parent'=> 'wp-escortwp-menu',
		'title' => '<span class="icon icon-dollar"></span> '.__('Configuracoes de pagamento','escortwp'),
		'href'  => get_permalink(get_option('edit_payment_settings_page_id')),
	));

	$admin_bar->add_menu(array(
		'id'    => 'wp-escortwp-menu-email-settings',
		'parent'=> 'wp-escortwp-menu',
		'title' => '<span class="icon icon-mail"></span> '.__('Email Settings','escortwp'),
		'href'  => get_permalink(get_option('email_settings_page_id')),
	));

	$admin_bar->add_menu(array(
		'id'    => 'wp-escortwp-menu-edit-user-types',
		'parent'=> 'wp-escortwp-menu',
		'title' => '<span class="icon icon-user"></span> '.__('Edit User Types','escortwp'),
		'href'  => get_permalink(get_option('edit_user_types')),
	));

	$admin_bar->add_menu(array(
		'id'    => 'wp-escortwp-menu-add-countries',
		'parent'=> 'wp-escortwp-menu',
		'title' => '<span class="icon icon-plus-circled"></span> '.__('Manage locations','escortwp'),
		'href'  => admin_url( 'edit-tags.php?taxonomy='.$taxonomy_location_url),
	));

	$admin_bar->add_menu(array(
		'id'    => 'wp-escortwp-menu-generate-demo-data',
		'parent'=> 'wp-escortwp-menu',
		'title' => '<span class="icon icon-plus-circled"></span> '.__('Generate demo data','escortwp'),
		'href'  => get_permalink(get_option('generate_demo_data_page')),
	));
}

function check_if_we_are_showing_the_slider() {
	add_action('wp_enqueue_scripts', 'add_js_css');
}
add_action('wp', 'check_if_we_are_showing_the_slider');
function login_stylesheet() {
	global $theme_version;
	wp_enqueue_style('main-css-file', get_template_directory_uri().'/style.css', array());
	wp_enqueue_style('responsive-css', get_template_directory_uri().'/css/responsive.css', array());
	wp_enqueue_style('reference-refresh-login', get_template_directory_uri().'/css/reference-refresh.css', array('main-css-file', 'responsive-css'), $theme_version);
	wp_enqueue_script('dolcejs', get_template_directory_uri().'/js/dolceescort.js', array('jquery'));
}
add_action('login_enqueue_scripts', 'login_stylesheet');


function login_logo_url() { return get_bloginfo( 'url'); }
add_filter('login_headerurl', 'login_logo_url');

function login_logo_url_title() { return get_bloginfo('name'); }
add_filter('login_headertitle', 'login_logo_url_title');

function escortwp_get_brand_logo_url() {
	$candidate_files = array(
		'i/garotas-df-logo-brand.png',
		'i/garotas-df-logo.svg',
	);

	foreach ( $candidate_files as $relative_path ) {
		$absolute_path = get_template_directory() . '/' . $relative_path;
		if ( file_exists( $absolute_path ) ) {
			return add_query_arg( 'ver', filemtime( $absolute_path ), get_template_directory_uri() . '/' . $relative_path );
		}
	}

	$uploaded_logo = trim( (string) get_option( 'sitelogo' ) );
	if ( $uploaded_logo ) {
		return $uploaded_logo;
	}

	return '';
}

function escortwp_get_brand_logo_markup( $class = '' ) {
	$logo_url = escortwp_get_brand_logo_url();
	if ( ! $logo_url ) {
		return esc_html( get_bloginfo( 'name' ) );
	}

	$class_attr = $class ? ' class="' . esc_attr( trim( $class ) ) . '"' : '';
	return sprintf(
		'<img%s src="%s" alt="%s" />',
		$class_attr,
		esc_url( $logo_url ),
		esc_attr( get_bloginfo( 'name' ) )
	);
}

function escortwp_get_age_gate_decline_url() {
	return esc_url_raw( apply_filters( 'escortwp_age_gate_decline_url', 'https://www.google.com/' ) );
}

function escortwp_login_title_filter_clean($login_title, $title) {
	if (!escortwp_should_use_pt_br_translations()) {
		return $login_title;
	}

	$site_name = get_bloginfo('name', 'display');
	$screen_title = $title ? wp_strip_all_tags($title) : __('Entrar', 'escortwp');

	return sprintf('%1$s &lsaquo; %2$s', $screen_title, $site_name);
}
add_filter('login_title', 'escortwp_login_title_filter_clean', 20, 2);

function escortwp_login_site_html_link_filter_clean($html_link) {
	if (!escortwp_should_use_pt_br_translations()) {
		return $html_link;
	}

	$label = sprintf(__('Ir para %s', 'escortwp'), get_bloginfo('name', 'display'));

	return sprintf('<a href="%1$s">&larr; %2$s</a>', esc_url(home_url('/')), esc_html($label));
}
add_filter('login_site_html_link', 'escortwp_login_site_html_link_filter_clean', 20);

function escortwp_get_age_gate_cookie_name() {
	return 'escortwp_age_verified';
}

function escortwp_is_local_environment() {
	$environment = function_exists('wp_get_environment_type') ? wp_get_environment_type() : '';
	$home_url = strtolower((string) home_url('/'));

	return in_array($environment, array('local', 'development'), true)
		|| strpos($home_url, '.local') !== false
		|| strpos($home_url, 'localhost') !== false
		|| strpos($home_url, '127.0.0.1') !== false;
}

function escortwp_age_gate_is_enabled() {
	return get_option('tos18') == '1';
}

function escortwp_age_gate_is_verified() {
	$age_cookie = isset($_COOKIE[escortwp_get_age_gate_cookie_name()]) ? sanitize_text_field(wp_unslash($_COOKIE[escortwp_get_age_gate_cookie_name()])) : '';
	$legacy_cookie = isset($_COOKIE['tos18']) ? sanitize_text_field(wp_unslash($_COOKIE['tos18'])) : '';

	return $age_cookie === '1' || strtolower($legacy_cookie) === 'yes';
}

function escortwp_should_render_age_gate() {
	return escortwp_age_gate_is_enabled() && !escortwp_age_gate_is_verified();
}

function escortwp_age_gate_body_class($classes) {
	if (escortwp_should_render_age_gate()) {
		$classes[] = 'escortwp-age-gate-open';
	}

	return $classes;
}
add_filter('body_class', 'escortwp_age_gate_body_class');

function escortwp_set_age_gate_cookie($confirmed = true) {
	$expires = time() + (DAY_IN_SECONDS * 30);
	$value = $confirmed ? '1' : '';
	$legacy_value = $confirmed ? 'yes' : '';

	setcookie(escortwp_get_age_gate_cookie_name(), $value, $expires, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, is_ssl(), true);
	setcookie('tos18', $legacy_value, $expires, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, is_ssl(), true);

	$_COOKIE[escortwp_get_age_gate_cookie_name()] = $value;
	$_COOKIE['tos18'] = $legacy_value;
}

function escortwp_handle_age_gate_submission() {
	if (!escortwp_age_gate_is_enabled()) {
		return;
	}

	if (is_admin() || wp_doing_ajax() || (defined('REST_REQUEST') && REST_REQUEST)) {
		return;
	}

	if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['escortwp_age_gate_action'])) {
		return;
	}

	$action = sanitize_text_field(wp_unslash($_POST['escortwp_age_gate_action']));
	$nonce = isset($_POST['escortwp_age_gate_nonce']) ? sanitize_text_field(wp_unslash($_POST['escortwp_age_gate_nonce'])) : '';

	if (!wp_verify_nonce($nonce, 'escortwp_age_gate_action')) {
		return;
	}

	$redirect_to = isset($_POST['escortwp_age_gate_redirect']) ? esc_url_raw(wp_unslash($_POST['escortwp_age_gate_redirect'])) : home_url('/');
	if (!$redirect_to || !wp_validate_redirect($redirect_to, false)) {
		$redirect_to = home_url('/');
	}

	if ($action === 'confirm') {
		escortwp_set_age_gate_cookie(true);
		wp_safe_redirect($redirect_to);
		exit;
	}

	if ($action === 'decline') {
		escortwp_set_age_gate_cookie(false);
		wp_safe_redirect(escortwp_get_age_gate_decline_url());
		exit;
	}
}
add_action('init', 'escortwp_handle_age_gate_submission', 1);

function escortwp_get_env_value($keys, $default = '') {
	foreach ((array) $keys as $key) {
		$value = getenv($key);
		if ($value !== false && trim((string) $value) !== '') {
			return trim((string) $value);
		}
	}

	return $default;
}

function escortwp_get_mail_transport_config() {
	$from_email = get_option('email_siteemail');
	if (!$from_email || !is_email($from_email)) {
		$from_email = get_option('admin_email');
	}
	if (!$from_email || !is_email($from_email)) {
		$from_email = get_bloginfo('admin_email');
	}

	$from_name = get_option('email_sitename');
	if (!$from_name) {
		$from_name = get_bloginfo('name');
	}

	$host = escortwp_get_env_value(array('ESCORTWP_SMTP_HOST', 'SMTP_HOST'));
	$port = (int) escortwp_get_env_value(array('ESCORTWP_SMTP_PORT', 'SMTP_PORT'), 0);
	$username = escortwp_get_env_value(array('ESCORTWP_SMTP_USER', 'SMTP_USER'));
	$password = escortwp_get_env_value(array('ESCORTWP_SMTP_PASS', 'SMTP_PASS'));
	$secure = strtolower(escortwp_get_env_value(array('ESCORTWP_SMTP_SECURE', 'SMTP_SECURE')));
	$auth = strtolower(escortwp_get_env_value(array('ESCORTWP_SMTP_AUTH', 'SMTP_AUTH'), ''));

	if ($host) {
		return array(
			'enabled' => true,
			'driver' => 'smtp',
			'host' => $host,
			'port' => $port > 0 ? $port : 587,
			'username' => $username,
			'password' => $password,
			'secure' => in_array($secure, array('ssl', 'tls'), true) ? $secure : '',
			'auth' => $auth === '' ? ($username !== '' && $password !== '') : in_array($auth, array('1', 'true', 'yes', 'on'), true),
			'from_email' => escortwp_get_env_value(array('ESCORTWP_SMTP_FROM_EMAIL', 'SMTP_FROM_EMAIL'), $from_email),
			'from_name' => escortwp_get_env_value(array('ESCORTWP_SMTP_FROM_NAME', 'SMTP_FROM_NAME'), $from_name),
			'description' => __('SMTP configurado por variÃ¡veis de ambiente.', 'escortwp'),
		);
	}

	if (escortwp_is_local_environment()) {
		return array(
			'enabled' => true,
			'driver' => 'smtp',
			'host' => '127.0.0.1',
			'port' => 10007,
			'username' => '',
			'password' => '',
			'secure' => '',
			'auth' => false,
			'from_email' => $from_email,
			'from_name' => $from_name,
			'description' => __('Ambiente local usando Mailpit na porta 10007.', 'escortwp'),
		);
	}

	return array(
		'enabled' => false,
		'driver' => 'mail',
		'host' => '',
		'port' => 0,
		'username' => '',
		'password' => '',
		'secure' => '',
		'auth' => false,
		'from_email' => $from_email,
		'from_name' => $from_name,
		'description' => __('Sem SMTP dedicado. O WordPress usarÃ¡ o mÃ©todo de envio disponÃ­vel no servidor.', 'escortwp'),
	);
}

function escortwp_get_mail_transport_summary() {
	$config = escortwp_get_mail_transport_config();

	if (!$config['enabled']) {
		return array(
			'title' => __('Envio padrÃ£o do servidor', 'escortwp'),
			'description' => $config['description'],
		);
	}

	return array(
		'title' => $config['driver'] === 'smtp' ? __('SMTP ativo', 'escortwp') : __('Envio ativo', 'escortwp'),
		'description' => sprintf(
			__('Servidor: %1$s:%2$s | Remetente: %3$s', 'escortwp'),
			$config['host'],
			$config['port'],
			$config['from_email']
		) . '<br />' . esc_html($config['description']),
	);
}

function escortwp_get_frontend_ajax_nonce() {
	return wp_create_nonce('escortwp_frontend_ajax');
}

function escortwp_verify_frontend_ajax_nonce($nonce = '') {
	if ($nonce === '') {
		$nonce = isset($_REQUEST['escortwp_nonce']) ? sanitize_text_field(wp_unslash($_REQUEST['escortwp_nonce'])) : '';
	}

	return !empty($nonce) && wp_verify_nonce($nonce, 'escortwp_frontend_ajax');
}

function escortwp_get_client_ip() {
	$keys = array('HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');
	foreach ($keys as $key) {
		if (empty($_SERVER[$key])) {
			continue;
		}

		$value = sanitize_text_field(wp_unslash($_SERVER[$key]));
		if ($key === 'HTTP_X_FORWARDED_FOR') {
			$value = trim(explode(',', $value)[0]);
		}

		if (filter_var($value, FILTER_VALIDATE_IP)) {
			return $value;
		}
	}

	return '0.0.0.0';
}

function escortwp_get_login_attempt_transient_key($username = '') {
	$normalized_username = strtolower(trim((string) $username));
	return 'escortwp_login_attempts_' . md5(escortwp_get_client_ip() . '|' . $normalized_username);
}

function escortwp_limit_login_attempts($user, $username, $password) {
	if (is_wp_error($user) || empty($username)) {
		return $user;
	}

	$key = escortwp_get_login_attempt_transient_key($username);
	$state = get_transient($key);
	if (!is_array($state)) {
		$state = array(
			'count' => 0,
			'locked_until' => 0,
		);
	}

	$locked_until = isset($state['locked_until']) ? (int) $state['locked_until'] : 0;
	if ($locked_until > time()) {
		return new WP_Error(
			'escortwp_login_rate_limit',
			sprintf(
				__('Muitas tentativas de acesso. Tente novamente em %s.', 'escortwp'),
				human_time_diff(time(), $locked_until)
			)
		);
	}

	return $user;
}
add_filter('authenticate', 'escortwp_limit_login_attempts', 30, 3);

function escortwp_track_failed_login($username) {
	$key = escortwp_get_login_attempt_transient_key($username);
	$state = get_transient($key);
	if (!is_array($state)) {
		$state = array(
			'count' => 0,
			'locked_until' => 0,
		);
	}

	$state['count'] = isset($state['count']) ? (int) $state['count'] + 1 : 1;
	if ($state['count'] >= 5) {
		$state['locked_until'] = time() + MINUTE_IN_SECONDS * 5;
	}

	set_transient($key, $state, MINUTE_IN_SECONDS * 10);
}
add_action('wp_login_failed', 'escortwp_track_failed_login');

function escortwp_reset_failed_login_attempts($user_login, $user) {
	delete_transient(escortwp_get_login_attempt_transient_key($user_login));
}
add_action('wp_login', 'escortwp_reset_failed_login_attempts', 10, 2);

function escortwp_optimize_attachment_image_attributes($attr) {
	if (empty($attr['loading'])) {
		$attr['loading'] = 'lazy';
	}
	if (empty($attr['decoding'])) {
		$attr['decoding'] = 'async';
	}
	return $attr;
}
add_filter('wp_get_attachment_image_attributes', 'escortwp_optimize_attachment_image_attributes', 20);

function escortwp_current_user_can_manage_post($post_id) {
	$post_id = (int) $post_id;
	if (!$post_id || !is_user_logged_in()) {
		return false;
	}

	$post = get_post($post_id);
	if (!$post instanceof WP_Post) {
		return false;
	}

	$current_user = wp_get_current_user();
	return ((int) $post->post_author === (int) $current_user->ID) || current_user_can('manage_options');
}

function escortwp_get_uploads_local_file_from_url($file_url) {
	$file_url = trim((string) $file_url);
	if ($file_url === '') {
		return '';
	}

	$uploads = wp_get_upload_dir();
	if (empty($uploads['baseurl']) || empty($uploads['basedir'])) {
		return '';
	}

	$base_url = trailingslashit(wp_normalize_path($uploads['baseurl']));
	$base_dir = trailingslashit(wp_normalize_path($uploads['basedir']));
	$normalized_url = wp_normalize_path($file_url);

	if (strpos($normalized_url, $base_url) !== 0) {
		return '';
	}

	$relative_path = ltrim(substr($normalized_url, strlen($base_url)), '/');
	if ($relative_path === '') {
		return '';
	}

	$file_path = wp_normalize_path($base_dir . $relative_path);
	if (strpos($file_path, $base_dir) !== 0) {
		return '';
	}

	return $file_path;
}

function escortwp_delete_uploaded_option_file($option_name) {
	$option_name = sanitize_key((string) $option_name);
	if ($option_name === '') {
		return false;
	}

	$file_url = get_option($option_name);
	$file_path = escortwp_get_uploads_local_file_from_url($file_url);
	if ($file_path && is_file($file_path)) {
		@unlink($file_path);
	}

	delete_option($option_name);
	return true;
}

function escortwp_login_register_message($message) {
	$register_url = get_option('main_reg_page_id') ? get_permalink(get_option('main_reg_page_id')) : home_url('/registration/');
	$member_register_url = get_option('member_register_page_id') ? get_permalink(get_option('member_register_page_id')) : home_url('/member-registration/');
	$escort_register_url = get_option('escort_reg_page_id') ? get_permalink(get_option('escort_reg_page_id')) : home_url('/acompanhante-registration/');

	$custom = '<div class="escortwp-login-register-links">';
	$custom .= '<strong>'.esc_html__('Ainda nÃ£o tem conta?', 'escortwp').'</strong>';
	$custom .= '<p>'.esc_html__('Escolha o tipo de cadastro e continue pelo fluxo certo do site.', 'escortwp').'</p>';
	$custom .= '<div class="escortwp-login-register-actions">';
	$custom .= '<a class="escortwp-login-register-button escortwp-login-register-button-primary" href="'.esc_url($register_url).'">'.esc_html__('Ver opÃ§Ãµes de cadastro', 'escortwp').'</a>';
	$custom .= '<a class="escortwp-login-register-button" href="'.esc_url($escort_register_url).'">'.esc_html__('Criar conta de acompanhante', 'escortwp').'</a>';
	$custom .= '<a class="escortwp-login-register-button" href="'.esc_url($member_register_url).'">'.esc_html__('Criar conta de cliente', 'escortwp').'</a>';
	$custom .= '</div></div>';

	return $custom.$message;
}
add_filter('login_message', 'escortwp_login_register_message');

remove_filter('login_message', 'escortwp_login_register_message');
function escortwp_login_register_message_v2($message) {
	$action = isset($_REQUEST['action']) ? sanitize_key(wp_unslash($_REQUEST['action'])) : 'login';
	if ($action && $action !== 'login') {
		return $message;
	}

	$register_url = get_option('main_reg_page_id') ? get_permalink(get_option('main_reg_page_id')) : home_url('/registration/');
	$member_register_url = get_option('member_register_page_id') ? get_permalink(get_option('member_register_page_id')) : home_url('/member-registration/');
	$escort_register_url = get_option('escort_reg_page_id') ? get_permalink(get_option('escort_reg_page_id')) : home_url('/acompanhante-registration/');

	$custom = '<div class="escortwp-login-register-links">';
	$custom .= '<strong>'.esc_html__('Ainda nÃ£o tem conta?', 'escortwp').'</strong>';
	$custom .= '<p>'.esc_html__('Escolha o tipo de cadastro e siga pelo fluxo certo do site.', 'escortwp').'</p>';
	$custom .= '<div class="escortwp-login-register-actions">';
	$custom .= '<a class="escortwp-login-register-button escortwp-login-register-button-primary" href="'.esc_url($register_url).'">'.esc_html__('Ver opÃ§Ãµes de cadastro', 'escortwp').'</a>';
	$custom .= '<a class="escortwp-login-register-button" href="'.esc_url($escort_register_url).'">'.esc_html__('Criar conta de acompanhante', 'escortwp').'</a>';
	$custom .= '<a class="escortwp-login-register-button" href="'.esc_url($member_register_url).'">'.esc_html__('Criar conta de cliente', 'escortwp').'</a>';
	$custom .= '</div></div>';

	return $custom.$message;
}
add_filter('login_message', 'escortwp_login_register_message_v2');

remove_filter('login_message', 'escortwp_login_register_message_v2');
function escortwp_login_register_message_clean($message) {
	$action = isset($_REQUEST['action']) ? sanitize_key(wp_unslash($_REQUEST['action'])) : 'login';
	if ($action && $action !== 'login') {
		return $message;
	}

	$register_url = get_option('main_reg_page_id') ? get_permalink(get_option('main_reg_page_id')) : home_url('/registration/');
	$member_register_url = get_option('member_register_page_id') ? get_permalink(get_option('member_register_page_id')) : home_url('/member-registration/');
	$escort_register_url = get_option('escort_reg_page_id') ? get_permalink(get_option('escort_reg_page_id')) : home_url('/acompanhante-registration/');

	$custom = '<div class="escortwp-login-register-links">';
	$custom .= '<strong>' . esc_html__('Ainda nÃ£o tem conta?', 'escortwp') . '</strong>';
	$custom .= '<p>' . esc_html__('Escolha o tipo de cadastro e siga pelo fluxo certo do site.', 'escortwp') . '</p>';
	$custom .= '<div class="escortwp-login-register-actions">';
	$custom .= '<a class="escortwp-login-register-button escortwp-login-register-button-primary" href="' . esc_url($register_url) . '">' . esc_html__('Ver opÃ§Ãµes de cadastro', 'escortwp') . '</a>';
	$custom .= '<a class="escortwp-login-register-button" href="' . esc_url($escort_register_url) . '">' . esc_html__('Criar conta de acompanhante', 'escortwp') . '</a>';
	$custom .= '<a class="escortwp-login-register-button" href="' . esc_url($member_register_url) . '">' . esc_html__('Criar conta de cliente', 'escortwp') . '</a>';
	$custom .= '</div></div>';

	return $custom . $message;
}
add_filter('login_message', 'escortwp_login_register_message_clean', 20);

function escortwp_get_validation_notice_page_ids() {
	$page_ids = array(
		get_option('main_reg_page_id'),
		get_option('member_register_page_id'),
		get_option('escort_reg_page_id'),
		get_option('member_edit_personal_info_page_id'),
		get_option('escort_edit_personal_info_page_id'),
		get_option('upload_photos_page_id'),
		get_option('member_edit_profile_page_id'),
		get_option('edit_profile_page_id'),
	);

	return array_values(array_filter(array_map('intval', $page_ids)));
}

function escortwp_should_show_email_validation_notice($user_id = 0) {
	$user_id = (int) $user_id;
	if ($user_id < 1 || !get_user_meta($user_id, 'emailhash', true)) {
		return false;
	}

	if (is_admin() || (function_exists('wp_doing_ajax') && wp_doing_ajax())) {
		return false;
	}

	if (!empty($_GET['ekey'])) {
		return false;
	}

	if (!empty($_GET['escortwp_show_validation_notice']) && $_GET['escortwp_show_validation_notice'] === '1') {
		return true;
	}

	$current_page_id = (int) get_queried_object_id();
	if ($current_page_id && in_array($current_page_id, escortwp_get_validation_notice_page_ids(), true)) {
		return true;
	}

	return false;
}

//change the look of the wordpress login form
function change_login_form() {
	?>
	<script type="text/javascript">
	jQuery(document).ready(function($){
		$('body').addClass('escortwp-login-screen');
		$('.login form, .login .message, .login #login_error, .login #backtoblog a, .login #nav a').addClass('rad3');
		$('.login form').addClass('form-styling escortwp-login-form');
		$('.login form .input').parent().addClass('form-input col100');

		<?php
		$site_logo = escortwp_get_brand_logo_markup('escortwp-login-logo');
		if($site_logo) {
		?>
			$('.login h1 a').html(<?php echo wp_json_encode($site_logo); ?>);
			$('.login h1 a img').on('load', function() {
				$('.login h1 a').css('height', $(this).height());
			});
		<?php } ?>
	});
	</script>
	<?php
}
add_action('login_head', 'change_login_form');

function dolce_email($fromname, $fromemail, $to, $subj, $body) {
	if (!$fromname) {
		$fromname = get_option("email_sitename");
	}
	if (!$fromemail) {
		$fromemail = get_option("email_siteemail");
	}
	$body = str_replace("<br /><br />", "<br />", nl2br($body));
	$body = $body."<br />".nl2br(get_option("email_signature"));

    $headers[] = "From: $fromname <$fromemail>";
	$headers[] = 'Content-Type: text/html; charset=UTF-8';
    wp_mail($to, $subj, $body, $headers);
}

function escortwp_configure_phpmailer_transport($phpmailer) {
	$config = escortwp_get_mail_transport_config();

	if (!$config['enabled'] || $config['driver'] !== 'smtp') {
		return;
	}

	$phpmailer->isSMTP();
	$phpmailer->Host = $config['host'];
	$phpmailer->Port = (int) $config['port'];
	$phpmailer->SMTPAuth = (bool) $config['auth'];
	$phpmailer->CharSet = 'UTF-8';

	if (!empty($config['secure'])) {
		$phpmailer->SMTPSecure = $config['secure'];
	}

	if ($phpmailer->SMTPAuth) {
		$phpmailer->Username = $config['username'];
		$phpmailer->Password = $config['password'];
	}

	if (!empty($config['from_email']) && is_email($config['from_email'])) {
		$phpmailer->setFrom($config['from_email'], wp_specialchars_decode($config['from_name'], ENT_QUOTES), false);
		$phpmailer->Sender = $config['from_email'];
	}
}
add_action('phpmailer_init', 'escortwp_configure_phpmailer_transport');

function change_password_reset_email($message){
	$signature = "<br />".nl2br(get_option("email_signature"));
	return nl2br($message).$signature;
}
add_filter('retrieve_password_message', 'change_password_reset_email');

function dolce_register_sidebars() {
	register_sidebar(array(
		'name' => 'Sidebar Left',
		'id' => 'widget-sidebar-left',
		'before_widget' => '<div id="%1$s" class="widgetbox rad3 widget %2$s">',
		'after_widget' => '</div><div class="clear10"></div>',
		'before_title' => '<h4 class="widgettitle">',
		'after_title' => '</h4>'
	));
	register_sidebar(array(
		'name' => 'Left Ads',
		'id' => 'widget-left-ads',
		'before_widget' => '<div id="%1$s" class="widgetadbox rad3 widget %2$s">',
		'after_widget' => '</div><div class="clear10"></div>',
		'before_title' => '<h4 class="widgettitle">',
		'after_title' => '</h4>'
	));
	register_sidebar(array(
		'name' => 'Sidebar Right',
		'id' => 'widget-sidebar-right',
		'before_widget' => '<div id="%1$s" class="widgetbox rad3 widget %2$s">',
		'after_widget' => '</div><div class="clear10"></div>',
		'before_title' => '<h4 class="widgettitle">',
		'after_title' => '</h4>'
	));
	register_sidebar(array(
		'name' => 'Right Ads',
		'id' => 'widget-right-ads',
		'before_widget' => '<div id="%1$s" class="widgetadbox rad3 widget %2$s">',
		'after_widget' => '</div><div class="clear10"></div>',
		'before_title' => '<h4 class="widgettitle">',
		'after_title' => '</h4>'
	));
	register_sidebar(array(
		'name' => 'Footer',
		'id' => 'widget-footer',
		'before_widget' => '<div id="%1$s" class="widgetbox rad3 widget %2$s l">',
		'after_widget' => '</div>',
		'before_title' => '<h4 class="widgettitle">',
		'after_title' => '</h4>'
	));
	register_sidebar(array(
		'name' => 'Header Language Switcher Only',
		'id' => 'header-language-switcher',
		'before_widget' => '<li class="header-language-switcher">',
		'after_widget' => '</li>',
		'before_title' => '',
		'after_title' => ''
	));
}
add_action('widgets_init', 'dolce_register_sidebars');


function dolce_create_post_taxonomies() {
	global $taxonomy_profile_url, $taxonomy_agency_url, $taxonomy_location_url;
	register_taxonomy(
		$taxonomy_location_url,
		array($taxonomy_profile_url,$taxonomy_agency_url,'tour'),
		array(
			'hierarchical' => true,
			'label' => __('Locais','escortwp'),
			'sort' => true,
			'show_ui' => true,
			'query_var' => true,
			'args' => array( 'orderby' => 'term_order' ),
            'rewrite' => array('slug' => $taxonomy_location_url, 'hierarchical' => true, 'with_front' => false),
		)
	);
}
add_action('init', 'dolce_create_post_taxonomies');

function dolce_create_post_types() {
	global $taxonomy_profile_name, $taxonomy_profile_url, $taxonomy_agency_name, $taxonomy_agency_url, $taxonomy_location_url;
	$post_types = array(
		array(ucfirst($taxonomy_profile_name), $taxonomy_profile_url, 'Add another '.$taxonomy_profile_name.' to the site'),
		array('Blacklisted '.ucfirst($taxonomy_profile_name), 'b'.$taxonomy_profile_url, 'Add another '.$taxonomy_profile_name.' to the blacklist'),
		array(ucfirst($taxonomy_agency_name), $taxonomy_agency_url, 'Add an '.$taxonomy_agency_name.' to the site'),
		array('City Tours', 'tour', 'Add city-tour'),
		array('Blacklisted Clients', 'bclient', 'Add a client to the blacklist'),
		array('Reviews', 'review', 'Add a review to an '.$taxonomy_profile_name),
		array('Classified Ads', 'ad', 'Add classified ad'),
	);

	foreach($post_types as $t) {
		$args = array(
			'label' => $t[0],
            'rewrite' => array('slug' => $t[1], 'hierarchical' => true, 'with_front' => false),
			'description ' => $t[2],
			'public' => true,
			'publicly_queryable' => true,
			'exclude_from_search' => true,
			'show_ui' => true,
			'show_in_menu' => true,
			'menu_position' => 80,
			'capability_type' => 'post',
			'hierarchical' => false,
			'menu_icon'	=> get_template_directory_uri().'/i/admin-menu-icon.png',
			'has_archive' => true,
			'supports' => array('title', 'editor', 'author', 'excerpt', 'custom-fields'),
			'taxonomies' => array($taxonomy_location_url)
		);
		if($t[1] == "escort") {
			$args['rewrite'] = array('slug' => _x('escort', 'Escort profile slug', 'escortwp'), 'hierarchical' => true, 'with_front' => false);
		}
		if($t[1] == "agency") {
			$args['rewrite'] = array('slug' => _x('agency', 'Agency profile slug', 'escortwp'), 'hierarchical' => true, 'with_front' => false);
		}
		register_post_type( $t[1], $args );
	}
}
add_action('init', 'dolce_create_post_types');

function edit_body_css_classes($classes){
	//remove the class "single-ad" from the body because AdBLockPlus hides the whole page when the class is present
	if(is_singular() && get_post_type() == "ad") {
		foreach($classes as $key=>$class) {
			if($class == "single-ad") {
				unset($classes[$key]);	
				break;
			}
		}
	}

	//add the "isphone" css class if the device is a phone
	global $isphone;
	if($isphone) { $classes[] = 'isphone'; }

	return $classes;
}
add_filter('body_class', 'edit_body_css_classes');


add_action( 'generate_rewrite_rules', 'register_product_rewrite_rules' );
function register_product_rewrite_rules( $wp_rewrite ) {
	global $taxonomy_location_url, $taxonomy_profile_url, $taxonomy_agency_url;
    $new_rules = array( 
		// agency/name/paged/2/
		$taxonomy_agency_url.'/([^/]+)/'.__('paged', 'escortwp').'/(\d{1,})/?$' => 'index.php?'.$taxonomy_agency_url.'=' . $wp_rewrite->preg_index(1) . '&paged=' . $wp_rewrite->preg_index(2),

        // escorts-from/location/
        $taxonomy_location_url.'/([^/]+)/?$' => 'index.php?'.$taxonomy_location_url.'=' . $wp_rewrite->preg_index(1),

        // escorts-from/location/page/2/
        $taxonomy_location_url.'/([^/]+)/'.$GLOBALS['wp_rewrite']->pagination_base.'/(\d{1,})/?$' => 'index.php?'.$taxonomy_location_url.'=' . $wp_rewrite->preg_index(1) . '&page=' . $wp_rewrite->preg_index(2), // match paginated results for a sub-category archive

        // escorts-from/country/city/page/2/
        $taxonomy_location_url.'/([^/]+)/([^/]+)/'.$GLOBALS['wp_rewrite']->pagination_base.'/(\d{1,})/?$' => 'index.php?'.$taxonomy_location_url.'=' . $wp_rewrite->preg_index(2) . '&page=' . $wp_rewrite->preg_index(3), // match paginated results for a sub-category archive

        // escorts-from/country/state/city/page/2/
        $taxonomy_location_url.'/([^/]+)/([^/]+)/([^/]+)/'.$GLOBALS['wp_rewrite']->pagination_base.'/(\d{1,})/?$' => 'index.php?'.$taxonomy_location_url.'=' . $wp_rewrite->preg_index(3) . '&page=' . $wp_rewrite->preg_index(4), // match paginated results for a sub-category archive
    );
    $wp_rewrite->rules = $new_rules + $wp_rewrite->rules;
}

function filter_post_type_link($link, $post) {
	global $taxonomy_location_url, $taxonomy_profile_url;
    if ($post->post_type != $taxonomy_profile_url)
        return $link;

    if ($cats = get_the_terms($post->ID, $taxonomy_location_url)) {
        $link = str_replace('%product_category%', get_taxonomy_parents(array_pop($cats)->term_id, $taxonomy_location_url, false, '/', true), $link); // see custom function defined below\
        $link = str_replace('//', '/', $link);
        $link = str_replace('http:/', 'http://', $link);
        $link = str_replace('https:/', 'https://', $link);
    }
    return $link;
}
add_filter('post_type_link', 'filter_post_type_link', 10, 2);

function get_taxonomy_parents($id, $taxonomy, $link = false, $separator = '/', $nicename = false, $visited = array()) {    
    $chain = '';   
    $parent = get_term($id, $taxonomy);

    if (is_wp_error($parent)) {
        return $parent;
    }

    if ($nicename) {
        $name = $parent -> slug;        
    } else {
		$name = $parent -> name;
    }

    if ($parent -> parent && ($parent -> parent != $parent -> term_id) && !in_array($parent -> parent, $visited)) {    
        $visited[] = $parent -> parent;    
        $chain .= get_taxonomy_parents($parent -> parent, $taxonomy, $link, $separator, $nicename, $visited);
    }

    if ($link) {
    } else {
        $chain .= $name . $separator;    
    }
    return $chain;    
}

function fix_product_subcategory_query($query) {
	global $taxonomy_profile_url, $taxonomy_location_url;
    if ( isset( $query['post_type'] ) && $taxonomy_profile_url == $query['post_type'] ) {
        if ( isset( $query[$taxonomy_profile_url] ) && $query[$taxonomy_profile_url] && isset( $query[$taxonomy_location_url] ) && $query[$taxonomy_location_url] ) {
            $query_old = $query;
            // Check if this is a paginated result(like search results)
            if ( 'page' == $query[$taxonomy_location_url] ) {
                $query['paged'] = $query['name'];
                unset( $query[$taxonomy_location_url], $query['name'], $query[$taxonomy_profile_url] );
            }
            // Make it easier on the DB
            $query['fields'] = 'ids';
            $query['posts_per_page'] = 1;
            // See if we have results or not
            $_query = new WP_Query( $query );
            if ( ! $_query->posts ) {
                $query = array( $taxonomy_location_url => $query[$taxonomy_profile_url] );
                if ( isset( $query_old[$taxonomy_location_url] ) && 'page' == $query_old[$taxonomy_location_url] ) {
                    $query['paged'] = $query_old['name'];
                }
            }
        }
    }
    return $query;
}
add_filter( 'request', 'fix_product_subcategory_query', 10 );


// restrict access to the admin dashboard for users other than admin
function restricted_pages(){
	$current_user = wp_get_current_user();
	if(!current_user_can('level_10') && !defined('DOING_AJAX')) {
		wp_redirect(get_bloginfo("url")); die();
	}
	if(defined('dolce_demo_theme') && $current_user->ID != "1"){
		wp_redirect(get_bloginfo("url")); die();
	}
}
add_action('admin_init', 'restricted_pages');

function escortwp_is_customizer_preview_request() {
	if (function_exists('is_customize_preview') && is_customize_preview()) {
		return true;
	}

	if (is_admin() && isset($_GET['customize_changeset_uuid'])) {
		return true;
	}

	return isset($_REQUEST['wp_customize']) || isset($_REQUEST['customize_messenger_channel']) || isset($_REQUEST['customize_autosaved']);
}

function escortwp_disable_redirects_in_customizer($location) {
	if (escortwp_is_customizer_preview_request()) {
		return false;
	}

	return $location;
}
add_filter('wp_redirect', 'escortwp_disable_redirects_in_customizer', 1);

function escortwp_force_woocommerce_store_live() {
	if (!defined('is_woocommerce_active') || !is_woocommerce_active) {
		return;
	}

	if (get_option('woocommerce_coming_soon') !== 'no') {
		update_option('woocommerce_coming_soon', 'no');
	}

	if (get_option('woocommerce_store_pages_only') !== 'no') {
		update_option('woocommerce_store_pages_only', 'no');
	}

	if (get_option('woocommerce_feature_site_visibility_badge_enabled') !== 'no') {
		update_option('woocommerce_feature_site_visibility_badge_enabled', 'no');
	}
}
add_action('plugins_loaded', 'escortwp_force_woocommerce_store_live', 50);

function escortwp_get_current_user_account_url() {
	global $taxonomy_profile_url, $taxonomy_agency_url;

	$home_url = home_url('/');
	$register_url = get_permalink(get_option('main_reg_page_id'));

	if (!is_user_logged_in()) {
		return $register_url ? $register_url : $home_url;
	}

	$current_user = wp_get_current_user();
	$current_user_id = isset($current_user->ID) ? (int) $current_user->ID : 0;

	if ($current_user_id && user_can($current_user, 'manage_options')) {
		return admin_url();
	}

	$current_user_status = escortwp_get_user_type($current_user_id);
	$account_url = $register_url ? $register_url : $home_url;

	switch ($current_user_status) {
		case 'member':
			$account_url = get_permalink(get_option('member_edit_personal_info_page_id'));
			if (!$account_url) {
				$account_url = get_permalink(get_option('member_favorite_escorts_page_id'));
			}
			break;
		case $taxonomy_profile_url:
			$account_url = get_permalink(get_option('escort_edit_personal_info_page_id'));
			if (!$account_url) {
				$escort_post_id = (int) get_option('escortpostid'.$current_user_id);
				if ($escort_post_id) {
					$account_url = get_permalink($escort_post_id);
				}
			}
			if (!$account_url) {
				$account_url = get_permalink(get_option('escort_reg_page_id'));
			}
			break;
		case $taxonomy_agency_url:
			$account_url = get_permalink(get_option('agency_reg_page_id'));
			break;
	}

	return $account_url ? $account_url : $home_url;
}

function escortwp_login_redirect($redirect_to, $requested_redirect_to, $user) {
	global $taxonomy_profile_url;

	if (is_wp_error($user) || !$user instanceof WP_User) {
		return $redirect_to;
	}

	if (user_can($user, 'manage_options')) {
		return admin_url();
	}

	$user_type = escortwp_get_user_type($user->ID);
	$default_redirect = escortwp_get_current_user_account_url();
	if ($user_type === 'member') {
		$member_url = get_permalink(get_option('member_edit_personal_info_page_id'));
		if ($member_url) {
			$default_redirect = $member_url;
		}
	} elseif ($user_type === $taxonomy_profile_url) {
		$escort_url = get_permalink(get_option('escort_edit_personal_info_page_id'));
		if ($escort_url) {
			$default_redirect = $escort_url;
		}
	}

	if (!empty($requested_redirect_to)) {
		$normalized_requested = wp_validate_redirect($requested_redirect_to, '');
		$admin_base = trailingslashit(admin_url());
		if (
			$normalized_requested &&
			strpos($normalized_requested, home_url('/')) === 0 &&
			strpos($normalized_requested, $admin_base) !== 0
		) {
			return $normalized_requested;
		}
	}

	return $default_redirect;
}
add_filter('login_redirect', 'escortwp_login_redirect', 10, 3);

function escortwp_logout_redirect() {
	return home_url('/');
}
add_filter('logout_redirect', 'escortwp_logout_redirect');

function escortwp_enforce_frontend_account_access() {
	global $taxonomy_profile_url;

	if (is_admin() || (defined('DOING_AJAX') && DOING_AJAX)) {
		return;
	}

	$member_pages = array_filter(array_map('intval', array(
		get_option('member_edit_personal_info_page_id'),
		get_option('member_favorite_escorts_page_id'),
		get_option('member_reviews_page_id'),
	)));

	$escort_pages = array_filter(array_map('intval', array(
		get_option('escort_edit_personal_info_page_id'),
		get_option('escort_tours_page_id'),
		get_option('escort_verified_status_page_id'),
		get_option('escort_blacklist_clients_page_id'),
	)));

	$logged_only_pages = array_filter(array_map('intval', array(
		get_option('change_password_page_id'),
	)));

	$current_url = escortwp_get_current_request_url();

	if ($member_pages && is_page($member_pages)) {
		if (!is_user_logged_in()) {
			escortwp_safe_template_redirect(escortwp_get_login_url($current_url), home_url('/'));
			return;
		}

		if (!escortwp_current_user_has_type('member') && !current_user_can('manage_options')) {
			escortwp_safe_template_redirect(escortwp_get_current_user_account_url(), home_url('/'));
		}
		return;
	}

	if ($escort_pages && is_page($escort_pages)) {
		if (!is_user_logged_in()) {
			escortwp_safe_template_redirect(escortwp_get_login_url($current_url), home_url('/'));
			return;
		}

		if (!escortwp_current_user_has_type($taxonomy_profile_url) && !current_user_can('manage_options')) {
			escortwp_safe_template_redirect(escortwp_get_current_user_account_url(), home_url('/'));
		}
		return;
	}

	if ($logged_only_pages && is_page($logged_only_pages) && !is_user_logged_in()) {
		escortwp_safe_template_redirect(escortwp_get_login_url($current_url), home_url('/'));
	}
}
add_action('template_redirect', 'escortwp_enforce_frontend_account_access', 2);

function escortwp_get_current_request_url() {
	$request_uri = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '/';
	$request_uri = $request_uri ? $request_uri : '/';

	$path = $request_uri;
	$query_string = '';
	if (strpos($request_uri, '?') !== false) {
		list($path, $query_string) = explode('?', $request_uri, 2);
		$query_string = $query_string !== '' ? '?'.$query_string : '';
	}

	return home_url($path).$query_string;
}

function escortwp_get_supported_registration_plan_intents() {
	return array('premium', 'featured_boost');
}

function escortwp_get_registration_plan_intent($raw_intent = '') {
	$intent = sanitize_key((string) $raw_intent);
	if (!in_array($intent, escortwp_get_supported_registration_plan_intents(), true)) {
		return '';
	}

	return $intent;
}

function escortwp_get_escort_registration_url_with_intent($plan_intent = '') {
	$base_url = get_option('escort_reg_page_id') ? get_permalink(get_option('escort_reg_page_id')) : home_url('/');
	$plan_intent = escortwp_get_registration_plan_intent($plan_intent);

	if (!$plan_intent) {
		return $base_url;
	}

	return add_query_arg('plan_intent', $plan_intent, $base_url);
}

function escortwp_get_escort_plan_redirect_url($plan_intent = '') {
	$base_url = get_option('escort_edit_personal_info_page_id') ? get_permalink(get_option('escort_edit_personal_info_page_id')) : escortwp_get_current_user_account_url();
	$plan_intent = escortwp_get_registration_plan_intent($plan_intent);

	if (!$plan_intent) {
		return $base_url;
	}

	return add_query_arg(
		array(
			'start_plan' => $plan_intent,
			'from_registration' => 1,
		),
		$base_url
	);
}

function escortwp_safe_template_redirect($target_url, $fallback_url = '') {
	if (escortwp_is_customizer_preview_request()) {
		return false;
	}

	$target_url = $target_url ? $target_url : $fallback_url;
	$target_url = $target_url ? $target_url : home_url('/');
	$current_url = escortwp_get_current_request_url();

	if (untrailingslashit($target_url) === untrailingslashit($current_url)) {
		return false;
	}

	wp_safe_redirect($target_url);
	exit;
}


function get_first_image($id, $s = "1") {
	global $thumb_sizes;
	$w = $thumb_sizes[$s][0]; //width
	$h = $thumb_sizes[$s][1]; //height

	$main_image_id = get_post_meta($id, "main_image_id", true);
	$upload_folder = get_post_meta($id, "upload_folder", true);
	if (wp_get_attachment_image_src($main_image_id, 'full')) {
		$imgurl = wp_get_attachment_image_src($main_image_id, 'full');
		$imgurl = $imgurl[0];
	} else {
		global $wpdb;
		$photos = get_children(array( 'post_parent' => $id, 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => 'ASC', 'orderby' => 'ID', 'numberposts' => '1' ));
		$photos = reset($photos);
		if ($photos) {
			$main_image_id = $photos->ID;
			update_post_meta(get_the_ID(), "main_image_id", $main_image_id);
			$imgurl = wp_get_attachment_image_src($main_image_id, 'full');
			$imgurl = $imgurl[0];
		} else {
			$no_image = "no-image.png";
			if($s == "2") { $no_image = "no-image.png"; }
			$imgurlth = get_bloginfo("template_url")."/i/".$no_image;
			return $imgurlth;
		}
	}

	$explode_url = explode("wp-content", $imgurl);
	$photo_url = explode(".", $explode_url[1]);
	$extension = $photo_url[count($photo_url)-1];
	unset($photo_url[count($photo_url)-1]);
	$imgurlth = "wp-content".implode(".", $photo_url)."-".$w."x".$h.".".strtolower($extension);

	if (!file_exists(ABSPATH.$imgurlth)) {
		$image = wp_get_image_editor(ABSPATH."wp-content".$explode_url[1]);
		if ( !is_wp_error($image) ) {
    		$image->resize( $w, $h, true );
    		$image->save(ABSPATH.$imgurlth);
		}
	}

	$imgurlth = site_url()."/".$imgurlth;
	return $imgurlth;
}



function get_escort_rating($id, $reviewcount="") {
	$args = array(
		'post_type' => 'review',
		'posts_per_page' => '-1',
		'meta_query' => array( array('key' => 'escortid', 'value' => $id, 'compare' => '=', 'type' => 'NUMERIC') )
	);
	$q = new WP_Query( $args );
	if ( $q->have_posts() ) {
		$rating = array();
		foreach ($q->posts as $post) {
			$rating[] = get_post_meta($post->ID, "rateescort", true);
		}
	}
	if(!isset($rating)) $rating = array();
	$num = (count($rating) == 0) ? "0" : array_sum($rating) / count($rating);

	if ($reviewcount == true) {
		return $q->post_count;
	} else {
		return str_replace(".", "", round_to_half($num));
	}
}



function get_agency_rating($id, $reviewcount="") {
	$args = array(
		'post_type' => 'review',
		'posts_per_page' => '-1',
		'meta_query' => array( array('key' => 'agencyid', 'value' => $id, 'compare' => '=', 'type' => 'NUMERIC') )
	);
	$rating = array();
	$q = new WP_Query( $args );
	if ( $q->have_posts() ) {
		$rating = array();
		foreach ($q->posts as $post) {
			$rating[] = get_post_meta($post->ID, "rateagency", true);
		}
	}

	$num = count($rating) == 0 ? "0" : array_sum($rating) / count($rating);

	if($reviewcount == true) {
		return $q->post_count;
	} else {
		return str_replace(".", "", round_to_half($num));
	}
}

function round_to_half($num) {
	if ($num >= ($half = ($ceil = ceil($num))- 0.5) + 0.25) {
		return $ceil;
	} else if ($num < $half - 0.25) {
		return floor($num);
	} else {
		return $half;
	}
}



function get_escort_labels($id) {
	$escort_label = array();

	$post = get_post($id);
	$date = $post->post_date;
	$daysago = date("Y-m-d H:i:s", strtotime("-".get_option('newlabelperiod')." days"));
	if ($date > $daysago) { $escort_label[] = '<span class="label label-new rad3 pinkdegrade">'.__('NEW','escortwp').'</span>'; }

	if (get_post_status($id) == "private") { $escort_label[] = '<span class="label label-private rad3 reddegrade">'.__('PRIVATE','escortwp').'</span>'; }

	$verified = get_post_meta($id, "verified", true);
	if ($verified == "1") { $escort_label[] = '<span class="label label-verified rad3 greendegrade">'.__('VERIFIED','escortwp').'</span>'; }

	$featured = get_post_meta($id, "featured", true);
	if ($featured == "1") { $escort_label[] = '<span class="label label-featured rad3 pinkdegrade">'.__('FEATURED','escortwp').'</span>'; }

	$escort_label[] = show_online_label_html($post->post_author);

	if($escort_label) {
		return '<span class="labels">'.implode('<div class="clear"></div>', array_filter($escort_label)).'</span>';
	}
}

function get_featured_escort_labels($id) {
	$escort_label = "";

	$verified = get_post_meta($id, "verified", true);
	if ($verified == "1") { $escort_label .= '<span class="verified greendegrade rad3">'.__('VERIFIED','escortwp').'</span>'; }

	$post = get_post($id);
	$date = $post->post_date;
	$daysago = date("Y-m-d H:i:s", strtotime("-".get_option('newlabelperiod')." days"));
	if ($date > $daysago) { $escort_label .= '<span class="new pinkdegrade rad3">'.__('NEW','escortwp').'</span>'; }
	            
	if($escort_label) {
		echo '<span class="labels l">'.$escort_label.'</span>';
	}
	return $escort_label;
}

function show_post_count($id) {
	global $wpdb, $taxonomy_profile_url;
	$sql = $wpdb->prepare("SELECT COUNT(ID) FROM `".$wpdb->posts."` WHERE `post_status` = 'publish' AND `post_type` = '".$taxonomy_profile_url."' AND `post_author`= %d", $id);
	$posts = $wpdb->get_var($sql);
	return $posts;
}

function did_user_post_review($user_id, $escort_id) {
	$args = array(
		'post_type' => 'review',
		'posts_per_page' => '1',
		'author' => $user_id,
		'meta_query' => array(
			'relation' => 'OR',
			array('key' => 'escortid', 'value' => $escort_id, 'compare' => '=', 'type' => 'NUMERIC'),
			array('key' => 'agencyid', 'value' => $escort_id, 'compare' => '=', 'type' => 'NUMERIC')
		)
	);
	$q = query_posts($args);
	if(count($q) > 0) {
		return true;
	} else {
		return false;
	}
}


//send email to escort when a review is published
function send_email_when_review_is_saved($post_id) {
	$email_sent = get_post_meta($post_id, 'email_sent', true);
	if ($email_sent != "yes") {
		$review_data = get_post($post_id);
		$escort_id = get_post_meta($post_id, 'escortid', true);
		$escort_data = get_post($escort_id);
		$escort_author = $escort_data->post_author;
		$escort_info = get_userdata($escort_author);
		$escort_email = $escort_info->user_email;
		$review_url = get_permalink($post_id);
		if ($review_data->post_type == "review" && $review_data->post_status == 'publish' && $escort_id > 1) {
			$body = __('Hello','escortwp').',<br /><br />
'.__('Someone added a new review to your profile','escortwp').'.<br />'.__('To read it please click the link below','escortwp').':<br />
'.$review_url;
			if($randomly_generated_data != "randomly_generated_data") {
				dolce_email(null, null, $escort_email, __('You have a new review on','escortwp')." ".get_option("email_sitename"), $body);
			}
			update_post_meta($post_id, 'email_sent', 'yes');
		}
	}
}
add_action('save_post', 'send_email_when_review_is_saved',10,2);

//add our own custom post types to the rss feed
function dolce_rssfeed($rss) {
	global $taxonomy_profile_url, $taxonomy_agency_url;
	if (isset($rss['feed']) && !isset($rss['post_type'])) {
		$rss['post_type'] = array($taxonomy_profile_url, $taxonomy_agency_url, 'ad');
	}
	return $rss;
}
add_filter('request', 'dolce_rssfeed');


//get available language list
function get_langs_list($lang) {
	$dir = get_template_directory()."/lang/";
   	if ($dh = opendir($dir)) {
       	while (($file = readdir($dh)) !== false) {
			if ($file != "." && $file != ".." && substr($file, -3, 3) == "php" && filetype($dir.$file) == "file") {
				$langs[] = preg_replace("/([^a-zA-Z0-9])/", "", str_replace(".php", "", $file));
			}
        }
   	    closedir($dh);
    }

    if($langs) {
	    sort($langs);
	    foreach ($langs as $key => $file) {
			$selected = ($file == $lang) ? ' selected="selected"' : '';
			echo '<option value="'.$file.'"'.$selected.'>'.ucfirst(strtolower($file)).'</option>'."\n";
			unset($selected);
	    }
    }
}

function check_if_user_has_validated_his_email() {
	global $taxonomy_profile_name, $taxonomy_profile_url, $taxonomy_agency_name, $taxonomy_agency_url;
	// check if the user has clicked the validation link
	if(isset($_GET['ekey'])) {
		global $wpdb;
		$ekey = preg_replace("/([^a-zA-Z0-9])/", "", sanitize_text_field(wp_unslash($_GET['ekey'])));
		$user_id = $wpdb->get_var($wpdb->prepare("SELECT `user_id` FROM `".$wpdb->usermeta."` WHERE `meta_key` = 'emailhash' AND `meta_value` = %s LIMIT 1", $ekey));
		$user_info = get_userdata($user_id);
		if($user_id) {
			delete_user_meta( $user_id, "emailhash", $ekey );
			delete_user_meta( $user_id, "last_email_validation_sent" );

			$user_type = get_option("escortid".$user_id);
			if($user_type == $taxonomy_agency_url) {
				$agency_post_id = get_option("agencypostid".$user_id);
				// if the admin has choosen to activate the profiles manually
				$post_status = "publish";
				if(get_option("manactivagprof") == "1" || payment_plans('agreg','price')) {
					$post_status = "private";
				}
				$post_agency = array( 'ID' => $agency_post_id, 'post_status' => $post_status );
				wp_update_post( $post_agency );

				// send email to agency
				$body = __('Hello','escortwp').' '.$user_info->display_name.'<br /><br />
'.__('Your account is now active on','escortwp').' '.get_option("email_sitename").'<br /><br />
'.__('Account information','escortwp').':<br />
'.__('type','escortwp').': <b>'.$taxonomy_agency_name.'</b><br />
'.__('username','escortwp').': <b>'.$user_info->user_login.'</b><br />
'.__('password','escortwp').': <b>('.__('hidden','escortwp').')</b><br /><br />
'.__('You can view your account here','escortwp').':<br />
<a href="'.get_permalink($agency_post_id).'">'.get_permalink($agency_post_id).'</a>';
				dolce_email("", "", $user_info->user_email, __('Welcome to','escortwp')." ".get_option("email_sitename"), $body);


				// send email to admin
				$body = __('Hello','escortwp').',<br /><br />
'.sprintf(esc_html__('A new %s has registered on','escortwp'),$taxonomy_agency_name).' '.get_option("email_sitename").':<br /><br />
'.__('Account information','escortwp').':<br />
'.__('username','escortwp').': <b>'.$user_info->user_login.'</b><br />
'.__('password','escortwp').': <b>('.__('hidden','escortwp').')</b><br /><br />
'.__('You can view the account here','escortwp').':<br />
<a href="'.get_permalink($agency_post_id).'">'.get_permalink($agency_post_id).'</a>';
				if (get_option("ifemail2") == "1") {
					dolce_email(null, null, get_bloginfo("admin_email"), sprintf(esc_html__('New %s registration on','escortwp'),$taxonomy_agency_name)." ".get_option("email_sitename"), $body);
				}
			} elseif ($user_type == $taxonomy_profile_url) {
				$escort_post_id = get_option("escortpostid".$user_id);
				$post_status = "publish";
				if(get_option("manactivindescprof") == "1" || payment_plans('indescreg','price')) {
					$post_status = "private";
				}
				$post_escort = array( 'ID' => $escort_post_id, 'post_status' => $post_status );
				wp_update_post($post_escort);

				// send email to escort
				$body = __('Hello','escortwp').' '.$user_info->display_name.'<br /><br />
'.__('Your account is now active on','escortwp').' '.get_option("email_sitename").'.<br /><br />
'.__('Account information','escortwp').':<br />
'.__('type','escortwp').': <b>'.sprintf(esc_html__('independent %s','escortwp'),$taxonomy_profile_name).'</b><br />
'.__('username','escortwp').': <b>'.$user_info->user_login.'</b><br />
'.__('password','escortwp').': <b>('.__('hidden','escortwp').')</b><br /><br />
'.__('You can view your account here','escortwp').':<br />
<a href="'.get_permalink($escort_post_id).'">'.get_permalink($escort_post_id).'</a>';
				dolce_email("", "", $user_info->user_email, __('Welcome to','escortwp')." ".get_option("email_sitename"), $body);

				// send email to admin
				$body = __('Hello','escortwp').',<br /><br />
'.sprintf(esc_html__('A new %s has been added on','escortwp'),$taxonomy_profile_name).' '.get_option("email_sitename").':<br /><br />
'.__('Account information','escortwp').':<br />
'.__('type','escortwp').': <b>'.sprintf(esc_html__('independent %s','escortwp'),$taxonomy_profile_name).'</b><br />
'.__('username','escortwp').': <b>'.$user_info->user_login.'</b><br />
'.__('password','escortwp').': <b>('.__('hidden','escortwp').')</b><br /><br />
'.__('You can view the account here','escortwp').':<br />
<a href="'.get_permalink($escort_post_id).'">'.get_permalink($escort_post_id).'</a>';
				if (get_option("ifemail3") == "1") {
					dolce_email(null, null, get_bloginfo("admin_email"), sprintf(esc_html__('New %s on','escortwp'),$taxonomy_profile_name)." ".get_option("email_sitename"), $body);
				}
			} elseif ($user_type == "member") {
				// send email to member
				$body = __('Hello','escortwp').' '.$user_info->display_name.'<br /><br />
'.__('Your account is now active on','escortwp').' '.get_option("email_sitename").'.<br /><br />
'.__('Account information','escortwp').':<br />
'.__('type','escortwp').': <b>'.__('member','escortwp').'</b><br />
'.__('username','escortwp').': <b>'.$user_info->user_login.'</b><br />
'.__('password','escortwp').': <b>('.__('hidden','escortwp').')</b>';
				dolce_email("", "", $user_info->user_email, __('Welcome to','escortwp')." ".get_option("email_sitename"), $body);

				// send email to admin
				$body = __('Hello','escortwp').',<br /><br />
'.__('A new member has registered on','escortwp').' '.get_option("email_sitename").':<br /><br />
'.__('Account information','escortwp').':<br />
'.__('type','escortwp').': <b>'.__('member','escortwp').'</b><br />
'.__('username','escortwp').': <b>'.$user_info->user_login.'</b><br />
'.__('password','escortwp').': <b>('.__('hidden','escortwp').')</b>';
				if (get_option("ifemail4") == "1") {
					dolce_email(null, null, get_bloginfo("admin_email"), __('New member registration on','escortwp')." ".get_option("email_sitename"), $body);
				}
			}
			echo '<div class="ok rad5">'.__('Thank you for verifying your email address. Your account has been activated.','escortwp').'</div>';
		}
	} elseif(is_user_logged_in()) {
		$current_user = wp_get_current_user();
		$new_email = '';
		$new_email_err = '';

		if(isset($_POST['action']) && $_POST['action'] == "change_email_address") {
			$new_email = sanitize_email(isset($_POST['email_addr']) ? wp_unslash($_POST['email_addr']) : '');
			$new_email_err = "";
			if (empty($_POST['escortwp_change_email_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['escortwp_change_email_nonce'])), 'escortwp_change_email_address')) {
				$new_email_err .= __('NÃ£o foi possÃ­vel validar sua solicitaÃ§Ã£o. Atualize a pÃ¡gina e tente novamente.', 'escortwp')."<br />";
			}
			if (!$new_email) { $new_email_err .= __('Informe um e-mail vÃ¡lido.', 'escortwp')."<br />"; } else {
				if (!is_email($new_email)) { $new_email_err .= __('O e-mail informado parece invÃ¡lido.', 'escortwp')."<br />"; }
				$user_info = get_userdata($current_user->ID);
				if (email_exists($new_email) && $new_email != $user_info->user_email) {
					$new_email_err .= __('Este e-mail jÃ¡ estÃ¡ em uso. Tente outro endereÃ§o.', 'escortwp')."<br />";
				}
			}

			if(!$new_email_err) {
				wp_update_user(array ('ID' => $current_user->ID, 'user_email' => $new_email));
				$current_user = wp_get_current_user();
				unset($new_email);
				$ok = __('Seu e-mail foi atualizado com sucesso.', 'escortwp');
				$resend_email = "ok";
			}
		}

		if(escortwp_should_show_email_validation_notice($current_user->ID)) {
			echo '<div class="bodybox rad5 registrationcomplete registrationcomplete--dismissible" data-validation-user="'.(int) $current_user->ID.'">';
			echo '<button type="button" class="registrationcomplete-close" aria-label="'.esc_attr__('Fechar aviso', 'escortwp').'"><span class="icon icon-cancel"></span></button>';
			echo "<div class='registrationcomplete-title'>".__('Confirme seu e-mail', 'escortwp')."</div>";
			if(isset($ok)) {
				echo '<div class="ok rad25" style="display: inline-block; padding: 5px 20px">'.$ok.'</div><div class="clear10"></div>';
			}
			echo '<p class="registrationcomplete-copy">'.__('Enviamos um link de confirmação para o e-mail cadastrado. Valide esse endereço para liberar todos os recursos da conta.', 'escortwp').'</p>';
			echo '<div class="clear15"></div>';
			echo '<div class="send-validation-email-button-preloader hide"></div>';
			echo '<span id="resendvalidationlink" class="greenbutton rad25">'.__('Reenviar e-mail de confirmação', 'escortwp').'</span><div class="resendvalidationlink-message hide"></div>'."<br />";
			echo '<div class="clear15"></div>';
			?>

			<div class="change-email-address <?=$new_email_err ? " hide" : ""?>"><?=__('Não recebeu o e-mail?', 'escortwp')?><br /><div class="change-email-button greenbutton rad25"><?=__('Alterar endereço de e-mail', 'escortwp')?></div></div>
			<?php
			if($new_email_err) {
				echo '<div class="err rad25" style="display: inline-block; padding: 5px 20px">'.$new_email_err.'</div><div class="clear"></div>';
			}
			?>
			<form action="" method="post" class="change-email-address-form form-styling"<?=$new_email_err ? " style='display: inline-block'" : ""?>>
				<input type="hidden" name="action" value="change_email_address" />
				<?php wp_nonce_field('escortwp_change_email_address', 'escortwp_change_email_nonce'); ?>
			    <div class="form-label col100">
					<label for="email_addr"><?php _e('Novo e-mail:', 'escortwp'); ?></label>
				</div>
				<div class="form-input col100">
			    	<input type="text" name="email_addr" id="email_addr" class="input longinput" value="<?=$new_email?>" required />
				</div><div class="clear10"></div>
				<input type="submit" name="submit" value="<?=__('Salvar e-mail', 'escortwp')?>" placeholder="<?=__('endereÃ§o de e-mail', 'escortwp')?>" class="greenbutton rad25" />
			</form>
			<?php

			echo '</div>';
    		echo '<div class="clear"></div>';
?>
			<script type="text/javascript">
				jQuery(document).ready(function($) {
					var noticeWrapper = $('.registrationcomplete--dismissible');
					if (noticeWrapper.length && window.sessionStorage) {
						var noticeKey = 'escortwp-validation-notice-' + noticeWrapper.data('validation-user');
						if (sessionStorage.getItem(noticeKey) === 'hidden') {
							noticeWrapper.hide();
						}

						noticeWrapper.find('.registrationcomplete-close').on('click', function(){
							noticeWrapper.slideUp(180);
							sessionStorage.setItem(noticeKey, 'hidden');
						});
					}

					function click_resend_button(button) {
						button.hide();
						$('.send-validation-email-button-preloader').show();
						$.ajax({
							type: "GET",
							url: "<?php bloginfo('template_url'); ?>/ajax/resend-validation-link.php?time=<?php echo time(); ?>",
							data: { escortwp_nonce: window.escortwpAjax ? window.escortwpAjax.nonce : '' },
							success: function(data){
								$('.send-validation-email-button-preloader').hide();
								$('.resendvalidationlink-message').html(data).fadeIn("slow").delay('5000').fadeOut("slow",function(){
									$('#resendvalidationlink').show();
								});
							}
						});
					}

					$('#resendvalidationlink').on('click', function(){
						click_resend_button($(this));
					});

					<?php if(isset($ok)) { ?>
						click_resend_button($('#resendvalidationlink'));
					<?php } ?>
				});
			</script>
			<?php
		}
	}
} // check_if_user_has_validated_his_email()

//check unverified users
time_check_unverified();
function time_check_unverified() {
	$time = get_option('time_check_unverified');
	if(!$time || $time < time()) {
		update_option("time_check_unverified", strtotime("+1 day 3:10:00"));
		check_unverified_users();
	}
}

//search for unverified users and delete them
function check_unverified_users() {
	global $wpdb, $taxonomy_agency_url, $taxonomy_profile_url;
	$users = $wpdb->get_col("SELECT `user_id` FROM `$wpdb->usermeta` WHERE `meta_key` = 'emailhash'");
	if(count($users) > 0) {
		foreach($users as $user_id) {
			$user_info = get_userdata($user_id);
			$user_registered = $user_info->user_registered;
			$user_registered = strtotime($user_registered);
			if($user_registered < strtotime("-2 days")) {
				$user_type = get_option("escortid".$user_id);
				if($user_type == $taxonomy_agency_url) {
					$agency_post_id = get_option("agencypostid".$user_id);
					wp_delete_post( $agency_post_id, true );
					delete_option("agencypostid".$user_id);
				} elseif ($user_type == $taxonomy_profile_url) {
					$escort_post_id = get_option("escortpostid".$user_id);
					wp_delete_post( $escort_post_id, true );
					delete_option("escortpostid".$user_id);
				} elseif ($user_type == "member") {
					//do nothing
				}
				include_once(ABSPATH."wp-admin/includes/user.php");
				wp_delete_user((int) $user_id);
				delete_option("escortid".$user_id);
			}
		}
	}
}





//check expired ads
function time_check_expired() {
	$time = get_option('time_check_expired');
	if(!$time || $time < time()) {
		update_option("time_check_expired", strtotime("+1 day 3:00:00"));
		check_expired();
	}
}

function check_expired() {
	global $wpdb, $taxonomy_profile_name_plural, $taxonomy_profile_url, $taxonomy_agency_name, $taxonomy_profile_name;
	include_once(ABSPATH."wp-admin/includes/user.php");

	if(function_exists('escortwp_expire_due_featured_boosts')) {
		escortwp_expire_due_featured_boosts();
	}

	// check for expired profiles/tours/upgrades

	// for expired tours
	$end = current_time('timestamp') - 60*60*24*2; // delete tours 2 days after they have expired
	$tours_args = array(
		'post_type' => 'tour',
		'meta_query' => array(
			array(
				'key' => 'end',
				'value' => $end,
				'compare' => '<=',
				'type' => 'NUMERIC'
			)
		),
		'posts_per_page' => '-1'
	);
	$tours = new WP_Query($tours_args);
	foreach($tours->posts as $tour) { wp_delete_post($tour->ID, true ); }

	// for premium status
	$expired_premium = $wpdb->get_col("SELECT `post_id` FROM `".$wpdb->postmeta."` WHERE `meta_key` = 'premium_expire' AND `meta_value` < '".time()."'");
	foreach($expired_premium as $id) {
		update_post_meta($id, "premium", "0");
		delete_post_meta($id, "premium_since");
		delete_post_meta($id, "premium_txn_id");
		delete_post_meta($id, "premium_expire");
		delete_post_meta($id, "premium_expire_notice");
		if(function_exists('escortwp_get_registration_plan_key_for_post') && function_exists('escortwp_sync_post_plan_state_from_legacy')) {
			$fallback_plan_key = escortwp_get_registration_plan_key_for_post($id);
			if($fallback_plan_key) {
				escortwp_sync_post_plan_state_from_legacy($id, $fallback_plan_key);
			}
		}
		$temp_post = get_post($id); $post_author = $temp_post->post_author;
		$email = $wpdb->get_var("SELECT `user_email` FROM `".$wpdb->users."` WHERE `ID`='".$post_author."'");
		if(get_option("escortid".$post_author) == $taxonomy_profile_url) {
			$body = __('Hello','escortwp').',<br /><br />
'.__('Your premium status has expired and it has been removed from your profile.','escortwp').'.<br />'.__('You can purchase a premium status again at any time by visiting your profile page','escortwp').':<br />
<a href="'.get_permalink($id).'">'.get_permalink($id).'</a>';
		} else {
			$body = __('Hello','escortwp').',<br /><br />
'.sprintf(esc_html__('The premium status for one of your %s has expired and has been removed from their profile.','escortwp'),$taxonomy_profile_name_plural).'.<br />'.__('If you would like to purchase a premium status again then you can do so by visiting the profile page here','escortwp').':<br />
<a href="'.get_permalink($id).'">'.get_permalink($id).'</a>';
		}
		dolce_email(null, null, $email, __('Expiration notice from','escortwp')." ".get_option("email_sitename"), $body);
	}


	// for featured status
	$expired_featured = $wpdb->get_col("SELECT `post_id` FROM `".$wpdb->postmeta."` WHERE `meta_key` = 'featured_expire' AND `meta_value` < '".time()."'");
	foreach($expired_featured as $id) {
		if(get_post_meta($id, 'escortwp_featured_source', true) == 'boost' && function_exists('escortwp_expire_due_featured_boosts')) {
			escortwp_expire_due_featured_boosts($id);
			continue;
		}

		update_post_meta($id, "featured", "0");
		delete_post_meta($id, "featured_txn_id");
		delete_post_meta($id, "featured_expire");
		delete_post_meta($id, "featured_expire_notice");
		$temp_post = get_post($id); $post_author = $temp_post->post_author;
		$email = $wpdb->get_var("SELECT `user_email` FROM `".$wpdb->users."` WHERE `ID`='".$post_author."'");
		if(get_option("escortid".$post_author) == $taxonomy_profile_url) {
			$body = __('Hello','escortwp').',<br /><br />
'.__('Your featured status has expired and it has been removed from your profile.','escortwp').'.<br />'.__('You can purchase a featured status again at any time by visiting the profile page','escortwp').':<br />
<a href="'.get_permalink($id).'">'.get_permalink($id).'</a>';
		} else {
			$body = __('Hello','escortwp').',<br /><br />
'.sprintf(esc_html__('The featured status for one of your %s has expired and has been removed from their profile.','escortwp'),$taxonomy_profile_name_plural).'.<br />'.__('You can purchase a featured status again at any time by visiting the profile page','escortwp').':<br />
<a href="'.get_permalink($id).'">'.get_permalink($id).'</a>';
		}
		dolce_email(null, null, $email, __('Expiration notice from','escortwp')." ".get_option("email_sitename"), $body);
	}

	// for VIP status
	$expired_vip = $wpdb->get_col("SELECT `user_id` FROM `".$wpdb->usermeta."` WHERE `meta_key` = 'vip_expire' AND `meta_value` < '".time()."'");
	foreach($expired_vip as $id) {
		delete_user_meta($id, "vip");
		delete_user_meta($id, "vip_txn_id");
		delete_user_meta($id, "vip_expire");
		delete_user_meta($id, "vip_expire_notice");
		$email = $wpdb->get_var("SELECT `user_email` FROM `".$wpdb->users."` WHERE `ID`='".$id."'");
		$body = __('Hello','escortwp').',<br /><br />
'.__('Your VIP status has expired and has been removed from your account.','escortwp').'.<br />'.__('You can purchase a VIP status again at any time by visiting our website','escortwp').':<br />
<a href="'.get_bloginfo('url').'/">'.get_bloginfo('url').'/</a>';
		dolce_email(null, null, $email, __('Expiration notice from','escortwp')." ".get_option("email_sitename"), $body);
	}


	// for agency profiles
	$expired_agency = $wpdb->get_col("SELECT `post_id` FROM `".$wpdb->postmeta."` WHERE `meta_key` = 'agency_expire' AND `meta_value` < '".time()."'");
	foreach($expired_agency as $id) {
		$temp_post = get_post($id);
		$post_author = $temp_post->post_author;
		$email = $wpdb->get_var("SELECT `user_email` FROM `".$wpdb->users."` WHERE `ID`='".$post_author."'");
		delete_post_meta($id, 'agency_expire');

		if(payment_plans('agreg','exp') == "1") {
			delete_agency($id);

			$body = __('Hello','escortwp').',<br /><br />
'.sprintf(esc_html__('Your %s profile has expired and has been deleted from our website.','escortwp'),$taxonomy_agency_name).'.<br />'.sprintf(esc_html__('If you had any %s in your profile they have been removed too.','escortwp'),$taxonomy_profile_name_plural).'.<br />'.__('You can create another account at anytime by visiting our website','escortwp').':<br />
<a href="'.get_bloginfo('url').'/">'.get_bloginfo('url').'/</a>';
			dolce_email(null, null, $email, __('Profile remove from','escortwp')." ".get_option("email_sitename"), $body);
		} else {
			$user_escorts = $wpdb->get_col("SELECT `ID` FROM `".$wpdb->posts."` WHERE `post_author` = '".$post_author."' AND `post_type` = '".$taxonomy_profile_url."'");
			foreach($user_escorts as $escort_id) {
				wp_update_post(array('ID' => $escort_id, 'post_status' => 'private'));
				update_post_meta($escort_id, "needs_ag_payment", "1"); // requires agency payment
				if(function_exists('escortwp_sync_post_plan_state_from_legacy')) {
					escortwp_sync_post_plan_state_from_legacy($escort_id, 'agescortreg');
				}
			}

			wp_update_post(array('ID' => $id, 'post_status' => 'private'));
			if(payment_plans('agreg','price')) {
				update_post_meta($id, "needs_payment", "1"); // requires payment
			} else {
				update_post_meta($id, "notactive", "1"); // requires admin activation
			}
			if(function_exists('escortwp_sync_post_plan_state_from_legacy')) {
				escortwp_sync_post_plan_state_from_legacy($id, 'agreg');
			}

			$body = __('Hello','escortwp').',<br /><br />
'.sprintf(esc_html__('Your %s profile has expired and we have set your profile to private.','escortwp'),$taxonomy_agency_name).'.<br />'.sprintf(esc_html__('If you had any %s in your profile then they have been set to private too.','escortwp'),$taxonomy_profile_name_plural).'.<br />'.sprintf(esc_html__('Your profile or any %s profiles that you added will not be visible in our website until you pay your registration fee.','escortwp'),$taxonomy_profile_name).'<br />
<a href="'.get_bloginfo($id).'/">'.get_permalink($id).'/</a>';
			dolce_email(null, null, $email, __('Expiration notice from','escortwp')." ".get_option("email_sitename"), $body);
		}
	}


	// for escort profiles(independent or from agencies)
	$expired_escort = $wpdb->get_col("SELECT `post_id` FROM `".$wpdb->postmeta."` WHERE `meta_key` = 'escort_expire' AND `meta_value` < '".time()."'");
	foreach($expired_escort as $id) {
		$temp_post = get_post($id);
		$post_author = $temp_post->post_author;
		$email = $wpdb->get_var("SELECT `user_email` FROM `".$wpdb->users."` WHERE `ID`='".$post_author."'");
		$user_type = get_option("escortid".$post_author); // checking the user type before deleting the escort
		delete_post_meta($id, 'escort_expire');

		if($user_type == $taxonomy_profile_url) { // independent
			if(payment_plans('indescreg','exp') == "1") { // delete profile on expiration
				delete_profile($id); //delete the escort profile

				$body = __('Hello','escortwp').',<br /><br />
'.sprintf(esc_html__('Your %s profile has expired and has been deleted from our website.','escortwp'),$taxonomy_profile_name).'.<br />'.__('You can create another account at anytime by visiting our website','escortwp').':<br />
<a href="'.get_bloginfo('url').'/">'.get_bloginfo('url').'/</a>';
				dolce_email(null, null, $email, __('Expiration notice from','escortwp')." ".get_option("email_sitename"), $body);
			} else {
				wp_update_post(array('ID' => $id, 'post_status' => 'private'));

				if(payment_plans('indescreg','price')) {
					update_post_meta($id, "needs_payment", "1"); // requires payment
				} else {
					update_post_meta($id, "notactive", "1"); // requires payment
				}
				if(function_exists('escortwp_sync_post_plan_state_from_legacy')) {
					escortwp_sync_post_plan_state_from_legacy($id, 'indescreg');
				}

				$body = __('Hello','escortwp').',<br /><br />
'.sprintf(esc_html__('Your %s profile has expired and has been set to private.','escortwp'),$taxonomy_profile_name).'.<br />'.__('Your profile will not be visible in our website anymore, until you pay your registration fee.','escortwp').'<br />
<a href="'.get_bloginfo('url').'/">'.get_bloginfo('url').'/</a>';
				dolce_email(null, null, $email, __('Expiration notice from','escortwp')." ".get_option("email_sitename"), $body);
			}
		} else { // escort from agency
			if(payment_plans('agescortreg','exp') == "1") { // delete profile on expiration
				delete_profile($id); //delete the escort profile

				$body = __('Hello','escortwp').',<br /><br />
'.sprintf(esc_html__('An %s you added has expired and has been deleted from our website.','escortwp'),$taxonomy_profile_name).'.<br />'.sprintf(esc_html__('%s name','escortwp'),ucfirst($taxonomy_profile_name)).':<br />
'.$temp_post->post_title.'<br /><br />
'.__('Website','escortwp').':<br /><a href="'.get_bloginfo('url').'/">'.get_bloginfo('url').'/</a>';
				dolce_email(null, null, $email, __('Expiration notice from','escortwp')." ".get_option("email_sitename"), $body);
			} else {
				wp_update_post(array('ID' => $id, 'post_status' => 'private'));
				if(payment_plans('agescortreg','price')) {
					update_post_meta($id, "needs_payment", "1"); // requires payment
				} else {
					update_post_meta($id, "notactive", "1"); // requires admin activation
				}
				if(function_exists('escortwp_sync_post_plan_state_from_legacy')) {
					escortwp_sync_post_plan_state_from_legacy($id, 'agescortreg');
				}

				$body = __('Hello','escortwp').',<br /><br />
'.sprintf(esc_html__('An %1$s you added has expired and has been set to private. This profile will not be shown on our website until you pay the registration fee for the %2$s.','escortwp'),$taxonomy_profile_name,$taxonomy_profile_name).'.<br />'.sprintf(esc_html__('%s name','escortwp'),ucfirst($taxonomy_profile_name)).':<br />
'.$temp_post->post_title.'<br /><br />
'.__('Website','escortwp').':<br /><a href="'.get_bloginfo('url').'/">'.get_bloginfo('url').'/</a>';
				dolce_email(null, null, $email, __('Expiration notice from','escortwp')." ".get_option("email_sitename"), $body);
			}
		}
	}
	//check for expired profiles END



	// send notice emails for profiles with soon to expire statuses
	// for premium status
	$soon_to_expire_premium = $wpdb->get_col("SELECT `post_id` FROM `".$wpdb->postmeta."` WHERE `meta_key` = 'premium_expire' AND `meta_value` < '".strtotime('+2 days')."'");
	foreach($soon_to_expire_premium as $id) {
		if(get_post_meta($id, "premium_expire_notice", true) != "1") {
			$temp_post = get_post($id);
			$post_author = $temp_post->post_author;
			$email = $wpdb->get_var("SELECT `user_email` FROM `".$wpdb->users."` WHERE `ID`='".$post_author."'");
			if(get_option("escortid".$post_author) == $taxonomy_profile_url) {
				$body = __('Hello','escortwp').',<br /><br />
'.__('Your premium status will expire very soon','escortwp').'.<br />'.__('If you want to renew your status please visit your profile page','escortwp').':<br />
<a href="'.get_permalink($id).'">'.get_permalink($id).'</a>';
			} else {
				$body = __('Hello','escortwp').',<br /><br />
'.sprintf(esc_html__('The premium status for one of your %s will expire very soon.','escortwp'),$taxonomy_profile_name_plural).'.<br />'.sprintf(esc_html__('If you want to renew this status please visit the %s profile page.','escortwp'),$taxonomy_profile_name).':<br />
<a href="'.get_permalink($id).'">'.get_permalink($id).'</a>';
			}
			dolce_email(null, null, $email, __('Expiration notice from','escortwp')." ".get_option("email_sitename"), $body);
			add_post_meta($id, "premium_expire_notice", "1", true);
		}
	}


	// for featured status
	$soon_to_expire_featured = $wpdb->get_col("SELECT `post_id` FROM `".$wpdb->postmeta."` WHERE `meta_key` = 'featured_expire' AND `meta_value` < '".strtotime('+2 days')."'");
	foreach($soon_to_expire_featured as $id) {
		if(get_post_meta($id, 'escortwp_featured_source', true) == 'boost') {
			continue;
		}

		if(get_post_meta($id, "featured_expire_notice", true) != "1") {
			$temp_post = get_post($id);
			$post_author = $temp_post->post_author;
			$email = $wpdb->get_var("SELECT `user_email` FROM `".$wpdb->users."` WHERE `ID`='".$post_author."'");
			if(get_option("escortid".$post_author) == $taxonomy_profile_url) {
				$body = __('Hello','escortwp').',<br /><br />
'.__('Your featured status will expire very soon.','escortwp').'.<br />'.__('If you want to renew your status please visit your profile page','escortwp').':<br />
<a href="'.get_permalink($id).'">'.get_permalink($id).'</a>';
			} else {
				$body = __('Hello','escortwp').',<br /><br />
'.sprintf(esc_html__('The featured status for one of your %s will expire very soon.','escortwp'),$taxonomy_profile_name_plural).'.<br />'.sprintf(esc_html__('If you want to renew this status please visit the %s profile page.','escortwp'),$taxonomy_profile_name).':<br />
<a href="'.get_permalink($id).'">'.get_permalink($id).'</a>';
			}
			dolce_email(null, null, $email, __('Expiration notice from','escortwp')." ".get_option("email_sitename"), $body);
			add_post_meta($id, "featured_expire_notice", "1", true);
		}
	}


	// for VIP status
	$soon_to_expire_vip = $wpdb->get_col("SELECT `user_id` FROM `".$wpdb->usermeta."` WHERE `meta_key` = 'vip_expire' AND `meta_value` < '".strtotime('+2 days')."'");
	foreach($soon_to_expire_vip as $id) {
		if(get_user_meta($id, "vip_expire_notice", true) != "1") {
			$email = $wpdb->get_var("SELECT `user_email` FROM `".$wpdb->users."` WHERE `ID`='".$id."'");
			$body = __('Hello','escortwp').',<br /><br />
'.__('Your VIP status will expire very soon.','escortwp').'.<br />'.__('If you want to renew your status please visit our website','escortwp').':<br />
<a href="'.get_bloginfo('url').'/">'.get_bloginfo('url').'/</a>';
			dolce_email(null, null, $email, __('Expiration notice from','escortwp')." ".get_option("email_sitename"), $body);
			add_user_meta($id, "vip_expire_notice", "1", true);
		}
	}


	// for agency profiles
	$soon_to_expire_agency = $wpdb->get_col("SELECT `post_id` FROM `".$wpdb->postmeta."` WHERE `meta_key` = 'agency_expire' AND `meta_value` < '".strtotime('+2 days')."'");
	foreach($soon_to_expire_agency as $id) {
		if(get_post_meta($id, "agency_expire_notice", true) != "1") {
			$temp_post = get_post($id);
			$post_author = $temp_post->post_author;
			$email = $wpdb->get_var("SELECT `user_email` FROM `".$wpdb->users."` WHERE `ID`='".$post_author."'");
			$body = __('Hello','escortwp').',<br /><br />
'.sprintf(esc_html__('Your %s profile will expire very soon.','escortwp'),$taxonomy_agency_name).'.<br />'.sprintf(esc_html__('If you do not want your profile to be removed from our website(along with any %s you might have added) please visit your profile page and renew it.','escortwp'),$taxonomy_profile_name_plural).':<br />
<a href="'.get_permalink($id).'">'.get_permalink($id).'</a>';
			dolce_email(null, null, $email, __('Expiration notice from','escortwp')." ".get_option("email_sitename"), $body);
			add_post_meta($id, "agency_expire_notice", "1", true);
		}
	}


	// for escort profiles(independent and from agencies)
	$soon_to_expire_escort = $wpdb->get_col("SELECT `post_id` FROM `".$wpdb->postmeta."` WHERE `meta_key` = 'escort_expire' AND `meta_value` < '".strtotime('+2 days')."'");
	foreach($soon_to_expire_escort as $id) {
		if(get_post_meta($id, "escort_expire_notice", true) != "1") {
			$temp_post = get_post($id);
			$post_author = $temp_post->post_author;
			$email = $wpdb->get_var("SELECT `user_email` FROM `".$wpdb->users."` WHERE `ID`='".$post_author."'");
			if(get_option("escortid".$post_author) == $taxonomy_profile_url) {
				$body = __('Hello','escortwp').',<br /><br />
'.sprintf(esc_html__('Your %s profile from our website will expire very soon.','escortwp'),$taxonomy_profile_name).'.<br />'.__('If you do not want your profile to be removed from our website please visit your profile page and renew it','escortwp').':<br />
<a href="'.get_permalink($id).'">'.get_permalink($id).'</a>';
			} else {
				$body = __('Hello','escortwp').',<br /><br />
'.sprintf(esc_html__('The profile for one of the %s you added will expire very soon.','escortwp'),$taxonomy_profile_name_plural).'.<br />'.__('If you do not want the profile to be deleted from our website please visit the profile page and renew it','escortwp').':<br />
<a href="'.get_permalink($id).'">'.get_permalink($id).'</a>';
			}
			dolce_email(null, null, $email, __('Expiration notice from','escortwp')." ".get_option("email_sitename"), $body);
			add_post_meta($id, "escort_expire_notice", "1", true);
		}
	}
} // check_expired()


function delete_profile($escort_id) {
	global $taxonomy_profile_url;
	$upload_folder = get_post_meta($escort_id, "upload_folder", true);
	$secret = get_post_meta($escort_id, "secret", true);
	$dirtodelete = ABSPATH."wp-content/uploads/".$upload_folder."/";

	$attachments = get_children(array('post_parent' => $escort_id, 'post_status' => 'inherit', 'post_type' => 'attachment'));
	foreach ($attachments as $attachment) {
		wp_delete_attachment($attachment->ID, 'true');
	}

	if (is_dir($dirtodelete)) {
		$objects = scandir($dirtodelete);
		foreach ($objects as $object) {
			if ($object != "." && $object != "..") {
				if (filetype($dirtodelete.$object) == "dir") {
					rmdir($dirtodelete.$object);
				} else {
					unlink($dirtodelete.$object);
				}
			}
		}
		reset($objects);
		rmdir($dirtodelete);
	} // delete directory and files

	//delete all tours
	$args = array(
		'post_type' => 'tour',
		'posts_per_page' => -1,
		'meta_query' => array( array('key' => 'belongstoescortid', 'value' => $escort_id, 'compare' => '=', 'type' => 'NUMERIC') )
	);
	query_posts( $args );
	if (have_posts()) :
		while ( have_posts() ) : the_post();
			wp_delete_post( get_the_ID(), true ); //delete post
		endwhile;
	endif;
	wp_reset_query();


	//delete all reviews
	$args = array(
		'post_type' => 'review',
		'posts_per_page' => -1,
		'meta_query' => array( array('key' => 'escortid', 'value' => $escort_id, 'compare' => '=', 'type' => 'NUMERIC') )
	);
	query_posts( $args );
	if (have_posts()) :
		while ( have_posts() ) : the_post();
			wp_delete_post( get_the_ID(), true ); //delete post
		endwhile;
	endif;
	wp_reset_query();

	$post = get_post($escort_id);
	delete_option("escortpostid".$escort_id);
	delete_option($secret);
	delete_option("agency".$secret);
	wp_delete_post( $escort_id, true ); //delete post
	if(get_option("escortid".$post->post_author) == $taxonomy_profile_url) {
		delete_option("escortid".$escort_id);
		include_once(ABSPATH."wp-admin/includes/user.php");
		wp_delete_user($post->post_author);
	}
}

function delete_agency($agency_id) {
	global $taxonomy_profile_url;
	$agency_profile = get_post($agency_id);
	$upload_folder = get_post_meta($agency_id, "upload_folder", true);
	$secret = get_post_meta($agency_id, "secret", true);
	$dirtodelete = ABSPATH."wp-content/uploads/".$upload_folder."/";

	//delete all profiles added by this agency
	$args = array(
		'post_type' => $taxonomy_profile_url,
		'posts_per_page' => -1,
		'author' => $agency_profile->post_author
	);
	query_posts( $args );
	if (have_posts()) :
	while ( have_posts() ) : the_post();
		delete_profile(get_the_ID());
	endwhile;
	endif;
	wp_reset_query();


	if (is_dir($dirtodelete)) {
		$objects = scandir($dirtodelete);
		foreach ($objects as $object) {
			if ($object != "." && $object != "..") {
				if (filetype($dirtodelete.$object) == "dir") {
					rmdir($dirtodelete.$object);
				} else {
					unlink($dirtodelete.$object);
				}
			}
		}
		reset($objects);
		rmdir($dirtodelete);
	} // delete directory and files

	delete_option($secret);
	delete_option("escortid".$agency_profile->post_author);
	delete_option("agencypostid".$agency_profile->post_author);

	wp_delete_post( $agency_id, true ); //delete post
	include_once(ABSPATH."wp-admin/includes/user.php");
	wp_delete_user($agency_profile->post_author);
}

// delete a member account
function escwp_delete_member() {
	if(!is_user_logged_in()) return false;

	$current_user = wp_get_current_user();
	$userid = $current_user->ID;
	$userstatus = get_option("escortid".$userid);
	if (isset($_POST['action']) && $_POST['action'] == 'member_delete_account' && $userstatus == "member") {
		include_once(ABSPATH."wp-admin/includes/user.php");
		wp_delete_user($userid);
		wp_redirect(get_bloginfo("url")); die();
	} // if admin
}
add_action('init', 'escwp_delete_member');

function dolce_pagination($total, $current="", $format="", $base="") {
	if ( $total > 1 ) {
		if(!$format) {
			$format = get_option('permalink_structure') ? 'page/%#%/' : '&page=%#%';
		}
		if(!$base) {
			$base = get_pagenum_link(1);
		}
		if(!(int)$current) { $current = "1"; }
		echo '<div class="escort-pagination">';
		echo paginate_links(array(
				'base' => $base . '%_%',
				'format' => $format,
				'total' => (int)$total,
				'current' => (int)$current,
				'end_size' => '2',
				'mid_size' => '2',
				'prev_text' => __('Previous','escortwp'),
				'next_text' => __('Next','escortwp'),
				'type' => 'list'
			));
		echo '</div>';
	}
}

function build_checkbox_edit_fields_page($value, $name, $position) {
	if($value == "1") {
		return '<input type="checkbox" '.build_name_for_checkbox_edit_fields_page($name, $position).' value="1" class="ios-checkbox" checked />';
	} elseif ($value == "2") {
		return '<input type="checkbox" '.build_name_for_checkbox_edit_fields_page($name, $position).' value="1" class="ios-checkbox" />';
	} elseif ($value == "3") {
		return __("YES",'escortwp');
	} elseif ($value == "4") {
		return __("NO",'escortwp');
	}
}
function build_name_for_checkbox_edit_fields_page($name, $position) {
	if($position == "1") {
		return 'name="'.$name.'showinreg" id="firstcheckbox'.$name.'"';
	} elseif ($position == "2") {
		return 'name="'.$name.'mandatory"';
	} elseif ($position == "3") {
		return 'name="'.$name.'useinsearch"';
	}
}

//is registration field mandatory
function ismand($name, $show = '') {
	$fields = get_option('regfieldsescort');
	if($fields[$name][2] == "1" || $fields[$name][2] == "3") {
		if($show) {
			return true;
		} else {
			echo '<i>*</i>';
		}
	}
}

//is field showing in reg page
function showfield($name) {
	$fields = get_option('regfieldsescort');
	if($fields[$name][1] == "1" || $fields[$name][1] == "3") {
		return true;
	} else {
		return false;
	}
}

//is field showing in search page
function insearch($name) {
	$fields = get_option('regfieldsescort');
	if($fields[$name][3] == "1" || $fields[$name][3] == "3") {
		return true;
	} else {
		return false;
	}
}


function get_reg_price($type, $free="") {
	if(!$type) { return false; }
	$pricecode = '';

	if(payment_plans($type,'price')) {
		$pricecode  =  '<span class="showprice showprice-'.$type.' rad3">';
		$pricecode .=  "<b>".format_price($type,'price')."</b>";
		if(payment_plans($type,'woo_product_id') && class_exists('WC_Subscriptions_Product') && get_post_meta(payment_plans($type,'woo_product_id'), '_subscription_price', true)) {
			$pricecode .=  "<small> / ".WC_Subscriptions_Product::get_period(payment_plans($type,'woo_product_id'))."</small>";
		} else {
			if(payment_plans($type,'duration')) {
				global $payment_duration_a;
				$pricecode .=  "<small>";
				$pricecode .=  " ".__('for','escortwp')." ";
				$pricecode .=  __($payment_duration_a[payment_plans($type,'duration')][0], 'escortwp');
				$pricecode .=  "</small>";
			}
		}

		$pricecode .=  "</span>";
	} else {
		if($free) { $pricecode =  '<span class="showprice showprice-'.$type.' rad3">'.__('Free','escortwp').'</span>'; }
	}

	return $pricecode;
}

function dolce_custom_menu() {
	register_nav_menus(array('header-menu' => 'Header Menu'));
}
add_action('init', 'dolce_custom_menu');

function closebtn($t=1) {
	if($t == "1")
		echo '<div class="rad25 redbutton closebtn r"><span class="label">'.__('Close','escortwp').'</span><span class="icon icon-cancel-circled r"></span></div>';

	if($t == "2")
		echo '<div class="closebtn_box rad25"><span class="icon icon-cancel-circled"></span></div>';
}

function get_current_url() {
	return esc_url(escortwp_get_current_request_url(), array('http', 'https'));
}

function upgrade_theme() {
	if(!get_option('is_theme_installed')) return false;

	global $theme_version;
	$revnr = get_option('revnr');

	if($revnr == $theme_version)
		return true;

	if($revnr < "200") {
		upgrade_theme_code('200');
	}

	if ($revnr < "220") {
		upgrade_theme_code('220');
	}
	if ($revnr < "230") {
		upgrade_theme_code('230');
	}
	if ($revnr < "300") {
		upgrade_theme_code('300');
	}
	if ($revnr < "350") {
		upgrade_theme_code('350');
	}
	if ($revnr < "360") {
		upgrade_theme_code('360');
	}

	update_option('revnr', $theme_version);

	return true;
}

function upgrade_theme_code($v) {
	switch ($v) {
		case '200':
				// adding new settings
				set_default_settings();
				update_option('generate_demo_data_alert', 'hide');

				// upgrading profile genders
				$args = array(
					'post_type' => 'escort', 'posts_per_page' => '-1',
					'meta_query' => array(
						array('key' => 'gender', 'value' => '3', 'compare' => '=')
					)
				);
				query_posts($args);
				if ( have_posts() ) :
					while ( have_posts() ) : the_post();
						update_post_meta(get_the_ID(), 'gender', '4');
					endwhile;
				endif;
				wp_reset_query();


				// add premium_since meta field to premium profiles otherwise the premium loops won't show any results
				$args = array(
					'post_type' => 'escort', 'posts_per_page' => '-1',
					'meta_query' => array( array('key' => 'premium', 'value' => '1', 'compare' => '=', 'type' => 'NUMERIC') )
				);
				$a = query_posts($args);
				if ( have_posts() ) :
					while ( have_posts() ) : the_post();
						update_post_meta(get_the_ID(), 'premium_since', get_the_time('U'));
					endwhile;
				endif;
				wp_reset_query();


				// upgrading jobs to ads
				$args = array('post_type' => 'job', 'posts_per_page' => '-1');
				query_posts($args);
				if ( have_posts() ) :
					global $wpdb;
					while ( have_posts() ) : the_post();
						set_post_type( get_the_ID(), 'ad');
					endwhile;
				endif;
				wp_reset_query();


				// upgrade reviews
				$args = array(
					'post_type' => 'review',
					'posts_per_page' => '-1',
					'meta_query' => array( array('key' => 'reviewfor', 'value' => 'escort', 'compare' => '=') ),
					'paged' => $paged
				);
				query_posts($args);
				if ( have_posts() ) :
					while ( have_posts() ) : the_post();
						update_post_meta(get_the_ID(), 'reviewfor', 'profile');
					endwhile;
				endif;
				wp_reset_query();


				update_option("taxonomy_profile_name", 'escort');
				update_option("taxonomy_profile_name_plural", 'escorts');
				update_option("taxonomy_profile_url", 'escort');
				update_option("settings_theme_genders", array('1', '2', '3', '4', '5'));
				update_option("taxonomy_agency_name", 'agency');
				update_option("taxonomy_agency_name_plural", 'agencies');
				update_option("taxonomy_agency_url", 'agency');
				update_option("taxonomy_location_url", 'escorts-from');

				// update page titles, urls and template files
				create_theme_pages();

				update_option('revnr', '200');
			break; // upgrade to 200

		case '220':
				global $escortregfields;
				update_option('newlabelperiod', '14');
				update_option('regfieldsescort', $escortregfields);
				update_option('revnr', '220');
			break;  // upgrade to 220

		case '230':
				global $taxonomy_profile_url, $escortregfields;
				update_option('regfieldsescort', $escortregfields);
				update_option('autoscrollheaderslider', '1');
				update_option('manactivclassads', '2');

				query_posts(array('post_type' => $taxonomy_profile_url, 'posts_per_page' => '-1'));
				if ( have_posts() ) :
					while ( have_posts() ) : the_post();
						if(get_post_meta(get_the_ID(), "upgraded_to_v230", true) != "yes") {
							update_post_meta(get_the_ID(), "ethnicity", get_post_meta(get_the_ID(), 'skincolor', true));
							delete_post_meta(get_the_ID(), 'skincolor');

							update_post_meta(get_the_ID(), "rate30min_incall", get_post_meta(get_the_ID(), 'rate30min', true));
							update_post_meta(get_the_ID(), "rate1h_incall", get_post_meta(get_the_ID(), 'rate1h', true));
							update_post_meta(get_the_ID(), "rate2h_incall", get_post_meta(get_the_ID(), 'rate2h', true));
							update_post_meta(get_the_ID(), "rate3h_incall", get_post_meta(get_the_ID(), 'rate3h', true));
							update_post_meta(get_the_ID(), "rate6h_incall", get_post_meta(get_the_ID(), 'rate6h', true));
							update_post_meta(get_the_ID(), "rate12h_incall", get_post_meta(get_the_ID(), 'rate12h', true));
							update_post_meta(get_the_ID(), "rate24h_incall", get_post_meta(get_the_ID(), 'rate24h', true));

							update_post_meta(get_the_ID(), "rate30min_outcall", get_post_meta(get_the_ID(), 'rate30min', true));
							update_post_meta(get_the_ID(), "rate1h_outcall", get_post_meta(get_the_ID(), 'rate1h', true));
							update_post_meta(get_the_ID(), "rate2h_outcall", get_post_meta(get_the_ID(), 'rate2h', true));
							update_post_meta(get_the_ID(), "rate3h_outcall", get_post_meta(get_the_ID(), 'rate3h', true));
							update_post_meta(get_the_ID(), "rate6h_outcall", get_post_meta(get_the_ID(), 'rate6h', true));
							update_post_meta(get_the_ID(), "rate12h_outcall", get_post_meta(get_the_ID(), 'rate12h', true));
							update_post_meta(get_the_ID(), "rate24h_outcall", get_post_meta(get_the_ID(), 'rate24h', true));
							update_post_meta(get_the_ID(), "upgraded_to_v230", 'yes');
						}
					endwhile;
				endif;
				wp_reset_query();

				update_option('revnr', '230');
				update_option('maximgupload', '20');
				update_option('maximguploadsize', '5');
			break;  // upgrade to 230

		case '300':
				global $height_a;
				query_posts(array('post_type' => $taxonomy_profile_url, 'posts_per_page' => '-1'));
				if ( have_posts() ) :
					while ( have_posts() ) : the_post();
						if(get_post_meta(get_the_ID(), "upgraded_to_v3", true) != "yes") {
							if($height_a[get_post_meta(get_the_ID(), "height", true)]) {
								update_post_meta(get_the_ID(), "height", $height_a[get_post_meta(get_the_ID(), "height", true)]);
								update_post_meta(get_the_ID(), "upgraded_to_v3", 'yes');
							}
						}
					endwhile;
				endif;
				wp_reset_query();
				update_option('revnr', '300');
			break;  // upgrade to 300

		case '350':
				global $taxonomy_profile_name, $taxonomy_agency_name;
				update_option('content_settings_page_id', get_option('hide_site_sections_page_id'));
				delete_option('hide_site_sections_page_id');

				$payment_plans = array(
					'indescreg' => array(
									'title' => array('Independent %s registration','taxonomy_profile_name'),
									'label' => array('Price to register as independent %s','taxonomy_profile_name'),
									'label_help' => array('keep empty for free registration',''),
									'price' => get_option("indescregprice"),
									'duration' => get_option("indescregduration"),
									'woo_product_id' => '',
									'woo_product_name' => array('Independent %s registration','taxonomy_profile_name'),
									'exp' => get_option("escexp"),
									'exp_text' => array('What happens on profile expiration?',''),
								),
					'agreg' => array(
									'title' => array('%s registration','taxonomy_agency_name'),
									'label' => array('Price to register as %s','taxonomy_agency_name'),
									'label_help' => array('keep empty for free registration',''),
									'price' => get_option("agregprice"),
									'duration' => get_option("agregduration"),
									'woo_product_id' => '',
									'woo_product_name' => array('%s registration','taxonomy_agency_name'),
									'exp' => get_option("agexp"),
									'exp_text' => array('What happens on profile expiration?',''),
								),
					'agescortreg' => array(
									'title' => array('%1$s adding %2$s','taxonomy_agency_name','taxonomy_profile_name'),
									'label' => array('Price for %1$s to add an %2$s','taxonomy_agency_name','taxonomy_profile_name'),
									'label_help' => array('keep empty for free registration',''),
									'price' => get_option("agescortregprice"),
									'duration' => get_option("agescortregduration"),
									'woo_product_id' => '',
									'woo_product_name' => array('Add new %s profile','taxonomy_profile_name'),
									'exp' => get_option("agescexp"),
									'exp_text' => array('What happens on profile expiration?',''),
								),
					'premium' => array(
									'title' => array('Premium options',''),
									'label' => array('Price to become a premium %s','taxonomy_profile_name'),
									'label_help' => array('keep empty to disable',''),
									'price' => get_option("premiumprice"),
									'duration' => get_option("premiumduration"),
									'woo_product_id' => '',
									'woo_product_name' => array('Upgrade profile to premium','taxonomy_profile_name'),
								),
					'featured' => array(
									'title' => array('Featured options',''),
									'label_help' => array('keep empty to disable',''),
									'label' => array('Price to become a featured %s','taxonomy_profile_name'),
									'price' => get_option("featuredprice"),
									'duration' => get_option("featuredduration"),
									'woo_product_id' => '',
									'woo_product_name' => array('Upgrade profile to featured','taxonomy_profile_name'),
								),
					'tours' => array(
									'title' => array('Tour options',''),
									'label' => array('Price to add a tour',''),
									'label_help' => array('keep empty for free tours',''),
									'price' => get_option("tourprice"),
									'woo_product_id' => '',
									'woo_product_name' => array('Add city tour','taxonomy_profile_name'),
								),
					'vip' => array(
									'title' => array('VIP Options',''),
									'label' => array('Price to become a VIP member',''),
									'label_help' => array('keep empty to disable',''),
									'price' => get_option("vipprice"),
									'duration' => get_option("vipduration"),
									'woo_product_id' => '',
									'woo_product_name' => array('Upgrade to VIP','taxonomy_profile_name'),
									'extra' => array(
													'hide_photos' => get_option("viphide1"),
													'hide_contact_info' => get_option("viphide2"),
													'hide_review_form' => get_option("viphide3"),
												),
								),
				);
				update_option('payment_plans', $payment_plans);

				global $escortregfields;
				update_option('newlabelperiod', '14');
				update_option('unregsendcontactform', '2');
				update_option("frontpageshowonline", '1');
				update_option("frontpageshowonlinecols", '2');
				update_option("hitcounter1", '1');
				update_option("hitcounter2", '1');
				update_option("hitcounter3", '1');

				$escortregfields = get_option('regfieldsescort');
				$new_escortregfields = array(
					'instagram' => array('Instagram','1','2','4'),
					'snapchat' => array('SnapChat','1','2','4'),
					'twitter' => array('Twitter','1','2','4'),
					'facebook' => array('Facebook','1','2','4'),
				);
				$escortregfields_final = insert_array_inside_another_array($escortregfields, 'website', $new_escortregfields);
				update_option('regfieldsescort', $escortregfields_final);
				create_theme_pages();
				update_option('revnr', '350');
			break;  // upgrade to 350

		case '360':
				update_option('watermark_position', 'cc');
				update_option('locationsliderpage', '1');
				update_option('revnr', '360');

				$pages = array(array('all_verified_profiles_page_id', 'verified-'.sanitize_title($taxonomy_profile_name_plural), 'Verified '.ucwords($taxonomy_profile_name_plural), 'all-profiles.php'));

				foreach($pages as $p) {
					$new_page = array(
						'post_author' => "1",
						'comment_status' => "closed",
						'ping_status' => "closed",
						'post_name' => $p[1], // slug
						'post_title' => $p[2], // title
						'post_status' => "publish",
						'post_type' => "page",
						'page_template'  => $p[3]
					);
					global $wpdb;
					if (get_option($p[0]) < 1) {
						// create page
						$current_lang = multilang_switch_language();
						$new_page_id = wp_insert_post( $new_page );
						multilang_switch_language($current_lang);
						if ($new_page_id && $new_page_id != "0") {
							update_option($p[0], $new_page_id);
							$wpdb->insert( $wpdb->postmeta, array( 'post_id' => $new_page_id, 'meta_key' => '_wp_page_template', 'meta_value' => $p[4] ), array( '%d', '%s', '%s' ) );
						}
					}
				} // foreach
			break;  // upgrade to 360

		default:
			break;
	}
} // upgrade_to_v2


function set_default_settings() {
	global $payment_plans;
	if(!get_option('dolce_sitelang')) update_option("dolce_sitelang", 'english');
	if(!get_option('secret_to_upload_site_logo')) update_option("secret_to_upload_site_logo", md5(rand(1, 999)));
	if(!get_option('showheaderslider')) update_option("showheaderslider", '1');
	if(!get_option('autoscrollheaderslider')) update_option("autoscrollheaderslider", '1');
	if(!get_option('headerslideritems')) update_option("headerslideritems", '10');
	if(!get_option('showheadersliderall')) update_option("showheadersliderall", '');
	if(!get_option('showheadersliderfront')) update_option("showheadersliderfront", '1');
	if(!get_option('showheaderslideresccat')) update_option("showheaderslideresccat", '');
	if(!get_option('showheadersliderescprof')) update_option("showheadersliderescprof", '');
	if(!get_option('showheaderslideragprof')) update_option("showheaderslideragprof", '');
	if(!get_option('showheaderslidersearch')) update_option("showheaderslidersearch", '');
	if(!get_option('showheadersliderct')) update_option("showheadersliderct", '');
	if(!get_option('showheadersliderrev')) update_option("showheadersliderrev", '');
	if(!get_option('showheadersliderads')) update_option("showheadersliderads", '');
	if(!get_option('showheadersliderads')) update_option("showheadersliderads", '');
	if(!get_option('hideunchedkedservices')) update_option("hideunchedkedservices", '2');

	if(!get_option('frontpageshowpremium')) update_option("frontpageshowpremium", '1');
	if(!get_option('frontpageshowpremiumcols')) update_option("frontpageshowpremiumcols", '2');
	if(!get_option('frontpageshowonline')) update_option("frontpageshowonline", '1');
	if(!get_option('frontpageshowonlinecols')) update_option("frontpageshowonlinecols", '2');
	if(!get_option('frontpageshownormal')) update_option("frontpageshownormal", '1');
	if(!get_option('frontpageshownormalcols')) update_option("frontpageshownormalcols", '2');
	if(!get_option('frontpageshowrev')) update_option("frontpageshowrev", '1');
	if(!get_option('frontpageshowrevitems')) update_option("frontpageshowrevitems", '3');
	if(!get_option('frontpageshowrevchars')) update_option("frontpageshowrevchars", '400');

	if(!get_option('newlabelperiod')) update_option("newlabelperiod", '14');

	if(!get_option('maximgupload')) update_option("maximgupload", '20');
	if(!get_option('maximguploadsize')) update_option("maximguploadsize", '5');

	if(!get_option('allowvideoupload')) update_option("allowvideoupload", '2');
	if(!get_option('maxvideoupload')) update_option("maxvideoupload", '5');
	if(!get_option('maxvideouploadsize')) update_option("maxvideouploadsize", '50');
	if(!get_option('videoresizeheight')) update_option("videoresizeheight", '400');

	if(!get_option('heightscale')) update_option("heightscale", 'metric');

	if(!get_option('manactivesc')) update_option("manactivesc", '2');
	if(!get_option('manactivag')) update_option("manactivag", '2');
	if(!get_option('manactivagescprof')) update_option("manactivagescprof", '2');
	if(!get_option('manactivindescprof')) update_option("manactivindescprof", '2');
	if(!get_option('manactivclassads')) update_option("manactivclassads", '2');

	if(!get_option('allowadpostingprofiles')) update_option("allowadpostingprofiles", '1');
	if(!get_option('allowadpostingagencies')) update_option("allowadpostingagencies", '1');
	if(!get_option('allowadpostingmembers')) update_option("allowadpostingmembers", '1');

	if(!get_option('unregsendcontactform')) update_option("unregsendcontactform", "2");
	if(!get_option('tos18')) update_option("tos18", "2");
	if(!get_option('quickescortsearch')) update_option("quickescortsearch", "1");
	if(!get_option('hitcounter1')) update_option("hitcounter1", "1");
	if(!get_option('hitcounter2')) update_option("hitcounter2", "1");
	if(!get_option('hitcounter3')) update_option("hitcounter3", "1");


	if(!get_option('payment_plans')) update_option("payment_plans", $payment_plans);

	if(!get_option('show_coupon_checkout')) update_option("show_coupon_checkout", '2');
	if(!get_option('show_address_checkout')) update_option("show_address_checkout", '2');

	if(!get_option('admin_email')) update_option("admin_email", get_bloginfo('admin_email'));
	if(!get_option('email_sitename')) update_option("email_sitename", get_bloginfo('name'));
	if(!get_option('email_siteemail')) update_option("email_siteemail", get_bloginfo('admin_email'));
	if(!get_option('email_signature')) update_option("email_signature", "\n"."--"."\n".get_bloginfo('name'));
		
	if(!get_option('ifemail1')) update_option("ifemail1", '1');
	if(!get_option('ifemail2')) update_option("ifemail2", '1');
	if(!get_option('ifemail3')) update_option("ifemail3", '1');
	if(!get_option('ifemail4')) update_option("ifemail4", '1');
	if(!get_option('ifemail5')) update_option("ifemail5", '1');
	if(!get_option('ifemail6')) update_option("ifemail6", '1');
	if(!get_option('ifemail7')) update_option("ifemail7", '1');
	if(!get_option('ifemail8')) update_option("ifemail8", '1');
	if(!get_option('ifemail9')) update_option("ifemail9", '1');
	if(!get_option('manactivagprof')) update_option("manactivagprof", '2');
	if(!get_option('manactivescprof')) update_option("manactivescprof", '2');
	if(!get_option('manactivindesc')) update_option("manactivindesc", '2');

	global $escortregfields, $theme_version;
	if(!get_option('regfieldsescort')) update_option('regfieldsescort', $escortregfields);
	if(!get_option('defaults_have_been_set')) update_option('defaults_have_been_set', 'yes');
	if(!get_option('revnr')) update_option('revnr', $theme_version);
}

function escortwp_run_time_check_expired_maintenance() {
	$lock_key = 'escortwp_time_check_expired_lock';

	set_transient($lock_key, 1, 5 * MINUTE_IN_SECONDS);

	try {
		time_check_expired();
		update_option('escortwp_time_check_expired_last_run', time());
	} catch (Exception $e) {
		// Keep the site responsive even if maintenance fails.
	} catch (Error $e) {
		// Keep the site responsive even if maintenance fails.
	}

	delete_transient($lock_key);
}
add_action('escortwp_run_time_check_expired_event', 'escortwp_run_time_check_expired_maintenance');

function escortwp_maybe_run_time_check_expired() {
	if (escortwp_is_customizer_preview_request()) {
		return false;
	}

	$lock_key = 'escortwp_time_check_expired_lock';
	$now = time();
	$last_run = (int) get_option('escortwp_time_check_expired_last_run');
	$next_scheduled = wp_next_scheduled('escortwp_run_time_check_expired_event');

	if (get_transient($lock_key)) {
		return false;
	}

	if ($next_scheduled && $next_scheduled > ($now - MINUTE_IN_SECONDS)) {
		return false;
	}

	if ($last_run && ($now - $last_run) < (5 * MINUTE_IN_SECONDS)) {
		return false;
	}

	wp_schedule_single_event($now + 5, 'escortwp_run_time_check_expired_event');
	return true;
}


//Import a full list of countries
function import_country_list($taxonomy_url) {
	if (!escortwp_is_brazil_only_location_mode_enabled()) {
		return;
	}

	escortwp_get_brazil_location_term_map(true);
}
//Create countries from custom list
function create_country_list($countries, $taxonomy_url) {
	if (!escortwp_is_brazil_only_location_mode_enabled()) {
		return;
	}

	escortwp_get_brazil_location_term_map(true);
}


// Create all the pages from the site
function create_theme_pages() {
	$taxonomy_profile_name = get_option("taxonomy_profile_name");
	$taxonomy_profile_name_plural = get_option("taxonomy_profile_name_plural");
	$taxonomy_profile_url = get_option("taxonomy_profile_url");
	$settings_theme_genders = get_option("settings_theme_genders");
	$taxonomy_agency_name = get_option("taxonomy_agency_name");
	$taxonomy_agency_name_plural = get_option("taxonomy_agency_name_plural");
	$taxonomy_agency_url = get_option("taxonomy_agency_url");
	$taxonomy_location_url = get_option("taxonomy_location_url");

	//wp option name - page slug - page title - php file
	$pages = array(
		array('main_reg_page_id', 'registration', 'Criar conta', 'register-main-page.php'),
		array('escort_reg_page_id', $taxonomy_profile_url.'-registration', 'Cadastro de '.ucwords($taxonomy_profile_name), 'register-independent.php'),
		array('escort_tours_page_id', 'manage-my-tours', 'Gerenciar passeios', 'register-independent-manage-my-tours.php'),
		array('escort_edit_personal_info_page_id', 'edit-profile', 'Painel da acompanhante', 'register-independent-edit-personal-information.php'),
		array('change_password_page_id', 'change-password', 'Alterar senha', 'register-page-change-password.php'),
		array('escort_verified_status_page_id', 'verify-account', 'Verificar conta', 'register-independent-verified-status.php'),
		array('escort_blacklist_clients_page_id', 'blacklisted-clients', 'Clientes bloqueados', 'blacklist-clients.php'),
		array('agency_reg_page_id', $taxonomy_agency_url.'-registration', 'Cadastro de agencia', 'register-agency.php'),

		array('all_profiles_page_id', 'all-'.sanitize_title($taxonomy_profile_name_plural), ucwords($taxonomy_profile_name_plural), 'all-profiles.php'),
		array('all_female_profiles_page_id', 'female-'.sanitize_title($taxonomy_profile_name_plural), 'Female '.ucwords($taxonomy_profile_name_plural), 'all-profiles.php'),
		array('all_male_profiles_page_id', 'male-'.sanitize_title($taxonomy_profile_name_plural), 'Male '.ucwords($taxonomy_profile_name_plural), 'all-profiles.php'),
		array('all_couple_profiles_page_id', 'couple-'.sanitize_title($taxonomy_profile_name_plural), 'Couple '.ucwords($taxonomy_profile_name_plural), 'all-profiles.php'),
		array('all_gay_profiles_page_id', 'gay-'.sanitize_title($taxonomy_profile_name_plural), 'Gay '.ucwords($taxonomy_profile_name_plural), 'all-profiles.php'),
		array('all_trans_profiles_page_id', 'transsexual-'.sanitize_title($taxonomy_profile_name_plural), 'Transsexual '.ucwords($taxonomy_profile_name_plural), 'all-profiles.php'),
		array('all_independent_profiles_page_id', 'independent-'.sanitize_title($taxonomy_profile_name_plural), 'Independent '.ucwords($taxonomy_profile_name_plural), 'all-profiles.php'),
		array('all_premium_profiles_page_id', 'premium-'.sanitize_title($taxonomy_profile_name_plural), 'Premium '.ucwords($taxonomy_profile_name_plural), 'all-profiles.php'),
		array('all_verified_profiles_page_id', 'verified-'.sanitize_title($taxonomy_profile_name_plural), 'Verified '.ucwords($taxonomy_profile_name_plural), 'all-profiles.php'),
		array('all_new_profiles_page_id', 'new-'.sanitize_title($taxonomy_profile_name_plural), 'New '.ucwords($taxonomy_profile_name_plural), 'all-profiles.php'),
		array('all_online_profiles_page_id', 'online-'.sanitize_title($taxonomy_profile_name_plural), 'Online '.ucwords($taxonomy_profile_name_plural), 'all-profiles.php'),

		array('agency_edit_personal_info_page_id', $taxonomy_agency_url.'-edit-profile', 'Edit Your '.ucfirst($taxonomy_agency_name).' Profile', 'register-agency-edit-personal-information.php'),
		array('agency_upload_logo_page_id', 'upload-logo', 'Upload/Edit your Logo', 'register-agency-upload-logo.php'),
		array('agency_manage_escorts_page_id', 'manage-'.sanitize_title($taxonomy_profile_name_plural), 'Manage your '.ucwords($taxonomy_profile_name_plural), 'register-agency-manage-escorts.php'),
		array('member_register_page_id', 'member-registration', 'Member Registration', 'register-member.php'),
		array('member_edit_personal_info_page_id', 'member-edit-profile', 'Member Edit Profile', 'register-member-edit-personal-information.php'),
		array('member_favorite_escorts_page_id', 'favorite-'.sanitize_title($taxonomy_profile_name_plural), 'My Favorite '.ucwords($taxonomy_profile_name_plural), 'register-member-see-favorites.php'),
		array('member_reviews_page_id', 'my-reviews', 'My Reviews', 'register-member-see-reviews.php'),
		array('city_tours_page_id', sanitize_title($taxonomy_profile_name_plural).'-on-tour', ucwords($taxonomy_profile_name_plural).' on Tour', 'nav-city-tours.php'),
		array('nav_reviews_page_id', 'reviews', 'Reviews', 'nav-reviews.php'),
		array('nav_reviews_agencies_page_id', $taxonomy_agency_url.'-reviews', ucwords($taxonomy_agency_name).' Reviews', 'nav-reviews-agencies.php'),
		array('list_agencies_page_id', sanitize_title($taxonomy_agency_name_plural), ucwords($taxonomy_agency_name_plural), 'nav-agencies.php'),
		array('contact_page_id', 'contact-us', 'Contact us', 'nav-contact.php'),
		array('search_page_id', 'search-for-'.sanitize_title($taxonomy_profile_name_plural), 'Search for '.ucwords($taxonomy_profile_name_plural), 'nav-search.php'),
		array('blacklisted_escorts_page_id', sanitize_title($taxonomy_profile_name_plural).'-blacklist', 'Blacklisted '.ucwords($taxonomy_profile_name_plural), 'blacklisted-escorts.php'),
		array('manage_ads_page_id', 'manage-classified-ads', 'Manage Classified Ads', 'manage-classified-ads.php'),
		array('see_all_ads_page_id', 'classified-ads', 'Classified ads', 'nav-classified-ads.php'),
		array('see_offering_ads_page_id', 'classified-ads-offering', 'Classified Ads - Offering', 'nav-classified-ads-offering.php'),
		array('see_looking_ads_page_id', 'classified-ads-looking', 'Classified Ads - Looking', 'nav-classified-ads-looking.php'),
		array('edit_payment_settings_page_id', 'payment-settings', 'Configuracoes de pagamento', 'edit-payment-settings.php'),
		array('edit_user_types', 'edit-user-types', 'Edit User Types', 'edit-user-types.php'),

		array('edit_registration_form_escort', 'edit-registration-form-for-'.$taxonomy_profile_url, 'Edit Registration Form for '.ucwords($taxonomy_profile_name), 'edit-registration-form-escort.php'),
		array('nav_blacklisted_escorts_page_id', 'blacklisted-'.sanitize_title($taxonomy_profile_name_plural), 'Blacklisted '.ucwords($taxonomy_profile_name_plural), 'nav-blacklisted-escorts.php'),
		array('email_settings_page_id', 'edit-email-options', 'Email Options', 'edit-email-options.php'),
		array('site_settings_page_id', 'edit-site-settings', 'Site Settings', 'edit-site-settings.php'),
		array('content_settings_page_id', 'content-settings', 'Content Settings', 'edit-content-settings.php'),
		array('blog_page_id', 'blog', 'Our Blog', 'nav-blog.php'),
		array('generate_demo_data_page', 'generate-demo-data', 'Generate Demo Data', 'admin-generate-demo-data.php')
	);

	foreach($pages as $p) {
		$new_page = array(
			'post_author' => "1",
			'comment_status' => "closed",
			'ping_status' => "closed",
			'post_name' => $p[1], // slug
			'post_title' => $p[2], // title
			'post_status' => "publish",
			'post_type' => "page",
			'page_template'  => $p[3]
		);
		global $wpdb;
		if (get_option($p[0]) > 0) {
			//update page details
			$page_id = get_option($p[0]);
			$new_page['ID'] = $page_id;
			wp_update_post($new_page);
			$wpdb->update( $wpdb->postmeta, array( 'post_id' => $page_id, 'meta_key' => '_wp_page_template', 'meta_value' => $p[4] ), '', array( '%d', '%s', '%s' ));
		} else {
			//create page
			$current_lang = multilang_switch_language();
			$new_page_id = wp_insert_post( $new_page );
			multilang_switch_language($current_lang);
			if ($new_page_id && $new_page_id != "0") {
				update_option($p[0], $new_page_id);
				$wpdb->insert( $wpdb->postmeta, array( 'post_id' => $new_page_id, 'meta_key' => '_wp_page_template', 'meta_value' => $p[4] ), array( '%d', '%s', '%s' ) );
			}
		}
	} // foreach

	//all pages are now created so we don't need to run this again
	update_option('are_all_pages_created', 'yes');

	flush_rewrite_rules();

	return count($pages);
} // create the site pages


if (is_user_logged_in() && isset($_GET['activated']) && !get_option('is_theme_installed')) {
	wp_redirect(site_url().'/?install=yes'); die();
}
function install_theme_wizard() {
	if(!get_option('is_theme_installed')) {
		if($_GET['install'] == "yes") {
			include(get_template_directory().'/functions-install-theme-wizard.php');
		} else { ?>
			<div class="all">
				<div class="err rad5">
					<p>
					<?=__("This theme has not been configured yet.",'escortwp')?><br />
					<?=__("In order to use the theme you will need to set your default options first.",'escortwp')?>
					</p>
					<p>
						<a href="<?php echo bloginfo('url').'/?install=yes'; ?>" class="pinkbutton rad3"><?=__("Configure your theme",'escortwp')?></a>
					</p>
					<div class="clear"></div>
				</div> <!-- err -->
			</div> <!-- all -->

			</body>
		</html>
		<?php
		}
		die();
	} // is theme installed?
} // function install_theme_wizard()


function char_to_utf8($string) {
	$array = preg_split("//u", strtolower(trim($string)), -1, PREG_SPLIT_NO_EMPTY);
	$chars = array ("Ãƒâ€ž" => 'Ae', 'ÃƒÂ¤' => 'ae', 'Ãƒâ€ ' => 'Ae', 'ÃƒÂ¦' => 'ae', 'Ãƒâ‚¬' => 'A', 'ÃƒÂ ' => 'a', 'ÃƒÂ' => 'A', 'ÃƒÂ¡' => 'a', 'Ãƒâ€š' => 'A', 'ÃƒÂ¢' => 'a', 'ÃƒÆ’' => 'A', 'ÃƒÂ£' => 'a', 'Ãƒâ€¦' => 'A', 'ÃƒÂ¥' => 'a', 'Ã‚Âª' => 'a', 'Ã¢â€šÂ' => 'a', 'Ã„Â' => 'a', 'Ã„â€ ' => 'C', 'Ã„â€¡' => 'c', 'Ãƒâ€¡' => 'C', 'ÃƒÂ§' => 'c', 'ÃƒÂ' => 'D', 'Ã„â€˜' => 'd', 'ÃƒË†' => 'E', 'ÃƒÂ¨' => 'e', 'Ãƒâ€°' => 'E', 'ÃƒÂ©' => 'e', 'ÃƒÅ ' => 'E', 'ÃƒÂª' => 'e', 'Ãƒâ€¹' => 'E', 'ÃƒÂ«' => 'e', 'Ã¢â€šâ€˜' => 'e', 'Ã†â€™' => 'f', 'Ã„Å¸' => 'g', 'Ã„Å¾' => 'G', 'ÃƒÅ’' => 'I', 'ÃƒÂ¬' => 'i', 'ÃƒÂ' => 'I', 'ÃƒÂ­' => 'i', 'ÃƒÅ½' => 'I', 'ÃƒÂ®' => 'i', 'ÃƒÂ' => 'Ii', 'ÃƒÂ¯' => 'ii', 'Ã„Â«' => 'i', 'Ã„Â±' => 'i', 'I' => 'I', 'Ãƒâ€˜' => 'N', 'ÃƒÂ±' => 'n', 'Ã¢ÂÂ¿' => 'n', 'Ãƒâ€™' => 'O', 'ÃƒÂ²' => 'o', 'Ãƒâ€œ' => 'O', 'ÃƒÂ³' => 'o', 'Ãƒâ€' => 'O', 'ÃƒÂ´' => 'o', 'Ãƒâ€¢' => 'O', 'ÃƒÂµ' => 'o', 'ÃƒËœ' => 'O', 'ÃƒÂ¸' => 'o', 'Ã¢â€šâ€™' => 'o', 'Ãƒâ€“' => 'Oe', 'ÃƒÂ¶' => 'oe', 'Ã…â€™' => 'Oe', 'Ã…â€œ' => 'oe', 'ÃƒÅ¸' => 'ss', 'Ã…Â ' => 'S', 'Ã…Â¡' => 's', 'Ã…Å¸' => 's', 'Ã…Å¾' => 'S', 'Ã¢â€žÂ¢' => 'TM', 'Ãƒâ„¢' => 'U', 'ÃƒÂ¹' => 'u', 'ÃƒÅ¡' => 'U', 'ÃƒÂº' => 'u', 'Ãƒâ€º' => 'U', 'ÃƒÂ»' => 'u', 'ÃƒÅ“' => 'Ue', 'ÃƒÂ¼' => 'ue', 'ÃƒÂ' => 'Y', 'ÃƒÂ½' => 'y', 'ÃƒÂ¿' => 'y', 'Ã…Â½' => 'Z', 'Ã…Â¾' => 'z',
	// Russian
	'ÃÂ' => 'A', 'Ãâ€˜' => 'B', 'Ãâ€™' => 'V', 'Ãâ€œ' => 'G', 'Ãâ€' => 'D', 'Ãâ€¢' => 'E', 'ÃÂ' => 'YO', 'Ãâ€“' => 'ZH', 'Ãâ€”' => 'Z', 'ÃËœ' => 'I', 'Ãâ„¢' => 'Y', 'ÃÅ¡' => 'K', 'Ãâ€º' => 'L', 'ÃÅ“' => 'M', 'ÃÂ' => 'N', 'ÃÅ¾' => 'O', 'ÃÅ¸' => 'P', 'ÃÂ ' => 'R', 'ÃÂ¡' => 'S', 'ÃÂ¢' => 'T', 'ÃÂ£' => 'U', 'ÃÂ¤' => 'F', 'ÃÂ¥' => 'H', 'ÃÂ¦' => 'TS', 'ÃÂ§' => 'CH', 'ÃÂ¨' => 'SH', 'ÃÂ©' => 'SCH', 'ÃÂª' => '', 'ÃÂ«' => 'YI', 'ÃÂ¬' => '', 'ÃÂ­' => 'E', 'ÃÂ®' => 'YU', 'ÃÂ¯' => 'YA', 'ÃÂ°' => 'a', 'ÃÂ±' => 'b', 'ÃÂ²' => 'v', 'ÃÂ³' => 'g', 'ÃÂ´' => 'd', 'ÃÂµ' => 'e', 'Ã‘â€˜' => 'yo', 'ÃÂ¶' => 'zh', 'ÃÂ·' => 'z', 'ÃÂ¸' => 'i', 'ÃÂ¹' => 'y', 'ÃÂº' => 'k', 'ÃÂ»' => 'l', 'ÃÂ¼' => 'm', 'ÃÂ½' => 'n', 'ÃÂ¾' => 'o', 'ÃÂ¿' => 'p', 'Ã‘â‚¬' => 'r', 'Ã‘Â' => 's', 'Ã‘â€š' => 't', 'Ã‘Æ’' => 'u', 'Ã‘â€ž' => 'f', 'Ã‘â€¦' => 'h', 'Ã‘â€ ' => 'ts', 'Ã‘â€¡' => 'ch', 'Ã‘Ë†' => 'sh', 'Ã‘â€°' => 'sch', 'Ã‘Å ' => '', 'Ã‘â€¹' => 'yi', 'Ã‘Å’' => '', 'Ã‘Â' => 'e', 'Ã‘Å½' => 'yu', 'Ã‘Â' => 'ya');

	foreach($array as $key=>$s) {
		if($chars[$s]) {
			$array[$key] = $chars[$s];
		}
	}
	return implode($array);
}


function generate_demo_data() {
	if(!get_option('generate_demo_data_alert') && current_user_can('level_10')) {
	?>
	<script type="text/javascript">
	jQuery(document).ready(function($) {
		$('.dont_show_me_this_again').on('click', function() {
			$.ajax({
				type: "GET",
				url: "<?php bloginfo('template_url'); ?>/ajax/settings-saver.php",
				data: {
					hide_demo_data_alert: 'yes',
					escortwp_nonce: window.escortwpAjax.nonce
				}
			});
			$('.demo_data_intro').slideUp();
		});
	});
	</script>
	<div class="all demo_data_intro">
		<div class="ok rad5">
			<p>
				<?php _e('It looks like this is your first time viewing the theme','escortwp'); ?>.<br />
				<?php _e('Do you want to generate some test profiles?','escortwp'); ?><br />
				<?php _e('That way you can see better how the theme looks','escortwp'); ?>.
			</p>
			<div class="clear10"></div>
			<div class="col50 center">
				<a href="<?php echo get_permalink(get_option('generate_demo_data_page')); ?>" class="pinkbutton rad25 l"><?php _e('Generate demo data','escortwp'); ?></a>
				<div class="graybutton rad25 r dont_show_me_this_again"><?php _e('Don\'t show me this again','escortwp'); ?></div>
			</div>
			<div class="clear10"></div>
		</div> <!-- ok -->
	</div> <!-- all -->
	<?php
	} // if !get_option('generate_demo_data')
}


function generate_random_name($gender) {
	if(in_array($gender, array('1', '5'))) { //if gender is for female or trans
		$gender = "1";
	} elseif(in_array($gender, array('2', '4'))) { //if gender is for male or gay
		$gender = "2";
	}
	$names = array(
		//female, transsexual
		'1' => array('Aaliyah','Abagail','Abbey','Abbie','Abbigail','Abby','Abigail','Abigayle','Abril','Ada','Adalyn','Adalynn','Addison','Addisyn','Addyson','Adelaide','Adeline','Adelyn','Adison','Adriana','Adrianna','Adrienne','Adyson','Aileen','Aimee','Ainsley','Aisha','Aiyana','Akira','Alaina','Alana','Alani','Alanna','Alannah','Alayna','Aleah','Aleena','Alejandra','Alena','Alessandra','Alexa','Alexandra','Alexandria','Alexia','Alexis','Alexus','Ali','Alia','Aliana','Alice','Alicia','Alina','Alisa','Alisha','Alison','Alissa','Alisson','Alivia','Aliya','Aliyah','Aliza','Allie','Allison','Allisson','Ally','Allyson','Alma','Alondra','Alyson','Alyssa','Alyvia','Amanda','Amani','Amara','Amari','Amaris','Amaya','Amber','Amelia','Amelie','America','Amiah','Amina','Amira','Amirah','Amiya','Amiyah','Amy','Amya','Ana','Anabel','Anabella','Anabelle','Anahi','Anastasia','Anaya','Andrea','Angel','Angela','Angelica','Angelina','Angeline','Angelique','Angie','Anika','Aniya','Aniyah','Ann','Anna','Annabel','Annabella','Annabelle','Annalise','Anne','Annie','Annika','Ansley','Anya','April','Arabella','Araceli','Aracely','Areli','Arely','Aria','Ariana','Arianna','Ariel','Ariella','Arielle','Armani','Aryana','Aryanna','Ashanti','Ashlee','Ashleigh','Ashley','Ashly','Ashlyn','Ashlynn','Ashtyn','Asia','Aspen','Athena','Aubree','Aubrey','Aubrie','Audrey','Audrina','Aurora','Autumn','Ava','Avah','Averi','Averie','Avery','Ayana','Ayanna','Ayla','Aylin','Azaria','Azul','Bailee','Bailey','Barbara','Baylee','Beatrice','Belen','Belinda','Bella','Bethany','Bianca','Braelyn','Breanna','Brenda','Brenna','Bria','Briana','Brianna','Bridget','Brielle','Briley','Brisa','Britney','Brittany','Brooke','Brooklyn','Brooklynn','Bryanna','Brylee','Brynlee','Brynn','Cadence','Cailyn','Caitlin','Caitlyn','Cali','Callie','Cameron','Camila','Camilla','Camille','Campbell','Camryn','Cara','Carina','Carissa','Carla','Carlee','Carleigh','Carley','Carlie','Carly','Carmen','Carolina','Caroline','Carolyn','Casey','Cassandra','Cassidy','Cassie','Catalina','Catherine','Caylee','Cecelia','Cecilia','Celeste','Celia','Chana','Chanel','Charity','Charlee','Charlie','Charlize','Charlotte','Chasity','Chaya','Chelsea','Cherish','Cheyanne','Cheyenne','Chloe','Christina','Christine','Ciara','Cierra','Cindy','Claire','Clara','Clare','Clarissa','Claudia','Cloe','Cora','Corinne','Courtney','Cristal','Cristina','Crystal','Cynthia','Dahlia','Daisy','Dakota','Dalia','Damaris','Dana','Dania','Danica','Daniela','Daniella','Danielle','Danika','Danna','Daphne','Dayami','Dayana','Dayanara','Deanna','Deborah','Deja','Delaney','Delilah','Denise','Denisse','Desirae','Desiree','Destinee','Destiney','Destiny','Diamond','Diana','Dixie','Diya','Dominique','Donna','Dulce','Dylan','Eden','Edith','Eileen','Elaina','Elaine','Eleanor','Elena','Eliana','Elianna','Elisa','Elisabeth','Elise','Eliza','Elizabeth','Ella','Elle','Ellen','Elliana','Ellie','Elsa','Elsie','Elyse','Emelia','Emely','Emerson','Emery','Emilee','Emilia','Emilie','Emily','Emma','Emmalee','Emmy','Erica','Erika','Erin','Esmeralda','Esperanza','Essence','Esther','Estrella','Eva','Evangeline','Eve','Evelin','Evelyn','Evie','Faith','Fatima','Felicity','Fernanda','Finley','Fiona','Frances','Francesca','Frida','Gabriela','Gabriella','Gabrielle','Gemma','Genesis','Genevieve','Georgia','Gia','Giada','Giana','Gianna','Gillian','Gina','Giovanna','Giselle','Gisselle','Giuliana','Gloria','Grace','Gracelyn','Gracie','Greta','Gretchen','Guadalupe','Gwendolyn','Hadassah','Hadley','Hailee','Hailey','Hailie','Haleigh','Haley','Halle','Hallie','Hana','Hanna','Hannah','Harley','Harmony','Harper','Haven','Hayden','Haylee','Hayley','Haylie','Hazel','Heather','Heaven','Heidi','Heidy','Helen','Helena','Hillary','Holly','Hope','Iliana','Imani','India','Ingrid','Ireland','Irene','Iris','Isabel','Isabela','Isabell','Isabella','Isabelle','Isis','Isla','Itzel','Ivy','Iyana','Izabella','Izabelle','Jacey','Jacqueline','Jacquelyn','Jada','Jade','Jaden','Jadyn','Jaelyn','Jaelynn','Jaida','Jaiden','Jaidyn','Jakayla','Jaliyah','Jamie','Jamiya','Jamya','Janae','Jane','Janelle','Janessa','Janet','Janiah','Janiya','Janiyah','Jaqueline','Jaslene','Jaslyn','Jasmin','Jasmine','Jaycee','Jayda','Jayden','Jayla','Jaylah','Jaylee','Jayleen','Jaylen','Jaylene','Jaylin','Jaylyn','Jaylynn','Jazlene','Jazlyn','Jazlynn','Jazmin','Jazmine','Jazmyn','Jenna','Jennifer','Jenny','Jessica','Jessie','Jewel','Jillian','Jimena','Joanna','Jocelyn','Jocelynn','Johanna','Jolie','Jordan','Jordin','Jordyn','Joselyn','Josephine','Josie','Joslyn','Journey','Joy','Joyce','Judith','Julia','Juliana','Julianna','Julianne','Julie','Juliet','Juliette','Julissa','June','Justice','Justine','Kadence','Kaelyn','Kaia','Kaila','Kailee','Kailey','Kailyn','Kaitlin','Kaitlyn','Kaitlynn','Kaiya','Kaleigh','Kaley','Kali','Kaliyah','Kallie','Kamari','Kamila','Kamora','Kamryn','Kara','Karen','Karina','Karissa','Karla','Karlee','Karley','Karli','Karlie','Karly','Karma','Karsyn','Kasey','Kassandra','Kassidy','Kate','Katelyn','Katelynn','Katherine','Kathleen','Kathryn','Kathy','Katie','Katrina','Kaya','Kayden','Kaydence','Kayla','Kaylah','Kaylee','Kayleigh','Kaylen','Kayley','Kaylie','Kaylin','Kaylyn','Kaylynn','Keely','Keira','Kelly','Kelsey','Kelsie','Kendal','Kendall','Kendra','Kenley','Kenna','Kennedi','Kennedy','Kenya','Kenzie','Keyla','Khloe','Kiana','Kianna','Kiara','Kiera','Kierra','Kiersten','Kiley','Kimberly','Kimora','Kinley','Kinsley','Kira','Kirsten','Krista','Kristen','Kristin','Kristina','Krystal','Kyla','Kylee','Kyleigh','Kylie','Kyra','Lacey','Laci','Laila','Lailah','Lainey','Lana','Laney','Lara','Larissa','Laura','Laurel','Lauren','Lauryn','Layla','Laylah','Lea','Leah','Leanna','Leia','Leila','Leilani','Lena','Leslie','Lesly','Leticia','Lexi','Lexie','Leyla','Lia','Liana','Libby','Liberty','Lila','Lilah','Lilia','Lilian','Liliana','Lilianna','Lillian','Lilliana','Lillianna','Lillie','Lilly','Lily','Lilyana','Lina','Linda','Lindsay','Lindsey','Lisa','Litzy','Livia','Lizbeth','Lizeth','Logan','Lola','London','Londyn','Lorelai','Lorelei','Lorena','Lucia','Luciana','Lucille','Lucy','Luna','Luz','Lydia','Lyla','Lyric','Macey','Maci','Macie','Mackenzie','Macy','Madalyn','Madalynn','Maddison','Madeleine','Madeline','Madelyn','Madelynn','Madilyn','Madilynn','Madison','Madisyn','Madyson','Maeve','Magdalena','Maggie','Maia','Makaila','Makayla','Makena','Makenna','Makenzie','Maleah','Malia','Maliyah','Mallory','Mara','Mareli','Marely','Maren','Margaret','Maria','Mariah','Mariam','Mariana','Marianna','Maribel','Marie','Mariela','Marilyn','Marin','Marina','Marisa','Marisol','Marissa','Maritza','Mariyah','Marlee','Marlene','Marley','Marlie','Martha','Mary','Maryjane','Matilda','Mattie','Maya','Mayra','Mckayla','Mckenna','Mckenzie','Mckinley','Meadow','Megan','Meghan','Melanie','Melany','Melina','Melissa','Melody','Mercedes','Meredith','Mia','Miah','Micaela','Micah','Michaela','Michelle','Mikaela','Mikayla','Mila','Milagros','Miley','Mina','Mira','Miracle','Miranda','Mireya','Miriam','Miya','Mollie','Molly','Monica','Monique','Monserrat','Morgan','Moriah','Mya','Myah','Myla','Mylee','Mylie','Nadia','Naima','Nancy','Naomi','Natalee','Natalia','Natalie','Nataly','Natalya','Natasha','Nathalia','Nathalie','Nathaly','Nayeli','Nevaeh','Neveah','Nia','Nicole','Nina','Noelle','Noemi','Nola','Nora','Norah','Nyasia','Nyla','Nylah','Olive','Olivia','Paige','Paisley','Paityn','Paloma','Pamela','Paola','Paris','Parker','Patience','Patricia','Paula','Paulina','Payten','Payton','Penelope','Perla','Peyton','Phoebe','Phoenix','Piper','Precious','Presley','Princess','Priscilla','Quinn','Rachael','Rachel','Raegan','Raelynn','Raina','Raquel','Raven','Rayna','Rayne','Reagan','Rebecca','Rebekah','Reese','Regan','Regina','Reina','Renee','Reyna','Rhianna','Rihanna','Riley','Riya','Rory','Rosa','Rose','Roselyn','Rosemary','Rowan','Rubi','Ruby','Ruth','Ryan','Ryann','Rylee','Ryleigh','Rylie','Sabrina','Sadie','Sage','Saige','Salma','Samantha','Samara','Sanaa','Sanai','Sandra','Saniya','Saniyah','Sara','Sarah','Sarahi','Sarai','Sariah','Sasha','Savanah','Savanna','Savannah','Scarlet','Scarlett','Selah','Selena','Selina','Serena','Serenity','Shania','Shaniya','Shannon','Sharon','Shayla','Shaylee','Shayna','Shea','Shelby','Sherlyn','Shiloh','Shirley','Shyann','Shyanne','Shyla','Sidney','Siena','Sienna','Sierra','Simone','Skye','Skyla','Skylar','Skyler','Sloane','Sofia','Sonia','Sophia','Sophie','Stacy','Stella','Stephanie','Stephany','Summer','Susan','Sydnee','Sydney','Sylvia','Tabitha','Talia','Taliyah','Tamara','Tamia','Tania','Taniya','Taniyah','Tanya','Tara','Taryn','Tatiana','Tatum','Taylor','Teagan','Teresa','Tess','Tessa','Thalia','Theresa','Tia','Tiana','Tianna','Tiara','Tiffany','Tori','Trinity','Valentina','Valeria','Valerie','Valery','Vanessa','Veronica','Victoria','Violet','Virginia','Vivian','Viviana','Wendy','Whitney','Willow','Ximena','Xiomara','Yadira','Yamilet','Yareli','Yaretzi','Yaritza','Yasmin','Yasmine','Yazmin','Yesenia','Yoselin','Yuliana','Zaniyah','Zara','Zaria','Zariah','Zion','Zoe','Zoey','Zoie'),
		//male, gay
		'2' => array('Aaden','Aarav','Aaron','Abdiel','Abdullah','Abel','Abraham','Abram','Ace','Adam','Adan','Addison','Aden','Aditya','Adolfo','Adonis','Adrian','Adriel','Adrien','Aedan','Agustin','Ahmad','Ahmed','Aidan','Aiden','Aidyn','Alan','Albert','Alberto','Alden','Aldo','Alec','Alejandro','Alessandro','Alex','Alexander','Alexis','Alexzander','Alfonso','Alfred','Alfredo','Ali','Alijah','Allan','Allen','Alonso','Alonzo','Alvaro','Alvin','Amare','Amari','Amir','Anderson','Andre','Andreas','Andres','Andrew','Andy','Angel','Angelo','Anthony','Antoine','Anton','Antonio','Antony','Antwan','Ari','Ariel','Arjun','Armando','Armani','Arnav','Aron','Arthur','Arturo','Aryan','Asa','Asher','Ashton','Atticus','August','Augustus','Austin','Avery','Axel','Ayaan','Aydan','Ayden','Aydin','Bailey','Baron','Barrett','Beau','Beckett','Beckham','Ben','Benjamin','Bennett','Bentley','Bernard','Billy','Blaine','Blake','Blaze','Bo','Bobby','Boston','Braden','Bradley','Brady','Bradyn','Braeden','Braedon','Braiden','Branden','Brandon','Branson','Braxton','Brayan','Brayden','Braydon','Braylen','Braylon','Brendan','Brenden','Brendon','Brennan','Brennen','Brent','Brenton','Brett','Brian','Brice','Bridger','Brock','Broderick','Brodie','Brody','Brogan','Bronson','Brooks','Bruce','Bruno','Bryan','Bryant','Bryce','Brycen','Bryson','Byron','Cade','Caden','Cael','Caiden','Cale','Caleb','Callum','Calvin','Camden','Cameron','Camren','Camron','Camryn','Cannon','Carl','Carlo','Carlos','Carmelo','Carsen','Carson','Carter','Case','Casey','Cash','Cason','Cassius','Cayden','Cedric','Cesar','Chace','Chad','Chaim','Chance','Chandler','Charles','Charlie','Chase','Chaz','Chris','Christian','Christopher','Clarence','Clark','Clay','Clayton','Clinton','Coby','Cody','Cohen','Colby','Cole','Coleman','Colin','Collin','Colt','Colten','Colton','Conner','Connor','Conor','Conrad','Cooper','Corbin','Cordell','Corey','Cornelius','Cortez','Cory','Craig','Cristian','Cristofer','Cristopher','Cruz','Cullen','Curtis','Cyrus','Dakota','Dale','Dallas','Dalton','Damari','Damarion','Damian','Damien','Damion','Damon','Dane','Dangelo','Daniel','Danny','Dante','Darian','Darien','Dario','Darion','Darius','Darnell','Darrell','Darren','Darryl','Darwin','Dashawn','Davian','David','Davin','Davion','Davis','Davon','Dawson','Dax','Dayton','Deacon','Dean','Deandre','Deangelo','Declan','Deegan','Demarcus','Demarion','Demetrius','Dennis','Denzel','Deon','Derek','Dereon','Derick','Derrick','Deshawn','Desmond','Devan','Deven','Devin','Devon','Devyn','Dexter','Diego','Dillan','Dillon','Dominic','Dominick','Dominik','Dominique','Donald','Donavan','Donovan','Donte','Dorian','Douglas','Drake','Draven','Drew','Duncan','Dustin','Dwayne','Dylan','Ean','Easton','Eddie','Eden','Edgar','Eduardo','Edward','Edwin','Efrain','Eli','Elian','Elias','Eliezer','Elijah','Elisha','Elliot','Elliott','Ellis','Elvis','Emanuel','Emerson','Emery','Emiliano','Emilio','Emmanuel','Emmett','Enrique','Enzo','Eric','Erick','Erik','Ernest','Ernesto','Esteban','Ethan','Ethen','Eugene','Evan','Everett','Ezekiel','Ezequiel','Ezra','Fabian','Felipe','Felix','Fernando','Finley','Finn','Finnegan','Fisher','Fletcher','Francis','Francisco','Franco','Frank','Frankie','Franklin','Freddy','Frederick','Gabriel','Gael','Gage','Gaige','Garrett','Gary','Gauge','Gaven','Gavin','Gavyn','George','Geovanni','Gerald','Gerardo','German','Giancarlo','Gianni','Gideon','Gilbert','Gilberto','Giovani','Giovanni','Giovanny','Glenn','Gordon','Grady','Graham','Grant','Grayson','Gregory','Greyson','Griffin','Guillermo','Gunnar','Gunner','Gustavo','Haiden','Hamza','Harley','Harold','Harper','Harrison','Harry','Hassan','Hayden','Heath','Hector','Henry','Hezekiah','Holden','Houston','Howard','Hudson','Hugh','Hugo','Humberto','Hunter','Ian','Ibrahim','Ignacio','Immanuel','Irvin','Isaac','Isai','Isaiah','Isaias','Ishaan','Isiah','Ismael','Israel','Issac','Ivan','Izaiah','Izayah','Jabari','Jace','Jack','Jackson','Jacob','Jacoby','Jaden','Jadiel','Jadon','Jadyn','Jaeden','Jagger','Jaiden','Jaidyn','Jaime','Jair','Jairo','Jake','Jakob','Jakobe','Jalen','Jamal','Jamar','Jamarcus','Jamari','Jamarion','James','Jameson','Jamie','Jamir','Jamison','Jan','Jaquan','Jared','Jaron','Jarrett','Jase','Jasiah','Jason','Jasper','Javier','Javion','Javon','Jax','Jaxon','Jaxson','Jay','Jayce','Jaydan','Jayden','Jaydin','Jaydon','Jaylan','Jaylen','Jaylin','Jaylon','Jayson','Jayvion','Jayvon','Jean','Jefferson','Jeffery','Jeffrey','Jensen','Jeramiah','Jeremiah','Jeremy','Jerimiah','Jermaine','Jerome','Jerry','Jesse','Jessie','Jett','Jimmy','Joaquin','Joe','Joel','Joey','Johan','John','Johnathan','Johnathon','Johnny','Jon','Jonah','Jonas','Jonathan','Jonathon','Jordan','Jorden','Jordon','Jordyn','Jorge','Jose','Joseph','Josh','Joshua','Josiah','Josue','Jovan','Jovani','Jovanni','Jovanny','Jovany','Juan','Judah','Jude','Julian','Julien','Julio','Julius','Junior','Justice','Justin','Justus','Kade','Kaden','Kadin','Kadyn','Kaeden','Kael','Kai','Kaiden','Kale','Kaleb','Kamari','Kamden','Kameron','Kamren','Kamron','Kane','Kareem','Karson','Karter','Kasen','Kasey','Kash','Kason','Kayden','Keagan','Keaton','Keegan','Keenan','Keith','Kellen','Kelton','Kelvin','Kendall','Kendrick','Kenneth','Kenny','Kenyon','Keon','Keshawn','Kevin','Keyon','Khalil','Kian','Kieran','Killian','King','Kingston','Kobe','Kody','Koen','Kolby','Kole','Kolten','Kolton','Konner','Konnor','Korbin','Krish','Kristian','Kristopher','Kyan','Kylan','Kyle','Kyler','Kymani','Kyson','Lamar','Lamont','Lance','Landen','Landin','Landon','Landyn','Lane','Larry','Lawrence','Lawson','Layne','Layton','Leandro','Lee','Leland','Lennon','Leo','Leon','Leonard','Leonardo','Leonel','Leonidas','Leroy','Levi','Lewis','Liam','Lincoln','Logan','London','Lorenzo','Louis','Luca','Lucas','Lucian','Luciano','Luis','Luka','Lukas','Luke','Lyric','Madden','Maddox','Makai','Makhi','Malachi','Malakai','Malaki','Malcolm','Malik','Manuel','Marc','Marcel','Marcelo','Marco','Marcos','Marcus','Mario','Mark','Markus','Marley','Marlon','Marques','Marquis','Marquise','Marshall','Martin','Marvin','Mason','Mateo','Mathew','Mathias','Matias','Matteo','Matthew','Matthias','Maurice','Mauricio','Maverick','Max','Maxim','Maximilian','Maximillian','Maximo','Maximus','Maxwell','Mekhi','Melvin','Memphis','Messiah','Micah','Michael','Micheal','Miguel','Mike','Miles','Milo','Milton','Misael','Mitchell','Moises','Morgan','Moses','Moshe','Muhammad','Myles','Nash','Nasir','Nathan','Nathanael','Nathanial','Nathaniel','Nathen','Nehemiah','Neil','Nelson','Nicholas','Nick','Nickolas','Nico','Nicolas','Nigel','Nikhil','Niko','Nikolai','Nikolas','Noah','Noe','Noel','Nolan','Octavio','Odin','Oliver','Omar','Omari','Orion','Orlando','Oscar','Osvaldo','Oswaldo','Owen','Pablo','Parker','Patrick','Paul','Paxton','Payton','Pedro','Peter','Peyton','Philip','Phillip','Phoenix','Pierce','Pierre','Porter','Pranav','Preston','Prince','Quentin','Quincy','Quinn','Quinten','Quintin','Quinton','Rafael','Raiden','Ralph','Ramiro','Ramon','Randall','Randy','Raphael','Rashad','Raul','Ray','Rayan','Raymond','Reagan','Reece','Reed','Reese','Reginald','Reid','Reilly','Remington','Rene','Reuben','Rex','Rey','Reynaldo','Rhett','Rhys','Ricardo','Richard','Ricky','Rigoberto','Riley','Rishi','River','Robert','Roberto','Rocco','Roderick','Rodney','Rodolfo','Rodrigo','Rogelio','Roger','Rohan','Roland','Rolando','Roman','Romeo','Ronald','Ronan','Ronin','Ronnie','Rory','Ross','Rowan','Roy','Royce','Ruben','Rudy','Russell','Ryan','Ryder','Ryker','Rylan','Ryland','Rylee','Sage','Salvador','Salvatore','Sam','Samir','Sammy','Samson','Samuel','Santiago','Santino','Santos','Saul','Savion','Sawyer','Scott','Seamus','Sean','Sebastian','Semaj','Sergio','Seth','Shamar','Shane','Shaun','Shawn','Sheldon','Sidney','Silas','Simeon','Simon','Sincere','Skylar','Skyler','Slade','Solomon','Sonny','Soren','Spencer','Stanley','Stephen','Sterling','Steve','Steven','Sullivan','Talan','Talon','Tanner','Tate','Taylor','Teagan','Terrance','Terrell','Terrence','Terry','Thaddeus','Theodore','Thomas','Timothy','Titus','Tobias','Toby','Todd','Tomas','Tommy','Tony','Trace','Travis','Trent','Trenton','Trevin','Trevon','Trevor','Trey','Tripp','Tristan','Tristen','Tristian','Tristin','Triston','Troy','Trystan','Tucker','Turner','Ty','Tyler','Tyree','Tyrell','Tyrese','Tyrone','Tyshawn','Tyson','Ulises','Uriah','Uriel','Urijah','Valentin','Valentino','Van','Vance','Vaughn','Vicente','Victor','Vincent','Wade','Walker','Walter','Warren','Waylon','Wayne','Wesley','Weston','Will','William','Willie','Wilson','Winston','Wyatt','Xander','Xavier','Xzavier','Yadiel','Yael','Yahir','Yair','Yandel','Yosef','Yurem','Yusuf','Zachariah','Zachary','Zachery','Zack','Zackary','Zackery','Zaid','Zaiden','Zain','Zaire','Zander','Zane','Zavier','Zayden','Zayne','Zechariah','Zion')
	);
	if($gender == "3") { //if gender is 'couple' then return two names
		return $names['1'][rand(0, (count($names['1'])))].' '.__('and','escortwp').' '.$names['2'][rand(0, (count($names['2'])))];
	} else {
		return $names[$gender][rand(0, (count($names[$gender])))];
	}
}

function generate_random_user($type) {
	// type:
	// 1 - independent profile
	// 2 - agency
	// 3 - member
	global $taxonomy_profile_url, $taxonomy_agency_url;
	if($type == "1") {
		$type_name = $taxonomy_profile_url;
	} elseif($type == "2") {
		$type_name = $taxonomy_agency_url;
	} elseif($type == "3") {
		$type_name = 'member';
		$yourname = generate_random_name('1');
	}
	$new_user_name = 'user-'.substr(time(), 5).rand(0,9999);
	$new_user_pass = wp_generate_password('20');
	$new_user_email = $new_user_name."@example.com";
	if(email_exists($new_user_email)) {
		generate_random_user($type);
	} else {
		$new_user_id = wp_create_user( $new_user_name, $new_user_pass, $new_user_email );
		wp_update_user(array('ID' => $new_user_id, 'nickname' => $yourname, 'display_name' => $yourname));
		update_option("escortid".$new_user_id, $type_name);
		update_user_meta($new_user_id, 'randomly_generated_data', 'randomly_generated_data');
		return $new_user_id;
	}
}

function generate_random_profile($user_id, $gender) {
	global $taxonomy_agency_url, $taxonomy_profile_url, $taxonomy_location_url, $ethnicity_a, $haircolor_a, $hairlength_a, $bustsize_a, $build_a, $looks_a, $smoker_a, $availability_a, $languagelevel_a, $services_a;
	// gender
	// 1 - female
	// 2 - male
	// 3 - couple
	// 4 - gay
	// 5 - transsexual
	$yourname = generate_random_name($gender);
	$aboutyou = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus in quam pretium, sodales velit id, aliquet dui. Vivamus nunc augue, elementum vel nulla sit amet, scelerisque aliquet sapien. Vestibulum non commodo urna. Sed tempus lacus ac quam pharetra dapibus. Ut sollicitudin odio vitae nisi rhoncus finibus. Nam pharetra rutrum mauris, a ultricies quam varius sed. Sed sodales felis magna, in cursus orci vulputate at. Maecenas semper eros eu eros lacinia, ut pellentesque massa tincidunt.<br /><br />Integer tempus justo at lectus convallis, at vestibulum purus placerat. Ut ultrices enim non elit molestie fringilla ac sed sem. Fusce efficitur nibh nec congue dignissim. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer dictum sed magna eu posuere. Vestibulum facilisis ultricies risus quis venenatis. Fusce sed porttitor sapien. Suspendisse at sapien finibus nulla rhoncus fringilla at non eros.<br /><br />Vestibulum egestas interdum lectus. Donec mollis sodales magna, ac facilisis ligula lacinia eu. Nunc pretium, massa ac efficitur venenatis, tellus nibh faucibus metus, id pharetra sapien eros nec nisl. Maecenas sed fermentum nisl. Cras dui lectus, lobortis finibus odio feugiat, scelerisque vulputate arcu. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ut ex nisi.";
	$post_profile = array(
		'post_title' => $yourname,
		'post_content' => $aboutyou,
		'post_name' => $yourname,
		'post_status' => 'publish',
		'post_author' => $user_id,
		'post_type' => $taxonomy_profile_url,
		'ping_status' => 'closed'
	);
	// Insert the post into the database
	$current_lang = multilang_switch_language();
	$post_profile_id = wp_insert_post($post_profile);

	$country_and_city = escortwp_get_demo_location_ids(); //returns an array with country id, state id and city id
	$country_id = $country_and_city[0];
	$state_id = $country_and_city[1];
	$city_id = $country_and_city[2];

	wp_set_post_terms($post_profile_id, $city_id, $taxonomy_location_url);
	multilang_switch_language($current_lang);
	update_post_meta($post_profile_id, "phone", '555 1234 567');
	update_post_meta($post_profile_id, "website", "https://escortwp.com/");
	update_post_meta($post_profile_id, "country", $country_id);
	update_post_meta($post_profile_id, "state", $state_id);
	update_post_meta($post_profile_id, "city", $city_id);
	update_post_meta($post_profile_id, "gender", $gender);
	update_post_meta($post_profile_id, "birthday", rand('1970', '1989')."-".rand(1,12)."-".rand(1,28));
	update_post_meta($post_profile_id, "ethnicity", rand(1,count($ethnicity_a)));
	update_post_meta($post_profile_id, "haircolor", rand(1,count($haircolor_a)));
	update_post_meta($post_profile_id, "hairlength", rand(1,count($hairlength_a)));
	update_post_meta($post_profile_id, "bustsize", rand(1,count($bustsize_a)));
	update_post_meta($post_profile_id, "height", rand(150,170));
	update_post_meta($post_profile_id, "weight", rand(50,70));
	update_post_meta($post_profile_id, "build", rand(1,count($build_a)));
	update_post_meta($post_profile_id, "looks", rand(1,count($looks_a)));
	update_post_meta($post_profile_id, "smoker", rand(1,count($smoker_a)));
	update_post_meta($post_profile_id, "availability", array((string)rand(1,count($availability_a))));
	update_post_meta($post_profile_id, "education", 'College');
	update_post_meta($post_profile_id, "sports", 'Bicycle, Dance');
	update_post_meta($post_profile_id, "hobbies", 'Photography, Dancing');
	update_post_meta($post_profile_id, "zodiacsign", 'Capricorn');
	update_post_meta($post_profile_id, "sexualorientation", 'rather not say');
	update_post_meta($post_profile_id, "occupation", 'rather not say');
	update_post_meta($post_profile_id, "language1", 'english');
	update_post_meta($post_profile_id, "language1level", rand(1,count($languagelevel_a)));
	update_post_meta($post_profile_id, "language2", 'spanish');
	update_post_meta($post_profile_id, "language2level", rand(1,count($languagelevel_a)));
	update_post_meta($post_profile_id, "language3", 'italian');
	update_post_meta($post_profile_id, "language3level", rand(1,count($languagelevel_a)));
	update_post_meta($post_profile_id, "currency", '22');
	update_post_meta($post_profile_id, "rate30min_incall", '50');
	update_post_meta($post_profile_id, "rate1h_incall", '100');
	update_post_meta($post_profile_id, "rate2h_incall", '200');
	update_post_meta($post_profile_id, "rate3h_incall", '300');
	update_post_meta($post_profile_id, "rate6h_incall", '600');
	update_post_meta($post_profile_id, "rate12h_incall", '1200');
	update_post_meta($post_profile_id, "rate24h_incall", '2400');
	update_post_meta($post_profile_id, "services", array_rand($services_a, floor((count($services_a)/2))));
	update_post_meta($post_profile_id, "randomly_generated_data", 'randomly_generated_data');
	if(rand(1,10) > 7) {
		update_post_meta($post_profile_id, "premium", '1');
		update_post_meta($post_profile_id, "premium_since", time());
	} else {
		update_post_meta($post_profile_id, "premium", '0');
	}
	if(rand(1,10) > 7) {
		update_post_meta($post_profile_id, "featured", '1');
	}
	if(rand(1,10) > 7) {
		update_post_meta($post_profile_id, "verified", '1');
	}
	$secret = md5($yourname.time().rand(1,9999));
	$upload_folder = "demo".time().rand(1,9999);
	update_post_meta($post_profile_id, "secret", $secret);
	update_post_meta($post_profile_id, "upload_folder", $upload_folder);

	if(get_option("escortid".$user_id) == $taxonomy_agency_url) { //only add if the profile belongs to an agency
		update_option("agency".$secret, $post_profile_id);
	} else { //else the profile is independent
		update_option("escortid".$post_profile_id, $taxonomy_profile_url);
		update_option("escortpostid".$user_id, $post_profile_id);
		update_post_meta($post_profile_id, "independent", "yes");
		update_option($secret, $user_id);
	}

	for ($i=1; $i < 3; $i++) {
		$tempFile = get_template_directory().'/i/demo-profiles-images/'.rand(1,87).".jpg";
		$targetPath = ABSPATH.'wp-content/uploads/'.$upload_folder;
		$targetFile =  time().rand(1000, 9999).".jpg";
		if (!is_dir($targetPath)) { mkdir($targetPath, 0777, true); }
		if (copy($tempFile,$targetPath."/".$targetFile)) {
			$attachment = array(
				'post_mime_type' => 'image/jpeg',
				'guid' => get_bloginfo("url")."/wp-content/uploads/".$upload_folder."/".$targetFile,
				'post_status' => 'inherit',
				'post_parent' => $post_profile_id,
				'post_title' => $targetFile,
				'post_type ' => "attachment"
			);
			wp_insert_attachment($attachment, $targetPath."/".$targetFile, $post_profile_id);
		}
	}
	return $post_profile_id;
}

function generate_random_agency($user_id) {
	global $taxonomy_agency_name, $taxonomy_agency_url, $taxonomy_location_url;
	$post_agency = array(
		'post_title' => generate_random_name('1')." ".ucfirst($taxonomy_agency_name),
		'post_content' => "<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus in quam pretium, sodales velit id, aliquet dui. Vivamus nunc augue, elementum vel nulla sit amet, scelerisque aliquet sapien. Vestibulum non commodo urna. Sed tempus lacus ac quam pharetra dapibus. Ut sollicitudin odio vitae nisi rhoncus finibus. Nam pharetra rutrum mauris, a ultricies quam varius sed. Sed sodales felis magna, in cursus orci vulputate at. Maecenas semper eros eu eros lacinia, ut pellentesque massa tincidunt.</p><p>Integer tempus justo at lectus convallis, at vestibulum purus placerat. Ut ultrices enim non elit molestie fringilla ac sed sem. Fusce efficitur nibh nec congue dignissim. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer dictum sed magna eu posuere. Vestibulum facilisis ultricies risus quis venenatis. Fusce sed porttitor sapien. Suspendisse at sapien finibus nulla rhoncus fringilla at non eros.</p><p>Vestibulum egestas interdum lectus. Donec mollis sodales magna, ac facilisis ligula lacinia eu. Nunc pretium, massa ac efficitur venenatis, tellus nibh faucibus metus, id pharetra sapien eros nec nisl. Maecenas sed fermentum nisl. Cras dui lectus, lobortis finibus odio feugiat, scelerisque vulputate arcu. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ut ex nisi.</p>",
		'post_status' => 'publish',
		'post_author' => $user_id,
		'post_type' => $taxonomy_agency_url,
		'ping_status' => 'closed'
	);
	// Insert the post into the database
	$current_lang = multilang_switch_language();
	$post_agency_id = wp_insert_post( $post_agency );
	$country_and_city = escortwp_get_demo_location_ids(); //returns an array with country id, state id and city id
	$country_id = $country_and_city[0];
	$state_id = $country_and_city[1];
	$city_id = $country_and_city[2];
	wp_set_post_terms($post_agency_id, $city_id, $taxonomy_location_url);
	multilang_switch_language($current_lang);
	update_post_meta($post_agency_id, "phone", "555 123 4567");
	update_post_meta($post_agency_id, "website", "https://escortwp.com/");
	update_post_meta($post_agency_id, "country", $country_id);
	update_post_meta($post_agency_id, "state", $state_id);
	update_post_meta($post_agency_id, "city", $city_id);
	update_post_meta($post_agency_id, "randomly_generated_data", 'randomly_generated_data');
	$secret = md5($yourname.time().rand(1,9999));
	update_post_meta($post_agency_id, "secret", $secret);
	$upload_folder = "demo_ag".time().rand(1,9999);
	update_post_meta($post_agency_id, "upload_folder", $upload_folder);
	update_post_meta($post_agency_id, "premium", '0');
	update_option("agencypostid".$user_id, $post_agency_id);
	update_option($secret, $user_id);

	for ($i=1; $i <= 1; $i++) {
		$tempFile = get_template_directory().'/i/demo-agencies-images/'.rand(1,8).".png";
		$targetPath = ABSPATH.'wp-content/uploads/'.$upload_folder;
		$targetFile =  time().rand(1000, 9999).".png";
		if (!is_dir($targetPath)) { mkdir($targetPath, 0777, true); }
		if (copy($tempFile,$targetPath."/".$targetFile)) {
			$attachment = array(
				'post_mime_type' => 'image/png',
				'guid' => get_bloginfo("url")."/wp-content/uploads/".$upload_folder."/".$targetFile,
				'post_status' => 'inherit',
				'post_parent' => $post_agency_id,
				'post_title' => $targetFile,
				'post_type ' => "attachment"
			);
			wp_insert_attachment($attachment, $targetPath."/".$targetFile, $post_agency_id);
		}
	}

	return $post_agency_id;
}

function generate_random_review($profile_id) {
	global $taxonomy_profile_url, $taxonomy_agency_url;

	$profile_data = get_post($profile_id);
	$reviews_cat_id = term_exists('Reviews', "category");
	if (!$reviews_cat_id) {
		$arg = array('description' => 'Reviews');
		$current_lang = multilang_switch_language();
		wp_insert_term('Reviews', "category", $arg);
		multilang_switch_language($current_lang);
		$reviews_cat_id = term_exists( 'Reviews', "category" );
	}
	$reviews_cat_id = $reviews_cat_id['term_id'];
	$reviewtext_arr = array(
			'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam at fringilla tellus, sit amet tristique elit. Phasellus in rutrum purus, vitae cursus sem. Vivamus nec est nec quam varius eleifend. Cras tempor, risus non condimentum aliquet, lectus lectus varius felis, sed euismod odio tortor non tortor. Vivamus lorem mi, vehicula et metus ac, sollicitudin feugiat diam. Ut convallis viverra venenatis. Integer dictum ex lacus, consequat faucibus magna euismod vel. Vivamus mollis magna ac est placerat, sit amet ornare neque semper. Mauris imperdiet molestie interdum. Fusce condimentum venenatis sapien, vitae venenatis arcu interdum eget.',
			'Fusce convallis pharetra ante vel maximus. Morbi vestibulum magna tempor cursus accumsan. Nam accumsan feugiat quam sed fringilla. Integer eget lobortis orci. Vivamus finibus lorem nulla, at euismod mauris accumsan ac. Nulla facilisi. Nulla facilisi. Ut augue lorem, commodo a orci sit amet, dictum placerat lectus. Donec arcu tortor, lobortis id sollicitudin non, iaculis non libero. Integer quis blandit massa. Vestibulum ut massa pellentesque, condimentum justo in, mattis metus. Donec imperdiet pulvinar ipsum, tempus ullamcorper mi. Pellentesque eu mi risus. Integer augue lectus, auctor lacinia sollicitudin id, ultricies nec tortor.',
			'Nunc maximus lorem vitae posuere lacinia. Ut iaculis sodales ipsum, sit amet convallis est accumsan sit amet. Proin sed efficitur odio. Cras condimentum commodo erat at finibus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed tempus augue nisi, tempus finibus lorem ornare in. Etiam non quam et mauris lobortis ultrices. Donec condimentum sem at condimentum condimentum. Sed consequat justo arcu, vel rhoncus diam suscipit ut. Aliquam erat volutpat. Nulla sit amet porttitor ex, in gravida ex.',
			'Mauris placerat tortor rhoncus metus ullamcorper sollicitudin. Curabitur vehicula sem a rhoncus lacinia. Sed rhoncus pellentesque nisl ac dictum. Proin ultricies hendrerit nulla. Etiam ut nibh molestie, sollicitudin tellus faucibus, tincidunt urna. Aenean feugiat hendrerit fringilla. Praesent dui nulla, aliquam ac augue at, efficitur ornare lectus. Fusce eget pharetra sapien, in euismod turpis. Fusce posuere gravida sagittis.',
			'Pellentesque lobortis aliquet ullamcorper. In vel blandit risus. Pellentesque nec eleifend ex. Nullam dictum elementum egestas. Integer vel fringilla enim, sit amet euismod nisi. Vestibulum egestas, lorem nec auctor varius, risus metus aliquam tortor, eget sagittis ex est a justo. Aliquam erat volutpat. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In congue vulputate mauris, vitae lacinia sapien interdum nec. Vivamus vitae mollis ante. Fusce facilisis, ante a pretium luctus, lacus ipsum condimentum felis, eu laoreet erat urna vel nibh. Suspendisse eget erat non justo feugiat elementum in in urna. Donec auctor vel odio mollis tempor. Sed pulvinar odio id lacinia lobortis.',
			'Phasellus viverra risus at odio egestas, sit amet condimentum dui venenatis. Duis mollis ullamcorper mi eu tempus. Fusce quis enim et lectus fermentum consectetur. Ut quis molestie libero. Aenean eu ultrices leo. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Curabitur aliquam nisl mauris, at porta ipsum elementum quis. Nulla facilisi. Pellentesque mattis dolor sit amet urna sollicitudin consequat. Duis ut libero erat. Praesent lobortis laoreet laoreet. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Suspendisse pharetra nibh lacus, ac semper tellus tincidunt nec. Duis scelerisque mi libero, nec pulvinar nulla bibendum in. Morbi eget tellus sed turpis maximus ultricies ut non mauris.',
			'Proin aliquam lobortis feugiat. Praesent eu luctus dui. Nunc posuere ac justo eget lacinia. Integer lacinia nisi id nunc tristique lacinia. In hac habitasse platea dictumst. Aenean tellus urna, luctus vel risus non, ornare feugiat felis. Maecenas quis libero nec diam placerat lacinia eget vitae nisl. In auctor arcu et eros fermentum bibendum. Curabitur sed varius urna, eget tristique tellus. In hac habitasse platea dictumst. Donec mollis quis lectus vel pharetra. Vestibulum semper ullamcorper augue sit amet aliquam. Sed at convallis augue, quis euismod dolor.',
			'Donec at ex nisl. Quisque sodales diam sit amet commodo molestie. Suspendisse quis tempus quam. Duis elementum mi nisi. Proin ac urna mollis, lacinia lacus non, volutpat ligula. Integer et mi at elit tristique pellentesque ut sed tortor. Ut eget orci arcu. Aliquam augue ligula, porta sed ullamcorper quis, eleifend at sem. Curabitur tincidunt tincidunt quam, ut aliquam nisi consequat sed. Fusce porta facilisis nisl nec dignissim. Aliquam massa lacus, porta laoreet dictum at, egestas commodo ligula. Ut tempor risus leo, ut sollicitudin erat consequat ac.',
			'Mauris aliquam risus eu dui imperdiet lobortis. Nam ornare a ligula eu accumsan. Nullam nunc orci, volutpat eu orci non, mattis venenatis lectus. Vivamus convallis auctor dictum. Nullam vel molestie libero, nec pulvinar tortor. Aliquam leo risus, vestibulum et rutrum a, fringilla sit amet sapien. Maecenas fermentum iaculis dolor cursus ultrices. Aliquam erat volutpat.',
			'In auctor purus sit amet ipsum egestas, eu sagittis lorem dignissim. Nam pretium, justo in fringilla accumsan, magna nisl fermentum libero, vel ullamcorper libero erat et est. Mauris nulla tortor, pulvinar id tellus varius, luctus rhoncus mi. Aliquam sed elit commodo, luctus enim quis, placerat nunc. Aenean condimentum pretium augue quis pellentesque. Phasellus sed ipsum elit. Duis gravida pretium tellus. In faucibus a leo ut volutpat.',
			'Maecenas ac felis ut ipsum bibendum viverra. Morbi at lorem dolor. In fermentum massa eu accumsan convallis. Praesent facilisis finibus risus, in sollicitudin sem ultricies in. Vestibulum ultrices vehicula faucibus. Proin eu neque quis ex fermentum ultricies. Vivamus aliquet vel tortor id ullamcorper. Curabitur ac eros purus. Vivamus blandit a enim sed porttitor. Integer at finibus felis. Duis a interdum felis. Nullam rutrum velit in tellus ullamcorper lobortis.',
			'Suspendisse potenti. Sed nec nunc at augue condimentum aliquam quis in libero. Mauris in turpis in nunc molestie lacinia vel nec lacus. Vivamus vitae sapien quis libero facilisis imperdiet. Vivamus in mi sed massa imperdiet egestas. Nulla facilisi. Integer semper fringilla quam at facilisis. Sed dapibus, mi in lobortis pellentesque, nisi quam consequat odio, a maximus quam lectus viverra magna. Mauris risus ligula, facilisis quis venenatis non, faucibus vitae libero. Phasellus a neque elementum, sodales justo at, bibendum orci. Sed eu diam elementum, sodales nibh ut, imperdiet dui.',
			'Duis efficitur metus et quam ornare, et sodales massa egestas. Cras nec venenatis erat, quis varius urna. Cras non semper magna. Aenean tincidunt aliquet urna. Aenean a dui et mauris vehicula suscipit. Mauris ut aliquam libero, sed dictum dolor. Praesent fringilla, urna a consectetur congue, sapien lacus pretium tortor, pellentesque ullamcorper orci magna a sapien. In in viverra erat. Praesent egestas auctor ex ut fringilla. Nam interdum nibh nisl, nec molestie quam accumsan ac. Quisque et elit ac purus iaculis dapibus.',
			'Vivamus sed orci nisl. Sed nec congue odio, non semper eros. Aenean vitae gravida elit. Nam in porta libero. Vestibulum iaculis leo ut est consequat, at pellentesque dolor cursus. Nullam semper diam ut ligula sagittis pretium. Praesent placerat congue sapien, ut dapibus nisi luctus eget. Proin varius non lacus a interdum.',
			'Maecenas augue enim, interdum non enim pulvinar, mattis pretium enim. Duis sed tortor ligula. Vestibulum lacinia diam ligula, quis tincidunt risus condimentum eget. Vivamus ac tincidunt nunc, a porta ex. Aenean fermentum accumsan magna non lacinia. Integer non urna sit amet ipsum molestie scelerisque. Phasellus et lacinia felis. Donec varius ante non elit gravida eleifend. Integer suscipit cursus lorem, id consectetur eros vestibulum sed. Nulla varius risus eget scelerisque iaculis.',
			'Fusce et nibh sollicitudin, pretium orci sit amet, imperdiet purus. Nunc ornare massa vel purus egestas pellentesque. Duis ornare scelerisque efficitur. In at elit sit amet arcu egestas lacinia ac at diam. Cras sit amet ipsum ac urna dignissim semper. Integer nec sem commodo eros eleifend ornare nec vel enim. Quisque dolor magna, eleifend at sodales ac, maximus sed nunc. Sed aliquet mollis orci quis tincidunt. Curabitur ut risus ac orci mollis dapibus et sit amet neque.',
			'Fusce sit amet lobortis sem. Maecenas pretium, ex nec lobortis hendrerit, neque elit gravida nisl, quis tempor odio enim eget massa. Proin cursus erat et risus faucibus sodales. Duis sed sapien quam. Duis vitae risus eget ligula dictum consequat. Praesent eget viverra augue, eu commodo lorem. Vestibulum commodo eros a ipsum efficitur mattis. Praesent feugiat consectetur consequat. Aliquam ornare massa consequat malesuada gravida. In ultricies nulla et metus porttitor fermentum. Cras vitae sem vel odio malesuada sodales sit amet vel augue. Proin ultrices, sapien eget malesuada hendrerit, ligula ligula lacinia purus, eu facilisis orci nibh ut tellus. Mauris sollicitudin blandit dolor a sodales.',
			'In pulvinar, nulla eget fringilla pellentesque, diam odio eleifend mi, eget pretium magna augue et turpis. Ut tincidunt posuere ante, a varius nunc fermentum at. Cras sed lacus augue. Curabitur vitae nulla eget ex suscipit lobortis. Praesent luctus, nulla eget laoreet fermentum, ipsum orci molestie est, eu consectetur eros magna a dui. Proin quis dui arcu. Sed eu mattis enim. Pellentesque consectetur eleifend molestie. Aenean vestibulum augue sit amet nisi eleifend, vulputate dictum massa congue. In consequat viverra sapien non dictum. Vestibulum dignissim ut nisi sodales rhoncus. Vivamus fringilla ullamcorper aliquet. Pellentesque ac ornare orci, vel tempus justo. Aliquam facilisis efficitur enim. Praesent a augue in ipsum vestibulum imperdiet. Nam condimentum tristique dignissim.'
		);
    $reviewtext = $reviewtext_arr[mt_rand(0, count($reviewtext_arr) - 1)];
	$add_review = array(
		'post_title' => __('Review for','escortwp')." ".$profile_data->post_title,
		'post_content' => $reviewtext,
		'post_status' => 'publish',
		'post_author' => generate_random_user('3'),
		'post_category' => array($reviews_cat_id),
		'post_type' => 'review',
		'ping_status' => 'closed'
	);
	$current_lang = multilang_switch_language();
	$add_review_id = wp_insert_post( $add_review );
	multilang_switch_language($current_lang);
	update_post_meta($add_review_id, "rateescort", rand(3,5));
	update_post_meta($add_review_id, "escortid", $profile_id);
	update_post_meta($add_review_id, "reviewfor", ($profile_data->post_type == $taxonomy_profile_url ? "profile" : "agency"));
	update_post_meta($add_review_id, "demo", "demo");
}

function escortwp_get_demo_location_ids() {
	$assignment = escortwp_get_default_brazil_location_assignment(mt_rand(1, 999999));
	if (!$assignment) {
		return array(0, 0, 0);
	}

	return array(
		(int) $assignment['country']->term_id,
		(int) $assignment['state']->term_id,
		(int) $assignment['city']->term_id,
	);
}

function get_country_and_city_id() {
	return escortwp_get_demo_location_ids();

	global $taxonomy_location_url;
	$locations = array(
			array(
				'country' => 'Germany', 
				'cities' => array('Berlin', 'Hamburg', 'Munich', 'Cologne', 'Frankfurt', 'Stuttgart', 'DÃƒÂ¼sseldorf', 'Dortmund')
			),
			array(
				'country' => 'France', 
				'cities' => array('Paris', 'Marseille', 'Rouen', 'Lyon', 'Toulouse', 'Montpellier', 'Bordeaux', 'Lille')
			),
			array(
				'country' => 'Italy', 
				'cities' => array('Rome', 'Milan', 'Turin', 'Genoa', 'Florence', 'Bari', 'Catania', 'Venice', 'Trieste')
			),
			array(
				'country' => 'Netherlands', 
				'cities' => array('Amsterdam', 'Rotterdam', 'The Hague', 'Eindhoven', 'Tilburg', 'Groningen', 'Almere')
			),
			array(
				'country' => 'Spain', 
				'cities' => array('Madrid', 'Barcelona', 'Valencia', 'Seville', 'Bilboa', 'MÃƒÂ¡laga', 'GijÃƒÂ³n', 'Las Palmas')
			),
			array(
				'country' => 'Austria', 
				'cities' => array('Vienna', 'Graz', 'Linz', 'Salzburg', 'Innsbruck', 'Klagenfurt', 'Villach', 'Wels')
			),
			array(
				'country' => 'United States', 
				'cities' => array('New York', 'Los Angeles', 'Chicago', 'Houston', 'Philadelphia', 'Phoenix', 'San Diego')
			),
		);
    $country_data = $locations[mt_rand(0, count($locations) - 1)];
    $country_name = $country_data['country'];
    $city_name = $country_data['cities'][mt_rand(0, count($country_data['cities']) - 1)];
	$current_lang = multilang_switch_language();
	wp_insert_term($country_name, $taxonomy_location_url, array('description' => 'randomly_generated_data'));
	$country_id = get_term_by('name', $country_name, $taxonomy_location_url);
	$country_id = $country_id->term_id;

	wp_insert_term($city_name, $taxonomy_location_url, array('parent' => $country_id, 'description' => 'randomly_generated_data'));
	multilang_switch_language($current_lang);
	$city_id = get_term_by('name', $city_name, $taxonomy_location_url);
	$city_id = $city_id->term_id;

	return array($country_id, $city_id);
}

//helper functions
function pr($t) { echo "<pre style='background-color: #fff; color: #000;'>"; print_r($t); echo "</pre><br />\n"; }
function prd($t) { pr($t); die(); }


function license_check() {
	if(get_option('dolce_check_license') < time() && current_user_can('level_10')) {
		global $license_key;
		$url = "https://escortwp.com/check-license/";
		$vars = "?key=".$license_key."&domain=".urlencode(get_bloginfo('url').'/')."&email=".urlencode(get_bloginfo('admin_email'));
		$args = array(
			'timeout'     => 5,
			'redirection' => 5,
			'user-agent'  => 'WordPress ' . get_bloginfo( 'url' )
		);
		$request = wp_remote_get($url.$vars, $args);
		// if license check fails check again in 1 hour
		if(is_wp_error($request)) {
			update_option('dolce_check_license', time()+3600 ); //add 1 hour
			return false;
		}

		// if license check fails check again in 1 hour
		$result = json_decode($request['body']);
		if(!isset($result->key_check) && !isset($result->allow_domain)) {
			update_option('dolce_check_license', time()+3600 ); //add 1 hour
			return false;
		}

		// if license is ok then check again in 3 days
		if($result->key_check == '1' && $result->allow_domain == "1") {
			update_option('dolce_check_license', time()+259200 ); //add 3 days
			return false;
		}

		// if key does not exist
		if($result->key_check != '1') {
			die('<div class="err rad5" style="line-height: 2em; padding: 20px 0;">Your copy of the theme does not have a valid license key! Because of this you will not be able to install the theme.<br />If you think this is an error then please send us a message with the help of our <a href="https://escortwp.com/contact-us/">contact form</a> and we can fix this for you.</div>');
		}

		// if the domain is not allowed
		if($result->allow_domain != '1') {
			foreach($result->domains_in_use as $domain) {
				$domains .= $domain." <small class='redbutton rad3' id='".$domain."'>delete</small><div class='clear10'></div>";
			} ?>
			<script type = 'text/javascript'>
				jQuery(document).ready(function($) {
					$('.redbutton').on('click', function() {
						$('.redbutton').hide();
						var domain = $(this).attr('id');
						var get_data = "?key=<?php echo $license_key; ?>&allow_this_domain=<?php bloginfo('url') ?>&remove_domain="+domain;
						$.ajax({
							url : "<?php echo $url; ?>"+get_data,
							dataType: 'jsonp',
							success: function(msg) {
								var response = jQuery.parseJSON(msg);
								if(response == "ok") {
									$('.check_license_div').html('<div class="ok rad5">The license has been removed from the old domain.</div>You will be redirected in 3 seconds.');
									setTimeout(function(){
										location.reload();
									}, 3000);
								}
								if(response == "err") {
									$('.redbutton').show();
									alert('Something went wrong. Try again.');
								}
							},
							error: function (msg) {
								var response = jQuery.parseJSON(msg);
								if(msg == "err") {
									$('.redbutton').show();
									alert('Something went wrong. Try again.');
								}
							}
						});
					});
				});
			</script>
			<div class="clear10"></div>
			<div class="check_license_div rad5" style="line-height: 1.5em; padding: 20px; text-align: left; max-width: 500px; margin: 0 auto; background-color: #fff;">
			<div class="err rad5">Your license has been used on too many domains.</div>
			Send us a message with the help of our <a href="https://escortwp.com/contact-us/"><u>contact form</u></a> and ask us how you can upgrade your theme package so you can use this theme on more domains.<br /><br />You can also remove the activation from some of your other domains. That way you will be able to use the theme on this domain instead.<br />Click the delete button for one of the domains bellow if you would like to do that:<div class="clear10"></div>
			<?php echo $domains; ?>
			<small>You will not be able to use the theme anymore on the domain you delete</small></div>
			<?php
			die();
		}
	} // if check_license < time()
} // license_check



function theme_comments( $comment, $args, $depth ) {
	$GLOBALS['comment'] = $comment;
	?>
	<div class="clear"></div>
	<div <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent' ) ?>><a name="comment-<?php comment_ID() ?>"></a>
		<div class="commentbox" id="commentbox-<?php comment_ID() ?>">
			<div class="comment-info">
	            <span class="commauthor l"><?php comment_author(); ?></span>
	            <span class="commdate r"><?php comment_date() ?> | <?php comment_reply_link( array_merge( $args, array( 'reply_text' => __('Reply','escortwp'), 'add_below' => 'commentbox', 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?><?php edit_comment_link('edit', ' | ', ''); ?></span>
	            <div class="clear"></div>
			</div> <!-- comment-info -->
			<div class="comment-text rad5">
		    	<?php if ($comment->comment_approved == '0') : ?>
					<div class="ok rad5"><?php _e('Your comment has been posted but needs to be approved by an admin first.','escortwp'); ?></div>
				<?php endif; ?>
				<?php comment_text() ?>
		        <div class="clear"></div>
			</div> <!-- comment-text -->
	        <div class="clear"></div>
		</div>
	    <div class="clear"></div>
	<?php
}

function verify_recaptcha() {
	$response = preg_replace("/([^a-zA-Z0-9_-])/", "", $_POST['g-recaptcha-response']);
	$url = "https://www.google.com/recaptcha/api/siteverify?secret=".get_option("recaptcha_secretkey")."&response=".$response."&remoteip=".getenv('REMOTE_ADDR');
	$result = wp_remote_get($url);
	$result = json_decode($result['body']);
	if(!$result->success) {
		return __('Are you a robot?','escortwp')."<br />";
	}
}

// Remove "Private" from the tittle
function title_format($content) {
	return '%s';
}
add_filter('private_title_format', 'title_format');

function is_video_processing_running($PID) {
	exec("ps $PID", $ProcessState);
	return(count($ProcessState) >= 2);
}

// does the user have a tour active in another city?
function get_user_current_tour($profile_id) {
	$tours_args = array(
		'post_type' => 'tour',
		'post_status' => 'publish',
		'posts_per_page' => '1',
		'order' => 'ASC',
		'orderby' => 'meta_value_num',
		'meta_key' => 'start',
		'meta_query' => array(
			array(
				'key' => 'belongstoescortid',
				'value' => $profile_id,
				'compare' => '=',
				'type' => 'NUMERIC'
			),
			array(
				'key' => 'start',
				'value' => mktime(0, 0, 0, date("m"), date("d"), date("Y")),
				'compare' => '<=',
				'type' => 'NUMERIC'
			),
			array(
				'key' => 'end',
				'value' => mktime(23, 59, 59, date("m"), date("d"), date("Y")),
				'compare' => '>=',
				'type' => 'NUMERIC'
			)
		),
		'fields' => 'ids'
	);
	$tours = new WP_Query($tours_args);
	if(count($tours->posts) > 0) {
		$post_id = $tours->posts[0];
	}
	if(isset($post_id) && $post_id > 0) {
		global $taxonomy_location_url;
		$country = get_term_by('id', get_post_meta($post_id, 'country', true), $taxonomy_location_url);
		$city = get_term_by('id', get_post_meta($post_id, 'city', true), $taxonomy_location_url);
		$response = array(
			'country' => $country,
			'city' => $city
			);
		if(get_post_meta($post_id, 'state', true)) {
			$state = get_term_by('id', get_post_meta($post_id, 'state', true), $taxonomy_location_url);
			$response['state'] = $state;
		}
		return $response;
	} else {
		return false;
	}
}


function yes_no_select_form_field($name, $val="") {
	$selected = array("1"=>"","2"=>"");
	if($selected) {
		$selected[$val] = ' selected="selected"';
	}
	$html = '<select name="'.$name.'">
				<option value="1"'.$selected["1"].'>'.__('No','escortwp').'</option>
				<option value="2"'.$selected["2"].'>'.__('Yes','escortwp').'</option>
			</select>';
	return $html;
}


function user_last_online_time() {
	if(is_user_logged_in()) {
		$current_user = wp_get_current_user();
		update_user_meta($current_user->ID, 'last_online', (int)current_time('timestamp'));
	}
}
add_action('init', 'user_last_online_time');



function insert_array_inside_another_array( array $array, $key, array $new ) {
	$keys = array_keys( $array );
	$index = array_search( $key, $keys );
	$pos = false === $index ? count( $array ) : $index + 1;
	return array_merge( array_slice( $array, 0, $pos ), $new, array_slice( $array, $pos ) );
}


function esc_page_hit_counter($id) {
	global $taxonomy_profile_url, $taxonomy_agency_url;
	$current_user = wp_get_current_user();
	$current_count = (int)get_post_meta($id, 'visitor_counter', true);
	$post = get_post($id);
	if(!current_user_can('level_10') && $post->post_author != $current_user->ID) {
		$current_count++;
		update_post_meta($id, 'visitor_counter', $current_count);
	}
	switch (get_post_type()) {
		case $taxonomy_profile_url:
			$page_name = __('profile','escortwp');
			break;
		
		case $taxonomy_agency_url:
			$page_name = __('profile','escortwp');
			break;
		
		case 'ad':
			$page_name = __('ad','escortwp');
			break;
		
		default:
			$page_name = __('page','escortwp');
			break;
	}
	$current_count_html = '<span class="count rad25">'.$current_count.'</span>';
	if($current_count == "1") {
		$return_html = sprintf(__('viewed %s time','escortwp'),$current_count_html);
	} else {
		$return_html = sprintf(__('viewed %s times','escortwp'),$current_count_html);
	}
	return '<div class="visitor-counter">'.$page_name.' '.$return_html.'</div>';
}


function multilang_switch_language($current_lang="") {
	if (function_exists('icl_object_id')) {
		global $sitepress;
		if($current_lang) {
			$sitepress->switch_lang($current_lang);
		} else {	
			$current_lang = ICL_LANGUAGE_CODE;
			$sitepress->switch_lang($sitepress->get_default_language());
			return $current_lang;
		}
	}
}


function add_opacity_to_watermark($img, $opacity) {
    if (!isset($opacity)) {
        return false;
    }
    $opacity /= 100;

    //get image width and height
    $w = imagesx($img);
    $h = imagesy($img);

    //turn alpha blending off
    imagealphablending($img, false);

    //find the most opaque pixel in the image (the one with the smallest alpha value)
    $minalpha = 127;
    for ($x = 0; $x < $w; $x++) {
        for ($y = 0; $y < $h; $y++) {
            $alpha = (imagecolorat($img, $x, $y) >> 24) & 0xFF;
            if ($alpha < $minalpha) {
                $minalpha = $alpha;
            }
        }
    }

    //loop through image pixels and modify alpha for each
    for ($x = 0; $x < $w; $x++) {
        for ($y = 0; $y < $h; $y++) {
            //get current alpha value (represents the TANSPARENCY!)
            $colorxy = imagecolorat($img, $x, $y);
            $alpha = ($colorxy >> 24) & 0xFF;
            //calculate new alpha
            if ($minalpha !== 127) {
                $alpha = 127 + 127 * $opacity * ($alpha - 127) / (127 - $minalpha);
            } else {
                $alpha += 127 * $opacity;
            }
            //get the color index with new alpha
            $alphacolorxy = imagecolorallocatealpha($img, ($colorxy >> 16) & 0xFF, ($colorxy >> 8) & 0xFF, $colorxy & 0xFF, $alpha);
            //set pixel with the new color + opacity
            if (!imagesetpixel($img, $x, $y, $alphacolorxy)) {
                return false;
            }
        }
    }

    return true;
}



function show_report_profile_button($id) {
	?>
	<script type="text/javascript">
	jQuery(document).ready(function($) {
		$('.report-profile-wrapper .report-profile-button').on('click', function(event) {
			$(this).hide();
			$(this).siblings('.report-profile-reason-wrapper').fadeIn('100', function (){
				$('html, body').animate({ scrollTop: $('.report-profile-reason-wrapper').offset().top }, 150);
			})
		});
		$('.report-profile-reason-wrapper .closebtn').on('click', function(event) {
			$(this).parent().hide();
			$(this).parent().siblings('.report-profile-button').show();
		});

		$('.report-profile-wrapper .submit-button').on('click', function(){
			if($(this).hasClass('working')) {
				return false;
			} else {
				$(this).addClass('working');
			}

			$('.report-profile-wrapper .err').remove();
			var form = $('.report-profile-reason-form');
			var profileid = form.find('.report-form-field-id').val();
			var reason = form.find('.report-form-field-reason').val();
			var recaptcha = "";
			<?php if(get_option('recaptcha_sitekey') && get_option('recaptcha_secretkey') && !is_user_logged_in() && get_option("recaptcha6")) { ?>
			recaptcha = grecaptcha.getResponse();
			if(!recaptcha) {
				$('.report-profile-wrapper .report-profile-reason-form').prepend('<div class="err rad5"><?=addslashes(__('Are you a robot?', 'escortwp'))?></div>');
				$(this).removeClass('working');
				return false;
			}
			<?php } ?>
			if(!reason) {
				$('.report-profile-wrapper .report-profile-reason-form').prepend('<div class="err rad5"><?=addslashes(__('Please write a reason for your report', 'escortwp'))?></div>');
				$(this).removeClass('working');
				return false;
			}
			$.ajax({
				type: "POST",
				url: "<?php bloginfo('template_url'); ?>/ajax/send-profile-report.php",
				data: { profileid: profileid, reason: reason, escortwp_nonce: window.escortwpAjax ? window.escortwpAjax.nonce : '', 'g-recaptcha-response': recaptcha },
				cache: false,
				timeout: 20000, // in milliseconds
				success: function(raw_data) {
					var data = JSON.parse(raw_data);
					if(data.status == 'ok') {
						$('.report-profile-wrapper').html('<div class="ok rad5">'+data.msg+'</div>');
					} else {
						$('.report-profile-wrapper .report-profile-reason-form').prepend('<div class="err rad5">'+data.msg+'</div>');
					}
					$(this).removeClass('working');
				},
				error: function(request, status, err) {
					$(this).removeClass('working');
				}
			});
		});
	});
	</script>
	<div class="report-profile-wrapper">
		<div class="report-profile-button rad25 redbutton"><span class="icon icon-report"></span><?=__('Report Profile', 'escortwp')?></div>
		<div class="clear"></div>
		<div class="report-profile-reason-wrapper rad5">
			<?php closebtn() ?><div class="clear"></div>
			<div class="report-profile-reason-form form-styling">
		    	<input type="hidden" name="profile_id" class="report-form-field-id" value="<?=$id?>" />
			    <div class="form-label col100">
					<label for="reason"><?php _e('Write a short description for your report:','escortwp'); ?></label>
				</div>
				<div class="form-input col100">
			    	<input type="text" maxlength="300" name="reason" id="reason" class="report-form-field-reason input longinput col100" autocomplete="off" />
				</div> <!-- username -->
			    <?php if(get_option('recaptcha_sitekey') && get_option('recaptcha_secretkey') && !is_user_logged_in() && get_option("recaptcha6")) { ?>
				<div class="form-input col100">
					<div class="g-recaptcha center" data-sitekey="<?php echo get_option('recaptcha_sitekey'); ?>"></div>
				</div> <!-- captcha --> <div class="clear10"></div>
			    <?php } ?>
				<button class="submit-button rad25 greenbutton"><span class="icon icon-report"></span> <span class="label-normal"><?=__('Send report', 'escortwp')?></span><span class="label-working"><?=__('Sending', 'escortwp')?></span></button>
			</div><!-- report-profile-reason-form -->
		</div><!-- report-profile-options -->
	</div><!-- report-profile-wrapper -->
	<?php
}


function show_online_label_html($user_id) {
	$last_online = get_user_meta($user_id, 'last_online', true);
	if($last_online >= (current_time('timestamp') - 60*5)) {
		$label = '<div class="online-status">
				<span class="online-label">
					<div class="notification-circle">
						<span class="notification-circle-outside">
							<span class="notification-circle-inside"></span>
						</span>
					</div>
					<span class="text-label">'.__('Online','escortwp').'</span>
				</span>
			</div>';
	} else {
		$label = "";
	}
	return $label;
}


remove_filter('pre_term_description', 'wp_filter_kses');
remove_filter('term_description', 'wp_kses_data');

add_filter( 'wp_insert_post_data', function( $data, $postarr ) {
if ( ! empty( $data['post_content'] ) ) {
    $data['post_content'] = wp_encode_emoji( $data['post_content'] );
}
return $data;
}, 99, 2 );


function add_theme_meta_tags() {
    echo "\n\t".'<!-- Este site foi criado com o tema premium WordPress da EscortWP.com -->' . "\t";
    echo "\n\t".'<meta name="theme-name" content="EscortWP" />' . "\n\t";
    echo "\n\t".'<meta name="theme-creator" content="https://escortwp.com/" />' . "\n";
}
add_action('wp_head', 'add_theme_meta_tags', 1);

function escortwp_output_basic_meta_description() {
	if (is_admin() || function_exists('is_feed') && is_feed()) {
		return;
	}

	if (defined('WPSEO_VERSION') || defined('RANK_MATH_VERSION')) {
		return;
	}

	$description = '';
	if (is_singular()) {
		$post = get_queried_object();
		if ($post instanceof WP_Post) {
			$description = wp_strip_all_tags(get_the_excerpt($post));
			if ($description === '') {
				$description = wp_trim_words(wp_strip_all_tags((string) $post->post_content), 24);
			}
		}
	}

	if ($description === '') {
		$description = get_bloginfo('description');
	}

	if ($description !== '') {
		echo "\n\t" . '<meta name="description" content="' . esc_attr($description) . '" />' . "\n";
	}
}
add_action('wp_head', 'escortwp_output_basic_meta_description', 3);

function escortwp_filter_document_title_parts($parts) {
	if (!escortwp_should_use_pt_br_translations()) {
		return $parts;
	}

	$title_map = array(
		'Search for Acompanhantes' => 'Buscar acompanhantes',
		'Register on Our Site' => 'Criar conta',
		'Contact us' => 'Fale conosco',
		'page not found' => 'Página não encontrada',
	);

	if (is_404()) {
		$parts['title'] = 'Página não encontrada';
		return $parts;
	}

	if (is_page((int) get_option('main_reg_page_id'))) {
		$parts['title'] = 'Criar conta';
		return $parts;
	}

	if (is_page((int) get_option('member_register_page_id'))) {
		$parts['title'] = 'Cadastro de cliente';
		return $parts;
	}

	if (is_page((int) get_option('escort_reg_page_id'))) {
		$parts['title'] = 'Cadastro de acompanhante';
		return $parts;
	}

	if (is_page((int) get_option('search_page_id'))) {
		$parts['title'] = 'Buscar acompanhantes';
		return $parts;
	}

	if (is_page((int) get_option('contact_page_id'))) {
		$parts['title'] = 'Fale conosco';
		return $parts;
	}

	if (!empty($parts['title']) && isset($title_map[$parts['title']])) {
		$parts['title'] = $title_map[$parts['title']];
	}

	return $parts;
}
add_filter('document_title_parts', 'escortwp_filter_document_title_parts', 20);

function escortwp_filter_document_title_parts_clean($parts) {
	if (!escortwp_should_use_pt_br_translations()) {
		return $parts;
	}

	if (is_404()) {
		$parts['title'] = 'Página não encontrada';
	}

	if (!empty($parts['title']) && $parts['title'] === 'page not found') {
		$parts['title'] = 'Página não encontrada';
	}

	return $parts;
}
add_filter('document_title_parts', 'escortwp_filter_document_title_parts_clean', 30);

function escortwp_normalize_visible_text($text) {
	if (!is_string($text) || $text === '') {
		return $text;
	}

	$replacements = array(
		'NavegaÃƒÂ§ÃƒÂ£o principal' => 'NavegaÃ§Ã£o principal',
		'InÃƒÂ­cio' => 'InÃ­cio',
		'RegiÃƒÂµes atendidas' => 'RegiÃµes atendidas',
		'Busca rÃƒÂ¡pida' => 'Busca rÃ¡pida',
		'Busca avanÃƒÂ§ada' => 'Busca avanÃ§ada',
		'ÃƒÂrea vip' => 'Ãrea vip',
		'ÃƒÂrea VIP' => 'Ãrea VIP',
		'Ver ÃƒÂ¡rea vip' => 'Ver Ã¡rea vip',
		'Ver ÃƒÂ¡rea VIP' => 'Ver Ã¡rea VIP',
		'ÃƒÅ¡ltimas avaliaÃƒÂ§ÃƒÂµes' => 'Ãšltimas avaliaÃ§Ãµes',
		'InformaÃƒÂ§ÃƒÂµes de contato' => 'InformaÃ§Ãµes de contato',
		'InformaÃƒÂ§ÃƒÂµes de contato:' => 'InformaÃ§Ãµes de contato:',
		'Plano gratis' => 'Plano grÃ¡tis',
		'Gratis' => 'GrÃ¡tis',
		'Criar conta gratis primeiro' => 'Criar conta grÃ¡tis primeiro',
		'Pagamento unico' => 'Pagamento Ãºnico',
		'Nao vira mensalidade e nao renova sozinho.' => 'NÃ£o vira mensalidade e nÃ£o renova sozinho.',
		'Seu cadastro foi concluido' => 'Seu cadastro foi concluÃ­do',
		'Reenviar e-mail de validacao' => 'Reenviar e-mail de validaÃ§Ã£o',
		'Nao recebeu o e-mail?' => 'NÃ£o recebeu o e-mail?',
		'Alterar endereco de e-mail' => 'Alterar endereÃ§o de e-mail',
		'PÃƒÂ¡gina nÃƒÂ£o encontrada' => 'PÃ¡gina nÃ£o encontrada',
		'FranÃƒÂ§a' => 'FranÃ§a',
		'GoiÃƒÂ¡s' => 'GoiÃ¡s',
		'GoiÃƒÂ¢nia' => 'GoiÃ¢nia',
		'AnÃƒÂ¡polis' => 'AnÃ¡polis',
		'CÃƒÂ©u Azul' => 'CÃ©u Azul',
		'SÃƒÂ£o SebastiÃƒÂ£o' => 'SÃ£o SebastiÃ£o',
		'GuarÃƒÂ¡' => 'GuarÃ¡',
		'BrazlÃƒÂ¢ndia' => 'BrazlÃ¢ndia',
		'CeilÃƒÂ¢ndia' => 'CeilÃ¢ndia',
		'ParanoÃƒÂ¡' => 'ParanoÃ¡',
		'LuziÃƒÂ¢nia' => 'LuziÃ¢nia',
		'Santo AntÃƒÂ´nio do Descoberto' => 'Santo AntÃ´nio do Descoberto',
		'ValparaÃƒÂ­so' => 'ValparaÃ­so',
		'Fotografia, danÃƒÂ§a' => 'Fotografia, danÃ§a',
		'OlÃƒÂ¡, mundo!' => 'OlÃ¡, mundo!',
		'View cart' => 'Ver carrinho',
		'Show password' => 'Mostrar senha',
		'Hide password' => 'Ocultar senha',
		'My account' => 'Minha conta',
		'Checkout' => 'Finalizar compra',
		'Cart' => 'Carrinho',
		'Lost your password?' => 'Perdeu a senha?',
		'Remember me' => 'Lembrar-me',
		'Log In' => 'Entrar',
		'Go to' => 'Ir para',
		'Ainda nao tem conta?' => 'Ainda nÃ£o tem conta?',
		'Ver opcoes de cadastro' => 'Ver opÃ§Ãµes de cadastro',
	);

	return strtr($text, $replacements);
}

function escortwp_filter_visible_translations($translated, $text = '', $domain = '') {
	return escortwp_fix_mojibake_text(escortwp_normalize_visible_text($translated));
}
add_filter('gettext', 'escortwp_filter_visible_translations', 999, 3);
add_filter('ngettext', 'escortwp_filter_visible_translations', 999, 3);

function escortwp_filter_visible_translations_late($translated, $text = '', $domain = '') {
	$replacements = array(
		'&larr; Go to %s' => '&larr; Ir para %s',
		'Go to %s' => 'Ir para %s',
		'NEW' => 'NOVA',
		'VERIFIED' => 'VERIFICADA',
		'FEATURED' => 'DESTAQUE',
		'PRIVATE' => 'PRIVADA',
		'On-line' => 'Online',
		'Plano grÃƒÂ¡tis' => 'Plano grÃ¡tis',
		'Plano gratis' => 'Plano grÃ¡tis',
		'Defina o preco do plano mensal.' => 'Defina o preÃ§o do plano mensal.',
		'Defina a duracao do plano mensal para que ele expire corretamente.' => 'Defina a duraÃ§Ã£o do plano mensal para que ele expire corretamente.',
		'O produto WooCommerce do plano mensal ainda nao foi criado.' => 'O produto WooCommerce do plano mensal ainda nÃ£o foi criado.',
		'Defina o preco do impulsionamento semanal.' => 'Defina o preÃ§o do impulsionamento semanal.',
		'O produto WooCommerce do impulsionamento ainda nao foi criado.' => 'O produto WooCommerce do impulsionamento ainda nÃ£o foi criado.',
		'O impulsionamento precisa permanecer como pagamento unico, sem assinatura.' => 'O impulsionamento precisa permanecer como pagamento Ãºnico, sem assinatura.',
		'Antes de liberar esta cobranca, conclua os itens abaixo:' => 'Antes de liberar esta cobranÃ§a, conclua os itens abaixo:',
		'Mercado Pago instalado. Configure as credenciais para liberar pagamentos por cartÃƒÂ£o e PIX.' => 'Mercado Pago instalado. Configure as credenciais para liberar pagamentos por cartÃ£o e PIX.',
		'Checkout vinculado a pagina %s.' => 'Checkout vinculado Ã  pÃ¡gina %s.',
		'Pagina de checkout ainda nao configurada.' => 'PÃ¡gina de checkout ainda nÃ£o configurada.',
		'Pagamento unico' => 'Pagamento Ãºnico',
		'Plano grÃƒÂ¡tis ativo. O anÃƒÂºncio pode ser editado normalmente e vocÃƒÂª pode contratar um plano adicional quando quiser.' => 'Plano grÃ¡tis ativo. O anÃºncio pode ser editado normalmente e vocÃª pode contratar um plano adicional quando quiser.',
		'Plano grÃƒÂ¡tis ativo. O anÃƒÂºncio pode ser editado normalmente e novos recursos podem ser contratados quando vocÃƒÂª quiser.' => 'Plano grÃ¡tis ativo. O anÃºncio pode ser editado normalmente e novos recursos podem ser contratados quando vocÃª quiser.',
		'Ative o plano mensal para manter o anuncio premium por 30 dias. Quando o periodo terminar, basta pagar novamente para continuar com os beneficios.' => 'Ative o plano mensal para manter o anÃºncio premium por 30 dias. Quando o perÃ­odo terminar, basta pagar novamente para continuar com os benefÃ­cios.',
		'Se voce pagar de novo antes do vencimento, o sistema soma mais 30 dias ao periodo atual.' => 'Se vocÃª pagar de novo antes do vencimento, o sistema soma mais 30 dias ao perÃ­odo atual.',
		'Este plano e manual, sem assinatura recorrente. O impulsionamento semanal continua separado e nao interfere aqui.' => 'Este plano Ã© manual, sem assinatura recorrente. O impulsionamento semanal continua separado e nÃ£o interfere aqui.',
		'Pagamento unico para destacar o anuncio por 7 dias. Nao e assinatura e nao gera cobranca recorrente.' => 'Pagamento Ãºnico para destacar o anÃºncio por 7 dias. NÃ£o Ã© assinatura e nÃ£o gera cobranÃ§a recorrente.',
		'Este destaque e avulso. Ele ativa so depois da confirmacao do pagamento e expira automaticamente apos 7 dias.' => 'Este destaque Ã© avulso. Ele ativa sÃ³ depois da confirmaÃ§Ã£o do pagamento e expira automaticamente apÃ³s 7 dias.',
		'O pagamento ainda nao foi confirmado. Assim que o checkout aprovar a cobranca, o plano sera ativado.' => 'O pagamento ainda nÃ£o foi confirmado. Assim que o checkout aprovar a cobranÃ§a, o plano serÃ¡ ativado.',
		'O pagamento falhou e o plano nao foi ativado.' => 'O pagamento falhou e o plano nÃ£o foi ativado.',
		'Plano da agencia' => 'Plano da agÃªncia',
		'Plano da acompanhante da agencia' => 'Plano da acompanhante da agÃªncia',
		'Destaque do anuncio' => 'Destaque do anÃºncio',
		'Planos do anuncio' => 'Planos do anÃºncio',
		'Gerencie aqui o plano atual do anuncio, o plano mensal de 30 dias e o impulsionamento avulso de 7 dias.' => 'Gerencie aqui o plano atual do anÃºncio, o plano mensal de 30 dias e o impulsionamento avulso de 7 dias.',
		'Acompanhe em um ÃƒÂºnico lugar o plano grÃƒÂ¡tis, o plano mensal de 30 dias e o impulsionamento avulso de 7 dias.' => 'Acompanhe em um Ãºnico lugar o plano grÃ¡tis, o plano mensal de 30 dias e o impulsionamento avulso de 7 dias.',
	);

	if (isset($replacements[$translated])) {
		return escortwp_fix_mojibake_text($replacements[$translated]);
	}

	if (isset($replacements[$text])) {
		return escortwp_fix_mojibake_text($replacements[$text]);
	}

	return escortwp_fix_mojibake_text($translated);
}
add_filter('gettext', 'escortwp_filter_visible_translations_late', 1000, 3);
add_filter('ngettext', 'escortwp_filter_visible_translations_late', 1000, 3);

function escortwp_filter_visible_translations_late_clean($translated, $text = '', $domain = '') {
	$replacements = array(
		'&larr; Go to %s' => '&larr; Ir para %s',
		'Go to %s' => 'Ir para %s',
		'NEW' => 'NOVA',
		'VERIFIED' => 'VERIFICADA',
		'FEATURED' => 'DESTAQUE',
		'PRIVATE' => 'PRIVADA',
		'On-line' => 'Online',
		'Plano grÃƒÆ’Ã‚Â¡tis' => 'Plano grÃ¡tis',
		'Plano grÃƒÂ¡tis' => 'Plano grÃ¡tis',
		'Plano gratis' => 'Plano grÃ¡tis',
		'RegiÃƒÂµes atendidas' => 'RegiÃµes atendidas',
		'InÃƒÂ­cio' => 'InÃ­cio',
		'Anuncie grÃƒÂ¡tis' => 'Anuncie grÃ¡tis',
		'NavegaÃƒÂ§ÃƒÂ£o principal' => 'NavegaÃ§Ã£o principal',
		'Ver ÃƒÂ¡rea VIP' => 'Ver Ã¡rea VIP',
		'Ainda nÃƒÂ£o hÃƒÂ¡ novas %s por aqui.' => 'Ainda nÃ£o hÃ¡ novas %s por aqui.',
		'Ainda nÃƒÂ£o hÃƒÂ¡ %s por aqui.' => 'Ainda nÃ£o hÃ¡ %s por aqui.',
		'ÃƒÅ¡ltimas avaliaÃƒÂ§ÃƒÂµes de %s' => 'Ãšltimas avaliaÃ§Ãµes de %s',
		'Ver todas as avaliaÃƒÂ§ÃƒÂµes' => 'Ver todas as avaliaÃ§Ãµes',
		'ver a avaliaÃƒÂ§ÃƒÂ£o' => 'ver a avaliaÃ§Ã£o',
		'Defina o preco do plano mensal.' => 'Defina o preÃ§o do plano mensal.',
		'Defina a duracao do plano mensal para que ele expire corretamente.' => 'Defina a duraÃ§Ã£o do plano mensal para que ele expire corretamente.',
		'O produto WooCommerce do plano mensal ainda nao foi criado.' => 'O produto WooCommerce do plano mensal ainda nÃ£o foi criado.',
		'Defina o preco do impulsionamento semanal.' => 'Defina o preÃ§o do impulsionamento semanal.',
		'O produto WooCommerce do impulsionamento ainda nao foi criado.' => 'O produto WooCommerce do impulsionamento ainda nÃ£o foi criado.',
		'O impulsionamento precisa permanecer como pagamento unico, sem assinatura.' => 'O impulsionamento precisa permanecer como pagamento Ãºnico, sem assinatura.',
		'Antes de liberar esta cobranca, conclua os itens abaixo:' => 'Antes de liberar esta cobranÃ§a, conclua os itens abaixo:',
		'Mercado Pago instalado. Configure as credenciais para liberar pagamentos por cartÃƒÆ’Ã‚Â£o e PIX.' => 'Mercado Pago instalado. Configure as credenciais para liberar pagamentos por cartÃ£o e PIX.',
		'Mercado Pago instalado. Configure as credenciais para liberar pagamentos por cartÃ£o e PIX.' => 'Mercado Pago instalado. Configure as credenciais para liberar pagamentos por cartÃ£o e PIX.',
		'Checkout vinculado a pagina %s.' => 'Checkout vinculado Ã  pÃ¡gina %s.',
		'Pagina de checkout ainda nao configurada.' => 'PÃ¡gina de checkout ainda nÃ£o configurada.',
		'Pagamento unico' => 'Pagamento Ãºnico',
		'Pagamento Ãºnico' => 'Pagamento Ãºnico',
		'Plano grÃƒÆ’Ã‚Â¡tis ativo. O anÃƒÆ’Ã‚Âºncio pode ser editado normalmente e vocÃƒÆ’Ã‚Âª pode contratar um plano adicional quando quiser.' => 'Plano grÃ¡tis ativo. O anÃºncio pode ser editado normalmente e vocÃª pode contratar um plano adicional quando quiser.',
		'Plano grÃƒÆ’Ã‚Â¡tis ativo. O anÃƒÆ’Ã‚Âºncio pode ser editado normalmente e novos recursos podem ser contratados quando vocÃƒÆ’Ã‚Âª quiser.' => 'Plano grÃ¡tis ativo. O anÃºncio pode ser editado normalmente e novos recursos podem ser contratados quando vocÃª quiser.',
		'Ative o plano mensal para manter o anuncio premium por 30 dias. Quando o periodo terminar, basta pagar novamente para continuar com os beneficios.' => 'Ative o plano mensal para manter o anÃºncio premium por 30 dias. Quando o perÃ­odo terminar, basta pagar novamente para continuar com os benefÃ­cios.',
		'Se voce pagar de novo antes do vencimento, o sistema soma mais 30 dias ao periodo atual.' => 'Se vocÃª pagar de novo antes do vencimento, o sistema soma mais 30 dias ao perÃ­odo atual.',
		'Este plano e manual, sem assinatura recorrente. O impulsionamento semanal continua separado e nao interfere aqui.' => 'Este plano Ã© manual, sem assinatura recorrente. O impulsionamento semanal continua separado e nÃ£o interfere aqui.',
		'Pagamento unico para destacar o anuncio por 7 dias. Nao e assinatura e nao gera cobranca recorrente.' => 'Pagamento Ãºnico para destacar o anÃºncio por 7 dias. NÃ£o Ã© assinatura e nÃ£o gera cobranÃ§a recorrente.',
		'Este destaque e avulso. Ele ativa so depois da confirmacao do pagamento e expira automaticamente apos 7 dias.' => 'Este destaque Ã© avulso. Ele ativa sÃ³ depois da confirmaÃ§Ã£o do pagamento e expira automaticamente apÃ³s 7 dias.',
		'O pagamento ainda nao foi confirmado. Assim que o checkout aprovar a cobranca, o plano sera ativado.' => 'O pagamento ainda nÃ£o foi confirmado. Assim que o checkout aprovar a cobranÃ§a, o plano serÃ¡ ativado.',
		'O pagamento falhou e o plano nao foi ativado.' => 'O pagamento falhou e o plano nÃ£o foi ativado.',
		'Plano da agencia' => 'Plano da agÃªncia',
		'Plano da acompanhante da agencia' => 'Plano da acompanhante da agÃªncia',
		'Destaque do anuncio' => 'Destaque do anÃºncio',
		'Planos do anuncio' => 'Planos do anÃºncio',
		'Gerencie aqui o plano atual do anuncio, o plano mensal de 30 dias e o impulsionamento avulso de 7 dias.' => 'Gerencie aqui o plano atual do anÃºncio, o plano mensal de 30 dias e o impulsionamento avulso de 7 dias.',
		'Acompanhe em um ÃƒÆ’Ã‚Âºnico lugar o plano grÃƒÆ’Ã‚Â¡tis, o plano mensal de 30 dias e o impulsionamento avulso de 7 dias.' => 'Acompanhe em um Ãºnico lugar o plano grÃ¡tis, o plano mensal de 30 dias e o impulsionamento avulso de 7 dias.',
		'Premium options' => 'Plano mensal',
		'Price to become a premium %s' => 'PreÃ§o do plano mensal para %s',
		'keep empty to disable' => 'deixe em branco para desativar',
		'Upgrade profile to premium' => 'Plano mensal do anÃºncio',
		'Featured options' => 'Destaque do anÃºncio',
		'Price to become a featured %s' => 'PreÃ§o para destacar %s',
		'One-time featured boost' => 'Impulsionamento avulso',
		'single payment only, no recurring billing' => 'pagamento Ãºnico, sem recorrÃªncia',
		'Price for a 1 week featured boost' => 'PreÃ§o do impulsionamento de 1 semana',
		'Boost %s for 1 week' => 'Impulsionar %s por 1 semana',
		'Quick Search' => 'Busca rÃ¡pida',
		'Advanced search' => 'Busca avanÃ§ada',
		'Contact us' => 'Fale conosco',
		'Acompanhante rating' => 'AvaliaÃ§Ã£o da acompanhante',
		'Anunciante rating' => 'AvaliaÃ§Ã£o da anunciante',
		'Great things are on the horizon' => 'A loja ainda nÃ£o estÃ¡ pronta',
		'Something big is brewing! Our store is in the works and will be launching soon!' => 'Ainda estamos preparando a loja.',
	);

	if (isset($replacements[$translated])) {
		return escortwp_fix_mojibake_text($replacements[$translated]);
	}

	if (isset($replacements[$text])) {
		return escortwp_fix_mojibake_text($replacements[$text]);
	}

	return escortwp_fix_mojibake_text($translated);
}
add_filter('gettext', 'escortwp_filter_visible_translations_late_clean', 1100, 3);
add_filter('ngettext', 'escortwp_filter_visible_translations_late_clean', 1100, 3);

function escortwp_force_store_currency_brl($currency = '') {
	return 'BRL';
}
add_filter('woocommerce_currency', 'escortwp_force_store_currency_brl', 50);

function escortwp_force_currency_symbol_brl($currency_symbol, $currency) {
	if ($currency === 'BRL') {
		return 'R$ ';
	}
	return $currency_symbol;
}
add_filter('woocommerce_currency_symbol', 'escortwp_force_currency_symbol_brl', 50, 2);

function escortwp_force_wc_price_args_brl($args) {
	$args['currency'] = 'BRL';
	$args['decimal_separator'] = ',';
	$args['thousand_separator'] = '.';
	$args['decimals'] = 2;
	$args['price_format'] = '%1$s%2$s';
	return $args;
}
add_filter('wc_price_args', 'escortwp_force_wc_price_args_brl', 50);

add_filter('woocommerce_price_num_decimals', function(){ return 2; }, 50);
add_filter('woocommerce_price_decimal_sep', function(){ return ','; }, 50);
add_filter('woocommerce_price_thousand_sep', function(){ return '.'; }, 50);

function escortwp_login_register_message_professional($message) {
	$action = isset($_REQUEST['action']) ? sanitize_key(wp_unslash($_REQUEST['action'])) : 'login';
	if ($action && $action !== 'login') {
		return $message;
	}

	$register_url = get_option('main_reg_page_id') ? get_permalink(get_option('main_reg_page_id')) : home_url('/registration/');
	$member_register_url = get_option('member_register_page_id') ? get_permalink(get_option('member_register_page_id')) : home_url('/member-registration/');
	$escort_register_url = get_option('escort_reg_page_id') ? get_permalink(get_option('escort_reg_page_id')) : home_url('/acompanhante-registration/');

	$custom = '<div class="escortwp-login-register-links escortwp-login-register-links--professional">';
	$custom .= '<div class="escortwp-login-register-badge">' . esc_html__('Acesso ao portal', 'escortwp') . '</div>';
	$custom .= '<strong>' . esc_html__('Entrar na sua conta', 'escortwp') . '</strong>';
	$custom .= '<p>' . esc_html__('Clientes acompanham favoritos e contatos. Acompanhantes gerenciam perfil, fotos, anúncios e planos dentro do próprio painel.', 'escortwp') . '</p>';
	$custom .= '<div class="escortwp-login-register-actions">';
	$custom .= '<a class="escortwp-login-register-button escortwp-login-register-button-primary" href="' . esc_url($escort_register_url) . '">' . esc_html__('Criar conta de acompanhante', 'escortwp') . '</a>';
	$custom .= '<a class="escortwp-login-register-button" href="' . esc_url($member_register_url) . '">' . esc_html__('Criar conta de cliente', 'escortwp') . '</a>';
	$custom .= '</div>';
	$custom .= '<div class="escortwp-login-register-support"><a href="' . esc_url($register_url) . '">' . esc_html__('Ver todas as opções de cadastro', 'escortwp') . '</a></div>';
	$custom .= '</div>';

	return $custom . $message;
}
remove_filter('login_message', 'escortwp_login_register_message_clean', 20);
add_filter('login_message', 'escortwp_login_register_message_professional', 40);

function escortwp_redirect_wp_register_to_theme_professional($register_url) {
	$registration_page = get_option('main_reg_page_id') ? get_permalink(get_option('main_reg_page_id')) : home_url('/registration/');
	return $registration_page ? $registration_page : $register_url;
}
add_filter('register_url', 'escortwp_redirect_wp_register_to_theme_professional', 40);

function escortwp_login_head_professional_enhancements() {
	?>
	<script type="text/javascript">
	jQuery(function($){
		if (!$('.escortwp-login-heading').length) {
			$('#login').prepend(
				'<div class="escortwp-login-heading">' +
					'<div class="escortwp-login-heading-kicker"><?php echo esc_js(__('Área segura', 'escortwp')); ?></div>' +
					'<h2><?php echo esc_js(__('Login profissional e organizado', 'escortwp')); ?></h2>' +
					'<p><?php echo esc_js(__('Acesse sua conta para continuar no painel certo: cliente ou acompanhante.', 'escortwp')); ?></p>' +
				'</div>'
			);
		}
	});
	</script>
	<?php
}
add_action('login_head', 'escortwp_login_head_professional_enhancements', 30);

function escortwp_validation_notice_persistence_script() {
	if (!is_user_logged_in()) {
		return;
	}
	?>
	<script type="text/javascript">
	jQuery(function($){
		var noticeWrapper = $('.registrationcomplete--dismissible');
		if (!noticeWrapper.length || !window.localStorage) {
			return;
		}

		var noticeKey = 'escortwp-validation-notice-' + noticeWrapper.data('validation-user');
		if (localStorage.getItem(noticeKey) === 'hidden') {
			noticeWrapper.hide();
		}

		noticeWrapper.find('.registrationcomplete-close').on('click', function(){
			localStorage.setItem(noticeKey, 'hidden');
		});
	});
	</script>
	<?php
}
add_action('wp_footer', 'escortwp_validation_notice_persistence_script', 50);

function escortwp_filter_visible_translations_final_ptbr($translated, $text = '', $domain = '') {
	$replacements = array(
		'RegiÃƒÂµes atendidas' => 'RegiÃµes atendidas',
		'RegiÃƒÆ’Ã‚Âµes atendidas' => 'RegiÃµes atendidas',
		'InÃƒÂ­cio' => 'InÃ­cio',
		'InÃƒÆ’Ã‚Â­cio' => 'InÃ­cio',
		'Anuncie grÃƒÂ¡tis' => 'Anuncie grÃ¡tis',
		'Anuncie grÃƒÆ’Ã‚Â¡tis' => 'Anuncie grÃ¡tis',
		'NavegaÃƒÂ§ÃƒÂ£o principal' => 'NavegaÃ§Ã£o principal',
		'NavegaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o principal' => 'NavegaÃ§Ã£o principal',
		'Ver ÃƒÂ¡rea VIP' => 'Ver Ã¡rea VIP',
		'Busca rÃƒÂ¡pida' => 'Busca rÃ¡pida',
		'Busca avanÃƒÂ§ada' => 'Busca avanÃ§ada',
		'Cadastro profissional' => 'Cadastro profissional',
		'Plano grÃƒÂ¡tis' => 'Plano grÃ¡tis',
		'Plano grÃƒÆ’Ã‚Â¡tis' => 'Plano grÃ¡tis',
		'GrÃƒÂ¡tis' => 'GrÃ¡tis',
		'Pagamento ÃƒÂºnico' => 'Pagamento Ãºnico',
		'Esta conta ÃƒÂ© feita para navegar, favoritar perfis, enviar mensagens e acompanhar seus contatos no portal com clareza e seguranÃƒÂ§a.' => 'Esta conta Ã© feita para navegar, favoritar perfis, enviar mensagens e acompanhar seus contatos no portal com clareza e seguranÃ§a.',
		'Esta conta ÃƒÂ© voltada para anÃƒÂºncio profissional: criar perfil, publicar conteÃƒÂºdo, gerenciar fotos e contratar planos dentro do painel.' => 'Esta conta Ã© voltada para anÃºncio profissional: criar perfil, publicar conteÃºdo, gerenciar fotos e contratar planos dentro do painel.',
		'Crie seu acesso com e-mail e senha vÃƒÂ¡lidos.' => 'Crie seu acesso com e-mail e senha vÃ¡lidos.',
		'Preencha os dados pÃƒÂºblicos do anÃƒÂºncio com clareza.' => 'Preencha os dados pÃºblicos do anÃºncio com clareza.',
		'SeÃƒÂ§ÃƒÂµes do cadastro' => 'SeÃ§Ãµes do cadastro',
		'SeÃƒÂ§ÃƒÂµes do painel' => 'SeÃ§Ãµes do painel',
		'LocalizaÃƒÂ§ÃƒÂ£o' => 'LocalizaÃ§Ã£o',
		'ServiÃƒÂ§os' => 'ServiÃ§os',
		'Gerencie o anÃƒÂºncio com mais clareza' => 'Gerencie o anÃºncio com mais clareza',
		'Concentre tudo em um ÃƒÂºnico painel: dados pÃƒÂºblicos, contato, localizaÃƒÂ§ÃƒÂ£o, valores, serviÃƒÂ§os, fotos e contrataÃƒÂ§ÃƒÂ£o de planos.' => 'Concentre tudo em um Ãºnico painel: dados pÃºblicos, contato, localizaÃ§Ã£o, valores, serviÃ§os, fotos e contrataÃ§Ã£o de planos.',
		'Acompanhe o plano atual, veja o vencimento e contrate o plano mensal ou o destaque semanal sem sair do painel.' => 'Acompanhe o plano atual, veja o vencimento e contrate o plano mensal ou o destaque semanal sem sair do painel.',
		'Clientes acompanham favoritos e contatos. Acompanhantes gerenciam perfil, fotos, anÃƒÂºncios e planos dentro do prÃƒÂ³prio painel.' => 'Clientes acompanham favoritos e contatos. Acompanhantes gerenciam perfil, fotos, anÃºncios e planos dentro do prÃ³prio painel.',
		'Ver todas as opÃƒÂ§ÃƒÂµes de cadastro' => 'Ver todas as opÃ§Ãµes de cadastro',
		'ÃƒÂrea segura' => 'Ãrea segura',
		'Great things are on the horizon' => 'Loja em preparaÃ§Ã£o',
		'Something big is brewing! Our store is in the works and will be launching soon!' => 'A loja ainda estÃ¡ sendo preparada.',
		'Quick Search' => 'Busca rÃ¡pida',
		'Advanced search' => 'Busca avanÃ§ada',
		'Contact us' => 'Fale conosco',
		'Login' => 'Entrar',
		'Logout' => 'Sair',
		'Username or Email Address' => 'Nome de usuÃ¡rio ou e-mail',
		'Remember Me' => 'Lembrar-me',
		'Language' => 'Idioma',
		'Change' => 'Alterar',
		'Username' => 'Nome de usuÃ¡rio',
		'Password' => 'Senha',
		'Name' => 'Nome',
		'Fields marked with <i>*</i> are mandatory' => 'Os campos marcados com <i>*</i> sÃ£o obrigatÃ³rios',
		'will be publicly shown' => 'serÃ¡ mostrado publicamente',
		'Between 4 and 30 characters' => 'Entre 4 e 30 caracteres',
		'Between 6 and 30 characters' => 'Entre 6 e 30 caracteres',
		'Register' => 'Criar conta',
		'Update' => 'Atualizar',
		'I agree with the %s of this website' => 'Concordo com %s deste site',
		'I agree with the %s and the %s of this website' => 'Concordo com %s e %s deste site',
		'Member Registration' => 'Cadastro de cliente',
		'Independent Escort Registration' => 'Cadastro de acompanhante',
		'Independent Girl Registration' => 'Cadastro de acompanhante',
		'Send username and password by email' => 'Enviar nome de usuÃ¡rio e senha por e-mail',
		'Country' => 'Estado',
		'Select country' => 'Selecione o estado',
		'State' => 'RegiÃ£o',
		'Select State' => 'Selecione a regiÃ£o',
		'Please select a country first' => 'Selecione um estado primeiro',
		'City' => 'Cidade',
		'Select City' => 'Selecione a cidade',
		'Please select a state first' => 'Selecione uma regiÃ£o primeiro',
		'Ethnicity' => 'Etnia',
		'Services' => 'ServiÃ§os',
		'Extra services' => 'ServiÃ§os extras',
		'Update Profile' => 'Atualizar perfil',
		'Complete Registration' => 'Concluir cadastro',
		'Incall' => 'No local',
		'Outcall' => 'Atendimento externo',
		'minutes' => 'minutos',
		'hour' => 'hora',
		'hours' => 'horas',
	);

	if (isset($replacements[$translated])) {
		return escortwp_fix_mojibake_text($replacements[$translated]);
	}

	if (isset($replacements[$text])) {
		return escortwp_fix_mojibake_text($replacements[$text]);
	}

	return escortwp_fix_mojibake_text($translated);
}
add_filter('gettext', 'escortwp_filter_visible_translations_final_ptbr', 1300, 3);
add_filter('ngettext', 'escortwp_filter_visible_translations_final_ptbr', 1300, 3);
add_filter('login_display_language_dropdown', '__return_false');

function escortwp_login_register_message_professional_final($message) {
	$action = isset($_REQUEST['action']) ? sanitize_key(wp_unslash($_REQUEST['action'])) : 'login';
	if ($action && $action !== 'login') {
		return $message;
	}

	$register_url = get_option('main_reg_page_id') ? get_permalink(get_option('main_reg_page_id')) : home_url('/registration/');
	$member_register_url = get_option('member_register_page_id') ? get_permalink(get_option('member_register_page_id')) : home_url('/member-registration/');
	$escort_register_url = get_option('escort_reg_page_id') ? get_permalink(get_option('escort_reg_page_id')) : home_url('/acompanhante-registration/');

	$custom = '<div class="escortwp-login-register-links escortwp-login-register-links--professional">';
	$custom .= '<div class="escortwp-login-register-badge">' . esc_html__('Acesso ao portal', 'escortwp') . '</div>';
	$custom .= '<strong>' . esc_html__('Entrar na sua conta', 'escortwp') . '</strong>';
	$custom .= '<p>' . esc_html__('Clientes acompanham favoritos e contatos. Acompanhantes gerenciam perfil, fotos, anúncios e planos dentro do próprio painel.', 'escortwp') . '</p>';
	$custom .= '<div class="escortwp-login-register-actions">';
	$custom .= '<a class="escortwp-login-register-button escortwp-login-register-button-primary" href="' . esc_url($escort_register_url) . '">' . esc_html__('Criar conta de acompanhante', 'escortwp') . '</a>';
	$custom .= '<a class="escortwp-login-register-button" href="' . esc_url($member_register_url) . '">' . esc_html__('Criar conta de cliente', 'escortwp') . '</a>';
	$custom .= '</div>';
	$custom .= '<div class="escortwp-login-register-support"><a href="' . esc_url($register_url) . '">' . esc_html__('Ver todas as opções de cadastro', 'escortwp') . '</a></div>';
	$custom .= '</div>';

	return $custom . $message;
}
remove_filter('login_message', 'escortwp_login_register_message_professional', 40);
add_filter('login_message', 'escortwp_login_register_message_professional_final', 60);

function escortwp_login_head_professional_enhancements_final() {
	?>
	<script type="text/javascript">
	jQuery(function($){
		$('.escortwp-login-heading').remove();
		if (!$('.escortwp-login-heading').length) {
			$('#login').prepend(
				'<div class="escortwp-login-heading">' +
					'<div class="escortwp-login-heading-kicker"><?php echo esc_js(__('Área segura', 'escortwp')); ?></div>' +
					'<h2><?php echo esc_js(__('Login profissional e organizado', 'escortwp')); ?></h2>' +
					'<p><?php echo esc_js(__('Acesse sua conta para continuar no painel certo: cliente ou acompanhante.', 'escortwp')); ?></p>' +
				'</div>'
			);
		}
	});
	</script>
	<?php
}
remove_action('login_head', 'escortwp_login_head_professional_enhancements', 30);
add_action('login_head', 'escortwp_login_head_professional_enhancements_final', 40);

function escortwp_login_register_message_refined($message) {
	$action = isset($_REQUEST['action']) ? sanitize_key(wp_unslash($_REQUEST['action'])) : 'login';
	if ($action && $action !== 'login') {
		return $message;
	}

	$register_url = get_option('main_reg_page_id') ? get_permalink(get_option('main_reg_page_id')) : home_url('/registration/');
	$member_register_url = get_option('member_register_page_id') ? get_permalink(get_option('member_register_page_id')) : home_url('/member-registration/');
	$escort_register_url = get_option('escort_reg_page_id') ? get_permalink(get_option('escort_reg_page_id')) : home_url('/acompanhante-registration/');

	$custom = '<div class="escortwp-login-register-links escortwp-login-register-links--professional">';
	$custom .= '<div class="escortwp-login-register-badge">' . esc_html__('Acesso ao portal', 'escortwp') . '</div>';
	$custom .= '<strong>' . esc_html__('Entrar na sua conta', 'escortwp') . '</strong>';
	$custom .= '<p>' . esc_html__('Entre como cliente ou acompanhante para continuar no painel certo, com acesso direto ao que importa.', 'escortwp') . '</p>';
	$custom .= '<div class="escortwp-login-register-actions">';
	$custom .= '<a class="escortwp-login-register-button escortwp-login-register-button-primary" href="' . esc_url($escort_register_url) . '">' . esc_html__('Criar conta de acompanhante', 'escortwp') . '</a>';
	$custom .= '<a class="escortwp-login-register-button" href="' . esc_url($member_register_url) . '">' . esc_html__('Criar conta de cliente', 'escortwp') . '</a>';
	$custom .= '</div>';
	$custom .= '<div class="escortwp-login-register-support"><a href="' . esc_url($register_url) . '">' . esc_html__('Ver opÃ§Ãµes de cadastro', 'escortwp') . '</a></div>';
	$custom .= '</div>';

	return $custom . $message;
}
remove_filter('login_message', 'escortwp_login_register_message_professional_final', 60);
add_filter('login_message', 'escortwp_login_register_message_refined', 80);

function escortwp_login_head_refined() {
	?>
	<script type="text/javascript">
	jQuery(function($){
		$('.escortwp-login-heading').remove();
		if (!$('.escortwp-login-heading').length) {
			$('#login').prepend(
				'<div class="escortwp-login-heading">' +
					'<div class="escortwp-login-heading-kicker"><?php echo esc_js(__('Acesso seguro', 'escortwp')); ?></div>' +
					'<h2><?php echo esc_js(__('Entre na sua conta', 'escortwp')); ?></h2>' +
					'<p><?php echo esc_js(__('Use seus dados para continuar como cliente ou acompanhante.', 'escortwp')); ?></p>' +
				'</div>'
			);
		}
	});
	</script>
	<?php
}
remove_action('login_head', 'escortwp_login_head_professional_enhancements_final', 40);
add_action('login_head', 'escortwp_login_head_refined', 60);

function escortwp_filter_visible_translations_refined_final($translated, $text = '', $domain = '') {
	$replacements = array(
		'Confirme seu e-mail' => 'Confirme o e-mail',
		'Enviamos um link de confirmaÃ§Ã£o para o e-mail cadastrado. Valide esse endereÃ§o para liberar todos os recursos da conta.' => 'Abra a mensagem enviada para confirmar o endereÃ§o e liberar o painel completo da conta.',
		'Enviamos um link de confirmaÃƒÂ§ÃƒÂ£o para o e-mail cadastrado. Valide esse endereÃƒÂ§o para liberar todos os recursos da conta.' => 'Abra a mensagem enviada para confirmar o endereÃ§o e liberar o painel completo da conta.',
		'Reenviar e-mail de confirmaÃ§Ã£o' => 'Reenviar e-mail',
		'Reenviar e-mail de confirmaÃƒÂ§ÃƒÂ£o' => 'Reenviar e-mail',
		'Alterar endereÃ§o de e-mail' => 'Trocar e-mail',
		'Alterar endereÃƒÂ§o de e-mail' => 'Trocar e-mail',
		'Cadastro profissional' => 'Entrada no portal',
		'Escolha o melhor caminho para entrar no portal' => 'Escolha como entrar no portal',
		'A conta de acompanhante ÃƒÂ© voltada para publicaÃƒÂ§ÃƒÂ£o e gestÃƒÂ£o do anÃƒÂºncio. A conta de cliente ÃƒÂ© para navegaÃƒÂ§ÃƒÂ£o, favoritos e contato com os perfis.' => 'Acompanhantes publicam e gerenciam anÃºncios. Clientes acessam favoritos, mensagens e contato com os perfis.',
		'Conta de acompanhante: cria perfil, publica anÃƒÂºncio, gerencia fotos e contrata planos. Conta de cliente: acessa favoritos, mensagens e avaliaÃƒÂ§ÃƒÂµes.' => 'Conta de acompanhante para anunciar e contratar planos. Conta de cliente para favoritos, mensagens e avaliaÃ§Ãµes.',
		'Pagamento mensal manual para manter o anÃƒÂºncio premium, com prioridade e benefÃƒÂ­cios ativos durante 30 dias.' => 'Pagamento mensal manual para manter o anÃºncio premium por 30 dias, com prioridade e mais visibilidade.',
		'A contrataÃƒÂ§ÃƒÂ£o acontece no painel do anÃƒÂºncio. Quando o perÃƒÂ­odo acabar, basta pagar novamente para renovar por mais 30 dias.' => 'A contrataÃ§Ã£o Ã© feita no painel do anÃºncio. Quando o perÃ­odo terminar, basta renovar com um novo pagamento.',
		'Pagamento ÃƒÂºnico para colocar o anÃƒÂºncio em destaque por 7 dias. NÃƒÂ£o vira mensalidade e nÃƒÂ£o renova sozinho.' => 'Pagamento Ãºnico para destacar o anÃºncio por 7 dias, sem renovaÃ§Ã£o automÃ¡tica.',
		'O pagamento e a ativaÃƒÂ§ÃƒÂ£o do destaque acontecem no painel do anÃƒÂºncio, depois do cadastro grÃƒÂ¡tis.' => 'A compra e a ativaÃ§Ã£o do destaque acontecem depois do cadastro, no painel do anÃºncio.',
		'Nesta etapa vocÃƒÂª escolhe apenas o tipo de conta gratuita. O plano mensal e o impulsionamento semanal aparecem depois, dentro do painel da acompanhante.' => 'Nesta etapa vocÃª escolhe apenas a conta gratuita. O plano mensal e o destaque semanal aparecem depois, no painel da acompanhante.',
		'Gerencie o anÃƒÂºncio com mais clareza' => 'Painel do anÃºncio',
		'Concentre tudo em um ÃƒÂºnico painel: dados pÃƒÂºblicos, contato, localizaÃƒÂ§ÃƒÂ£o, valores, serviÃƒÂ§os, fotos e contrataÃƒÂ§ÃƒÂ£o de planos.' => 'Edite dados pÃºblicos, contato, localizaÃ§Ã£o, valores, serviÃ§os e planos em um fluxo mais objetivo.',
		'Painel da acompanhante' => 'Painel da acompanhante',
		'Planos da acompanhante' => 'Planos do anÃºncio',
		'Acompanhe o plano atual, veja o vencimento e contrate o plano mensal ou o destaque semanal sem sair do painel.' => 'Veja o status atual e ative o mensal ou o destaque semanal sem sair do painel.',
		'Dados principais da conta' => 'Base da conta',
		'Preencha os dados de acesso com atenÃ§Ã£o. Eles controlam login, recuperaÃ§Ã£o de senha e a entrada no painel da acompanhante.' => 'Cadastre acesso, e-mail e nome pÃºblico com atenÃ§Ã£o. Esses dados controlam o login e a entrada no painel da acompanhante.',
		'Preencha os dados de acesso com atenÃƒÂ§ÃƒÂ£o. Eles controlam login, recuperaÃƒÂ§ÃƒÂ£o de senha e a entrada no painel da acompanhante.' => 'Cadastre acesso, e-mail e nome pÃºblico com atenÃ§Ã£o. Esses dados controlam o login e a entrada no painel da acompanhante.',
		'Canais visÃ­veis no anÃºncio' => 'Canais do anÃºncio',
		'Canais visÃƒÂ­veis no anÃƒÂºncio' => 'Canais do anÃºncio',
		'Defina telefone, WhatsApp e redes que realmente serÃ£o usados para atendimento. Isso deixa o perfil mais confiÃ¡vel e objetivo.' => 'Mostre apenas telefone, WhatsApp e redes que realmente serÃ£o usados no atendimento. Isso deixa o anÃºncio mais confiÃ¡vel e direto.',
		'Defina telefone, WhatsApp e redes que realmente serÃƒÂ£o usados para atendimento. Isso deixa o perfil mais confiÃƒÂ¡vel e objetivo.' => 'Mostre apenas telefone, WhatsApp e redes que realmente serÃ£o usados no atendimento. Isso deixa o anÃºncio mais confiÃ¡vel e direto.',
		'RegiÃ£o principal do anÃºncio' => 'RegiÃ£o atendida',
		'RegiÃƒÂ£o principal do anÃƒÂºncio' => 'RegiÃ£o atendida',
		'Selecione a regiÃ£o certa para que o perfil apareÃ§a nas buscas corretas e mantenha a navegaÃ§Ã£o do site organizada.' => 'Escolha o estado, a regiÃ£o e a cidade corretos para posicionar o anÃºncio nas buscas certas.',
		'Selecione a regiÃƒÂ£o certa para que o perfil apareÃƒÂ§a nas buscas corretas e mantenha a navegaÃƒÂ§ÃƒÂ£o do site organizada.' => 'Escolha o estado, a regiÃ£o e a cidade corretos para posicionar o anÃºncio nas buscas certas.',
		'ApresentaÃ§Ã£o pÃºblica da acompanhante' => 'ApresentaÃ§Ã£o do anÃºncio',
		'ApresentaÃƒÂ§ÃƒÂ£o pÃƒÂºblica da acompanhante' => 'ApresentaÃ§Ã£o do anÃºncio',
		'Preencha os dados do perfil com clareza para gerar mais confianÃ§a e facilitar o entendimento de quem visita o anÃºncio.' => 'Organize os dados do perfil com clareza para transmitir confianÃ§a e facilitar a leitura de quem visita o anÃºncio.',
		'Preencha os dados do perfil com clareza para gerar mais confianÃƒÂ§a e facilitar o entendimento de quem visita o anÃƒÂºncio.' => 'Organize os dados do perfil com clareza para transmitir confianÃ§a e facilitar a leitura de quem visita o anÃºncio.',
		'Tabela de atendimento' => 'Tabela de valores',
		'Informe apenas os valores que realmente serÃ£o praticados. Isso ajuda o painel a montar um anÃºncio mais profissional e transparente.' => 'Informe apenas valores reais. Isso torna o anÃºncio mais profissional, transparente e fÃ¡cil de comparar.',
		'Informe apenas os valores que realmente serÃƒÂ£o praticados. Isso ajuda o painel a montar um anÃƒÂºncio mais profissional e transparente.' => 'Informe apenas valores reais. Isso torna o anÃºncio mais profissional, transparente e fÃ¡cil de comparar.',
		'ServiÃ§os e extras do anÃºncio' => 'ServiÃ§os e extras',
		'ServiÃƒÂ§os e extras do anÃƒÂºncio' => 'ServiÃ§os e extras',
		'Selecione sÃ³ o que faz sentido para o perfil. Um painel mais limpo deixa o anÃºncio mais forte e mais fÃ¡cil de entender.' => 'Selecione apenas o que faz sentido para o perfil. Menos ruÃ­do deixa o anÃºncio mais forte e mais fÃ¡cil de entender.',
		'Selecione sÃƒÂ³ o que faz sentido para o perfil. Um painel mais limpo deixa o anÃƒÂºncio mais forte e mais fÃƒÂ¡cil de entender.' => 'Selecione apenas o que faz sentido para o perfil. Menos ruÃ­do deixa o anÃºncio mais forte e mais fÃ¡cil de entender.',
		'Filter search' => 'Ajustar filtros',
		'Back to results' => 'Voltar aos resultados',
		'Phone' => 'Telefone',
		'Available on' => 'DisponÃ­vel em',
		'Hair Color' => 'Cor do cabelo',
		'Hair length' => 'Comprimento do cabelo',
		'Bust size' => 'Tamanho do busto',
		'Build' => 'Porte fÃ­sico',
		'Looks' => 'Visual',
		'Smoker' => 'Fumante',
		'Rates' => 'Valores',
		'Between' => 'Entre',
		'Search %s' => 'Pesquisar %s',
		'ÃƒÂrea segura' => 'Acesso seguro',
		'Login profissional e organizado' => 'Entre na sua conta',
		'Acesse sua conta para continuar no painel certo: cliente ou acompanhante.' => 'Use seus dados para continuar como cliente ou acompanhante.',
		'Clientes acompanham favoritos e contatos. Acompanhantes gerenciam perfil, fotos, anÃƒÂºncios e planos dentro do prÃƒÂ³prio painel.' => 'Entre como cliente ou acompanhante para continuar no painel certo, com acesso direto ao que importa.',
		'Ver todas as opÃƒÂ§ÃƒÂµes de cadastro' => 'Ver opÃ§Ãµes de cadastro',
	);

	if (isset($replacements[$translated])) {
		return escortwp_fix_mojibake_text($replacements[$translated]);
	}

	if (isset($replacements[$text])) {
		return escortwp_fix_mojibake_text($replacements[$text]);
	}

	return escortwp_fix_mojibake_text($translated);
}
add_filter('gettext', 'escortwp_filter_visible_translations_refined_final', 1400, 3);
add_filter('ngettext', 'escortwp_filter_visible_translations_refined_final', 1400, 3);

function escortwp_login_register_message_split_layout($message) {
	$action = isset($_REQUEST['action']) ? sanitize_key(wp_unslash($_REQUEST['action'])) : 'login';
	if ($action && $action !== 'login') {
		return $message;
	}

	$register_url = get_option('main_reg_page_id') ? get_permalink(get_option('main_reg_page_id')) : home_url('/registration/');
	$member_register_url = get_option('member_register_page_id') ? get_permalink(get_option('member_register_page_id')) : home_url('/member-registration/');
	$escort_register_url = get_option('escort_reg_page_id') ? get_permalink(get_option('escort_reg_page_id')) : home_url('/acompanhante-registration/');

	$custom = '<div class="escortwp-login-register-links escortwp-login-register-links--split">';
	$custom .= '<div class="escortwp-login-split-card escortwp-login-split-card--register">';
	$custom .= '<div class="escortwp-login-register-badge">' . esc_html__('Primeiro acesso', 'escortwp') . '</div>';
	$custom .= '<strong>' . esc_html__('Cadastre-se', 'escortwp') . '</strong>';
	$custom .= '<p>' . esc_html__('Escolha o tipo de conta correto para entrar no portal com acesso organizado desde o início.', 'escortwp') . '</p>';
	$custom .= '<div class="escortwp-login-account-types">';
	$custom .= '<a class="escortwp-login-register-button escortwp-login-register-button-primary" href="' . esc_url($escort_register_url) . '">' . esc_html__('Sou acompanhante', 'escortwp') . '</a>';
	$custom .= '<a class="escortwp-login-register-button escortwp-login-register-button-secondary" href="' . esc_url($member_register_url) . '">' . esc_html__('Sou cliente', 'escortwp') . '</a>';
	$custom .= '</div>';
	$custom .= '<div class="escortwp-login-register-support"><a href="' . esc_url($register_url) . '">' . esc_html__('Ver opções de cadastro', 'escortwp') . '</a></div>';
	$custom .= '</div>';
	$custom .= '</div>';

	return $custom . $message;
}
remove_filter('login_message', 'escortwp_login_register_message_refined', 80);
add_filter('login_message', 'escortwp_login_register_message_split_layout', 100);

function escortwp_login_head_split_layout() {
	?>
	<script type="text/javascript">
	jQuery(function($){
		$('.escortwp-login-heading').remove();
		$('.escortwp-login-form-intro').remove();
		if (!$('#loginform .escortwp-login-form-intro').length) {
			$('#loginform').prepend(
				'<div class="escortwp-login-form-intro">' +
					'<div class="escortwp-login-heading-kicker"><?php echo esc_js(__('Já tem conta?', 'escortwp')); ?></div>' +
					'<h2><?php echo esc_js(__('Entrar', 'escortwp')); ?></h2>' +
					'<p><?php echo esc_js(__('Use seu e-mail ou nome de usuário e a senha para acessar o painel correto.', 'escortwp')); ?></p>' +
				'</div>'
			);
		}
	});
	</script>
	<?php
}
remove_action('login_head', 'escortwp_login_head_refined', 60);
add_action('login_head', 'escortwp_login_head_split_layout', 80);

function escortwp_filter_login_recovery_texts_final($translated, $text = '', $domain = '') {
	$replacements = array(
		'Lost Password' => 'Recuperar senha',
		'Please enter your username or email address. You will receive an email message with instructions on how to reset your password.' => 'Informe seu nome de usuário ou e-mail. Você receberá uma mensagem com o passo a passo para redefinir a senha.',
		'Get New Password' => 'Receber link de redefinição',
		'Log in' => 'Voltar para entrar',
		'Enter your new password below or generate one.' => 'Defina uma nova senha para voltar ao painel com segurança.',
		'New Password' => 'Nova senha',
		'Save Password' => 'Salvar senha',
		'Your password has been reset.' => 'Sua senha foi redefinida com sucesso.',
	);

	if (isset($replacements[$translated])) {
		return escortwp_fix_mojibake_text($replacements[$translated]);
	}

	if (isset($replacements[$text])) {
		return escortwp_fix_mojibake_text($replacements[$text]);
	}

	return escortwp_fix_mojibake_text($translated);
}
add_filter('gettext', 'escortwp_filter_login_recovery_texts_final', 1500, 3);
add_filter('ngettext', 'escortwp_filter_login_recovery_texts_final', 1500, 3);

function escortwp_login_head_split_layout_final() {
	$action = isset($_REQUEST['action']) ? sanitize_key(wp_unslash($_REQUEST['action'])) : 'login';
	$kicker = __('Já tem conta?', 'escortwp');
	$title = __('Entrar', 'escortwp');
	$copy = __('Use seu e-mail ou nome de usuário e a senha para acessar o painel correto.', 'escortwp');

	if ($action === 'lostpassword' || $action === 'retrievepassword') {
		$kicker = __('Recuperação de acesso', 'escortwp');
		$title = __('Redefinir senha', 'escortwp');
		$copy = __('Informe seu e-mail ou nome de usuário para receber o link de recuperação.', 'escortwp');
	} elseif ($action === 'rp' || $action === 'resetpass') {
		$kicker = __('Nova senha', 'escortwp');
		$title = __('Criar nova senha', 'escortwp');
		$copy = __('Escolha uma senha forte para voltar ao painel com segurança.', 'escortwp');
	}
	?>
	<script type="text/javascript">
	jQuery(function($){
		$('.escortwp-login-heading').remove();
		$('.escortwp-login-form-intro').remove();
		$('body').addClass('escortwp-login-action-<?php echo esc_js($action); ?>');
		if (!$('#loginform .escortwp-login-form-intro').length && $('#loginform').length) {
			$('#loginform').prepend(
				'<div class="escortwp-login-form-intro">' +
					'<div class="escortwp-login-heading-kicker"><?php echo esc_js($kicker); ?></div>' +
					'<h2><?php echo esc_js($title); ?></h2>' +
					'<p><?php echo esc_js($copy); ?></p>' +
				'</div>'
			);
		}
	});
	</script>
	<?php
}
remove_action('login_head', 'escortwp_login_head_split_layout', 80);
add_action('login_head', 'escortwp_login_head_split_layout_final', 100);

function escortwp_filter_plan_panel_copy_final($translated, $text = '', $domain = '') {
	$replacements = array(
		'Painel do anÃºncio' => 'Painel do anúncio',
		'Planos do anÃºncio' => 'Planos e destaque',
		'Edite dados pÃºblicos, contato, localizaÃ§Ã£o, valores, serviÃ§os e planos em um fluxo mais objetivo.' => 'Ajuste os dados principais do anúncio e acompanhe os planos sem excesso visual.',
		'Veja o status atual e ative o mensal ou o destaque semanal sem sair do painel.' => 'Veja o status atual e ative o mensal ou o destaque semanal em um bloco mais direto.',
		'Gerencie aqui o plano atual do anÃºncio, o plano mensal de 30 dias e o impulsionamento avulso de 7 dias.' => 'Acompanhe o plano grátis, o mensal de 30 dias e o destaque semanal em um só lugar.',
		'Acompanhe em um Ãºnico lugar o plano grÃ¡tis, o plano mensal de 30 dias e o impulsionamento avulso de 7 dias.' => 'Acompanhe em um único lugar o plano grátis, o mensal de 30 dias e o destaque semanal.',
		'SituaÃ§Ã£o atual' => 'Status atual',
		'Situacao atual' => 'Status atual',
		'Plano grÃ¡tis ativo. O anÃºncio pode ser editado normalmente e novos recursos podem ser contratados quando vocÃª quiser.' => 'Seu anúncio está ativo e pronto para receber upgrades quando você quiser.',
		'Plano grÃƒÂ¡tis ativo. O anÃƒÂºncio pode ser editado normalmente e novos recursos podem ser contratados quando vocÃƒÂª quiser.' => 'Seu anúncio está ativo e pronto para receber upgrades quando você quiser.',
		'Plano mensal de 30 dias' => '30 dias de prioridade',
		'Ative o plano mensal para manter o anÃºncio premium por 30 dias. Quando o perÃ­odo terminar, basta pagar novamente para continuar com os benefÃ­cios.' => 'Mantenha o anúncio premium por 30 dias com pagamento simples e direto.',
		'Ative o plano mensal para manter o anuncio premium por 30 dias. Quando o periodo terminar, basta pagar novamente para continuar com os beneficios.' => 'Mantenha o anúncio premium por 30 dias com pagamento simples e direto.',
		'Se vocÃª pagar de novo antes do vencimento, o sistema soma mais 30 dias ao perÃ­odo atual.' => 'Se renovar antes do vencimento, o sistema soma mais 30 dias ao período atual.',
		'Se voce pagar de novo antes do vencimento, o sistema soma mais 30 dias ao periodo atual.' => 'Se renovar antes do vencimento, o sistema soma mais 30 dias ao período atual.',
		'Este plano Ã© manual, sem assinatura recorrente. O impulsionamento semanal continua separado e nÃ£o interfere aqui.' => 'Pagamento manual, sem renovação automática.',
		'Este plano e manual, sem assinatura recorrente. O impulsionamento semanal continua separado e nao interfere aqui.' => 'Pagamento manual, sem renovação automática.',
		'Pagamento avulso' => 'Destaque',
		'Sem impulsionamento ativo' => 'Sem destaque ativo',
		'O destaque semanal aparece aqui assim que o pagamento for confirmado.' => 'Quando houver pagamento confirmado, o período aparece aqui.',
		'Impulsionar por 1 semana' => '7 dias em destaque',
		'Pagamento Ãºnico para destacar o anÃºncio por 7 dias. NÃ£o Ã© assinatura e nÃ£o gera cobranÃ§a recorrente.' => 'Destaque o anúncio por 7 dias com pagamento único, sem mensalidade.',
		'Pagamento unico para destacar o anuncio por 7 dias. Nao e assinatura e nao gera cobranca recorrente.' => 'Destaque o anúncio por 7 dias com pagamento único, sem mensalidade.',
		'Este destaque Ã© avulso. Ele ativa sÃ³ depois da confirmaÃ§Ã£o do pagamento e expira automaticamente apÃ³s 7 dias.' => 'Ativa após a confirmação do pagamento e expira sozinha em 7 dias.',
		'Este destaque e avulso. Ele ativa so depois da confirmacao do pagamento e expira automaticamente apos 7 dias.' => 'Ativa após a confirmação do pagamento e expira sozinha em 7 dias.',
	);

	if (isset($replacements[$translated])) {
		return escortwp_fix_mojibake_text($replacements[$translated]);
	}

	if (isset($replacements[$text])) {
		return escortwp_fix_mojibake_text($replacements[$text]);
	}

	return escortwp_fix_mojibake_text($translated);
}
add_filter('gettext', 'escortwp_filter_plan_panel_copy_final', 1700, 3);
add_filter('ngettext', 'escortwp_filter_plan_panel_copy_final', 1700, 3);

