﻿<?php
if(!defined('error_reporting')) { define('error_reporting', '0'); }
ini_set( 'display_errors', error_reporting );
if(error_reporting == '1') { error_reporting( E_ALL ); }
if(isdolcetheme !== 1) { die(); }

function escortwp_get_default_payment_plans() {
	return array(
		'indescreg' => array(
			'title' => array('Cadastro de %s independente', 'taxonomy_profile_name'),
			'label' => array('Preço para cadastrar %s independente', 'taxonomy_profile_name'),
			'label_help' => array('deixe em branco para cadastro grátis'),
			'price' => '',
			'duration' => '',
			'woo_product_id' => '',
			'woo_product_name' => array('Cadastro de %s independente', 'taxonomy_profile_name'),
			'exp' => '2',
			'exp_text' => array('O que acontece quando o perfil expira?'),
		),
		'agreg' => array(
			'title' => array('Cadastro de %s', 'taxonomy_agency_name'),
			'label' => array('Preço para cadastrar %s', 'taxonomy_agency_name'),
			'label_help' => array('deixe em branco para cadastro grátis'),
			'price' => '',
			'duration' => '',
			'woo_product_id' => '',
			'woo_product_name' => array('Cadastro de %s', 'taxonomy_agency_name'),
			'exp' => '2',
			'exp_text' => array('O que acontece quando o perfil expira?'),
		),
		'agescortreg' => array(
			'title' => array('%1$s adicionando %2$s', 'taxonomy_agency_name', 'taxonomy_profile_name'),
			'label' => array('Preço para %1$s adicionar %2$s', 'taxonomy_agency_name', 'taxonomy_profile_name'),
			'label_help' => array('deixe em branco para cadastro grátis'),
			'price' => '',
			'duration' => '',
			'woo_product_id' => '',
			'woo_product_name' => array('Adicionar novo perfil de %s', 'taxonomy_profile_name'),
			'exp' => '2',
			'exp_text' => array('O que acontece quando o perfil expira?'),
		),
		'premium' => array(
			'title' => array('Plano mensal'),
			'label' => array('Preço do plano mensal para %s', 'taxonomy_profile_name'),
			'label_help' => array('deixe em branco para desativar'),
			'price' => '',
			'duration' => '',
			'woo_product_id' => '',
			'woo_product_name' => array('Plano mensal do anúncio', 'taxonomy_profile_name'),
		),
		'featured' => array(
			'title' => array('Destaque do anúncio'),
			'label_help' => array('deixe em branco para desativar'),
			'label' => array('Preço para destacar %s', 'taxonomy_profile_name'),
			'price' => '',
			'duration' => '',
			'woo_product_id' => '',
			'woo_product_name' => array('Destacar anúncio', 'taxonomy_profile_name'),
		),
		'featured_boost' => array(
			'title' => array('Impulsionamento avulso'),
			'label_help' => array('pagamento único, sem recorrência'),
		'label' => array('Preço do impulsionamento de 1 semana', 'taxonomy_profile_name'),
			'price' => '9.99',
			'duration' => '2',
			'lock_duration' => '1',
			'woo_product_id' => '',
			'woo_product_name' => array('Impulsionar %s por 1 semana', 'taxonomy_profile_name'),
		),
		'tours' => array(
			'title' => array('Passeios'),
			'label' => array('Preço para adicionar um passeio'),
			'label_help' => array('deixe em branco para passeios grátis'),
			'price' => '',
			'woo_product_id' => '',
			'woo_product_name' => array('Adicionar passeio em cidade', 'taxonomy_profile_name'),
		),
		'vip' => array(
			'title' => array('Opções VIP'),
			'label' => array('Preço para se tornar membro VIP'),
			'label_help' => array('deixe em branco para desativar'),
			'price' => '',
			'duration' => '',
			'woo_product_id' => '',
			'woo_product_name' => array('Upgrade para VIP', 'taxonomy_profile_name'),
			'extra' => array(
				'hide_photos' => '',
				'hide_contact_info' => '',
				'hide_review_form' => '',
			),
		),
	);
}

function escortwp_disable_stripe_gateway_classes($gateways) {
	if(!is_array($gateways)) {
		return $gateways;
	}

	foreach($gateways as $index => $gateway_class) {
		$class_name = is_string($gateway_class) ? strtolower($gateway_class) : '';
		if($class_name && strpos($class_name, 'stripe') !== false) {
			unset($gateways[$index]);
		}
	}

	return $gateways;
}
add_filter('woocommerce_payment_gateways', 'escortwp_disable_stripe_gateway_classes', 999);

function escortwp_disable_stripe_available_gateways($gateways) {
	if(!is_array($gateways)) {
		return $gateways;
	}

	foreach($gateways as $gateway_id => $gateway) {
		$gateway_key = strtolower((string)$gateway_id);
		$gateway_class = is_object($gateway) ? strtolower(get_class($gateway)) : '';
		if(strpos($gateway_key, 'stripe') !== false || ($gateway_class && strpos($gateway_class, 'stripe') !== false)) {
			unset($gateways[$gateway_id]);
		}
	}

	return $gateways;
}
add_filter('woocommerce_available_payment_gateways', 'escortwp_disable_stripe_available_gateways', 999);

function escortwp_mp_fetch_remote_json($url, $access_token) {
	if(empty($url) || empty($access_token)) {
		return false;
	}

	$response = wp_remote_get($url, array(
		'timeout' => 20,
		'headers' => array(
			'Authorization' => 'Bearer '.trim((string)$access_token),
			'Accept' => 'application/json',
		),
	));

	if(is_wp_error($response)) {
		return false;
	}

	$status = (int) wp_remote_retrieve_response_code($response);
	$body = json_decode((string) wp_remote_retrieve_body($response), true);
	if($status < 200 || $status >= 300 || !is_array($body)) {
		return false;
	}

	return $body;
}

function escortwp_sync_mercadopago_basic_checkout() {
	if(!class_exists('WooCommerce') || !class_exists('MercadoPago\\Woocommerce\\WoocommerceMercadoPago')) {
		return;
	}

	$access_token = defined('MERCADO_PAGO_ACCESS_TOKEN') ? trim((string) MERCADO_PAGO_ACCESS_TOKEN) : '';
	$access_token_test = defined('MERCADO_PAGO_ACCESS_TOKEN_TEST') ? trim((string) MERCADO_PAGO_ACCESS_TOKEN_TEST) : '';
	$public_key_prod = defined('MERCADO_PAGO_PUBLIC_KEY') ? trim((string) MERCADO_PAGO_PUBLIC_KEY) : trim((string) get_option('_mp_public_key_prod', ''));
	$public_key_test = defined('MERCADO_PAGO_PUBLIC_KEY_TEST') ? trim((string) MERCADO_PAGO_PUBLIC_KEY_TEST) : trim((string) get_option('_mp_public_key_test', ''));
	if(empty($access_token)) {
		return;
	}

	$sync_signature = md5($access_token.'|'.$access_token_test.'|'.$public_key_prod.'|'.$public_key_test.'|'.(defined('MERCADO_PAGO_SANDBOX') && MERCADO_PAGO_SANDBOX ? 'sandbox' : 'prod'));
	$last_signature = (string) get_option('_escortwp_mp_basic_checkout_sync_signature', '');
	$last_synced_at = (int) get_option('_escortwp_mp_basic_checkout_synced_at', 0);

	if($sync_signature === $last_signature && $last_synced_at > (time() - HOUR_IN_SECONDS)) {
		return;
	}

	update_option('_mp_access_token_prod', $access_token, false);
	if($access_token_test !== '') {
		update_option('_mp_access_token_test', $access_token_test, false);
	}
	if($public_key_prod !== '') {
		update_option('_mp_public_key_prod', $public_key_prod, false);
	}
	if($public_key_test !== '') {
		update_option('_mp_public_key_test', $public_key_test, false);
	}
	update_option('checkbox_checkout_test_mode', (defined('MERCADO_PAGO_SANDBOX') && MERCADO_PAGO_SANDBOX) ? 'yes' : 'no', false);

	$user_data = escortwp_mp_fetch_remote_json('https://api.mercadopago.com/users/me', $access_token);
	if(is_array($user_data)) {
		if(!empty($user_data['site_id'])) {
			update_option('_site_id_v1', sanitize_text_field((string)$user_data['site_id']), false);
		}
		if(!empty($user_data['country_id'])) {
			update_option('checkout_country', sanitize_text_field(substr((string)$user_data['country_id'], 0, 2)), false);
		}
		if(!empty($user_data['id'])) {
			update_option('_collector_id_v1', sanitize_text_field((string)$user_data['id']), false);
		}
	}

	$credentials_data = escortwp_mp_fetch_remote_json('https://api.mercadopago.com/plugins-credentials-wrapper/credentials', $access_token);
	if(is_array($credentials_data) && !empty($credentials_data['client_id'])) {
		$app_data = escortwp_mp_fetch_remote_json('https://api.mercadopago.com/applications/'.rawurlencode((string)$credentials_data['client_id']), $access_token);
		if(is_array($app_data) && !empty($app_data['test_access_token'])) {
			update_option('_mp_access_token_test', sanitize_text_field((string)$app_data['test_access_token']), false);
		}
	}

	$payment_methods = escortwp_mp_fetch_remote_json('https://api.mercadopago.com/v1/payment_methods', $access_token);
	if(is_array($payment_methods)) {
		$basic_methods = array();
		$pix_methods = array();

		foreach($payment_methods as $payment_method) {
			if(empty($payment_method['id']) || empty($payment_method['payment_type_id'])) {
				continue;
			}

			$serialized = array(
				'id' => sanitize_text_field((string)$payment_method['id']),
				'name' => sanitize_text_field((string)($payment_method['name'] ?? '')),
				'type' => sanitize_text_field((string)$payment_method['payment_type_id']),
				'image' => esc_url_raw((string)($payment_method['secure_thumbnail'] ?? '')),
				'config' => 'ex_payments_'.sanitize_key((string)$payment_method['id']),
			);

			if($serialized['id'] === 'pix') {
				$pix_methods[] = $serialized;
			}

			if(in_array($serialized['id'], array('consumer_credits', 'paypal', 'account_money'), true)) {
				continue;
			}

			$basic_methods[] = $serialized;
		}

		update_option('_checkout_payments_methods', $basic_methods, false);
		update_option('_mp_payment_methods_pix', $pix_methods, false);
	}

	$basic_settings = get_option('woocommerce_woo-mercado-pago-basic_settings', array());
	if(!is_array($basic_settings)) {
		$basic_settings = array();
	}
	$basic_settings['enabled'] = 'no';
	update_option('woocommerce_woo-mercado-pago-basic_settings', $basic_settings, false);

	$custom_settings = get_option('woocommerce_woo-mercado-pago-custom_settings', array());
	if(!is_array($custom_settings)) {
		$custom_settings = array();
	}
	$custom_settings['enabled'] = 'yes';
	$custom_settings['title'] = 'Cartão de crédito e débito';
	$custom_settings['wallet_button'] = 'no';
	$custom_settings['binary_mode'] = 'no';
	update_option('woocommerce_woo-mercado-pago-custom_settings', $custom_settings, false);

	$pix_settings = get_option('woocommerce_woo-mercado-pago-pix_settings', array());
	if(!is_array($pix_settings)) {
		$pix_settings = array();
	}
	$pix_settings['enabled'] = 'yes';
	$pix_settings['title'] = 'PIX';
	update_option('woocommerce_woo-mercado-pago-pix_settings', $pix_settings, false);

	$credits_settings = get_option('woocommerce_woo-mercado-pago-credits_settings', array());
	if(is_array($credits_settings)) {
		$credits_settings['enabled'] = 'no';
		update_option('woocommerce_woo-mercado-pago-credits_settings', $credits_settings, false);
	}

	$ticket_settings = get_option('woocommerce_woo-mercado-pago-ticket_settings', array());
	if(is_array($ticket_settings)) {
		$ticket_settings['enabled'] = 'no';
		update_option('woocommerce_woo-mercado-pago-ticket_settings', $ticket_settings, false);
	}

	if(function_exists('escortwp_log_payment_event') && $public_key_prod === '' && $public_key_test === '') {
		escortwp_log_payment_event('Mercado Pago sincronizado sem Public Key configurada. O PIX pode continuar disponível, mas cartão não tokeniza corretamente sem a chave pública.', array(
			'sandbox' => defined('MERCADO_PAGO_SANDBOX') && MERCADO_PAGO_SANDBOX ? 'yes' : 'no',
		));
	}

	update_option('_escortwp_mp_basic_checkout_sync_signature', $sync_signature, false);
	update_option('_escortwp_mp_basic_checkout_synced_at', time(), false);
}
add_action('init', 'escortwp_sync_mercadopago_basic_checkout', 30);

function escortwp_remove_legacy_stripe_integration() {
	if(!function_exists('deactivate_plugins') || !function_exists('is_plugin_active')) {
		require_once ABSPATH.'wp-admin/includes/plugin.php';
	}

	if(function_exists('is_plugin_active') && is_plugin_active('woocommerce-gateway-stripe/woocommerce-gateway-stripe.php')) {
		deactivate_plugins('woocommerce-gateway-stripe/woocommerce-gateway-stripe.php', true, false);
	}

	$stripe_options = array(
		'woocommerce_stripe_settings',
		'woocommerce_stripe_sepa_settings',
		'woocommerce_stripe_becs_settings',
		'woocommerce_stripe_sofort_settings',
		'woocommerce_stripe_ideal_settings',
		'woocommerce_stripe_p24_settings',
		'woocommerce_stripe_bancontact_settings',
		'woocommerce_stripe_giropay_settings',
		'woocommerce_stripe_eps_settings',
		'woocommerce_stripe_upe_settings',
		'wc_stripe_show_ssl_notice',
	);

	foreach($stripe_options as $stripe_option) {
		delete_option($stripe_option);
	}
}
add_action('init', 'escortwp_remove_legacy_stripe_integration', 4);

function escortwp_array_merge_recursive_distinct($base, $override) {
	if(!is_array($base)) {
		return is_array($override) ? $override : $base;
	}
	if(!is_array($override)) {
		return $base;
	}

	foreach($override as $key => $value) {
		if(array_key_exists($key, $base) && is_array($base[$key]) && is_array($value)) {
			$base[$key] = escortwp_array_merge_recursive_distinct($base[$key], $value);
		} else {
			$base[$key] = $value;
		}
	}

	return $base;
}

function escortwp_get_enforced_payment_plan_defaults() {
	return array(
		'premium' => array(
			'price' => '49.00',
			'duration' => '5',
		),
		'featured_boost' => array(
			'price' => '9.99',
			'duration' => '2',
			'lock_duration' => '1',
		),
	);
}

function escortwp_normalize_payment_plans($payment_plans) {
	$enforced_defaults = escortwp_get_enforced_payment_plan_defaults();

	foreach($enforced_defaults as $plan_key => $plan_defaults) {
		if(!isset($payment_plans[$plan_key]) || !is_array($payment_plans[$plan_key])) {
			$payment_plans[$plan_key] = array();
		}

		foreach($plan_defaults as $default_key => $default_value) {
			$current_value = isset($payment_plans[$plan_key][$default_key]) ? trim((string)$payment_plans[$plan_key][$default_key]) : '';
			if($current_value === '') {
				$payment_plans[$plan_key][$default_key] = $default_value;
			}
		}
	}

	return $payment_plans;
}

// Default Payment Plans
$payment_plans = escortwp_get_default_payment_plans();
// update_option('payment_plans', $payment_plans);
// $payment_plans = get_option('payment_plans');

function escortwp_generate_woocommerce_payment_button($product, $payment_for_id, $text = "", $button_class = 'greenbutton payment-button rad25') {
	$product = sanitize_key($product);
	$payment_for_id = (int)$payment_for_id;
	$submit_text = $text ? $text : __("Pagar agora",'escortwp');

	if(!is_woocommerce_active) {
		return false;
	}

	global $woocommerce;
	$woo_id = payment_plans($product, 'woo_product_id');
	if(!$woo_id && function_exists('escortwp_ensure_payment_plan_products')) {
		escortwp_ensure_payment_plan_products();
		$woo_id = payment_plans($product, 'woo_product_id');
	}
	if(!$woo_id) {
		return false;
	}
	$checkout_url = function_exists('wc_get_checkout_url') ? wc_get_checkout_url() : $woocommerce->cart->get_checkout_url();
    $button  = '<form action="'.esc_url($checkout_url).'" class="cart escortwp-payment-choice-form" method="post" enctype="multipart/form-data">';
    $button .= '<input type="hidden" name="add-to-cart" value="'.esc_attr($woo_id).'" />';
    $button .= '<input type="hidden" name="order_for_id" value="'.esc_attr($payment_for_id).'" />';
    $button .= '<button type="submit" class="'.esc_attr($button_class).'">'.$submit_text.'</button>';
    $button .= '</form>';
	return $button;
}

function generate_payment_buttons($product, $payment_for_id, $text="") {
	$product = sanitize_key($product);
	$payment_for_id = (int)$payment_for_id;
	$submit_text = $text ? $text : __("Pagar agora",'escortwp');
	return escortwp_generate_woocommerce_payment_button($product, $payment_for_id, $submit_text);
}

function escortwp_cart_contains_plan_payment_products() {
	if(!function_exists('WC') || !WC() || !WC()->cart) {
		return false;
	}

	foreach((array) WC()->cart->get_cart() as $cart_item) {
		$product_id = !empty($cart_item['product_id']) ? (int) $cart_item['product_id'] : 0;
		if(!$product_id) {
			continue;
		}

		$payment_type = (string) get_post_meta($product_id, 'payment_type', true);
		if(in_array($payment_type, array('premium', 'featured', 'featured_boost', 'indescreg', 'agreg', 'agescortreg', 'tours', 'vip'), true)) {
			return true;
		}
	}

	return false;
}

function escortwp_limit_plan_payment_gateways($gateways) {
	if(!is_array($gateways) || is_admin()) {
		return $gateways;
	}

	if(!escortwp_cart_contains_plan_payment_products()) {
		return $gateways;
	}

	$allowed_gateway_ids = array(
		'woo-mercado-pago-custom',
		'woo-mercado-pago-pix',
	);

	foreach($gateways as $gateway_id => $gateway) {
		if(!in_array((string) $gateway_id, $allowed_gateway_ids, true)) {
			unset($gateways[$gateway_id]);
		}
	}

	return $gateways;
}
add_filter('woocommerce_available_payment_gateways', 'escortwp_limit_plan_payment_gateways', 995);

// Add custom id to cart order
function woo_add_order_extra_data($cart_item_data, $product_id, $variation_id) {
    if(isset($_REQUEST['order_for_id'])) {
        $cart_item_data['order_for_id'] = sanitize_text_field($_REQUEST['order_for_id']);
    }
    return $cart_item_data;
}
add_filter('woocommerce_add_cart_item_data','woo_add_order_extra_data',10,3);

// Show custom id information in checkout and cart page
function woo_show_custom_info_checkout($product_name, $values, $cart_item_key) {
    if(isset($values['order_for_id']) && $values['order_for_id']) {
    	$custom_id = (int)$values['order_for_id'];
    	$payment_type = get_post_meta($values['product_id'], 'payment_type', true);
    	if($payment_type == "vip") {
    		$user_info = get_userdata($custom_id);
			$extra_info = $user_info ? $user_info->display_name : '';
    	} else {
			$extra_info = get_the_title($custom_id);
    	}

        $product_text = $product_name;
        $product_text .= $extra_info ? '<div class="extra-info">'.$extra_info.'</div>' : "";
        return $product_text;
    } else {
        return $product_name;
    }
}
add_filter('woocommerce_checkout_cart_item_quantity','woo_show_custom_info_checkout',1,3);  

// Save custom id to order
function wdm_add_custom_order_line_item_meta($item, $cart_item_key, $values, $order) {
    if(array_key_exists('order_for_id', $values)) {
        $item->add_meta_data('order_for_id', $values['order_for_id']);
    }
}
add_action( 'woocommerce_checkout_create_order_line_item', 'wdm_add_custom_order_line_item_meta',10,4 );

// Get any payment plan fast
function payment_plans($payment_name="", $key="", $key2="") {
	$payment_plans = escortwp_get_payment_plans();
	if(!$payment_name) return $payment_plans;
	if($key2) {
		return isset($payment_plans[$payment_name][$key][$key2]) ? $payment_plans[$payment_name][$key][$key2] : '';
	} else {
		return isset($payment_plans[$payment_name][$key]) ? $payment_plans[$payment_name][$key] : '';
	}
}

function escortwp_get_payment_plans() {
	static $payment_plans_cache = null;

	if(isset($GLOBALS['escortwp_payment_plans_cache_override']) && is_array($GLOBALS['escortwp_payment_plans_cache_override'])) {
		return $GLOBALS['escortwp_payment_plans_cache_override'];
	}

	if($payment_plans_cache !== null) {
		return $payment_plans_cache;
	}

	$saved_plans = get_option('payment_plans');
	if(!is_array($saved_plans)) {
		$saved_plans = array();
	}

	$payment_plans_cache = escortwp_array_merge_recursive_distinct(escortwp_get_default_payment_plans(), $saved_plans);
	$payment_plans_cache = escortwp_normalize_payment_plans($payment_plans_cache);
	if($payment_plans_cache !== $saved_plans) {
		update_option('payment_plans', $payment_plans_cache);
	}

	return $payment_plans_cache;
}

function escortwp_get_payment_plan_product_title($plan_key, $plan = array()) {
	if(empty($plan)) {
		$plan = payment_plans($plan_key);
	}

	if(empty($plan['woo_product_name'][0])) {
		return ucfirst(str_replace('_', ' ', $plan_key));
	}

	$arg_1 = '';
	$arg_2 = '';
	if(!empty($plan['woo_product_name'][1]) && isset($GLOBALS[$plan['woo_product_name'][1]])) {
		$arg_1 = $GLOBALS[$plan['woo_product_name'][1]];
	}
	if(!empty($plan['woo_product_name'][2]) && isset($GLOBALS[$plan['woo_product_name'][2]])) {
		$arg_2 = $GLOBALS[$plan['woo_product_name'][2]];
	}

	return sprintf(esc_html__($plan['woo_product_name'][0], 'escortwp'), $arg_1, $arg_2);
}

function escortwp_ensure_payment_plan_products() {
	if(!is_woocommerce_active) {
		return;
	}

	$payment_plans = escortwp_get_payment_plans();
	$current_user = wp_get_current_user();
	$product_author = $current_user && $current_user->ID ? (int)$current_user->ID : 1;
	$updated = false;

	foreach($payment_plans as $plan_name => $plan) {
		$price = isset($plan['price']) ? trim((string)$plan['price']) : '';
		if($price === '') {
			continue;
		}

		$product_id = isset($plan['woo_product_id']) ? (int)$plan['woo_product_id'] : 0;
		if($product_id && get_post_type($product_id) == 'product') {
			continue;
		}

		$product_title = escortwp_get_payment_plan_product_title($plan_name, $plan);
		$product_id = wp_insert_post(array(
			'post_title' => $product_title,
			'post_content' => $product_title,
			'post_name' => sanitize_title($product_title),
			'post_status' => 'publish',
			'post_author' => $product_author,
			'post_type' => 'product',
			'ping_status' => 'closed',
		));

		if(!$product_id || is_wp_error($product_id)) {
			continue;
		}

		update_post_meta($product_id, '_virtual', 'yes');
		update_post_meta($product_id, '_downloadable', 'no');
		update_post_meta($product_id, '_regular_price', $price);
		update_post_meta($product_id, '_price', $price);
		update_post_meta($product_id, 'payment_type', $plan_name);

		$payment_plans[$plan_name]['woo_product_id'] = $product_id;
		$updated = true;
	}

	if($updated) {
		update_option('payment_plans', $payment_plans);
		$GLOBALS['escortwp_payment_plans_cache_override'] = $payment_plans;
	}
}
add_action('init', 'escortwp_ensure_payment_plan_products', 24);

function escortwp_get_featured_boost_table_name() {
	global $wpdb;
	return $wpdb->prefix.'escortwp_featured_boosts';
}

function escortwp_ensure_featured_boost_product_is_one_time() {
	if(!is_woocommerce_active) {
		return;
	}

	$product_id = (int)payment_plans('featured_boost', 'woo_product_id');
	if(!$product_id || get_post_type($product_id) != 'product') {
		return;
	}

	$changed = false;
	$subscription_meta_keys = array(
		'_subscription_price',
		'_subscription_sign_up_fee',
		'_subscription_period',
		'_subscription_period_interval',
		'_subscription_length',
		'_subscription_trial_period',
		'_subscription_trial_length',
	);

	foreach($subscription_meta_keys as $subscription_meta_key) {
		if(get_post_meta($product_id, $subscription_meta_key, true) !== '') {
			delete_post_meta($product_id, $subscription_meta_key);
			$changed = true;
		}
	}

	if(get_post_meta($product_id, 'payment_type', true) !== 'featured_boost') {
		update_post_meta($product_id, 'payment_type', 'featured_boost');
		$changed = true;
	}

	if(get_post_meta($product_id, '_virtual', true) !== 'yes') {
		update_post_meta($product_id, '_virtual', 'yes');
		$changed = true;
	}

	if($changed) {
		wp_set_object_terms($product_id, 'simple', 'product_type');
	}
}
add_action('init', 'escortwp_ensure_featured_boost_product_is_one_time', 25);

function escortwp_ensure_premium_plan_is_monthly_one_time() {
	if(!is_woocommerce_active) {
		return;
	}

	$product_id = (int)payment_plans('premium', 'woo_product_id');
	$price = trim((string)payment_plans('premium', 'price'));
	if(!$product_id || !$price || get_post_type($product_id) != 'product') {
		return;
	}

	$updated = false;
	$subscription_meta_keys = array(
		'_subscription_price',
		'_subscription_sign_up_fee',
		'_subscription_period',
		'_subscription_period_interval',
		'_subscription_length',
		'_subscription_trial_period',
		'_subscription_trial_length',
	);

	foreach($subscription_meta_keys as $subscription_meta_key) {
		if(get_post_meta($product_id, $subscription_meta_key, true) !== '') {
			delete_post_meta($product_id, $subscription_meta_key);
			$updated = true;
		}
	}

	if((string)get_post_meta($product_id, '_price', true) !== $price) {
		update_post_meta($product_id, '_price', $price);
		$updated = true;
	}
	if((string)get_post_meta($product_id, '_regular_price', true) !== $price) {
		update_post_meta($product_id, '_regular_price', $price);
		$updated = true;
	}
	if((string)get_post_meta($product_id, '_virtual', true) !== 'yes') {
		update_post_meta($product_id, '_virtual', 'yes');
		$updated = true;
	}
	if((string)get_post_meta($product_id, 'payment_type', true) !== 'premium') {
		update_post_meta($product_id, 'payment_type', 'premium');
		$updated = true;
	}

	if($updated) {
		wp_set_object_terms($product_id, 'simple', 'product_type');
	}
}
add_action('init', 'escortwp_ensure_premium_plan_is_monthly_one_time', 26);

function escortwp_install_payment_schema() {
	$installed_version = get_option('escortwp_payment_schema_version');
	$current_version = '2026-04-03-01';

	if($installed_version === $current_version) {
		return;
	}

	global $wpdb;
	$table_name = escortwp_get_featured_boost_table_name();
	$charset_collate = $wpdb->get_charset_collate();

	require_once ABSPATH.'wp-admin/includes/upgrade.php';

	$sql = "CREATE TABLE {$table_name} (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		order_id bigint(20) unsigned NOT NULL DEFAULT 0,
		order_item_id bigint(20) unsigned NOT NULL DEFAULT 0,
		product_id bigint(20) unsigned NOT NULL DEFAULT 0,
		profile_id bigint(20) unsigned NOT NULL DEFAULT 0,
		user_id bigint(20) unsigned NOT NULL DEFAULT 0,
		boost_key varchar(50) NOT NULL DEFAULT 'featured_boost',
		payment_status varchar(30) NOT NULL DEFAULT 'pending',
		boost_status varchar(30) NOT NULL DEFAULT 'pending',
		amount decimal(10,2) NOT NULL DEFAULT 0.00,
		currency varchar(10) NOT NULL DEFAULT '',
		starts_at bigint(20) unsigned NOT NULL DEFAULT 0,
		expires_at bigint(20) unsigned NOT NULL DEFAULT 0,
		notes text NULL,
		created_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
		updated_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
		PRIMARY KEY  (id),
		UNIQUE KEY order_item_boost (order_item_id, boost_key),
		KEY profile_boost_status (profile_id, boost_status),
		KEY order_boost_status (order_id, boost_status),
		KEY expires_at (expires_at)
	) {$charset_collate};";

	dbDelta($sql);
	update_option('escortwp_payment_schema_version', $current_version);
}
add_action('init', 'escortwp_install_payment_schema', 1);

function escortwp_get_payment_duration_seconds($payment_plan) {
	global $payment_duration_a;

	$duration = payment_plans($payment_plan, 'duration');
	if(!$duration || !isset($payment_duration_a[$duration])) {
		return 0;
	}

	return ((int)$payment_duration_a[$duration][1]) * DAY_IN_SECONDS;
}

function escortwp_plan_is_registration($plan_key) {
	return in_array($plan_key, array('indescreg', 'agreg', 'agescortreg'), true);
}

function escortwp_plan_is_post_based($plan_key) {
	return in_array($plan_key, array('indescreg', 'agreg', 'agescortreg', 'premium', 'featured', 'featured_boost', 'tours'), true);
}

function escortwp_is_paid_order_status($status) {
	return in_array($status, array('processing', 'completed'), true);
}

function escortwp_is_pending_order_status($status) {
	return in_array($status, array('pending', 'on-hold'), true);
}

function escortwp_is_failed_order_status($status) {
	return in_array($status, array('failed', 'cancelled', 'refunded'), true);
}

function escortwp_is_subscription_product($product_id) {
	$product_id = (int)$product_id;
	if(!$product_id) {
		return false;
	}

	return class_exists('WC_Subscriptions_Product') && (string)get_post_meta($product_id, '_subscription_price', true) !== '';
}

function escortwp_is_subscription_plan($plan_key) {
	if($plan_key == 'featured_boost') {
		return false;
	}

	return escortwp_is_subscription_product(payment_plans($plan_key, 'woo_product_id'));
}

function escortwp_get_payment_environment_status() {
	static $payment_environment_status = null;

	if($payment_environment_status !== null) {
		return $payment_environment_status;
	}

	$woocommerce_active = (bool)is_woocommerce_active;
	if($woocommerce_active) {
		escortwp_ensure_payment_plan_products();
		escortwp_ensure_featured_boost_product_is_one_time();
		escortwp_ensure_premium_plan_is_monthly_one_time();
	}

	$checkout_page_id = 0;
	$checkout_page_url = '';
	$checkout_page_title = '';
	$checkout_ready = false;
	if($woocommerce_active && function_exists('wc_get_page_id')) {
		$checkout_page_id = (int)wc_get_page_id('checkout');
	}
	if($checkout_page_id > 0 && get_post($checkout_page_id)) {
		$checkout_page_title = get_the_title($checkout_page_id);
		$checkout_page_url = function_exists('wc_get_checkout_url') ? wc_get_checkout_url() : get_permalink($checkout_page_id);
		$checkout_ready = !empty($checkout_page_url);
	}

	$gateway_names = array();
	if($woocommerce_active && function_exists('WC') && WC() && method_exists(WC(), 'payment_gateways')) {
		$payment_gateways = WC()->payment_gateways();
		if($payment_gateways && method_exists($payment_gateways, 'payment_gateways')) {
			foreach((array)$payment_gateways->payment_gateways() as $gateway) {
				if(!is_object($gateway) || !isset($gateway->enabled) || $gateway->enabled !== 'yes') {
					continue;
				}
				if(!empty($gateway->title)) {
					$gateway_names[] = wp_strip_all_tags($gateway->title);
				} elseif(!empty($gateway->method_title)) {
					$gateway_names[] = wp_strip_all_tags($gateway->method_title);
				}
			}
		}
	}

	$mp_config = function_exists('escortwp_mp_get_config') ? escortwp_mp_get_config() : array();
	$mercadopago_plugin_active = defined('MP_PLUGIN_FILE') || class_exists('MercadoPago\\Woocommerce\\WoocommerceMercadoPago');
	$mercadopago_sdk_ready = function_exists('escortwp_mp_bootstrap_sdk') ? escortwp_mp_bootstrap_sdk() : false;
	$mercadopago_token_ready = !empty($mp_config['access_token']);
	$mercadopago_ready = function_exists('escortwp_mp_is_ready') ? escortwp_mp_is_ready() : false;
	$mercadopago_webhook_mode = function_exists('escortwp_mp_get_webhook_validation_mode') ? escortwp_mp_get_webhook_validation_mode() : '';
	$mercadopago_notification_url = !empty($mp_config['notification_url']) ? $mp_config['notification_url'] : '';

	$premium_price = trim((string)payment_plans('premium', 'price'));
	$premium_product_id = (int)payment_plans('premium', 'woo_product_id');
	$premium_product_exists = $premium_product_id > 0 && get_post_type($premium_product_id) === 'product';
	$premium_is_subscription = $premium_product_exists && escortwp_is_subscription_product($premium_product_id);
	$premium_is_one_time = $premium_product_exists
		&& !$premium_is_subscription
		&& (string)get_post_meta($premium_product_id, 'payment_type', true) === 'premium';
	$premium_duration_seconds = (int)escortwp_get_payment_duration_seconds('premium');

	$boost_price = trim((string)payment_plans('featured_boost', 'price'));
	$boost_product_id = (int)payment_plans('featured_boost', 'woo_product_id');
	$boost_product_exists = $boost_product_id > 0 && get_post_type($boost_product_id) === 'product';
	$boost_is_one_time = $boost_product_exists
		&& !escortwp_is_subscription_product($boost_product_id)
		&& (string)get_post_meta($boost_product_id, 'payment_type', true) === 'featured_boost';

	$payment_environment_status = array(
		'woocommerce_active' => $woocommerce_active,
		'subscriptions_active' => class_exists('WC_Subscriptions_Product'),
		'mercadopago_plugin_active' => $mercadopago_plugin_active,
		'mercadopago_sdk_ready' => $mercadopago_sdk_ready,
		'mercadopago_token_ready' => $mercadopago_token_ready,
		'mercadopago_ready' => $mercadopago_ready,
		'mercadopago_webhook_mode' => $mercadopago_webhook_mode,
		'mercadopago_notification_url' => $mercadopago_notification_url,
		'mercadopago_sandbox' => !empty($mp_config['sandbox']),
		'checkout_page_id' => $checkout_page_id,
		'checkout_page_title' => $checkout_page_title,
		'checkout_page_url' => $checkout_page_url,
		'checkout_ready' => $checkout_ready,
		'gateway_names' => array_values(array_unique($gateway_names)),
		'gateway_ready' => $mercadopago_ready,
		'premium_price' => $premium_price,
		'premium_product_id' => $premium_product_id,
		'premium_product_exists' => $premium_product_exists,
		'premium_is_subscription' => $premium_is_subscription,
		'premium_is_one_time' => $premium_is_one_time,
		'premium_duration_seconds' => $premium_duration_seconds,
		'boost_price' => $boost_price,
		'boost_product_id' => $boost_product_id,
		'boost_product_exists' => $boost_product_exists,
		'boost_is_one_time' => $boost_is_one_time,
	);

	return $payment_environment_status;
}

function escortwp_get_payment_action_status($plan_key) {
	$plan_key = sanitize_key($plan_key);
	$environment = escortwp_get_payment_environment_status();
	$missing = array();
	$label = $plan_key === 'premium' ? __('Plano mensal', 'escortwp') : __('Impulsionamento semanal', 'escortwp');

	if(empty($environment['mercadopago_plugin_active'])) {
		$missing[] = __('Instale e ative o plugin oficial do Mercado Pago para WooCommerce.', 'escortwp');
	}

	if(empty($environment['mercadopago_sdk_ready'])) {
		$missing[] = __('O SDK oficial do Mercado Pago não está disponível. Reinstale ou reative o plugin do Mercado Pago.', 'escortwp');
	}

	if(empty($environment['mercadopago_token_ready'])) {
		$missing[] = __('Defina o ACCESS_TOKEN do Mercado Pago antes de cobrar via checkout com PIX e cartão.', 'escortwp');
	}

	if($plan_key === 'premium') {
		if($environment['premium_price'] === '') {
			$missing[] = __('Defina o preco do plano mensal.', 'escortwp');
		}
		if(empty($environment['premium_duration_seconds'])) {
			$missing[] = __('Defina a duracao do plano mensal para que ele expire corretamente.', 'escortwp');
		}
		if(empty($environment['premium_product_exists'])) {
			$missing[] = __('O produto interno do plano mensal ainda não foi criado.', 'escortwp');
		} elseif(empty($environment['premium_is_one_time'])) {
			$missing[] = __('O plano mensal precisa permanecer como cobrança manual de 30 dias, sem assinatura automática.', 'escortwp');
		}
	} elseif($plan_key === 'featured_boost') {
		if($environment['boost_price'] === '') {
			$missing[] = __('Defina o preco do impulsionamento semanal.', 'escortwp');
		}
		if(empty($environment['boost_product_exists'])) {
		$missing[] = __('O produto interno do impulsionamento ainda não foi criado.', 'escortwp');
		} elseif(empty($environment['boost_is_one_time'])) {
			$missing[] = __('O impulsionamento precisa permanecer como pagamento único, sem recorrência.', 'escortwp');
		}
	}

	return array(
		'plan_key' => $plan_key,
		'label' => $label,
		'ready' => empty($missing),
		'missing' => $missing,
		'environment' => $environment,
	);
}

function escortwp_render_payment_action_requirements($plan_key, $args = array()) {
	$status = escortwp_get_payment_action_status($plan_key);
	$args = wp_parse_args($args, array(
		'show_ready' => false,
		'context' => 'front',
	));

	if($status['ready'] && empty($args['show_ready'])) {
		return '';
	}

	$classes = 'escortwp-payment-readiness-note';
	$classes .= $status['ready'] ? ' is-ready' : ' is-warning';
	$classes .= $args['context'] === 'admin' ? ' is-admin' : ' is-front';

	ob_start();
	?>
	<div class="<?php echo esc_attr($classes); ?>">
		<strong><?php echo esc_html($status['label']); ?></strong>
		<?php if($status['ready']) { ?>
			<p><?php _e('Pronto para cobrar via checkout do Mercado Pago assim que o access token estiver configurado no ambiente.', 'escortwp'); ?></p>
		<?php } else { ?>
			<p><?php _e('Antes de liberar esta cobranca, conclua os itens abaixo:', 'escortwp'); ?></p>
			<ul>
				<?php foreach($status['missing'] as $missing_message) { ?>
					<li><?php echo esc_html($missing_message); ?></li>
				<?php } ?>
			</ul>
		<?php } ?>
	</div>
	<?php

	return ob_get_clean();
}

function escortwp_render_payment_environment_panel($args = array()) {
	$environment = escortwp_get_payment_environment_status();
	$monthly_status = escortwp_get_payment_action_status('premium');
	$boost_status = escortwp_get_payment_action_status('featured_boost');
	$args = wp_parse_args($args, array(
		'title' => __('Pronto para cobrar', 'escortwp'),
		'description' => __('Confira aqui se o tema já tem tudo o que precisa para vender o plano mensal de 30 dias e o impulsionamento semanal via checkout do Mercado Pago, com PIX e cartão.', 'escortwp'),
		'context' => 'admin',
	));

	if(!empty($environment['mercadopago_ready'])) {
		$gateway_summary = !empty($environment['mercadopago_sandbox'])
			? __('Mercado Pago ativo em sandbox.', 'escortwp')
			: __('Mercado Pago pronto para produção.', 'escortwp');
	} elseif(!empty($environment['mercadopago_plugin_active'])) {
		$gateway_summary = __('Mercado Pago instalado. Falta apenas configurar o access token para liberar PIX e cartão.', 'escortwp');
	} else {
		$gateway_summary = __('Mercado Pago ainda não está ativo nesta instalação.', 'escortwp');
	}

	$webhook_summary = !empty($environment['mercadopago_notification_url'])
		? sprintf(esc_html__('Webhook do Mercado Pago pronto em %s.', 'escortwp'), $environment['mercadopago_notification_url'])
		: __('Webhook do Mercado Pago ainda não configurado.', 'escortwp');

	ob_start();
	?>
	<div class="escortwp-payment-readiness escortwp-payment-readiness--<?php echo esc_attr($args['context']); ?>">
		<div class="escortwp-payment-readiness-header">
			<h4><?php echo esc_html($args['title']); ?></h4>
			<p><?php echo esc_html($args['description']); ?></p>
		</div>
		<div class="escortwp-payment-readiness-grid">
			<div class="escortwp-payment-readiness-card <?php echo !empty($environment['mercadopago_ready']) ? 'is-ready' : 'is-warning'; ?>">
				<span class="escortwp-payment-readiness-label"><?php _e('Infraestrutura', 'escortwp'); ?></span>
				<h5><?php _e('Mercado Pago', 'escortwp'); ?></h5>
				<ul class="escortwp-payment-readiness-list">
					<li class="<?php echo !empty($environment['woocommerce_active']) ? 'is-ready' : 'is-missing'; ?>"><?php echo !empty($environment['woocommerce_active']) ? esc_html__('WooCommerce ativo', 'escortwp') : esc_html__('WooCommerce ausente', 'escortwp'); ?></li>
					<li class="<?php echo !empty($environment['mercadopago_plugin_active']) ? 'is-ready' : 'is-missing'; ?>"><?php echo !empty($environment['mercadopago_plugin_active']) ? esc_html__('Plugin oficial do Mercado Pago ativo', 'escortwp') : esc_html__('Plugin oficial do Mercado Pago ausente', 'escortwp'); ?></li>
					<li class="<?php echo !empty($environment['mercadopago_sdk_ready']) ? 'is-ready' : 'is-missing'; ?>"><?php echo !empty($environment['mercadopago_sdk_ready']) ? esc_html__('SDK oficial carregado', 'escortwp') : esc_html__('SDK oficial não encontrado', 'escortwp'); ?></li>
					<li class="<?php echo !empty($environment['mercadopago_token_ready']) ? 'is-ready' : 'is-missing'; ?>"><?php echo !empty($environment['mercadopago_token_ready']) ? esc_html__('Access token configurado', 'escortwp') : esc_html__('Access token pendente', 'escortwp'); ?></li>
					<li class="<?php echo !empty($environment['mercadopago_notification_url']) ? 'is-ready' : 'is-missing'; ?>"><?php echo esc_html($webhook_summary); ?></li>
					<li class="<?php echo !empty($environment['mercadopago_ready']) ? 'is-ready' : 'is-missing'; ?>"><?php echo esc_html($gateway_summary); ?></li>
				</ul>
			</div>

			<div class="escortwp-payment-readiness-card <?php echo $monthly_status['ready'] ? 'is-ready' : 'is-warning'; ?>">
				<span class="escortwp-payment-readiness-label"><?php _e('Plano mensal manual', 'escortwp'); ?></span>
				<h5><?php _e('Plano mensal', 'escortwp'); ?></h5>
				<div class="escortwp-payment-readiness-price"><?php echo $environment['premium_price'] !== '' ? wp_kses_post(format_price('premium', 'small')) : esc_html__('Sem preço definido', 'escortwp'); ?></div>
				<?php echo escortwp_render_payment_action_requirements('premium', array('show_ready' => true, 'context' => $args['context'])); ?>
			</div>

			<div class="escortwp-payment-readiness-card <?php echo $boost_status['ready'] ? 'is-ready' : 'is-warning'; ?>">
				<span class="escortwp-payment-readiness-label"><?php _e('Pagamento único', 'escortwp'); ?></span>
				<h5><?php _e('Impulsionamento de 7 dias', 'escortwp'); ?></h5>
				<div class="escortwp-payment-readiness-price"><?php echo $environment['boost_price'] !== '' ? wp_kses_post(format_price('featured_boost', 'small')) : esc_html__('Sem preço definido', 'escortwp'); ?></div>
				<?php echo escortwp_render_payment_action_requirements('featured_boost', array('show_ready' => true, 'context' => $args['context'])); ?>
			</div>
		</div>
	</div>
	<?php

	return ob_get_clean();
}
function escortwp_get_post_plan_meta($post_id, $suffix = '') {
	return $suffix ? 'escortwp_plan_'.$suffix : 'escortwp_plan_';
}

function escortwp_read_post_plan_state_from_meta($post_id) {
	$post_id = (int)$post_id;
	if(!$post_id) {
		return array();
	}

	return array(
		'plan_key' => get_post_meta($post_id, escortwp_get_post_plan_meta($post_id, 'key'), true),
		'plan_type' => get_post_meta($post_id, escortwp_get_post_plan_meta($post_id, 'type'), true),
		'plan_status' => get_post_meta($post_id, escortwp_get_post_plan_meta($post_id, 'status'), true),
		'started_at' => (int)get_post_meta($post_id, escortwp_get_post_plan_meta($post_id, 'started_at'), true),
		'expires_at' => (int)get_post_meta($post_id, escortwp_get_post_plan_meta($post_id, 'expires_at'), true),
		'order_id' => (int)get_post_meta($post_id, escortwp_get_post_plan_meta($post_id, 'order_id'), true),
		'product_id' => (int)get_post_meta($post_id, escortwp_get_post_plan_meta($post_id, 'product_id'), true),
		'subscription_id' => (int)get_post_meta($post_id, escortwp_get_post_plan_meta($post_id, 'subscription_id'), true),
		'subscription_status' => get_post_meta($post_id, escortwp_get_post_plan_meta($post_id, 'subscription_status'), true),
	);
}

function escortwp_get_post_plan_state($post_id) {
	static $refreshing_subscription_state = array();

	$post_id = (int)$post_id;
	if(!$post_id || !get_post($post_id)) {
		return array();
	}

	$plan_key = get_post_meta($post_id, escortwp_get_post_plan_meta($post_id, 'key'), true);
	$legacy_plan_key = escortwp_get_registration_plan_key_for_post($post_id);

	if(!$plan_key && $legacy_plan_key) {
		escortwp_sync_post_plan_state_from_legacy($post_id, $legacy_plan_key);
		$plan_key = get_post_meta($post_id, escortwp_get_post_plan_meta($post_id, 'key'), true);
	}

	$state = escortwp_read_post_plan_state_from_meta($post_id);

	if($plan_key && empty($state['plan_key'])) {
		$state['plan_key'] = $plan_key;
	}

	if($state['subscription_id'] && empty($refreshing_subscription_state[$post_id])) {
		$refreshing_subscription_state[$post_id] = true;
		escortwp_refresh_post_plan_state_from_subscription($post_id, $state['subscription_id']);
		unset($refreshing_subscription_state[$post_id]);
		$state = escortwp_read_post_plan_state_from_meta($post_id);
	}

	return $state;
}

function escortwp_get_registration_plan_key_for_post($post_id) {
	global $taxonomy_profile_url, $taxonomy_agency_url;

	$post_type = get_post_type($post_id);
	if($post_type == $taxonomy_agency_url) {
		return 'agreg';
	}

	if($post_type == $taxonomy_profile_url) {
		if(get_post_meta($post_id, 'independent', true) == 'yes') {
			return 'indescreg';
		}
		return 'agescortreg';
	}

	return '';
}

function escortwp_get_plan_display_label($plan_key, $plan_type = '') {
	if(function_exists('escortwp_get_plan_display_label_v2')) {
		return escortwp_get_plan_display_label_v2($plan_key, $plan_type);
	}

	if($plan_type == 'free') {
		return __('Plano grátis', 'escortwp');
	}

	if($plan_type == 'subscription') {
		return __('Assinatura mensal', 'escortwp');
	}

	switch($plan_key) {
		case 'featured_boost':
			return __('Impulsionamento de 7 dias', 'escortwp');
		case 'premium':
			return __('Plano premium', 'escortwp');
		case 'featured':
			return __('Destaque', 'escortwp');
		case 'agreg':
			return __('Plano da agência', 'escortwp');
		case 'agescortreg':
			return __('Plano da anunciante da agência', 'escortwp');
		case 'indescreg':
			return __('Plano da anunciante', 'escortwp');
		case 'vip':
			return __('Plano VIP', 'escortwp');
		default:
			return __('Plano ativo', 'escortwp');
	}
}

function escortwp_get_plan_meta_prefix($plan_key) {
	switch($plan_key) {
		case 'agreg':
			return 'agency';
		case 'indescreg':
		case 'agescortreg':
			return 'escort';
		case 'premium':
			return 'premium';
		case 'featured':
			return 'featured';
		case 'vip':
			return 'vip';
		default:
			return '';
	}
}

function escortwp_get_plan_status_display_label($status) {
	switch((string)$status) {
		case 'pending-payment':
			return __('Pagamento pendente', 'escortwp');
		case 'pending-approval':
			return __('Aguardando aprovação', 'escortwp');
		case 'payment-failed':
			return __('Pagamento falhou', 'escortwp');
		case 'payment-refunded':
			return __('Pagamento reembolsado', 'escortwp');
		case 'cancelled':
			return __('Cancelado', 'escortwp');
		case 'expired':
			return __('Vencido', 'escortwp');
		case 'active':
		default:
			return __('Ativo', 'escortwp');
	}
}

function escortwp_get_boost_status_display_label($status) {
	switch((string)$status) {
		case 'pending':
			return __('Aguardando pagamento', 'escortwp');
		case 'failed':
			return __('Pagamento falhou', 'escortwp');
		case 'refunded':
			return __('Reembolsado', 'escortwp');
		case 'cancelled':
			return __('Cancelado', 'escortwp');
		case 'expired':
			return __('Expirado', 'escortwp');
		case 'active':
		default:
			return __('Ativo', 'escortwp');
	}
}

function escortwp_update_post_plan_state($post_id, $args = array()) {
	$post_id = (int)$post_id;
	if(!$post_id) {
		return false;
	}

	$defaults = array(
		'plan_key' => '',
		'plan_type' => '',
		'plan_status' => '',
		'started_at' => 0,
		'expires_at' => 0,
		'order_id' => 0,
		'product_id' => 0,
		'subscription_id' => 0,
		'subscription_status' => '',
	);
	$args = wp_parse_args($args, $defaults);

	foreach($args as $key => $value) {
		$meta_key = escortwp_get_post_plan_meta($post_id, $key);
		if($value === '' || $value === null || $value === 0) {
			delete_post_meta($post_id, $meta_key);
		} else {
			update_post_meta($post_id, $meta_key, $value);
		}
	}

	return escortwp_read_post_plan_state_from_meta($post_id);
}

function escortwp_initialize_post_plan_state($post_id, $plan_key, $args = array()) {
	$post_id = (int)$post_id;
	if(!$post_id || !$plan_key) {
		return false;
	}

	$requires_payment = (string)payment_plans($plan_key, 'price') !== '';
	$plan_type = $requires_payment ? (escortwp_is_subscription_plan($plan_key) ? 'subscription' : 'one_time') : 'free';
	$default_status = $requires_payment ? 'pending-payment' : 'active';
	if(get_post_meta($post_id, 'notactive', true) == '1' && !$requires_payment) {
		$default_status = 'pending-approval';
	}

	$state = wp_parse_args($args, array(
		'plan_key' => $plan_key,
		'plan_type' => $plan_type,
		'plan_status' => $default_status,
		'started_at' => current_time('timestamp'),
		'expires_at' => 0,
		'order_id' => 0,
		'product_id' => (int)payment_plans($plan_key, 'woo_product_id'),
		'subscription_id' => 0,
		'subscription_status' => $plan_type == 'subscription' ? 'pending' : '',
	));

	return escortwp_update_post_plan_state($post_id, $state);
}

function escortwp_sync_post_plan_state_from_legacy($post_id, $plan_key = '') {
	$post_id = (int)$post_id;
	if(!$post_id) {
		return array();
	}

	if(!$plan_key) {
		$plan_key = escortwp_get_registration_plan_key_for_post($post_id);
	}
	if(!$plan_key) {
		return array();
	}

	$plan_type = escortwp_is_subscription_plan($plan_key) ? 'subscription' : ((string)payment_plans($plan_key, 'price') === '' ? 'free' : 'one_time');
	$meta_prefix = $plan_key === 'agreg' ? 'agency' : 'escort';
	$status = 'active';
	$expires_at = (int)get_post_meta($post_id, $meta_prefix.'_expire', true);
	$subscription_status = '';

	if(get_post_meta($post_id, 'needs_payment', true) == '1') {
		$status = 'pending-payment';
	} elseif(get_post_meta($post_id, 'notactive', true) == '1' || get_post_status($post_id) == 'private' && !$expires_at && $plan_type == 'free') {
		$status = 'pending-approval';
	} elseif($plan_type == 'subscription' || get_post_meta($post_id, $meta_prefix.'_renew', true) == '1') {
		$status = 'active';
		$plan_type = 'subscription';
		$subscription_status = get_post_meta($post_id, escortwp_get_post_plan_meta($post_id, 'subscription_status'), true);
	} elseif($expires_at && $expires_at <= current_time('timestamp')) {
		$status = 'expired';
	} elseif($plan_type == 'free') {
		$status = 'active';
	}

	return escortwp_update_post_plan_state($post_id, array(
		'plan_key' => $plan_key,
		'plan_type' => $plan_type,
		'plan_status' => $status,
		'started_at' => (int)get_post_meta($post_id, escortwp_get_post_plan_meta($post_id, 'started_at'), true) ?: current_time('timestamp'),
		'expires_at' => $plan_type == 'subscription' ? (int)get_post_meta($post_id, escortwp_get_post_plan_meta($post_id, 'expires_at'), true) : $expires_at,
		'order_id' => (int)get_post_meta($post_id, $meta_prefix == 'agency' ? 'agency_txn_id' : 'profile_txn_id', true),
		'product_id' => (int)payment_plans($plan_key, 'woo_product_id'),
		'subscription_id' => (int)get_post_meta($post_id, escortwp_get_post_plan_meta($post_id, 'subscription_id'), true),
		'subscription_status' => $subscription_status,
	));
}

function escortwp_refresh_post_plan_state_from_subscription($post_id, $subscription_id) {
	if(!$subscription_id || !function_exists('wcs_get_subscription')) {
		return false;
	}

	$subscription = wcs_get_subscription($subscription_id);
	if(!$subscription) {
		return false;
	}

	$status = $subscription->get_status();
	$plan_status = in_array($status, array('cancelled', 'pending-cancel'), true) ? 'cancelled' : ($status == 'expired' ? 'expired' : 'active');
	$expires_at = 0;
	if(method_exists($subscription, 'get_time')) {
		$expires_at = (int)$subscription->get_time('end');
		if(!$expires_at && $plan_status == 'active') {
			$expires_at = (int)$subscription->get_time('next_payment');
		}
	}

	escortwp_update_post_plan_state($post_id, array(
		'plan_type' => 'subscription',
		'plan_status' => $plan_status,
		'expires_at' => $expires_at,
		'subscription_status' => $status,
	));

	return true;
}

function escortwp_get_featured_boost_price() {
	return (float)payment_plans('featured_boost', 'price');
}

function escortwp_get_featured_boost_duration_seconds() {
	$seconds = escortwp_get_payment_duration_seconds('featured_boost');
	return $seconds ? $seconds : WEEK_IN_SECONDS;
}

function escortwp_get_featured_boost_record($order_item_id = 0, $order_id = 0, $profile_id = 0) {
	global $wpdb;
	$table_name = escortwp_get_featured_boost_table_name();

	if($order_item_id) {
		return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} WHERE order_item_id = %d LIMIT 1", $order_item_id));
	}
	if($order_id && $profile_id) {
		return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} WHERE order_id = %d AND profile_id = %d AND boost_key = %s LIMIT 1", $order_id, $profile_id, 'featured_boost'));
	}
	return null;
}

function escortwp_get_latest_featured_boost_record($profile_id) {
	global $wpdb;
	$profile_id = (int)$profile_id;
	if(!$profile_id) {
		return null;
	}

	$table_name = escortwp_get_featured_boost_table_name();
	return $wpdb->get_row($wpdb->prepare(
		"SELECT * FROM {$table_name}
		WHERE profile_id = %d
		ORDER BY updated_at DESC, created_at DESC, id DESC
		LIMIT 1",
		$profile_id
	));
}

function escortwp_upsert_featured_boost_record($args = array()) {
	global $wpdb;
	$table_name = escortwp_get_featured_boost_table_name();
	$now_mysql = current_time('mysql');

	$defaults = array(
		'order_id' => 0,
		'order_item_id' => 0,
		'product_id' => 0,
		'profile_id' => 0,
		'user_id' => 0,
		'boost_key' => 'featured_boost',
		'payment_status' => 'pending',
		'boost_status' => 'pending',
		'amount' => escortwp_get_featured_boost_price(),
		'currency' => function_exists('get_woocommerce_currency') ? get_woocommerce_currency() : '',
		'starts_at' => 0,
		'expires_at' => 0,
		'notes' => '',
	);
	$data = wp_parse_args($args, $defaults);

	$existing = escortwp_get_featured_boost_record((int)$data['order_item_id'], (int)$data['order_id'], (int)$data['profile_id']);
	$row = array(
		'order_id' => (int)$data['order_id'],
		'order_item_id' => (int)$data['order_item_id'],
		'product_id' => (int)$data['product_id'],
		'profile_id' => (int)$data['profile_id'],
		'user_id' => (int)$data['user_id'],
		'boost_key' => sanitize_key($data['boost_key']),
		'payment_status' => sanitize_key($data['payment_status']),
		'boost_status' => sanitize_key($data['boost_status']),
		'amount' => (float)$data['amount'],
		'currency' => sanitize_text_field($data['currency']),
		'starts_at' => (int)$data['starts_at'],
		'expires_at' => (int)$data['expires_at'],
		'notes' => sanitize_text_field($data['notes']),
		'updated_at' => $now_mysql,
	);

	if($existing) {
		$wpdb->update($table_name, $row, array('id' => (int)$existing->id));
		return (int)$existing->id;
	}

	$row['created_at'] = $now_mysql;
	$wpdb->insert($table_name, $row);
	return (int)$wpdb->insert_id;
}

function escortwp_capture_featured_legacy_state($profile_id) {
	if(get_post_meta($profile_id, 'escortwp_featured_source', true) == 'boost') {
		return;
	}

	update_post_meta($profile_id, 'escortwp_featured_legacy_active', get_post_meta($profile_id, 'featured', true));
	update_post_meta($profile_id, 'escortwp_featured_legacy_expire', get_post_meta($profile_id, 'featured_expire', true));
	update_post_meta($profile_id, 'escortwp_featured_legacy_renew', get_post_meta($profile_id, 'featured_renew', true));
	update_post_meta($profile_id, 'escortwp_featured_legacy_txn_id', get_post_meta($profile_id, 'featured_txn_id', true));
}

function escortwp_clear_featured_legacy_snapshot($profile_id) {
	delete_post_meta($profile_id, 'escortwp_featured_legacy_active');
	delete_post_meta($profile_id, 'escortwp_featured_legacy_expire');
	delete_post_meta($profile_id, 'escortwp_featured_legacy_renew');
	delete_post_meta($profile_id, 'escortwp_featured_legacy_txn_id');
}

function escortwp_apply_featured_boost_state($profile_id, $starts_at, $expires_at, $order_id = 0) {
	update_post_meta($profile_id, 'escortwp_featured_source', 'boost');
	update_post_meta($profile_id, 'escortwp_featured_boost_status', 'active');
	update_post_meta($profile_id, 'escortwp_featured_boost_started_at', (int)$starts_at);
	update_post_meta($profile_id, 'escortwp_featured_boost_expires_at', (int)$expires_at);
	update_post_meta($profile_id, 'featured', '1');
	update_post_meta($profile_id, 'featured_expire', (int)$expires_at);
	if($order_id) {
		update_post_meta($profile_id, 'featured_txn_id', (int)$order_id);
	}
	delete_post_meta($profile_id, 'featured_renew');
	delete_post_meta($profile_id, 'featured_expire_notice');
}

function escortwp_restore_featured_state_after_boost($profile_id) {
	$legacy_active = get_post_meta($profile_id, 'escortwp_featured_legacy_active', true);
	$legacy_expire = get_post_meta($profile_id, 'escortwp_featured_legacy_expire', true);
	$legacy_renew = get_post_meta($profile_id, 'escortwp_featured_legacy_renew', true);
	$legacy_txn_id = get_post_meta($profile_id, 'escortwp_featured_legacy_txn_id', true);

	if($legacy_active == '1') {
		update_post_meta($profile_id, 'featured', '1');
		if($legacy_expire) {
			update_post_meta($profile_id, 'featured_expire', $legacy_expire);
		} else {
			delete_post_meta($profile_id, 'featured_expire');
		}
		if($legacy_renew) {
			update_post_meta($profile_id, 'featured_renew', $legacy_renew);
		} else {
			delete_post_meta($profile_id, 'featured_renew');
		}
		if($legacy_txn_id) {
			update_post_meta($profile_id, 'featured_txn_id', $legacy_txn_id);
		}
	} else {
		update_post_meta($profile_id, 'featured', '0');
		delete_post_meta($profile_id, 'featured_expire');
		delete_post_meta($profile_id, 'featured_renew');
		delete_post_meta($profile_id, 'featured_txn_id');
	}

	delete_post_meta($profile_id, 'escortwp_featured_source');
	delete_post_meta($profile_id, 'escortwp_featured_boost_status');
	delete_post_meta($profile_id, 'escortwp_featured_boost_started_at');
	delete_post_meta($profile_id, 'escortwp_featured_boost_expires_at');
	escortwp_clear_featured_legacy_snapshot($profile_id);
}

function escortwp_get_profile_active_boosts($profile_id) {
	global $wpdb;
	$table_name = escortwp_get_featured_boost_table_name();
	$now = current_time('timestamp');

	return $wpdb->get_results($wpdb->prepare(
		"SELECT * FROM {$table_name}
		WHERE profile_id = %d
		AND payment_status IN ('approved', 'paid')
		AND boost_status = 'active'
		AND expires_at > %d
		ORDER BY expires_at DESC",
		$profile_id,
		$now
	));
}

function escortwp_schedule_featured_boost_expiration($profile_id, $expires_at) {
	$profile_id = (int)$profile_id;
	$expires_at = (int)$expires_at;
	if(!$profile_id || !$expires_at) {
		return;
	}

	wp_clear_scheduled_hook('escortwp_featured_boost_expire_event', array($profile_id));
	if($expires_at > time()) {
		wp_schedule_single_event($expires_at, 'escortwp_featured_boost_expire_event', array($profile_id));
	}
}

function escortwp_recalculate_featured_boost_state($profile_id) {
	$profile_id = (int)$profile_id;
	if(!$profile_id) {
		return;
	}

	$active_boosts = escortwp_get_profile_active_boosts($profile_id);
	if($active_boosts) {
		$latest_expires_at = 0;
		$latest_starts_at = current_time('timestamp');
		$latest_order_id = 0;

		foreach($active_boosts as $boost) {
			if((int)$boost->expires_at > $latest_expires_at) {
				$latest_expires_at = (int)$boost->expires_at;
				$latest_starts_at = (int)$boost->starts_at;
				$latest_order_id = (int)$boost->order_id;
			}
		}

		escortwp_apply_featured_boost_state($profile_id, $latest_starts_at, $latest_expires_at, $latest_order_id);
		escortwp_schedule_featured_boost_expiration($profile_id, $latest_expires_at);
		return;
	}

	if(get_post_meta($profile_id, 'escortwp_featured_source', true) == 'boost') {
		escortwp_restore_featured_state_after_boost($profile_id);
	}
}

function escortwp_expire_due_featured_boosts($profile_id = 0) {
	global $wpdb;
	$table_name = escortwp_get_featured_boost_table_name();
	$now = current_time('timestamp');

	if($profile_id) {
		$wpdb->query($wpdb->prepare(
			"UPDATE {$table_name}
			SET boost_status = 'expired', updated_at = %s
			WHERE profile_id = %d
			AND boost_status = 'active'
			AND expires_at > 0
			AND expires_at <= %d",
			current_time('mysql'),
			$profile_id,
			$now
		));
		escortwp_recalculate_featured_boost_state($profile_id);
		return;
	}

	$expired_profile_ids = $wpdb->get_col($wpdb->prepare(
		"SELECT DISTINCT profile_id FROM {$table_name}
		WHERE boost_status = 'active'
		AND expires_at > 0
		AND expires_at <= %d",
		$now
	));

	if($expired_profile_ids) {
		$wpdb->query($wpdb->prepare(
			"UPDATE {$table_name}
			SET boost_status = 'expired', updated_at = %s
			WHERE boost_status = 'active'
			AND expires_at > 0
			AND expires_at <= %d",
			current_time('mysql'),
			$now
		));

		foreach($expired_profile_ids as $expired_profile_id) {
			escortwp_recalculate_featured_boost_state((int)$expired_profile_id);
		}
	}
}
add_action('escortwp_featured_boost_expire_event', 'escortwp_expire_due_featured_boosts', 10, 1);

function escortwp_run_payment_maintenance() {
	escortwp_expire_due_featured_boosts();
}
add_action('init', 'escortwp_run_payment_maintenance', 20);

function escortwp_get_order_subscription_id($order_id) {
	if(!$order_id || !function_exists('wcs_get_subscriptions_for_order')) {
		return 0;
	}

	$subscriptions = wcs_get_subscriptions_for_order($order_id, array('order_type' => 'any'));
	if(!$subscriptions) {
		return 0;
	}

	foreach($subscriptions as $subscription) {
		if(is_object($subscription) && method_exists($subscription, 'get_id')) {
			return (int)$subscription->get_id();
		}
	}

	return 0;
}

function escortwp_get_profile_owner_email($payment_type, $target_id) {
	if($payment_type == 'vip') {
		return get_the_author_meta('user_email', $target_id);
	}

	$post = get_post($target_id);
	if(!$post) {
		return '';
	}

	return get_the_author_meta('user_email', $post->post_author);
}

function escortwp_profile_has_active_boost($profile_id) {
	$profile_id = (int)$profile_id;
	if(!$profile_id) {
		return false;
	}

	$boost_expires_at = (int)get_post_meta($profile_id, 'escortwp_featured_boost_expires_at', true);
	return get_post_meta($profile_id, 'escortwp_featured_source', true) == 'boost' && $boost_expires_at > current_time('timestamp');
}

function escortwp_get_featured_boost_state($profile_id) {
	$profile_id = (int)$profile_id;
	if(!$profile_id) {
		return array();
	}

	$status = get_post_meta($profile_id, 'escortwp_featured_boost_status', true);
	$started_at = (int)get_post_meta($profile_id, 'escortwp_featured_boost_started_at', true);
	$expires_at = (int)get_post_meta($profile_id, 'escortwp_featured_boost_expires_at', true);

	if(!$status && get_post_meta($profile_id, 'escortwp_featured_source', true) == 'boost') {
		$status = $expires_at > current_time('timestamp') ? 'active' : 'expired';
	}

	if(!$status) {
		$latest_boost = escortwp_get_latest_featured_boost_record($profile_id);
		if($latest_boost) {
			$status = $latest_boost->boost_status ? $latest_boost->boost_status : $latest_boost->payment_status;
			$started_at = $started_at ?: (int)$latest_boost->starts_at;
			$expires_at = $expires_at ?: (int)$latest_boost->expires_at;
		}
	}

	return array(
		'status' => $status,
		'started_at' => $started_at,
		'expires_at' => $expires_at,
		'is_active' => $status == 'active' && $expires_at > current_time('timestamp'),
	);
}

function escortwp_render_subscription_cancel_button($post_id, $plan_key) {
	if(!is_user_logged_in()) {
		return '';
	}

	return '<div class="sidebar-expire-notice-cancel-subscription text-center">'
		.'<form action="" method="post" class="sidebar-expire-notice-cancel-subscription-form visible">'
		.'<input type="hidden" name="action" value="escortwp_cancel_plan_subscription" />'
		.'<input type="hidden" name="target_post_id" value="'.esc_attr($post_id).'" />'
		.'<input type="hidden" name="plan_key" value="'.esc_attr($plan_key).'" />'
		.'<button class="fake-button fake-button2 redbutton rad25 center">'.__('Cancelar assinatura', 'escortwp').'</button>'
		.'</form>'
		.'</div>';
}

function escortwp_render_admin_plan_overview_metabox($post) {
	if(!$post || empty($post->ID)) {
		return;
	}

	$post_id = (int)$post->ID;
	$state = escortwp_get_post_plan_state($post_id);
	$boost_state = escortwp_get_featured_boost_state($post_id);

	echo '<div class="escortwp-admin-plan-overview">';

	if($state && !empty($state['plan_key'])) {
		$type_label = __('Pagamento único', 'escortwp');
		if($state['plan_type'] == 'subscription') {
			$type_label = __('Assinatura recorrente', 'escortwp');
		} elseif($state['plan_type'] == 'free') {
			$type_label = __('Gratuito', 'escortwp');
		}

		echo '<p><strong>'.esc_html__('Plano atual', 'escortwp').':</strong> '.esc_html(escortwp_get_plan_display_label($state['plan_key'], $state['plan_type'])).'</p>';
		echo '<p><strong>'.esc_html__('Tipo', 'escortwp').':</strong> '.esc_html($type_label).'</p>';
		echo '<p><strong>'.esc_html__('Status do plano', 'escortwp').':</strong> '.esc_html(escortwp_get_plan_status_display_label($state['plan_status'])).'</p>';

		if(!empty($state['started_at'])) {
			echo '<p><strong>'.esc_html__('Início', 'escortwp').':</strong> '.esc_html(date_i18n('d/m/Y H:i', $state['started_at'])).'</p>';
		}
		if(!empty($state['expires_at'])) {
			echo '<p><strong>'.esc_html__('Válido até', 'escortwp').':</strong> '.esc_html(date_i18n('d/m/Y H:i', $state['expires_at'])).'</p>';
		}
		if(!empty($state['order_id'])) {
			echo '<p><strong>'.esc_html__('Pedido', 'escortwp').':</strong> #'.esc_html($state['order_id']).'</p>';
		}
		if(!empty($state['subscription_id'])) {
			echo '<p><strong>'.esc_html__('Assinatura', 'escortwp').':</strong> #'.esc_html($state['subscription_id']).'</p>';
		}
		if(!empty($state['subscription_status'])) {
			echo '<p><strong>'.esc_html__('Status da assinatura', 'escortwp').':</strong> '.esc_html($state['subscription_status']).'</p>';
		}
	} else {
		echo '<p>'.esc_html__('Nenhum estado de plano salvo para este anúncio ainda.', 'escortwp').'</p>';
	}

	if($boost_state && !empty($boost_state['status'])) {
		echo '<hr />';
		echo '<p><strong>'.esc_html__('Impulsionamento de 7 dias', 'escortwp').':</strong> '.esc_html(escortwp_get_boost_status_display_label($boost_state['status'])).'</p>';
		if(!empty($boost_state['started_at'])) {
			echo '<p><strong>'.esc_html__('Início do destaque', 'escortwp').':</strong> '.esc_html(date_i18n('d/m/Y H:i', $boost_state['started_at'])).'</p>';
		}
		if(!empty($boost_state['expires_at'])) {
			echo '<p><strong>'.esc_html__('Fim do destaque', 'escortwp').':</strong> '.esc_html(date_i18n('d/m/Y H:i', $boost_state['expires_at'])).'</p>';
		}
	}

	echo '</div>';
}

function escortwp_register_admin_plan_overview_metabox() {
	global $taxonomy_profile_url, $taxonomy_agency_url;

	foreach(array($taxonomy_profile_url, $taxonomy_agency_url) as $post_type) {
		if($post_type) {
			add_meta_box(
				'escortwp-plan-overview',
				__('Plano e impulsionamento', 'escortwp'),
				'escortwp_render_admin_plan_overview_metabox',
				$post_type,
				'side',
				'high'
			);
		}
	}
}
add_action('add_meta_boxes', 'escortwp_register_admin_plan_overview_metabox');

function escortwp_render_post_plan_status_notice_legacy($post_id) {
	$state = escortwp_get_post_plan_state($post_id);
	if(!$state || empty($state['plan_key'])) {
		return '';
	}

	$label = escortwp_get_plan_display_label($state['plan_key'], $state['plan_type']);
	$status_text = '';
	$action_markup = '';

	switch($state['plan_status']) {
		case 'pending-payment':
			$status_text = __('Pagamento pendente para ativar o anúncio.', 'escortwp');
			if(payment_plans($state['plan_key'], 'price')) {
				$action_markup .= '<div class="clear15"></div><div class="text-center">'.generate_payment_buttons($state['plan_key'], $post_id, __('Pagar agora', 'escortwp')).'</div>';
				$action_markup .= '<div class="clear5"></div><small>'.format_price($state['plan_key']).'</small>';
			}
			break;
		case 'pending-approval':
			$status_text = __('Cadastro recebido e aguardando liberação.', 'escortwp');
			break;
		case 'cancelled':
			if($state['expires_at']) {
				$status_text = sprintf(esc_html__('Assinatura cancelada. O anúncio segue ativo até %s.', 'escortwp'), date_i18n('d/m/Y H:i', $state['expires_at']));
			} else {
				$status_text = __('Assinatura cancelada.', 'escortwp');
			}
			break;
		case 'expired':
			$status_text = __('Plano vencido.', 'escortwp');
			if(payment_plans($state['plan_key'], 'price')) {
				$action_markup .= '<div class="clear15"></div><div class="text-center">'.generate_payment_buttons($state['plan_key'], $post_id, __('Renovar plano', 'escortwp')).'</div>';
				$action_markup .= '<div class="clear5"></div><small>'.format_price($state['plan_key']).'</small>';
			}
			break;
		default:
			if($state['plan_type'] == 'free') {
				$status_text = __('Plano grátis ativo.', 'escortwp');
			} elseif($state['plan_type'] == 'subscription') {
				$status_text = __('Assinatura mensal ativa.', 'escortwp');
				if($state['expires_at']) {
					$status_text .= ' '.sprintf(esc_html__('Próximo ciclo / fim do período atual: %s.', 'escortwp'), date_i18n('d/m/Y H:i', $state['expires_at']));
				}
				$action_markup .= '<div class="clear15"></div>'.escortwp_render_subscription_cancel_button($post_id, $state['plan_key']);
			} elseif($state['expires_at']) {
				$status_text = sprintf(esc_html__('Plano ativo até %s.', 'escortwp'), date_i18n('d/m/Y H:i', $state['expires_at']));
			} else {
				$status_text = __('Plano ativo.', 'escortwp');
			}
			break;
	}

	return '<div class="sidebar-expire-notice greendegrade center escortwp-plan-status">'
		.'<small>'.__('Plano atual', 'escortwp').':</small><b>'.esc_html($label).'</b>'
		.'<div class="clear5"></div><div class="expiration-date">'.wp_kses_post($status_text).'</div>'
		.$action_markup
		.'</div>';
}

function escortwp_render_featured_boost_offer_legacy($profile_id) {
	$profile_id = (int)$profile_id;
	if(!$profile_id || !payment_plans('featured_boost', 'price')) {
		return '';
	}

	$boost_state = escortwp_get_featured_boost_state($profile_id);
	if($boost_state && ($boost_state['is_active'] || $boost_state['status'] == 'pending')) {
		return '';
	}

	$markup = '<div class="pinkbutton buyfeatured">'.__('Impulsionar por 1 semana','escortwp').'<span class="show-price rad3 greendegrade">'.format_price('featured_boost','small').'</span></div>';
	$markup .= '<div class="buyfeatured_details blueishdegrade">';
	ob_start();
	closebtn('2');
	$markup .= ob_get_clean();
	$markup .= __('Pagamento único de R$ 9,99 para colocar o anúncio em destaque por 7 dias, sem cobrança recorrente.','escortwp');
	$markup .= '<div class="clear10"></div>';
	$markup .= generate_payment_buttons('featured_boost', $profile_id, __('Impulsionar por 1 semana','escortwp'));
	$markup .= '<div class="clear5"></div><small>'.format_price('featured_boost').'</small>';
	$markup .= '</div><div class="clear"></div>';

	return $markup;
}

function escortwp_render_featured_boost_status_notice_legacy($profile_id) {
	$profile_id = (int)$profile_id;
	if(!$profile_id) {
		return '';
	}

	$boost_state = escortwp_get_featured_boost_state($profile_id);
	if(!$boost_state || (!$boost_state['status'] && !payment_plans('featured_boost', 'price'))) {
		return '';
	}

	if($boost_state['is_active']) {
		$remaining = human_time_diff(current_time('timestamp'), $boost_state['expires_at']);
		$markup = '<div class="sidebar-expire-notice bluedegrade center escortwp-boost-status">';
		$markup .= '<small>'.__('Destaque ativo até', 'escortwp').':</small><b>'.date_i18n('d/m/Y H:i', $boost_state['expires_at']).'</b>';
		$markup .= '<small>'.$remaining.' '.__('restantes','escortwp').'</small>';
		$markup .= '</div>';
		return $markup;
	}

	if($boost_state['status'] == 'pending') {
		return '<div class="sidebar-expire-notice bluedegrade center escortwp-boost-status"><small>'.__('Impulsionamento aguardando confirmação de pagamento.','escortwp').'</small></div>';
	}

	return '';
}

function escortwp_render_post_plan_status_notice($post_id) {
	if(function_exists('escortwp_render_post_plan_status_notice_v2')) {
		return escortwp_render_post_plan_status_notice_v2($post_id);
	}

	$state = escortwp_get_post_plan_state($post_id);
	if(!$state || empty($state['plan_key'])) {
		return '';
	}

	$label = escortwp_get_plan_display_label($state['plan_key'], $state['plan_type']);
	$status_text = '';
	$action_markup = '';

	switch($state['plan_status']) {
		case 'pending-payment':
			$status_text = __('Pagamento pendente para ativar o anúncio.', 'escortwp');
			if(payment_plans($state['plan_key'], 'price')) {
				$action_markup .= '<div class="clear15"></div><div class="text-center">'.generate_payment_buttons($state['plan_key'], $post_id, __('Pagar agora', 'escortwp')).'</div>';
				$action_markup .= '<div class="clear5"></div><small>'.format_price($state['plan_key']).'</small>';
			}
			break;
		case 'pending-approval':
			$status_text = __('Cadastro recebido e aguardando liberação.', 'escortwp');
			break;
		case 'payment-failed':
			$status_text = __('O pagamento falhou e o plano não foi ativado.', 'escortwp');
			if(payment_plans($state['plan_key'], 'price')) {
				$action_markup .= '<div class="clear15"></div><div class="text-center">'.generate_payment_buttons($state['plan_key'], $post_id, __('Tentar novamente', 'escortwp')).'</div>';
				$action_markup .= '<div class="clear5"></div><small>'.format_price($state['plan_key']).'</small>';
			}
			break;
		case 'payment-refunded':
			$status_text = __('O pagamento foi reembolsado e o plano foi desativado.', 'escortwp');
			break;
		case 'cancelled':
			if($state['expires_at']) {
				$status_text = sprintf(esc_html__('Assinatura cancelada. O anúncio segue ativo até %s.', 'escortwp'), date_i18n('d/m/Y H:i', $state['expires_at']));
			} else {
				$status_text = __('Assinatura cancelada.', 'escortwp');
			}
			break;
		case 'expired':
			$status_text = __('Plano vencido.', 'escortwp');
			if(payment_plans($state['plan_key'], 'price')) {
				$action_markup .= '<div class="clear15"></div><div class="text-center">'.generate_payment_buttons($state['plan_key'], $post_id, __('Renovar plano', 'escortwp')).'</div>';
				$action_markup .= '<div class="clear5"></div><small>'.format_price($state['plan_key']).'</small>';
			}
			break;
		default:
			if($state['plan_type'] == 'free') {
				$status_text = __('Plano grátis ativo.', 'escortwp');
			} elseif($state['plan_type'] == 'subscription') {
				$status_text = __('Assinatura mensal ativa.', 'escortwp');
				if($state['expires_at']) {
					$status_text .= ' '.sprintf(esc_html__('Próximo ciclo / fim do período atual: %s.', 'escortwp'), date_i18n('d/m/Y H:i', $state['expires_at']));
				}
				$action_markup .= '<div class="clear15"></div>'.escortwp_render_subscription_cancel_button($post_id, $state['plan_key']);
			} elseif($state['expires_at']) {
				$status_text = sprintf(esc_html__('Plano ativo até %s.', 'escortwp'), date_i18n('d/m/Y H:i', $state['expires_at']));
			} else {
				$status_text = __('Plano ativo.', 'escortwp');
			}
			break;
	}

	return '<div class="sidebar-expire-notice greendegrade center escortwp-plan-status">'
		.'<small>'.__('Plano atual', 'escortwp').':</small><b>'.esc_html($label).'</b>'
		.'<div class="clear5"></div><div class="expiration-date">'.wp_kses_post($status_text).'</div>'
		.$action_markup
		.'</div>';
}

function escortwp_render_featured_boost_offer($profile_id) {
	$profile_id = (int)$profile_id;
	if(!$profile_id || !payment_plans('featured_boost', 'price')) {
		return '';
	}

	$boost_state = escortwp_get_featured_boost_state($profile_id);
	if($boost_state && ($boost_state['is_active'] || $boost_state['status'] == 'pending')) {
		return '';
	}

	$markup = '<div class="pinkbutton buyfeatured escortwp-buyfeatured-boost">'.__('Impulsionar por 1 semana','escortwp').'<span class="show-price rad3 greendegrade">'.format_price('featured_boost','small').'</span></div>';
	$markup .= '<div class="buyfeatured_details blueishdegrade escortwp-buyfeatured-boost-details">';
	$markup .= '<a class="closebtn closebtn2">x</a>';
	$markup .= __('Pagamento único de R$ 9,99 para colocar o anúncio em destaque por 7 dias, sem cobrança recorrente.', 'escortwp');
	$markup .= '<div class="clear10"></div>';
	$markup .= generate_payment_buttons('featured_boost', $profile_id, __('Impulsionar por 1 semana','escortwp'));
	$markup .= '<div class="clear5"></div><small>'.format_price('featured_boost').'</small>';
	$markup .= '</div><div class="clear"></div>';

	return $markup;
}

function escortwp_render_featured_boost_status_notice($profile_id) {
	if(function_exists('escortwp_render_featured_boost_status_notice_v2')) {
		return escortwp_render_featured_boost_status_notice_v2($profile_id);
	}

	$profile_id = (int)$profile_id;
	if(!$profile_id) {
		return '';
	}

	$boost_state = escortwp_get_featured_boost_state($profile_id);
	if(!$boost_state || (!$boost_state['status'] && !payment_plans('featured_boost', 'price'))) {
		return '';
	}

	if($boost_state['is_active']) {
		$remaining = human_time_diff(current_time('timestamp'), $boost_state['expires_at']);
		$markup = '<div class="sidebar-expire-notice bluedegrade center escortwp-boost-status">';
		$markup .= '<small>'.__('Destaque ativo até', 'escortwp').':</small><b>'.date_i18n('d/m/Y H:i', $boost_state['expires_at']).'</b>';
		$markup .= '<small>'.$remaining.' '.__('restantes','escortwp').'</small>';
		$markup .= '</div>';
		return $markup;
	}

	if($boost_state['status'] == 'pending') {
		return '<div class="sidebar-expire-notice bluedegrade center escortwp-boost-status"><small>'.__('Impulsionamento aguardando confirmação do pagamento.', 'escortwp').'</small></div>';
	}

	if(in_array($boost_state['status'], array('failed', 'cancelled', 'refunded'), true)) {
		$messages = array(
			'failed' => __('O pagamento do impulsionamento falhou.', 'escortwp'),
			'cancelled' => __('O impulsionamento foi cancelado.', 'escortwp'),
			'refunded' => __('O impulsionamento foi reembolsado.', 'escortwp'),
		);
		return '<div class="sidebar-expire-notice bluedegrade center escortwp-boost-status"><small>'.$messages[$boost_state['status']].'</small></div>';
	}

	if($boost_state['status'] == 'expired' && $boost_state['expires_at']) {
		return '<div class="sidebar-expire-notice bluedegrade center escortwp-boost-status"><small>'.sprintf(esc_html__('O destaque de 7 dias terminou em %s.', 'escortwp'), date_i18n('d/m/Y H:i', $boost_state['expires_at'])).'</small></div>';
	}

	return '';
}

function escortwp_render_profile_plan_management_panel($profile_id, $args = array()) {
	if(function_exists('escortwp_render_profile_plan_management_panel_v2')) {
		return escortwp_render_profile_plan_management_panel_v2($profile_id, $args);
	}

	$profile_id = (int)$profile_id;
	if(!$profile_id || !get_post($profile_id)) {
		return '';
	}

	$args = wp_parse_args($args, array(
		'title' => __('Planos do anuncio', 'escortwp'),
		'description' => __('Gerencie aqui o plano atual do anuncio, o plano mensal de 30 dias e o impulsionamento avulso de 7 dias.', 'escortwp'),
		'show_free_status' => true,
		'panel_id' => 'planos-anuncio',
	));

	$plan_state = escortwp_get_post_plan_state($profile_id);
	$boost_state = escortwp_get_featured_boost_state($profile_id);
	$plan_notice = escortwp_render_post_plan_status_notice($profile_id);
	$boost_notice = escortwp_render_featured_boost_status_notice($profile_id);
	$monthly_enabled = (string)payment_plans('premium', 'price') !== '';
	$boost_enabled = (string)payment_plans('featured_boost', 'price') !== '';
	$has_active_monthly_plan = !empty($plan_state['plan_key']) && $plan_state['plan_key'] === 'premium' && !empty($plan_state['plan_status']) && in_array($plan_state['plan_status'], array('active', 'pending-payment'), true);
	if(!empty($plan_state['plan_key']) && $plan_state['plan_key'] === 'premium' && !empty($plan_state['plan_status']) && $plan_state['plan_status'] === 'expired') {
		$monthly_button_label = __('Reativar plano mensal', 'escortwp');
	} elseif($has_active_monthly_plan) {
		$monthly_button_label = __('Renovar agora por mais 30 dias', 'escortwp');
	} else {
		$monthly_button_label = __('Ativar plano mensal', 'escortwp');
	}
	$monthly_checkout_markup = $monthly_enabled ? generate_payment_buttons('premium', $profile_id, $monthly_button_label) : '';
	$boost_checkout_markup = $boost_enabled ? generate_payment_buttons('featured_boost', $profile_id, __('Impulsionar por 1 semana', 'escortwp')) : '';
	$show_boost_purchase_card = $boost_enabled && (!$boost_state || empty($boost_state['is_active'])) && (!isset($boost_state['status']) || $boost_state['status'] !== 'pending');

	ob_start();
	?>
	<div class="escortwp-plan-management-panel profile-plan-panel" id="<?php echo esc_attr($args['panel_id']); ?>">
		<div class="profile-plan-panel-header">
			<h4><?php echo esc_html($args['title']); ?></h4>
			<p><?php echo esc_html($args['description']); ?></p>
		</div>
		<div class="profile-plan-grid">
			<div class="profile-plan-card profile-plan-card-status">
				<span class="profile-plan-card-label"><?php _e('Situacao atual', 'escortwp'); ?></span>
				<?php if($plan_notice) { ?>
					<?php echo $plan_notice; ?>
				<?php } elseif(!empty($args['show_free_status'])) { ?>
					<div class="sidebar-expire-notice greendegrade center escortwp-plan-status">
						<small><?php _e('Plano atual', 'escortwp'); ?>:</small>
						<b><?php _e('Plano grátis', 'escortwp'); ?></b>
						<div class="clear5"></div>
						<div class="expiration-date"><?php _e('Plano grátis ativo. O anúncio pode ser editado normalmente e você pode contratar um plano adicional quando quiser.', 'escortwp'); ?></div>
					</div>
				<?php } ?>
			</div>

			<?php if($monthly_enabled) { ?>
				<div class="profile-plan-card profile-plan-card-offer">
					<span class="profile-plan-card-label"><?php _e('Plano mensal', 'escortwp'); ?></span>
					<h5><?php _e('Plano mensal de 30 dias', 'escortwp'); ?></h5>
					<p><?php _e('Ative o plano mensal para manter o anuncio premium por 30 dias. Quando o periodo terminar, basta pagar novamente para continuar com os beneficios.', 'escortwp'); ?></p>
					<div class="profile-plan-card-price"><?php echo wp_kses_post(format_price('premium', 'small')); ?></div>
					<div class="profile-plan-card-actions">
						<?php
						if($monthly_checkout_markup) {
							echo $monthly_checkout_markup;
						} else {
							echo escortwp_render_payment_action_requirements('premium');
						}
						?>
					</div>
					<div class="profile-plan-card-helper"><?php echo $has_active_monthly_plan ? esc_html__('Se voce pagar de novo antes do vencimento, o sistema soma mais 30 dias ao periodo atual.', 'escortwp') : esc_html__('Este plano e manual, sem assinatura recorrente. O impulsionamento semanal continua separado e nao interfere aqui.', 'escortwp'); ?></div>
				</div>
			<?php } ?>

			<?php if($boost_enabled) { ?>
				<div class="profile-plan-card profile-plan-card-boost">
					<span class="profile-plan-card-label"><?php _e('Pagamento avulso', 'escortwp'); ?></span>
					<?php if($boost_notice) { ?>
						<?php echo $boost_notice; ?>
					<?php } else { ?>
						<div class="profile-plan-card-empty">
							<strong><?php _e('Sem impulsionamento ativo', 'escortwp'); ?></strong>
							<span><?php _e('O destaque semanal aparece aqui assim que o pagamento for confirmado.', 'escortwp'); ?></span>
						</div>
					<?php } ?>
					<?php if($show_boost_purchase_card) { ?>
						<div class="profile-plan-card-divider"></div>
						<h5><?php _e('Impulsionar por 1 semana', 'escortwp'); ?></h5>
						<p><?php _e('Pagamento unico para destacar o anuncio por 7 dias. Nao e assinatura e nao gera cobranca recorrente.', 'escortwp'); ?></p>
						<div class="profile-plan-card-price"><?php echo format_price('featured_boost', 'small'); ?></div>
						<div class="profile-plan-card-actions">
							<?php
							if($boost_checkout_markup) {
								echo $boost_checkout_markup;
							} else {
								echo escortwp_render_payment_action_requirements('featured_boost');
							}
							?>
						</div>
					<?php } ?>
					<div class="profile-plan-card-helper"><?php _e('Este destaque e avulso. Ele ativa so depois da confirmacao do pagamento e expira automaticamente apos 7 dias.', 'escortwp'); ?></div>
				</div>
			<?php } ?>
		</div>
	</div>
	<?php
	return ob_get_clean();
}

function escortwp_get_plan_display_label_v2($plan_key, $plan_type = '') {
	if($plan_type == 'free') {
		return __('Plano grátis', 'escortwp');
	}

	if($plan_type == 'subscription') {
		return __('Plano mensal recorrente', 'escortwp');
	}

	switch($plan_key) {
		case 'featured_boost':
			return __('Impulsionamento de 7 dias', 'escortwp');
		case 'premium':
			return __('Plano mensal', 'escortwp');
		case 'featured':
			return __('Destaque do anuncio', 'escortwp');
		case 'agreg':
			return __('Plano da agencia', 'escortwp');
		case 'agescortreg':
			return __('Plano da acompanhante da agencia', 'escortwp');
		case 'indescreg':
			return __('Plano da acompanhante', 'escortwp');
		case 'vip':
			return __('Plano VIP', 'escortwp');
		default:
			return __('Plano ativo', 'escortwp');
	}
}

function escortwp_render_post_plan_status_notice_v2($post_id) {
	$state = escortwp_get_post_plan_state($post_id);
	if(!$state || empty($state['plan_key'])) {
		return '';
	}

	$label = escortwp_get_plan_display_label_v2($state['plan_key'], $state['plan_type']);
	$status_text = '';
	$action_markup = '';

	switch($state['plan_status']) {
		case 'pending-payment':
			$status_text = __('O pagamento foi iniciado e está aguardando confirmação. Assim que o Mercado Pago aprovar, o plano será ativado automaticamente.', 'escortwp');
			if(payment_plans($state['plan_key'], 'price')) {
				$action_markup .= '<div class="clear15"></div><div class="text-center">'.generate_payment_buttons($state['plan_key'], $post_id, __('Continuar pagamento', 'escortwp')).'</div>';
				$action_markup .= '<div class="clear5"></div><small>'.format_price($state['plan_key']).'</small>';
			}
			break;
		case 'pending-approval':
			$status_text = __('Cadastro recebido e aguardando liberacao.', 'escortwp');
			break;
		case 'payment-failed':
			$status_text = __('O pagamento falhou e o plano nao foi ativado.', 'escortwp');
			if(payment_plans($state['plan_key'], 'price')) {
				$action_markup .= '<div class="clear15"></div><div class="text-center">'.generate_payment_buttons($state['plan_key'], $post_id, __('Tentar novamente', 'escortwp')).'</div>';
				$action_markup .= '<div class="clear5"></div><small>'.format_price($state['plan_key']).'</small>';
			}
			break;
		case 'payment-refunded':
			$status_text = __('O pagamento foi reembolsado e o plano foi desativado.', 'escortwp');
			break;
		case 'cancelled':
			if(!empty($state['expires_at'])) {
				$status_text = sprintf(esc_html__('Assinatura cancelada. O anuncio segue ativo ate %s.', 'escortwp'), date_i18n('d/m/Y H:i', $state['expires_at']));
			} else {
				$status_text = __('Assinatura cancelada.', 'escortwp');
			}
			break;
		case 'expired':
			$status_text = __('Plano vencido.', 'escortwp');
			if(payment_plans($state['plan_key'], 'price')) {
				$action_markup .= '<div class="clear15"></div><div class="text-center">'.generate_payment_buttons($state['plan_key'], $post_id, __('Reativar plano', 'escortwp')).'</div>';
				$action_markup .= '<div class="clear5"></div><small>'.format_price($state['plan_key']).'</small>';
			}
			break;
		default:
			if($state['plan_type'] == 'free') {
				$status_text = __('Plano grátis ativo. O anúncio pode ser editado normalmente e novos recursos podem ser contratados quando você quiser.', 'escortwp');
			} elseif($state['plan_type'] == 'subscription') {
				$status_text = __('Assinatura mensal ativa.', 'escortwp');
				if(!empty($state['expires_at'])) {
					$status_text .= ' '.sprintf(esc_html__('Proximo ciclo / fim do periodo atual: %s.', 'escortwp'), date_i18n('d/m/Y H:i', $state['expires_at']));
				}
				$action_markup .= '<div class="clear15"></div>'.escortwp_render_subscription_cancel_button($post_id, $state['plan_key']);
			} elseif(!empty($state['expires_at'])) {
				$status_text = sprintf(esc_html__('Plano ativo ate %s.', 'escortwp'), date_i18n('d/m/Y H:i', $state['expires_at']));
			} else {
				$status_text = __('Plano ativo.', 'escortwp');
			}
			break;
	}

	return '<div class="sidebar-expire-notice greendegrade center escortwp-plan-status">'
		.'<small>'.__('Plano atual', 'escortwp').':</small><b>'.esc_html($label).'</b>'
		.'<div class="clear5"></div><div class="expiration-date">'.wp_kses_post($status_text).'</div>'
		.$action_markup
		.'</div>';
}

function escortwp_render_featured_boost_status_notice_v2($profile_id) {
	$profile_id = (int)$profile_id;
	if(!$profile_id) {
		return '';
	}

	$boost_state = escortwp_get_featured_boost_state($profile_id);
	if(!$boost_state || (!$boost_state['status'] && !payment_plans('featured_boost', 'price'))) {
		return '';
	}

	if(!empty($boost_state['is_active'])) {
		$remaining = human_time_diff(current_time('timestamp'), $boost_state['expires_at']);
		$markup = '<div class="sidebar-expire-notice bluedegrade center escortwp-boost-status">';
		$markup .= '<small>'.__('Destaque ativo ate', 'escortwp').':</small><b>'.date_i18n('d/m/Y H:i', $boost_state['expires_at']).'</b>';
		$markup .= '<small>'.$remaining.' '.__('restantes','escortwp').'</small>';
		$markup .= '</div>';
		return $markup;
	}

	if($boost_state['status'] == 'pending') {
		$markup = '<div class="sidebar-expire-notice bluedegrade center escortwp-boost-status"><small>'.__('Impulsionamento aguardando confirmação do pagamento.', 'escortwp').'</small>';
		if(payment_plans('featured_boost', 'price')) {
			$markup .= '<div class="clear15"></div><div class="text-center">'.generate_payment_buttons('featured_boost', $profile_id, __('Continuar pagamento', 'escortwp')).'</div>';
			$markup .= '<div class="clear5"></div><small>'.format_price('featured_boost').'</small>';
		}
		$markup .= '</div>';
		return $markup;
	}

	if(in_array($boost_state['status'], array('failed', 'cancelled', 'refunded'), true)) {
		$messages = array(
			'failed' => __('O pagamento do impulsionamento falhou.', 'escortwp'),
			'cancelled' => __('O impulsionamento foi cancelado.', 'escortwp'),
			'refunded' => __('O impulsionamento foi reembolsado.', 'escortwp'),
		);
		return '<div class="sidebar-expire-notice bluedegrade center escortwp-boost-status"><small>'.$messages[$boost_state['status']].'</small></div>';
	}

	if($boost_state['status'] == 'expired' && !empty($boost_state['expires_at'])) {
		return '<div class="sidebar-expire-notice bluedegrade center escortwp-boost-status"><small>'.sprintf(esc_html__('O destaque de 7 dias terminou em %s.', 'escortwp'), date_i18n('d/m/Y H:i', $boost_state['expires_at'])).'</small></div>';
	}

	return '';
}

function escortwp_render_profile_plan_management_panel_v2($profile_id, $args = array()) {
	$profile_id = (int)$profile_id;
	if(!$profile_id || !get_post($profile_id)) {
		return '';
	}

	$args = wp_parse_args($args, array(
		'title' => __('Planos do anuncio', 'escortwp'),
		'description' => __('Acompanhe em um único lugar o plano grátis, o plano mensal de 30 dias e o impulsionamento avulso de 7 dias.', 'escortwp'),
		'show_free_status' => true,
		'panel_id' => 'planos-anuncio',
	));

	$plan_state = escortwp_get_post_plan_state($profile_id);
	$boost_state = escortwp_get_featured_boost_state($profile_id);
	$plan_notice = escortwp_render_post_plan_status_notice_v2($profile_id);
	$boost_notice = escortwp_render_featured_boost_status_notice_v2($profile_id);
	$monthly_enabled = (string)payment_plans('premium', 'price') !== '';
	$boost_enabled = (string)payment_plans('featured_boost', 'price') !== '';
	$has_active_monthly_plan = !empty($plan_state['plan_key']) && $plan_state['plan_key'] === 'premium' && !empty($plan_state['plan_status']) && in_array($plan_state['plan_status'], array('active', 'pending-payment'), true);
	if(!empty($plan_state['plan_key']) && $plan_state['plan_key'] === 'premium' && !empty($plan_state['plan_status']) && $plan_state['plan_status'] === 'expired') {
		$monthly_button_label = __('Reativar plano mensal', 'escortwp');
	} elseif($has_active_monthly_plan) {
		$monthly_button_label = __('Renovar agora por mais 30 dias', 'escortwp');
	} else {
		$monthly_button_label = __('Ativar plano mensal', 'escortwp');
	}
	$monthly_checkout_markup = $monthly_enabled ? generate_payment_buttons('premium', $profile_id, $monthly_button_label) : '';
	$boost_checkout_markup = $boost_enabled ? generate_payment_buttons('featured_boost', $profile_id, __('Impulsionar por 1 semana', 'escortwp')) : '';
	$show_boost_purchase_card = $boost_enabled && (!$boost_state || empty($boost_state['is_active'])) && (!isset($boost_state['status']) || $boost_state['status'] !== 'pending');

	ob_start();
	?>
	<div class="escortwp-plan-management-panel profile-plan-panel" id="<?php echo esc_attr($args['panel_id']); ?>">
		<div class="profile-plan-panel-header">
			<h4><?php echo esc_html($args['title']); ?></h4>
			<p><?php echo esc_html($args['description']); ?></p>
		</div>
		<div class="profile-plan-grid">
			<div class="profile-plan-card profile-plan-card-status">
				<span class="profile-plan-card-label"><?php _e('Situacao atual', 'escortwp'); ?></span>
				<?php if($plan_notice) { ?>
					<?php echo $plan_notice; ?>
				<?php } elseif(!empty($args['show_free_status'])) { ?>
					<div class="sidebar-expire-notice greendegrade center escortwp-plan-status">
						<small><?php _e('Plano atual', 'escortwp'); ?>:</small>
						<b><?php _e('Plano grátis', 'escortwp'); ?></b>
						<div class="clear5"></div>
						<div class="expiration-date"><?php _e('Plano grátis ativo. O anúncio pode ser editado normalmente e novos recursos podem ser contratados quando você quiser.', 'escortwp'); ?></div>
					</div>
				<?php } ?>
			</div>

			<?php if($monthly_enabled) { ?>
				<div class="profile-plan-card profile-plan-card-offer">
					<span class="profile-plan-card-label"><?php _e('Plano mensal', 'escortwp'); ?></span>
					<h5><?php _e('Plano mensal de 30 dias', 'escortwp'); ?></h5>
					<p><?php _e('Ative o plano mensal para manter o anuncio premium por 30 dias. Quando o periodo terminar, basta pagar novamente para continuar com os beneficios.', 'escortwp'); ?></p>
					<div class="profile-plan-card-price"><?php echo format_price('premium', 'small'); ?></div>
					<div class="profile-plan-card-actions">
						<?php
						if($monthly_checkout_markup) {
							echo $monthly_checkout_markup;
						} else {
							echo escortwp_render_payment_action_requirements('premium');
						}
						?>
					</div>
					<div class="profile-plan-card-helper"><?php echo $has_active_monthly_plan ? esc_html__('Se voce pagar de novo antes do vencimento, o sistema soma mais 30 dias ao periodo atual.', 'escortwp') : esc_html__('Este plano e manual, sem assinatura recorrente. O impulsionamento semanal continua separado e nao interfere aqui.', 'escortwp'); ?></div>
				</div>
			<?php } ?>

			<?php if($boost_enabled) { ?>
				<div class="profile-plan-card profile-plan-card-boost">
					<span class="profile-plan-card-label"><?php _e('Pagamento avulso', 'escortwp'); ?></span>
					<?php if($boost_notice) { ?>
						<?php echo $boost_notice; ?>
					<?php } else { ?>
						<div class="profile-plan-card-empty">
							<strong><?php _e('Sem impulsionamento ativo', 'escortwp'); ?></strong>
							<span><?php _e('O destaque semanal aparece aqui assim que o pagamento for confirmado.', 'escortwp'); ?></span>
						</div>
					<?php } ?>
					<?php if($show_boost_purchase_card) { ?>
						<div class="profile-plan-card-divider"></div>
						<h5><?php _e('Impulsionar por 1 semana', 'escortwp'); ?></h5>
						<p><?php _e('Pagamento unico para destacar o anuncio por 7 dias. Nao e assinatura e nao gera cobranca recorrente.', 'escortwp'); ?></p>
						<div class="profile-plan-card-price"><?php echo wp_kses_post(format_price('featured_boost', 'small')); ?></div>
						<div class="profile-plan-card-actions">
							<?php
							if($boost_checkout_markup) {
								echo $boost_checkout_markup;
							} else {
								echo escortwp_render_payment_action_requirements('featured_boost');
							}
							?>
						</div>
					<?php } ?>
					<div class="profile-plan-card-helper"><?php _e('Este destaque e avulso. Ele ativa so depois da confirmacao do pagamento e expira automaticamente apos 7 dias.', 'escortwp'); ?></div>
				</div>
			<?php } ?>
		</div>
	</div>
	<?php
	return ob_get_clean();
}


// add_filter('woocommerce_add_to_cart_redirect', 'direct_checkout_redirect');
// function direct_checkout_redirect() {
// 	global $woocommerce;
// 	$checkout_url = wc_get_checkout_url();
// 	return $checkout_url;
// }

/**
 * WooCommerce Remove Address Fields from checkout based on presence of virtual products in cart
 * @link https://www.skyverge.com/blog/checking-woocommerce-cart-contains-product-category/
 * @link https://docs.woothemes.com/document/tutorial-customising-checkout-fields-using-actions-and-filters/
 * @link https://businessbloomer.com/woocommerce-hide-checkout-billing-fields-if-virtual-product-cart/
 */
function woo_remove_address_from_checkout( $fields ) {
	// set flag to be true until we find a product that isn't virtual
	$virtual_products = true;
	$cart_items = (WC()->cart && is_object(WC()->cart)) ? WC()->cart->get_cart() : array();

	// loop through our cart
	foreach($cart_items as $cart_item_key => $cart_item) {
		// Check if there are non-virtual products and if so make it false
		if (!$cart_item['data']->is_virtual()) $virtual_products = false; 
	}

	// only unset fields if virtual_products is true so we have no physical products in the cart
	if($virtual_products === true) {
		unset($fields['billing']['billing_company']);
		unset($fields['billing']['billing_address_2']);
		// Removes Additional Info title and Order Notes
		add_filter('woocommerce_enable_order_notes_field', '__return_false',9999);
	}

	return $fields;
}
if(get_option('show_address_checkout') == "2") {
	add_filter('woocommerce_checkout_fields', 'woo_remove_address_from_checkout');
}

// Remove coupon field from checkout
function remove_checkout_coupon_form(){
    remove_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_coupon_form', 10 );
}
if(get_option('show_coupon_checkout') == "2") {
	add_action( 'woocommerce_before_checkout_form', 'remove_checkout_coupon_form', 9 );
}


$payment_duration_a = array(
	/*
	[0] Name (translatable)
	[1] Number of days
	[2] Name (to be used in php functions)
	*/
	"1" => array(__('1 day','escortwp'), "1", '1 day'),
	"2" => array(__('1 week','escortwp'), "7", '1 week'),
	"3" => array(__('2 weeks','escortwp'), "14", '2 weeks'),
	"4" => array(__('3 weeks','escortwp'), "21", '3 weeks'),
	"5" => array(__('1 month','escortwp'), "30", '1 month'),
	"6" => array(__('2 months','escortwp'), "60", '2 months'),
	"7" => array(__('3 months','escortwp'), "90", '3 months'),
	"8" => array(__('4 months','escortwp'), "120", '4 months'),
	"9" => array(__('5 months','escortwp'), "150", '5 months'),
	"10" => array(__('6 months','escortwp'), "180", '6 months'),
	"11" => array(__('7 months','escortwp'), "210", '7 months'),
	"12" => array(__('8 months','escortwp'), "240", '8 months'),
	"13" => array(__('9 months','escortwp'), "270", '9 months'),
	"14" => array(__('10 months','escortwp'), "300", '10 months'),
	"15" => array(__('11 months','escortwp'), "330", '11 months'),
	"16" => array(__('1 year','escortwp'), "365", '1 year'),
	"17" => array(__('2 years','escortwp'), "730", '2 years')
);


function format_price($payment_plan,$size="long") {
	global $payment_duration_a, $woocommerce;
	$raw_price = (string) payment_plans($payment_plan, 'price');
	$duration = payment_plans($payment_plan, 'duration');
	$currency_symbol = function_exists('get_woocommerce_currency_symbol') ? get_woocommerce_currency_symbol() : 'R$';
	$fallback_price = '';
	if($raw_price !== '') {
		$normalized_price = number_format((float) $raw_price, 2, ',', '.');
		$fallback_price = $currency_symbol.$normalized_price;
	}

	$woo_product_id = payment_plans($payment_plan, 'woo_product_id');
	if(!$woo_product_id || !class_exists('WC_Product')) {
		$price = $fallback_price;
		if(!$price) {
			return false;
		}
		if($size == "long") {
			if($duration && isset($payment_duration_a[$duration])) {
				$price .= ' '.__('for','escortwp').' '.$payment_duration_a[$duration][0];
			}
			if($payment_plan === 'premium') {
				$price .= '<br />'.__('monthly manual renewal','escortwp');
			} else {
				$price .= '<br />'.__('one time payment','escortwp');
			}
		}
		return $price;
	}

	$woo_product = new WC_Product($woo_product_id);
	$price = $woo_product->get_price_html();
	if(!$price && $fallback_price) {
		$price = $fallback_price;
	}
	if($size == "long") {;
		if(class_exists('WC_Subscriptions_Product') && get_post_meta($woo_product_id, '_subscription_price', true)) {
			$price = '<br />'.get_woocommerce_currency_symbol().WC_Subscriptions_Product::get_price_string($woo_product_id);
			$price .= '<br />'.__('recurring payment','escortwp');
		} else {
			if($duration) {
				$price .= ' '.__('for','escortwp').' '.$payment_duration_a[$duration][0];
			}
			if($payment_plan === 'premium') {
				$price .= '<br />'.__('monthly manual renewal','escortwp');
			} else {
				$price .= '<br />'.__('one time payment','escortwp');
			}
		}

	}
	return $price;
}


add_filter('woocommerce_cart_item_thumbnail','__return_false'); // remove product thumbnails from cart
add_filter('woocommerce_cart_item_permalink','__return_false'); // remove product link from cart
add_filter('woocommerce_order_item_permalink','__return_false'); // remove order link

// show product name in order list
function woo_add_new_column_to_order_list($columns) {
    $new_columns = array();
    foreach ($columns as $key => $name) {
        $new_columns[$key] = $name;
        if ('order-number' === $key) {
            $new_columns['order-payment-for'] = __('Payment for', 'escortwp');
        }
    }
    return $new_columns;
}
add_filter('woocommerce_my_account_my_orders_columns', 'woo_add_new_column_to_order_list');

function woo_order_list_column_payment_for($order) {
    $items = $order->get_items();
    foreach ($items as $item_id => $item) {
	    $item_name = $item->get_name();
	    $order_for_id = wc_get_order_item_meta($item_id, 'order_for_id', true);
	    $payment_type = get_post_meta($item->get_product_id(), 'payment_type', true);
	    echo $item_name."<br />";
	    if($payment_type == "vip") {
		    $vip_user = get_user_by('id', $order_for_id);
		    echo $vip_user->display_name;
	    } elseif($payment_type == "tours") {
		    echo get_the_title($order_for_id);
	    } else {
		    echo '<a href="'.get_permalink($order_for_id).'">'.get_the_title($order_for_id).'</a>';
	    }
    }
}
add_action('woocommerce_my_account_my_orders_column_order-payment-for', 'woo_order_list_column_payment_for' );



// Remove notification emails from WooCommerce
function woo_remove_extra_emails_from_woocommerce($email_class) {
		// New order emails
		remove_action('woocommerce_order_status_pending_to_processing_notification', array( $email_class->emails['WC_Email_New_Order'], 'trigger'));
		remove_action('woocommerce_order_status_pending_to_completed_notification', array( $email_class->emails['WC_Email_New_Order'], 'trigger'));
		remove_action('woocommerce_order_status_pending_to_on-hold_notification', array( $email_class->emails['WC_Email_New_Order'], 'trigger'));
		remove_action('woocommerce_order_status_failed_to_processing_notification', array( $email_class->emails['WC_Email_New_Order'], 'trigger'));
		remove_action('woocommerce_order_status_failed_to_completed_notification', array( $email_class->emails['WC_Email_New_Order'], 'trigger'));
		remove_action('woocommerce_order_status_failed_to_on-hold_notification', array( $email_class->emails['WC_Email_New_Order'], 'trigger'));
		
		// Processing order emails
		remove_action('woocommerce_order_status_pending_to_processing_notification', array( $email_class->emails['WC_Email_Customer_Processing_Order'], 'trigger'));
		remove_action('woocommerce_order_status_pending_to_on-hold_notification', array( $email_class->emails['WC_Email_Customer_Processing_Order'], 'trigger'));
		
		// Completed order emails
		remove_action('woocommerce_order_status_completed_notification', array( $email_class->emails['WC_Email_Customer_Completed_Order'], 'trigger'));
			
		// Note emails
		remove_action('woocommerce_new_customer_note_notification', array( $email_class->emails['WC_Email_Customer_Note'], 'trigger'));
}
add_action('woocommerce_email', 'woo_remove_extra_emails_from_woocommerce');

// when a new item is added to cart the old items are removed
function woo_only_one_item_in_cart($passed, $added_product_id) {
	wc_empty_cart();
	return $passed;
}
add_filter('woocommerce_add_to_cart_validation', 'woo_only_one_item_in_cart', 99, 2);

// remove quantity field from cart, for virtual items
function woo_remove_quantity_field($return, $product) {
	if($product->virtual == "yes") {
		return true;
	} else {
		// return false;
	}
}
add_filter('woocommerce_is_sold_individually', 'woo_remove_quantity_field', 10, 2);

// change shop page to homepage
function woo_change_shop_page_url($link) {
	return get_home_url();
}
add_filter('woocommerce_get_shop_page_permalink', 'woo_change_shop_page_url');

// redirect shop page to homepage
function woo_disable_shop_page() {
    global $post;
    if (is_woocommerce_active && function_exists("is_shop") && is_shop() && !current_user_can('level_10')):
    	wp_redirect(get_home_url(), "301"); die();
    endif;
}
add_action('wp', 'woo_disable_shop_page');


function escortwp_get_order_item_state($item_id) {
	if(!function_exists('wc_get_order_item_meta')) {
		return '';
	}
	return wc_get_order_item_meta($item_id, 'escortwp_payment_state', true);
}

function escortwp_set_order_item_state($item_id, $state) {
	if(function_exists('wc_update_order_item_meta')) {
		wc_update_order_item_meta($item_id, 'escortwp_payment_state', sanitize_key($state));
	}
}

function escortwp_get_order_item_target_id($item_id, $item = null, $parent_order = null) {
	$order_for_id = (int)wc_get_order_item_meta($item_id, 'order_for_id', true);
	if($order_for_id) {
		return $order_for_id;
	}

	if($item && $parent_order && is_object($parent_order)) {
		$product_id = method_exists($item, 'get_product_id') ? (int)$item->get_product_id() : 0;
		foreach($parent_order->get_items() as $parent_item_id => $parent_item) {
			if((int)$parent_item->get_product_id() === $product_id) {
				$order_for_id = (int)wc_get_order_item_meta($parent_item_id, 'order_for_id', true);
				if($order_for_id) {
					return $order_for_id;
				}
			}
		}
	}

	return 0;
}

function escortwp_mark_featured_boost_pending($profile_id, $order, $item, $product_id) {
	$profile_id = (int)$profile_id;
	if(!$profile_id) {
		return false;
	}

	$order_item_id = method_exists($item, 'get_id') ? (int)$item->get_id() : 0;
	$post = get_post($profile_id);
	$item_amount = method_exists($item, 'get_total') ? (float)$item->get_total() : (float)$order->get_total();
	escortwp_upsert_featured_boost_record(array(
		'order_id' => (int)$order->get_id(),
		'order_item_id' => $order_item_id,
		'product_id' => (int)$product_id,
		'profile_id' => $profile_id,
		'user_id' => $post ? (int)$post->post_author : 0,
		'payment_status' => sanitize_key($order->get_status()),
		'boost_status' => 'pending',
		'amount' => $item_amount,
		'currency' => $order->get_currency(),
	));

	update_post_meta($profile_id, 'escortwp_featured_boost_status', 'pending');
	return true;
}

function escortwp_activate_featured_boost_payment($profile_id, $order, $item, $product_id) {
	$profile_id = (int)$profile_id;
	if(!$profile_id || !get_post($profile_id)) {
		return false;
	}

	$order_item_id = method_exists($item, 'get_id') ? (int)$item->get_id() : 0;
	$existing_record = escortwp_get_featured_boost_record($order_item_id);
	if($existing_record && $existing_record->boost_status == 'active' && (int)$existing_record->expires_at > current_time('timestamp')) {
		escortwp_recalculate_featured_boost_state($profile_id);
		return true;
	}

	$now = current_time('timestamp');
	$current_expires_at = (int)get_post_meta($profile_id, 'escortwp_featured_boost_expires_at', true);
	if($current_expires_at < $now) {
		$current_expires_at = 0;
	}

	$starts_at = $current_expires_at > $now ? $current_expires_at : $now;
	$expires_at = $starts_at + escortwp_get_featured_boost_duration_seconds();
	$post = get_post($profile_id);
	$item_amount = method_exists($item, 'get_total') ? (float)$item->get_total() : (float)$order->get_total();

	escortwp_capture_featured_legacy_state($profile_id);
	escortwp_upsert_featured_boost_record(array(
		'order_id' => (int)$order->get_id(),
		'order_item_id' => $order_item_id,
		'product_id' => (int)$product_id,
		'profile_id' => $profile_id,
		'user_id' => $post ? (int)$post->post_author : 0,
		'payment_status' => 'approved',
		'boost_status' => 'active',
		'amount' => $item_amount,
		'currency' => $order->get_currency(),
		'starts_at' => $starts_at,
		'expires_at' => $expires_at,
	));

	escortwp_apply_featured_boost_state($profile_id, $starts_at, $expires_at, (int)$order->get_id());
	escortwp_schedule_featured_boost_expiration($profile_id, $expires_at);

	return true;
}

function escortwp_revoke_featured_boost_payment($order_id, $order_item_id = 0, $reason = 'cancelled') {
	global $wpdb;
	$table_name = escortwp_get_featured_boost_table_name();

	$where_sql = $order_item_id
		? $wpdb->prepare("WHERE order_item_id = %d", $order_item_id)
		: $wpdb->prepare("WHERE order_id = %d", $order_id);

	$records = $wpdb->get_results("SELECT * FROM {$table_name} {$where_sql}");
	if(!$records) {
		return;
	}

	foreach($records as $record) {
		$wpdb->update(
			$table_name,
			array(
				'payment_status' => sanitize_key($reason),
				'boost_status' => in_array($reason, array('cancelled', 'refunded', 'failed'), true) ? sanitize_key($reason) : 'expired',
				'updated_at' => current_time('mysql'),
			),
			array('id' => (int)$record->id)
		);

		update_post_meta((int)$record->profile_id, 'escortwp_featured_boost_status', sanitize_key($reason));
		update_post_meta((int)$record->profile_id, 'escortwp_featured_boost_started_at', (int)$record->starts_at);
		update_post_meta((int)$record->profile_id, 'escortwp_featured_boost_expires_at', (int)$record->expires_at);

		escortwp_recalculate_featured_boost_state((int)$record->profile_id);
	}
}

function escortwp_revoke_user_payment($payment_type, $target_id, $woo_order_id, $woo_product_id, $reason = 'cancelled') {
	$target_id = (int)$target_id;
	$woo_order_id = (int)$woo_order_id;
	$is_subscription = escortwp_is_subscription_product($woo_product_id);

	if($payment_type == 'featured_boost') {
		escortwp_revoke_featured_boost_payment($woo_order_id, 0, $reason);
		return;
	}

	if($payment_type == 'vip') {
		if((int)get_user_meta($target_id, 'vip_txn_id', true) !== $woo_order_id) {
			return;
		}

		delete_user_meta($target_id, 'vip');
		delete_user_meta($target_id, 'vip_txn_id');
		delete_user_meta($target_id, 'vip_renew');
		if(!$is_subscription) {
			delete_user_meta($target_id, 'vip_expire');
		}
		return;
	}

	$post = get_post($target_id);
	if(!$post) {
		return;
	}

	switch($payment_type) {
		case 'premium':
			if((int)get_post_meta($target_id, 'premium_txn_id', true) === $woo_order_id) {
				update_post_meta($target_id, 'premium', '0');
				delete_post_meta($target_id, 'premium_txn_id');
				delete_post_meta($target_id, 'premium_renew');
				delete_post_meta($target_id, 'premium_since');
				if(!$is_subscription) {
					delete_post_meta($target_id, 'premium_expire');
				}
				escortwp_update_post_plan_state($target_id, array(
					'plan_key' => 'premium',
					'plan_type' => $is_subscription ? 'subscription' : 'one_time',
					'plan_status' => in_array($reason, array('refunded', 'failed'), true) ? 'payment-'.$reason : 'cancelled',
					'expires_at' => 0,
					'subscription_status' => $is_subscription ? sanitize_key($reason) : '',
				));
			}
			break;

		case 'featured':
			if((int)get_post_meta($target_id, 'featured_txn_id', true) === $woo_order_id && get_post_meta($target_id, 'escortwp_featured_source', true) !== 'boost') {
				update_post_meta($target_id, 'featured', '0');
				delete_post_meta($target_id, 'featured_txn_id');
				delete_post_meta($target_id, 'featured_renew');
				if(!$is_subscription) {
					delete_post_meta($target_id, 'featured_expire');
				}
				escortwp_update_post_plan_state($target_id, array(
					'plan_key' => 'featured',
					'plan_type' => $is_subscription ? 'subscription' : 'one_time',
					'plan_status' => in_array($reason, array('refunded', 'failed'), true) ? 'payment-'.$reason : 'cancelled',
					'expires_at' => 0,
					'subscription_status' => $is_subscription ? sanitize_key($reason) : '',
				));
			}
			break;

		case 'agreg':
			if((int)get_post_meta($target_id, 'agency_txn_id', true) === $woo_order_id || $is_subscription) {
				wp_update_post(array('ID' => $target_id, 'post_status' => 'private'));
				update_post_meta($target_id, 'needs_payment', '1');
				delete_post_meta($target_id, 'agency_renew');
				if(!$is_subscription) {
					delete_post_meta($target_id, 'agency_expire');
				}
				escortwp_update_post_plan_state($target_id, array(
					'plan_key' => 'agreg',
					'plan_type' => $is_subscription ? 'subscription' : 'one_time',
					'plan_status' => in_array($reason, array('refunded', 'failed'), true) ? 'payment-'.$reason : 'cancelled',
					'expires_at' => 0,
					'subscription_status' => $is_subscription ? sanitize_key($reason) : '',
				));
			}
			break;

		case 'agescortreg':
		case 'indescreg':
			if((int)get_post_meta($target_id, 'profile_txn_id', true) === $woo_order_id || $is_subscription) {
				wp_update_post(array('ID' => $target_id, 'post_status' => 'private'));
				update_post_meta($target_id, 'needs_payment', '1');
				delete_post_meta($target_id, 'escort_renew');
				if(!$is_subscription) {
					delete_post_meta($target_id, 'escort_expire');
				}
				escortwp_update_post_plan_state($target_id, array(
					'plan_key' => $payment_type,
					'plan_type' => $is_subscription ? 'subscription' : 'one_time',
					'plan_status' => in_array($reason, array('refunded', 'failed'), true) ? 'payment-'.$reason : 'cancelled',
					'expires_at' => 0,
					'subscription_status' => $is_subscription ? sanitize_key($reason) : '',
				));
			}
			break;
	}
}

// Payment complete trigger
function woo_payment_complete_trigger($order_id) {
	escortwp_sync_order_payments($order_id, 'completed');
}
add_action('woocommerce_order_status_processing', 'woo_payment_complete_trigger');
add_action('woocommerce_order_status_completed', 'woo_payment_complete_trigger');

function escortwp_sync_order_payments($order_id, $forced_status = '') {
	if(!is_woocommerce_active || !function_exists('wc_get_order')) {
		return false;
	}

	$order = wc_get_order($order_id);
	if(!$order) {
		return false;
	}

	$status = $forced_status ? sanitize_key($forced_status) : sanitize_key($order->get_status());
	if(function_exists('escortwp_log_payment_event')) {
		escortwp_log_payment_event('Sincronizando plano do pedido pelo status oficial do WooCommerce.', array(
			'order_id' => (int) $order_id,
			'status' => $status,
		));
	}

	foreach($order->get_items() as $item_id => $item) {
		$product_id = (int)$item->get_product_id();
		$payment_type = get_post_meta($product_id, 'payment_type', true);
		if(!$payment_type) {
			continue;
		}

		$target_id = escortwp_get_order_item_target_id($item_id);
		$current_state = escortwp_get_order_item_state($item_id);
		if(function_exists('escortwp_log_payment_event')) {
			escortwp_log_payment_event('Item do pedido analisado para ativação de benefício.', array(
				'order_id' => (int) $order_id,
				'item_id' => (int) $item_id,
				'payment_type' => (string) $payment_type,
				'target_id' => (int) $target_id,
				'current_state' => (string) $current_state,
				'status' => $status,
			));
		}

		if($payment_type == 'featured_boost') {
			if(escortwp_is_paid_order_status($status)) {
				escortwp_activate_featured_boost_payment($target_id, $order, $item, $product_id);
				escortwp_set_order_item_state($item_id, 'paid');
			} elseif(escortwp_is_pending_order_status($status)) {
				escortwp_mark_featured_boost_pending($target_id, $order, $item, $product_id);
				escortwp_set_order_item_state($item_id, 'pending');
			} elseif(escortwp_is_failed_order_status($status)) {
				escortwp_revoke_featured_boost_payment((int)$order->get_id(), (int)$item_id, $status);
				escortwp_set_order_item_state($item_id, $status);
			}
			continue;
		}

		if(
			escortwp_is_pending_order_status($status)
			&& $target_id
			&& escortwp_plan_is_post_based($payment_type)
			&& !in_array($payment_type, array('featured_boost', 'tours'), true)
		) {
			escortwp_update_post_plan_state($target_id, array(
				'plan_key' => $payment_type,
				'plan_type' => escortwp_is_subscription_product($product_id) ? 'subscription' : 'one_time',
				'plan_status' => 'pending-payment',
				'order_id' => (int)$order->get_id(),
				'product_id' => $product_id,
			));
			escortwp_set_order_item_state($item_id, 'pending');
			continue;
		}

		if(escortwp_is_paid_order_status($status)) {
			if($current_state !== 'paid') {
				woo_activate_user_payment($payment_type, $item->get_name(), $target_id, (int)$order->get_id(), $product_id);
			} elseif(function_exists('escortwp_log_payment_event')) {
				escortwp_log_payment_event('Ativação ignorada por idempotência: item já marcado como pago.', array(
					'order_id' => (int) $order_id,
					'item_id' => (int) $item_id,
					'payment_type' => (string) $payment_type,
					'target_id' => (int) $target_id,
				));
			}
			escortwp_set_order_item_state($item_id, 'paid');
			continue;
		}

		if(escortwp_is_failed_order_status($status)) {
			escortwp_revoke_user_payment($payment_type, $target_id, (int)$order->get_id(), $product_id, $status);
			escortwp_set_order_item_state($item_id, $status);
		}
	}

	return true;
}

function woo_activate_user_payment($payment_type, $item_name, $custom, $woo_order_id, $woo_product_id) {
	if(!$payment_type) {
		return false;
	}

	global $taxonomy_profile_name, $taxonomy_agency_name, $taxonomy_agency_name_plural, $payment_duration_a, $taxonomy_profile_url;

	$is_subscription = escortwp_is_subscription_product($woo_product_id);
	$subscription_id = $is_subscription ? escortwp_get_order_subscription_id($woo_order_id) : 0;
	$now = current_time('timestamp');

	$body = __('Hello admin','escortwp').',<br /><br /><br />'.__('Someone made a payment of','escortwp').' '.format_price($payment_type,'small').' '.__('in your account','escortwp').'.<br />'.__('Type of payment','escortwp').': <b>'.$item_name."</b>";
	if ($payment_type == 'vip') {
		$body .= '<br />'.__('Usuária que realizou o pagamento','escortwp').':<br /><a href="'.admin_url('user-edit.php?user_id='.$custom).'">'.admin_url('user-edit.php?user_id='.$custom).'</a>';
	} elseif($payment_type == 'tours') {
		$belongstoescortid = get_post_meta($custom, 'belongstoescortid', true);
		$body .= '<br />'.__('Payment for','escortwp').':<br /><a href="'.get_permalink($belongstoescortid).'">'.get_permalink($belongstoescortid).'</a>';
	} else {
		$body .= '<br />'.__('Payment for','escortwp').':<br /><a href="'.get_permalink($custom).'">'.get_permalink($custom).'</a>';
	}
	if(get_option('ifemail7') == '1') {
		dolce_email(null, null, get_bloginfo('admin_email'), __('New payment on','escortwp').' '.get_option('email_sitename'), $body);
	}

	$customer_body = __('Hello','escortwp').',<br /><br /><br />'.__('Your payment on','escortwp').' '.get_option('email_sitename').' '.__('has been accepted','escortwp').'.<br />';
	$expiration = 0;

	if($payment_type == 'featured_boost') {
		$order = function_exists('wc_get_order') ? wc_get_order($woo_order_id) : null;
		if($order) {
			foreach($order->get_items() as $order_item) {
				if((int)$order_item->get_product_id() === (int)$woo_product_id && escortwp_get_order_item_target_id($order_item->get_id()) == $custom) {
					escortwp_activate_featured_boost_payment($custom, $order, $order_item, $woo_product_id);
					break;
				}
			}
		}
		$expires_at = (int)get_post_meta($custom, 'escortwp_featured_boost_expires_at', true);
		$customer_body .= sprintf(esc_html__('Seu anúncio ficou em destaque até %s.','escortwp'), $expires_at ? date_i18n('d/m/Y H:i', $expires_at) : date_i18n('d/m/Y H:i', $now + escortwp_get_featured_boost_duration_seconds()));
	} elseif($payment_type == 'premium') {
		$customer_body .= sprintf(esc_html__('Seu %s agora esta com o plano mensal ativo.','escortwp'), $taxonomy_profile_name);
		update_post_meta($custom, 'premium', '1');
		update_post_meta($custom, 'premium_since', $now);
		update_post_meta($custom, 'premium_txn_id', $woo_order_id);
		if($is_subscription) {
			update_post_meta($custom, 'premium_renew', '1');
			delete_post_meta($custom, 'premium_expire');
		} else {
			$duration_seconds = escortwp_get_payment_duration_seconds('premium');
			if($duration_seconds) {
				$available_time = (int)get_post_meta($custom, 'premium_expire', true);
				$expiration = ($available_time && $available_time > $now) ? ($available_time + $duration_seconds) : ($now + $duration_seconds);
				update_post_meta($custom, 'premium_expire', $expiration);
			} else {
				delete_post_meta($custom, 'premium_expire');
			}
			delete_post_meta($custom, 'premium_renew');
		}
		escortwp_update_post_plan_state($custom, array(
			'plan_key' => 'premium',
			'plan_type' => $is_subscription ? 'subscription' : 'one_time',
			'plan_status' => 'active',
			'started_at' => $now,
			'expires_at' => isset($expiration) ? (int)$expiration : 0,
			'order_id' => $woo_order_id,
			'product_id' => $woo_product_id,
			'subscription_id' => $subscription_id,
			'subscription_status' => $is_subscription ? 'active' : '',
		));
	} elseif($payment_type == 'featured') {
		$customer_body .= sprintf(esc_html__('You are now a featured %s.','escortwp'), $taxonomy_profile_name);
		update_post_meta($custom, 'featured', '1');
		update_post_meta($custom, 'featured_txn_id', $woo_order_id);
		if($is_subscription) {
			update_post_meta($custom, 'featured_renew', '1');
			delete_post_meta($custom, 'featured_expire');
		} else {
			$duration_seconds = escortwp_get_payment_duration_seconds('featured');
			if($duration_seconds) {
				$available_time = (int)get_post_meta($custom, 'featured_expire', true);
				$expiration = ($available_time && $available_time > $now) ? ($available_time + $duration_seconds) : ($now + $duration_seconds);
				update_post_meta($custom, 'featured_expire', $expiration);
			} else {
				delete_post_meta($custom, 'featured_expire');
			}
			delete_post_meta($custom, 'featured_renew');
		}
		escortwp_update_post_plan_state($custom, array(
			'plan_key' => 'featured',
			'plan_type' => $is_subscription ? 'subscription' : 'one_time',
			'plan_status' => 'active',
			'started_at' => $now,
			'expires_at' => isset($expiration) ? (int)$expiration : 0,
			'order_id' => $woo_order_id,
			'product_id' => $woo_product_id,
			'subscription_id' => $subscription_id,
			'subscription_status' => $is_subscription ? 'active' : '',
		));
	} elseif($payment_type == 'tours') {
		$customer_body .= __('Your tour has been activated.','escortwp');
		wp_update_post(array('ID' => $custom, 'post_status' => 'publish'));
		update_post_meta($custom, 'tour_txn_id', $woo_order_id);
		delete_post_meta($custom, 'needs_payment');
	} elseif($payment_type == 'vip') {
		$customer_body .= __('You are now a VIP member.','escortwp');
		update_user_meta($custom, 'vip', '1');
		update_user_meta($custom, 'vip_txn_id', $woo_order_id);
		if($is_subscription) {
			update_user_meta($custom, 'vip_renew', '1');
			delete_user_meta($custom, 'vip_expire');
		} else {
			$duration_seconds = escortwp_get_payment_duration_seconds('vip');
			if($duration_seconds) {
				$available_time = (int)get_user_meta($custom, 'vip_expire', true);
				$expiration = ($available_time && $available_time > $now) ? ($available_time + $duration_seconds) : ($now + $duration_seconds);
				update_user_meta($custom, 'vip_expire', $expiration);
			}
			delete_user_meta($custom, 'vip_renew');
		}
	} elseif($payment_type == 'agreg') {
		$customer_body .= sprintf(esc_html__('Your %s profile has been activated.','escortwp'), $taxonomy_agency_name);
		if(get_option('manactivagprof') != '1') {
			wp_update_post(array('ID' => $custom, 'post_status' => 'publish'));
			delete_post_meta($custom, 'notactive');
		}

		$args = array(
			'post_type' => $taxonomy_profile_url,
			'posts_per_page' => -1,
			'author' => $custom,
			'meta_query' => array(
				array('key' => 'needs_ag_payment', 'value' => '1', 'type' => 'numeric', 'compare' => '='),
				array('key' => 'needs_payment', 'value' => '1', 'type' => 'numeric', 'compare' => '!='),
			),
		);
		$profiles = new WP_Query($args);
		if($profiles->have_posts()) {
			while($profiles->have_posts()) {
				$profiles->the_post();
				wp_update_post(array('ID' => get_the_ID(), 'post_status' => 'publish'));
				delete_post_meta(get_the_ID(), 'needs_ag_payment');
			}
		}
		wp_reset_postdata();

		if($is_subscription) {
			update_post_meta($custom, 'agency_renew', '1');
			delete_post_meta($custom, 'agency_expire');
		} else {
			$duration_seconds = escortwp_get_payment_duration_seconds('agreg');
			if($duration_seconds) {
				$available_time = (int)get_post_meta($custom, 'agency_expire', true);
				$expiration = ($available_time && $available_time > $now) ? ($available_time + $duration_seconds) : ($now + $duration_seconds);
				update_post_meta($custom, 'agency_expire', $expiration);
			} else {
				delete_post_meta($custom, 'agency_expire');
			}
			delete_post_meta($custom, 'agency_renew');
		}
		update_post_meta($custom, 'agency_txn_id', $woo_order_id);
		delete_post_meta($custom, 'needs_payment');
		escortwp_update_post_plan_state($custom, array(
			'plan_key' => 'agreg',
			'plan_type' => $is_subscription ? 'subscription' : ((string)payment_plans('agreg', 'price') === '' ? 'free' : 'one_time'),
			'plan_status' => 'active',
			'started_at' => $now,
			'expires_at' => $expiration,
			'order_id' => $woo_order_id,
			'product_id' => $woo_product_id,
			'subscription_id' => $subscription_id,
			'subscription_status' => $is_subscription ? 'active' : '',
		));
	} elseif($payment_type == 'agescortreg' || $payment_type == 'indescreg') {
		$customer_body .= $payment_type == 'indescreg'
			? sprintf(esc_html__('Seu perfil de %s já está ativo.','escortwp'), $taxonomy_profile_name)
			: sprintf(esc_html__('The %s you added has been activated.','escortwp'), $taxonomy_profile_name);

		if(($payment_type == 'indescreg' && get_option('manactivindescprof') != '1') || ($payment_type == 'agescortreg' && get_option('manactivagescprof') != '1')) {
			wp_update_post(array('ID' => $custom, 'post_status' => 'publish'));
			delete_post_meta($custom, 'notactive');
		}

		if($is_subscription) {
			update_post_meta($custom, 'escort_renew', '1');
			delete_post_meta($custom, 'escort_expire');
		} else {
			$duration_seconds = escortwp_get_payment_duration_seconds($payment_type);
			if($duration_seconds) {
				$available_time = (int)get_post_meta($custom, 'escort_expire', true);
				$expiration = ($available_time && $available_time > $now) ? ($available_time + $duration_seconds) : ($now + $duration_seconds);
				update_post_meta($custom, 'escort_expire', $expiration);
			} else {
				delete_post_meta($custom, 'escort_expire');
			}
			delete_post_meta($custom, 'escort_renew');
		}
		update_post_meta($custom, 'profile_txn_id', $woo_order_id);
		delete_post_meta($custom, 'needs_payment');
		escortwp_update_post_plan_state($custom, array(
			'plan_key' => $payment_type,
			'plan_type' => $is_subscription ? 'subscription' : ((string)payment_plans($payment_type, 'price') === '' ? 'free' : 'one_time'),
			'plan_status' => 'active',
			'started_at' => $now,
			'expires_at' => $expiration,
			'order_id' => $woo_order_id,
			'product_id' => $woo_product_id,
			'subscription_id' => $subscription_id,
			'subscription_status' => $is_subscription ? 'active' : '',
		));
	}

	$customeremail = escortwp_get_profile_owner_email($payment_type, $custom);
	if($customeremail) {
		dolce_email('', '', $customeremail, __('Payment accepted on','escortwp').' '.get_option('email_sitename'), $customer_body);
	}

	return true;
}

// If the order status changes we sync entitlements with the effective order state.
add_action('woocommerce_order_status_changed', 'check_subscription_order_status_change', 99, 4);
function check_subscription_order_status_change($order_id, $old_status, $new_status, $order) {
	if($old_status === $new_status) {
		return;
	}
	escortwp_sync_order_payments($order_id, $new_status);
}

function woo_show_sidebar_expiration_notice($payment_type) {
	// '1' => 'premium'
	// '2' => 'featured'
	// '3' => 'tour'
	// '5' => 'vip'
	// '6' => 'agency'
	// '7' => 'ag escort'
	// '8' => 'escort'
	$var_names_array = array(
							// '1' => 'premium',
							// '2' => 'featured',
							// '3' => 'tour',
							'5' => 'vip',
							// '6' => 'agency',
							// '7' => 'escort',
							// '8' => 'escort'
						);
	$payment_plan_names_array = array(
							// '1' => 'premium',
							// '2' => 'featured',
							// '3' => 'tour',
							'5' => 'vip',
							// '6' => 'agency',
							// '7' => 'escort',
							// '8' => 'escort'
						);

	$text_names_array = array('1' => __('premium', 'escortwp'), '2' => __('featured', 'escortwp'), '3' => __('tour', 'escortwp'), '5' => __('vip', 'escortwp'), '6' => __('agency', 'escortwp'), '7' => __('escort', 'escortwp'), '8' => __('escort', 'escortwp'));
	$current_user = wp_get_current_user();
	$userid = $current_user->ID;
	// $userstatus = get_option("escortid".$userid);
	// $orderid = get_user_meta($userid, $var_names_array[$payment_type].'_txn_id', true);
	if(get_user_meta($userid, $var_names_array[$payment_type].'_expire', true)) {
		// one time payment
		$expire_date = date("d M Y", get_user_meta($userid, $var_names_array[$payment_type].'_expire', true));
		$expire_text = sprintf(__('Your %s status is active until','escortwp'), strtoupper($text_names_array[$payment_type])).': <b>'.$expire_date.'</b>';
		// $expire_text_mobile = __('VIP expiration:','escortwp').' <b>'.$vip_expire_date.'</b>';
	} else {
		if(get_user_meta($userid, $var_names_array[$payment_type].'_renew', true) == "1") {
			// subscription
			$expire_text = sprintf(__('Your %s status subscription is ACTIVE','escortwp'), strtoupper($text_names_array[$payment_type]));
			// $expire_text_mobile = __('VIP status ACTIVE','escortwp');
		} else {
			// forever
			$expire_text = sprintf(__('Your %s status is active FOREVER','escortwp'), strtoupper($text_names_array[$payment_type]));
			// $expire_text_mobile = __('VIP status ACTIVE forever','escortwp');
		}
	}

	// echo '<div class="sidebar-expire-notice-mobile bluedegrade text-center" data-payment-plan="featured">';
	// 	echo '<div class="expiration-date">'.$expire_text_mobile.'</div>';
	// 	if (get_user_meta($userid, 'vip_expire', true) && payment_plans('vip','price')) {
	// 		echo '<div class="sidebar-expire-mobile-extent-button greenbutton rad25">'.__('Extend','escortwp').'</div>';
	// 	}
	// echo '</div>';

	// echo '<div class="sidebar-expire-notice sidebar-expire-notice-has-mobile pinkdegrade center">';
	echo '<div class="sidebar-expire-notice greendegrade center">';
		echo $expire_text;
		if(get_user_meta($userid, $var_names_array[$payment_type]."_renew", true)) {
			?>
				<script type="text/javascript">
					jQuery(document).ready(function($) {
						$('.sidebar-expire-notice-cancel-subscription .fake-button1').on('click', function(event) {
							$(this).hide();
							$(this).siblings('.sidebar-expire-notice-cancel-subscription-form').show();
						});
					});
				</script>
			    <div class="sidebar-expire-notice-cancel-subscription text-center">
			    	<div class="fake-button fake-button1 redbutton rad25 center"><?=__('Cancelar assinatura', 'escortwp')?></div>
				    <form action="" method="post" class="sidebar-expire-notice-cancel-subscription-form">
				    	<input type="hidden" name="payment_type" value="<?=$payment_type?>" />
				    	<input type="hidden" name="action" value="cancel_subscription" />
				    	<div class="clear10"></div>
				    	<?=__('Tem certeza?', 'escortwp')?>
				    	<div class="clear5"></div>
				    	<button class="fake-button fake-button2 redbutton rad25 center"><?=__('Cancelar agora', 'escortwp')?></button>
				    </form>
			    </div>
			<?php
		} elseif (get_user_meta($userid, $var_names_array[$payment_type]."_expire", true) && payment_plans($payment_plan_names_array[$payment_type],'price')) {
			echo '<div class="clear20"></div>';
			echo '<div class="text-center">'.generate_payment_buttons($payment_plan_names_array[$payment_type], $userid, sprintf(__('Extend %s status','escortwp'), strtoupper($text_names_array[$payment_type])))."</div> <!--center-->";
			echo '<div class="clear5"></div>';
			echo '<small>'.format_price($payment_plan_names_array[$payment_type]).'</small>';
		}
	echo '</div>';
}

function woo_cancel_subscription_form_process_legacy_disabled() {
	if(!is_user_logged_in()) return false;

	if (isset($_POST['action']) && $_POST['action'] == 'cancel_subscription') {
		$current_user = wp_get_current_user();
		$userid = $current_user->ID;
		$payment_type = (int)$_POST['payment_type'];
		if($payment_type < 1 || $payment_type > 8) return false;

    	// '1' => 'premium'
    	// '2' => 'featured'
    	// '3' => 'tour'
    	// '5' => 'vip'
    	// '6' => 'agency'
    	// '7' => 'escort'
    	// '8' => 'escort'
    	switch ($payment_type) {
    		case '1':
    			break;
    		
    		case '2':
    			break;
    		
    		case '3':
    			break;
    		
    		case '5': // vip
					$order_id = get_user_meta($userid, 'vip_txn_id', true);
					// $exp = get_next_payment_date($order_id);
					// prd($exp);
					// if($exp) {
					// 	update_user_meta($userid, 'vip_expire', $exp);
					// }
					// $payment_name = __('VIP', 'escortwp');
    			break;

    		case '6': // agency
		    		// $agency_profile_id = get_option('agencypostid'.$userid);
					// $order_id = get_user_meta($agency_profile_id , 'agency_tax_id', true);
    			break;
    	}

		// global $woocommerce; // in case of needâ€¦
		$order = new WC_Order($order_id);
		if (!empty($order)) $order->update_status('cancelled');

		// include_once(ABSPATH."wp-admin/includes/user.php");
		// wp_delete_user($userid);
		wp_redirect(get_bloginfo("url")); die();
	} // if admin
}
add_action('init', 'woo_cancel_subscription_form_process');

function order_subscription_canceled_legacy_disabled($customeremail, $paymenttype, $custom, $eventtype, $woo_order_id, $woo_product_id) {
	global $taxonomy_profile_name, $taxonomy_agency_name;
	$var_names_array = array('1' => 'premium', '2' => 'featured', '3' => 'tour', '5' => 'vip', '6' => 'agency', '7' => 'escort', '8' => 'escort');
	$text_names_array = array('1' => __('premium', 'escortwp'), '2' => __('featured', 'escortwp'), '3' => __('tour', 'escortwp'), '5' => __('VIP', 'escortwp'), '6' => __('agency', 'escortwp'), '7' => __('escort', 'escortwp'), '8' => __('escort', 'escortwp'));
	$body = __('Hello','escortwp').'<br /><br /><br />'.sprintf(__('Your %s subscription from','escortwp'),$text_names_array[$paymenttype]).' '.get_option("email_sitename").' ';
	switch ($eventtype) {
		case '1': // Cancellation
				$subject = __('was canceled','escortwp');
				$body .= __('was canceled','escortwp').'.<br />';
				if(class_exists('WC_Subscriptions') && get_post_meta($woo_product_id, '_subscription_price', true)) {
				    if(WC_Subscriptions_Renewal_Order::is_renewal($woo_order_id)) {
				        $parent_id = WC_Subscriptions_Renewal_Order::get_parent_order_id($woo_order_id); /* This gets the original parent order id */
				        $parent_order = new WC_Order($parent_id);
				        foreach ($parent_order->get_items() as $item) { /* This loops through each item in the order */
				            $expiration = WC_Subscriptions_Order::get_next_payment_date($parent_order, $item['product_id']); /* This should get the next payment date... */
				        }
				    } elseif (WC_Subscriptions_Order::order_contains_subscription($woo_order_id)) {
				    	$woo_order_id_obj = new WC_Order($woo_order_id);
				        foreach($woo_order_id_obj->get_items() as $item ) { /* This loops through each item in the order */
				            $expiration = WC_Subscriptions_Order::get_next_payment_date($woo_order_id, $item['product_id']); /* This should get the next payment date... */
				        }
				    }
				    $expiration = strtotime($expiration);
				    pr($expiration);
				}

			break;

		case '2': // Expiration
				// $expiration = strtotime("-1 days");
				// $subject = __('has expired','escortwp');
				// $body .= __('has expired','escortwp').'.<br />';
			break;

		case '3': // Refund / Chargeback / Return / Void
				// $body = __('Hello','escortwp').'<br /><br />'.__('Your payment for','escortwp').' '.get_option("email_sitename").' ';
				// $subject = __('was refunded','escortwp');
				// $body .= __('was refunded','escortwp').'.<br />';
				// $expiration = strtotime("-1 days");
			break;
	}
	prd($expiration);


	if($expiration) {
		update_post_meta($custom, $var_names_array[$paymenttype].'_expire', $expiration);
	}
	delete_post_meta($custom, $var_names_array[$paymenttype].'_renew');

if($send_email)
	dolce_email("", "", $customeremail, __('Your subscription on','escortwp')." ".get_option("email_sitename")." ".$subject, $body);
}

function escortwp_cancel_saved_subscription_for_post($post_id, $plan_key) {
	$post_id = (int)$post_id;
	$subscription_id = (int)get_post_meta($post_id, escortwp_get_post_plan_meta($post_id, 'subscription_id'), true);
	$expires_at = (int)get_post_meta($post_id, escortwp_get_post_plan_meta($post_id, 'expires_at'), true);
	$prefix = escortwp_get_plan_meta_prefix($plan_key);

	if($subscription_id && function_exists('wcs_get_subscription')) {
		$subscription = wcs_get_subscription($subscription_id);
		if($subscription) {
			if(method_exists($subscription, 'get_time')) {
				$expires_at = (int)$subscription->get_time('end');
				if(!$expires_at) {
					$expires_at = (int)$subscription->get_time('next_payment');
				}
			}
			if(method_exists($subscription, 'get_status') && !in_array($subscription->get_status(), array('cancelled', 'expired'), true) && method_exists($subscription, 'update_status')) {
				$subscription->update_status('cancelled');
			}
		}
	} else {
		$order_id = (int)get_post_meta($post_id, escortwp_get_post_plan_meta($post_id, 'order_id'), true);
		if(!$order_id) {
			$order_id = (int)get_post_meta($post_id, $plan_key == 'agreg' ? 'agency_txn_id' : 'profile_txn_id', true);
		}
		if($order_id && function_exists('wc_get_order')) {
			$order = wc_get_order($order_id);
			if($order && method_exists($order, 'update_status')) {
				$order->update_status('cancelled');
			}
		}
	}

	if($prefix) {
		delete_post_meta($post_id, $prefix.'_renew');
		if($expires_at) {
			update_post_meta($post_id, $prefix.'_expire', $expires_at);
		}
	}

	escortwp_update_post_plan_state($post_id, array(
		'plan_key' => $plan_key,
		'plan_type' => 'subscription',
		'plan_status' => 'cancelled',
		'expires_at' => $expires_at,
		'subscription_status' => 'cancelled',
	));

	return true;
}

function escortwp_handle_subscription_status_updated($subscription, $new_status = '', $old_status = '') {
	if(!is_object($subscription) || !method_exists($subscription, 'get_items')) {
		return;
	}

	$subscription_id = method_exists($subscription, 'get_id') ? (int)$subscription->get_id() : 0;
	$parent_order = null;
	if(method_exists($subscription, 'get_parent_id') && $subscription->get_parent_id()) {
		$parent_order = wc_get_order($subscription->get_parent_id());
	}

	$expires_at = 0;
	if(method_exists($subscription, 'get_time')) {
		$expires_at = (int)$subscription->get_time('end');
		if(!$expires_at && in_array($new_status, array('active', 'pending-cancel'), true)) {
			$expires_at = (int)$subscription->get_time('next_payment');
		}
	}

	$plan_status = 'active';
	if(in_array($new_status, array('cancelled', 'pending-cancel'), true)) {
		$plan_status = 'cancelled';
	} elseif($new_status == 'expired') {
		$plan_status = 'expired';
	} elseif(in_array($new_status, array('on-hold', 'pending'), true)) {
		$plan_status = 'pending-payment';
	}

	foreach($subscription->get_items() as $item_id => $item) {
		$product_id = (int)$item->get_product_id();
		$payment_type = get_post_meta($product_id, 'payment_type', true);
		if(!$payment_type || !escortwp_plan_is_post_based($payment_type) || $payment_type == 'featured_boost') {
			continue;
		}

		$target_id = escortwp_get_order_item_target_id($item_id, $item, $parent_order);
		if(!$target_id) {
			continue;
		}

		$prefix = escortwp_get_plan_meta_prefix($payment_type);
		if($prefix) {
			if(in_array($new_status, array('active', 'pending-cancel'), true)) {
				update_post_meta($target_id, $prefix.'_renew', '1');
				if($expires_at) {
					update_post_meta($target_id, $prefix.'_expire', $expires_at);
				}
			} else {
				delete_post_meta($target_id, $prefix.'_renew');
				if($expires_at) {
					update_post_meta($target_id, $prefix.'_expire', $expires_at);
				}
			}
		}

		if($prefix) {
			escortwp_update_post_plan_state($target_id, array(
				'plan_key' => $payment_type,
				'plan_type' => 'subscription',
				'plan_status' => $plan_status,
				'expires_at' => $expires_at,
				'subscription_id' => $subscription_id,
				'subscription_status' => sanitize_key($new_status),
			));
		}
	}
}
add_action('woocommerce_subscription_status_updated', 'escortwp_handle_subscription_status_updated', 10, 3);

function woo_cancel_subscription_form_process() {
	if(!is_user_logged_in()) {
		return false;
	}

	$action = isset($_POST['action']) ? sanitize_key($_POST['action']) : '';
	if(!$action || !in_array($action, array('cancel_subscription', 'escortwp_cancel_plan_subscription'), true)) {
		return false;
	}

	$current_user = wp_get_current_user();
	$userid = (int)$current_user->ID;
	$redirect_url = wp_get_referer() ? wp_get_referer() : home_url('/');

	if($action == 'cancel_subscription') {
		$payment_type = isset($_POST['payment_type']) ? (int)$_POST['payment_type'] : 0;
		if($payment_type === 5) {
			$order_id = (int)get_user_meta($userid, 'vip_txn_id', true);
			if($order_id && function_exists('wc_get_order')) {
				$order = wc_get_order($order_id);
				if($order && method_exists($order, 'update_status')) {
					$order->update_status('cancelled');
				}
			}
			delete_user_meta($userid, 'vip_renew');
			wp_safe_redirect($redirect_url);
			exit;
		}
		return false;
	}

	$post_id = isset($_POST['target_post_id']) ? (int)$_POST['target_post_id'] : 0;
	$plan_key = isset($_POST['plan_key']) ? sanitize_key($_POST['plan_key']) : '';
	if(!$post_id || !$plan_key || !escortwp_plan_is_post_based($plan_key) || in_array($plan_key, array('featured_boost', 'tours'), true)) {
		return false;
	}

	$post = get_post($post_id);
	if(!$post) {
		return false;
	}

	if((int)$post->post_author !== $userid && !current_user_can('level_10')) {
		return false;
	}

	escortwp_cancel_saved_subscription_for_post($post_id, $plan_key);
	wp_safe_redirect($redirect_url);
	exit;
}


// Mark orders with virtual items as completed after payment
add_action( 'woocommerce_payment_complete', 'custom_mark_virtual_orders_completed' );
function custom_mark_virtual_orders_completed( $order_id ) {
    // Get the order object
    $order = wc_get_order( $order_id );

    // Check if the order contains virtual products
    $virtual_order = false;

    if ( count( $order->get_items() ) > 0 ) {
        foreach ( $order->get_items() as $item ) {
            // Check if the product is virtual
            if ( $item->get_product()->is_virtual() ) {
                $virtual_order = true;
                break;
            }
        }
    }

    // If the order contains virtual items, mark it as completed
    if ( $virtual_order ) {
        $order->update_status( 'completed' );
    }
}


