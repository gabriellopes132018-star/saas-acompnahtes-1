<?php
$age_gate_redirect = home_url( '/' );
$age_gate_decline_url = function_exists( 'escortwp_get_age_gate_decline_url' ) ? escortwp_get_age_gate_decline_url() : 'https://www.google.com/';

if ( ! empty( $_SERVER['REQUEST_URI'] ) ) {
	$age_gate_redirect = home_url( wp_unslash( $_SERVER['REQUEST_URI'] ) );
}
?>
<div class="escortwp-age-gate" data-age-gate aria-hidden="false">
	<div class="escortwp-age-gate__overlay"></div>
	<div class="escortwp-age-gate__dialog" role="dialog" aria-modal="true" aria-labelledby="escortwp-age-gate-title" tabindex="-1">
		<?php if ( function_exists( 'escortwp_get_brand_logo_url' ) && escortwp_get_brand_logo_url() ) : ?>
			<div class="escortwp-age-gate__logo">
				<?php echo escortwp_get_brand_logo_markup( 'escortwp-age-gate__logo-image' ); ?>
			</div>
		<?php endif; ?>
		<div class="escortwp-age-gate__eyebrow"><?php _e( 'Acesso restrito', 'escortwp' ); ?></div>
		<h2 id="escortwp-age-gate-title"><?php _e( 'Você tem mais de 18 anos?', 'escortwp' ); ?></h2>
		<p><?php _e( 'Este portal é destinado exclusivamente a maiores de idade. Ao continuar, você confirma que possui 18 anos ou mais e aceita acessar conteúdo adulto de forma responsável.', 'escortwp' ); ?></p>
		<div class="escortwp-age-gate__actions">
			<form method="post" class="escortwp-age-gate__form" data-age-gate-confirm>
				<input type="hidden" name="escortwp_age_gate_action" value="confirm" />
				<input type="hidden" name="escortwp_age_gate_redirect" value="<?php echo esc_url( $age_gate_redirect ); ?>" />
				<?php wp_nonce_field( 'escortwp_age_gate_action', 'escortwp_age_gate_nonce' ); ?>
				<button type="submit" class="escortwp-age-gate__button escortwp-age-gate__button--primary"><?php _e( 'Sim, tenho mais de 18', 'escortwp' ); ?></button>
			</form>
			<a href="<?php echo esc_url( $age_gate_decline_url ); ?>" class="escortwp-age-gate__button escortwp-age-gate__button--ghost" data-age-gate-decline-link><?php _e( 'Não', 'escortwp' ); ?></a>
		</div>
		<div class="escortwp-age-gate__note"><?php _e( 'Sua confirmação será lembrada por 30 dias neste dispositivo.', 'escortwp' ); ?></div>
	</div>
</div>
